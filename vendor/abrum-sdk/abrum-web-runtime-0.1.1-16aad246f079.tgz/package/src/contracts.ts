// Host ↔ embedded-app contracts.
//
// Single source of truth for the signals a desktop host (abrum desktop, …) uses
// to embed an abrum app, so the producer (host) and consumer (@abrum/react + the
// runtime) can't drift. Both the encoders (what a host emits) and decoders
// (what an app reads) live here and are round-tripped in contracts.test.ts.
//
// This module is intentionally dependency-free (a leaf) so it stays trivially
// testable and embeddable by any host.

// ---------------------------------------------------------------------------
// Session handoff: a host hands an app its identity + selected room so the app
// opens straight into the right session. Carried in the URL hash so it never
// hits a server. `<app-url>#abrumSession=<base64url-json>`.
// ---------------------------------------------------------------------------

export const SESSION_HANDOFF_HASH_KEY = "abrumSession";

export interface AbrumSessionHandoff {
  // The app surface's OWN deviceKey seed (32-byte hex) and its did:key. This is a
  // per-app runner identity scoped by a room grant — NOT the user's identity and
  // NEVER the recovery mnemonic (IK-14/IK-15: keys/mnemonics must not travel into
  // an app). The app signs its station calls with this key.
  deviceKeySeedHex: string;
  actorDid: string;
  displayName?: string | null;
  hostedRoomId?: string | null;
  selectedRoomId?: string | null;
  cursorByRoom?: Record<string, number>;
  /** Host-verified routing snapshot. It is a startup hint, never authority;
   * every data request remains signed and Station-authorized. */
  bootstrap?: {
    stationIdentity: import("./index").StationIdentity;
    room: import("./index").RoomDescriptor;
    stationClaimed?: boolean;
  } | null;
}

export function abrumStorageKeyForStation(stationUrl: string): string {
  return `abrum:${stationUrl.replace(/\/+$/, "")}`;
}

export function encodeAbrumSessionHandoff(handoff: AbrumSessionHandoff): string {
  return base64UrlEncode(JSON.stringify(handoff));
}

export function decodeAbrumSessionHandoff(encoded: string): AbrumSessionHandoff {
  const decoded = JSON.parse(base64UrlDecode(encoded)) as Partial<AbrumSessionHandoff>;
  if (typeof decoded.deviceKeySeedHex !== "string" || decoded.deviceKeySeedHex.trim().length === 0) {
    throw new Error("abrum session handoff is missing a device key seed");
  }
  if (typeof decoded.actorDid !== "string" || decoded.actorDid.trim().length === 0) {
    throw new Error("abrum session handoff is missing an actor did");
  }
  return {
    deviceKeySeedHex: decoded.deviceKeySeedHex.trim(),
    actorDid: decoded.actorDid.trim(),
    displayName: decoded.displayName ?? null,
    hostedRoomId: decoded.hostedRoomId ?? null,
    selectedRoomId: decoded.selectedRoomId ?? decoded.hostedRoomId ?? null,
    cursorByRoom: decoded.cursorByRoom ?? {},
    ...(decoded.bootstrap !== undefined ? { bootstrap: decoded.bootstrap ?? null } : {}),
  };
}

// ---------------------------------------------------------------------------
// Embed signal: tells an app it's running inside a host shell and the host owns
// the window chrome (so the app hides its own navbar). Delivered either by an
// injected `window.abrumContainer` (WebView hosts that run scripts in the page)
// or by URL params (cross-origin <iframe> hosts that can't inject).
// ---------------------------------------------------------------------------

/**
 * Optional theme a host propagates to an embedded app. Apps are cross-origin
 * iframes, so they can't inherit the host's CSS variables — the host hands the
 * theme over this channel and `mountAbrumApp` applies it to <html> (see the abrum
 * token layer, `@abrum/react/theme.css`).
 */
export interface AbrumEmbedTheme {
  /** Force a color scheme regardless of the OS setting; omit to follow it. */
  scheme?: "light" | "dark";
  /**
   * Override individual design tokens, keyed WITHOUT the `--abrum-` prefix.
   * e.g. `{ accent: "#0071e3" }` sets `--abrum-accent` on <html>.
   */
  vars?: Record<string, string>;
}

export interface AbrumEmbedSignal {
  kind: "native" | "web" | (string & {});
  /** Hide the in-app navbar; the host provides its own window chrome. */
  hideShellChrome: boolean;
  /** The host can render app-declared navigation in its own top app bar. */
  globalNavigation?: boolean;
  /** The host can render an app-owned hierarchy inside its left app tree. */
  sidebarNavigation?: boolean;
  stationUrl?: string;
  roomId?: string;
  appId?: string;
  /** Host theme (color scheme + token overrides). Omitted when unthemed. */
  theme?: AbrumEmbedTheme;
}

const EMBED_PARAM = "abrumEmbed";
const CHROME_PARAM = "abrumChrome"; // "hide" | "show"
const HOST_PARAM = "abrumHost";
const STATION_PARAM = "abrumStation";
const SPACE_PARAM = "abrumRoom";
const APP_PARAM = "abrumApp";
const THEME_PARAM = "abrumTheme"; // base64url(JSON) of AbrumEmbedTheme
const GLOBAL_NAVIGATION_PARAM = "abrumGlobalNavigation";
const SIDEBAR_NAVIGATION_PARAM = "abrumSidebarNavigation";

/** Encode an embed signal as URL query params (for cross-origin iframe hosts). */
export function encodeEmbedParams(signal: AbrumEmbedSignal): URLSearchParams {
  const params = new URLSearchParams();
  params.set(EMBED_PARAM, "1");
  params.set(CHROME_PARAM, signal.hideShellChrome ? "hide" : "show");
  if (signal.globalNavigation) params.set(GLOBAL_NAVIGATION_PARAM, "1");
  if (signal.sidebarNavigation) params.set(SIDEBAR_NAVIGATION_PARAM, "1");
  if (signal.kind) params.set(HOST_PARAM, signal.kind);
  if (signal.stationUrl) params.set(STATION_PARAM, signal.stationUrl);
  if (signal.roomId) params.set(SPACE_PARAM, signal.roomId);
  if (signal.appId) params.set(APP_PARAM, signal.appId);
  const theme = normalizeAbrumEmbedTheme(signal.theme);
  if (theme) params.set(THEME_PARAM, base64UrlEncode(JSON.stringify(theme)));
  return params;
}

/** Drop an empty/invalid theme to `undefined` so it round-trips as absent. */
export function normalizeAbrumEmbedTheme(theme: AbrumEmbedTheme | undefined): AbrumEmbedTheme | undefined {
  if (!theme || typeof theme !== "object") return undefined;
  const out: AbrumEmbedTheme = {};
  if (theme.scheme === "light" || theme.scheme === "dark") out.scheme = theme.scheme;
  if (theme.vars && typeof theme.vars === "object") {
    const vars: Record<string, string> = {};
    for (const [key, value] of Object.entries(theme.vars)) {
      if (typeof value === "string") vars[key] = value;
    }
    if (Object.keys(vars).length > 0) out.vars = vars;
  }
  return out.scheme || out.vars ? out : undefined;
}

function decodeEmbedTheme(raw: string | null): AbrumEmbedTheme | undefined {
  if (!raw) return undefined;
  try {
    return normalizeAbrumEmbedTheme(JSON.parse(base64UrlDecode(raw)) as AbrumEmbedTheme);
  } catch {
    return undefined;
  }
}

/** Decode an embed signal from a URL search string / params, or null if absent. */
export function decodeEmbedParams(search: string | URLSearchParams): AbrumEmbedSignal | null {
  const params = typeof search === "string" ? new URLSearchParams(search) : search;
  const embed = params.get(EMBED_PARAM);
  const chrome = params.get(CHROME_PARAM);
  const globalNavigation = params.get(GLOBAL_NAVIGATION_PARAM) === "1";
  const sidebarNavigation = params.get(SIDEBAR_NAVIGATION_PARAM) === "1";
  if (embed !== "1" && embed !== "true" && chrome !== "hide" && chrome !== "show" && !globalNavigation && !sidebarNavigation) {
    return null;
  }
  const signal: AbrumEmbedSignal = {
    kind: params.get(HOST_PARAM) ?? "native",
    hideShellChrome: chrome !== "show",
    stationUrl: params.get(STATION_PARAM) ?? undefined,
    roomId: params.get(SPACE_PARAM) ?? undefined,
    appId: params.get(APP_PARAM) ?? undefined,
  };
  if (globalNavigation) signal.globalNavigation = true;
  if (sidebarNavigation) signal.sidebarNavigation = true;
  const theme = decodeEmbedTheme(params.get(THEME_PARAM));
  if (theme) signal.theme = theme;
  return signal;
}

interface EmbedWindowLike {
  abrumContainer?: Partial<AbrumEmbedSignal>;
  location?: { search?: string };
}

/**
 * Read the embed signal: an injected `window.abrumContainer` wins, else the URL.
 * Returns null when running standalone (e.g. a normal browser tab).
 */
export function readEmbedSignal(win?: EmbedWindowLike): AbrumEmbedSignal | null {
  const w = win ?? (typeof window !== "undefined" ? (window as EmbedWindowLike) : undefined);
  if (!w) return null;
  const injected = w.abrumContainer;
  if (injected && typeof injected === "object") {
    const signal: AbrumEmbedSignal = {
      kind: typeof injected.kind === "string" ? injected.kind : "native",
      hideShellChrome: injected.hideShellChrome === true,
      stationUrl: injected.stationUrl,
      roomId: injected.roomId,
      appId: injected.appId,
      theme: normalizeAbrumEmbedTheme(injected.theme),
    };
    if (injected.globalNavigation === true) signal.globalNavigation = true;
    if (injected.sidebarNavigation === true) signal.sidebarNavigation = true;
    return signal;
  }
  try {
    return decodeEmbedParams(w.location?.search ?? "");
  } catch {
    return null;
  }
}

/**
 * Advertise global-navigation support on an already-authenticated app URL.
 * The desktop applies this to its in-shell iframe and to detached app windows
 * whose trusted host shell renders the app's top navigation.
 */
export function withAbrumGlobalNavigation(url: string, enabled = true): string {
  // EIN URL-HELFER DARF DIE OBERFLAECHE NICHT MITREISSEN, DIE ER NUR VERZIERT.
  // Gemessen 2026-08-03: der Desktop zeigte nach dem Neustart ein GRAUES FENSTER.
  // Ursache-Kette: eine App ohne gebautes `dist` wird von der Station uebersprungen
  // (Log: "web app dist missing ... skipping"), ihr Eintrag kommt trotzdem in die
  // Liste, und ContentViewport ruft diese Funktion WAEHREND DES RENDERNS auf
  // (ContentViewport.tsx:428, oberste Zeilen der Komponente). `new URL("")` wirft,
  // React faengt es in der Fehlergrenze von NativeAppSurface — und die ganze Schale
  // ist weg. Aus einer fehlenden App wurde so ein toter Desktop.
  //
  // Die Schwester withAbrumWindowRoute fuehrt genau diesen Guard seit jeher; nur diese
  // beiden hier hatten ihn nicht. Kein neuer Mechanismus, sondern derselbe.
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return url;   // relativ, leer oder unparsbar: unveraendert zurueck, nie werfen
  }
  if (enabled) parsed.searchParams.set(GLOBAL_NAVIGATION_PARAM, "1");
  else parsed.searchParams.delete(GLOBAL_NAVIGATION_PARAM);
  return parsed.toString();
}

/** Advertise that the native Shell can host a bounded app-owned sidebar tree. */
export function withAbrumSidebarNavigation(url: string, enabled = true): string {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return url;
  }
  if (enabled) parsed.searchParams.set(SIDEBAR_NAVIGATION_PARAM, "1");
  else parsed.searchParams.delete(SIDEBAR_NAVIGATION_PARAM);
  return parsed.toString();
}

// ---------------------------------------------------------------------------
// Embedded-surface lifecycle + live theme messages. The URL carries the
// initial theme so the first paint is correct; these messages let a host update
// that theme without reloading the iframe and let the app distinguish "page
// loaded" from "abrum runtime ready". Hosts must still validate event.source.
// ---------------------------------------------------------------------------

export const ABRUM_HOST_THEME_MESSAGE_TYPE = "abrum:host-theme" as const;
export const ABRUM_SURFACE_STATUS_MESSAGE_TYPE = "abrum:surface-status" as const;
export const ABRUM_SURFACE_STATUS_REQUEST_MESSAGE_TYPE = "abrum:surface-status-request" as const;

export interface AbrumHostThemeMessage {
  type: typeof ABRUM_HOST_THEME_MESSAGE_TYPE;
  theme: AbrumEmbedTheme;
}

export interface AbrumSurfaceStatusMessage {
  type: typeof ABRUM_SURFACE_STATUS_MESSAGE_TYPE;
  status: "ready" | "error";
  roomId?: string;
  appId?: string;
  message?: string;
}

export interface AbrumSurfaceStatusRequestMessage {
  type: typeof ABRUM_SURFACE_STATUS_REQUEST_MESSAGE_TYPE;
}

// Operation lifecycle is separate from iframe readiness and conveys no authority.
// The host must authenticate the source frame before using it for dialog chrome.
export type AbrumSurfaceOperationPhase = "idle" | "preparing" | "awaiting-confirmation" | "saving" | "complete" | "failed" | "uncertain";
export const ABRUM_SURFACE_OPERATION_MESSAGE_TYPE = "abrum:surface-operation" as const;

export function isAbrumSurfaceOperationBusy(phase: AbrumSurfaceOperationPhase): boolean {
  return phase === "preparing" || phase === "awaiting-confirmation" || phase === "saving";
}

export function readAbrumSurfaceOperation(data: unknown): { phase: AbrumSurfaceOperationPhase } | null {
  if (!data || typeof data !== "object") return null;
  const value = data as { type?: unknown; phase?: unknown };
  if (value.type !== ABRUM_SURFACE_OPERATION_MESSAGE_TYPE
    || typeof value.phase !== "string"
    || !["idle", "preparing", "awaiting-confirmation", "saving", "complete", "failed", "uncertain"].includes(value.phase)) return null;
  return { phase: value.phase as AbrumSurfaceOperationPhase };
}

export function postAbrumSurfaceOperation(
  phase: AbrumSurfaceOperationPhase,
  win = typeof window !== "undefined" ? window : undefined,
): boolean {
  if (!win || win.parent === win) return false;
  win.parent.postMessage({ type: ABRUM_SURFACE_OPERATION_MESSAGE_TYPE, phase }, "*");
  return true;
}

export function postAbrumHostTheme(
  target: Pick<Window, "postMessage"> | null | undefined,
  theme: AbrumEmbedTheme,
): boolean {
  const normalized = normalizeAbrumEmbedTheme(theme);
  if (!target || !normalized) return false;
  const message: AbrumHostThemeMessage = {
    type: ABRUM_HOST_THEME_MESSAGE_TYPE,
    theme: normalized,
  };
  target.postMessage(message, "*");
  return true;
}

export function postAbrumSurfaceStatusRequest(
  target: Pick<Window, "postMessage"> | null | undefined,
): boolean {
  if (!target) return false;
  const message: AbrumSurfaceStatusRequestMessage = {
    type: ABRUM_SURFACE_STATUS_REQUEST_MESSAGE_TYPE,
  };
  target.postMessage(message, "*");
  return true;
}

export function readAbrumHostTheme(data: unknown): AbrumHostThemeMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumHostThemeMessage>;
  if (candidate.type !== ABRUM_HOST_THEME_MESSAGE_TYPE) return null;
  const theme = normalizeAbrumEmbedTheme(candidate.theme);
  return theme ? { type: ABRUM_HOST_THEME_MESSAGE_TYPE, theme } : null;
}

interface PostAbrumSurfaceStatusContext {
  status: "ready" | "error";
  roomId?: string | null;
  appId?: string | null;
  message?: string | null;
  win?: Pick<Window, "parent" | "postMessage"> & { parent: unknown };
}

export function postAbrumSurfaceStatus(ctx: PostAbrumSurfaceStatusContext): boolean {
  const win = ctx.win ?? (typeof window !== "undefined" ? window : undefined);
  if (!win || win.parent === win) return false;
  const message: AbrumSurfaceStatusMessage = {
    type: ABRUM_SURFACE_STATUS_MESSAGE_TYPE,
    status: ctx.status,
    roomId: ctx.roomId?.trim() || undefined,
    appId: ctx.appId?.trim() || undefined,
    message: ctx.status === "error" ? ctx.message?.trim() || "The app surface failed to start." : undefined,
  };
  (win.parent as Window).postMessage(message, "*");
  return true;
}

export function readAbrumSurfaceStatus(data: unknown): AbrumSurfaceStatusMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumSurfaceStatusMessage>;
  if (candidate.type !== ABRUM_SURFACE_STATUS_MESSAGE_TYPE) return null;
  if (candidate.status !== "ready" && candidate.status !== "error") return null;
  return {
    type: ABRUM_SURFACE_STATUS_MESSAGE_TYPE,
    status: candidate.status,
    roomId: typeof candidate.roomId === "string" && candidate.roomId.trim() ? candidate.roomId.trim() : undefined,
    appId: typeof candidate.appId === "string" && candidate.appId.trim() ? candidate.appId.trim() : undefined,
    message: candidate.status === "error" && typeof candidate.message === "string" && candidate.message.trim()
      ? candidate.message.trim()
      : undefined,
  };
}

// Host-owned rendering lifecycle; it changes transport liveness, not authority.
export const ABRUM_SURFACE_VISIBILITY_MESSAGE_TYPE = "abrum:surface-visibility" as const;

export function readAbrumSurfaceVisibility(data: unknown): { visible: boolean } | null {
  if (!data || typeof data !== "object") return null;
  const value = data as { type?: unknown; visible?: unknown };
  return value.type === ABRUM_SURFACE_VISIBILITY_MESSAGE_TYPE && typeof value.visible === "boolean"
    ? { visible: value.visible }
    : null;
}

export function readAbrumSurfaceStatusRequest(data: unknown): AbrumSurfaceStatusRequestMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumSurfaceStatusRequestMessage>;
  return candidate.type === ABRUM_SURFACE_STATUS_REQUEST_MESSAGE_TYPE
    ? { type: ABRUM_SURFACE_STATUS_REQUEST_MESSAGE_TYPE }
    : null;
}

// ---------------------------------------------------------------------------
// App activity. Embedded apps publish transient work-in-progress state to
// their host (for example while an Agent run is executing). The host binds the
// signal to event.source, so app/Room identity never comes from the payload.
// This is intentionally ephemeral UI state, not a Twin.
// ---------------------------------------------------------------------------

export const ABRUM_APP_ACTIVITY_MESSAGE_TYPE = "abrum:app-activity" as const;

// ---------------------------------------------------------------------------
// App lens sources (host -> embedded app). The host lists every Room whose
// data contributes to the current view. Each Room remains independently
// authorized; this message grants nothing and apps must route reads per Room.
// ---------------------------------------------------------------------------

export const ABRUM_APP_LENS_MESSAGE_TYPE = "abrum:app-lens" as const;
export const ABRUM_APP_LENS_READY_MESSAGE_TYPE = "abrum:app-lens-ready" as const;

export interface AbrumAppLensMessage {
  type: typeof ABRUM_APP_LENS_MESSAGE_TYPE;
  appId: string;
  active: boolean;
  roomIds: string[];
}

export interface AbrumAppLensReadyMessage {
  type: typeof ABRUM_APP_LENS_READY_MESSAGE_TYPE;
}

/** Announce after the app has installed its lens listener. The host replies
 * with the current lens state, removing timing/retry assumptions at startup. */
export function postAbrumAppLensReady(
  win: Pick<Window, "parent"> | null | undefined = typeof window !== "undefined" ? window : undefined,
): boolean {
  if (!win || !win.parent || win.parent === win) return false;
  win.parent.postMessage({ type: ABRUM_APP_LENS_READY_MESSAGE_TYPE }, "*");
  return true;
}

export function readAbrumAppLensReady(data: unknown): AbrumAppLensReadyMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumAppLensReadyMessage>;
  return candidate.type === ABRUM_APP_LENS_READY_MESSAGE_TYPE
    ? { type: ABRUM_APP_LENS_READY_MESSAGE_TYPE }
    : null;
}

export function readAbrumAppLens(data: unknown, expectedAppId?: string | null): AbrumAppLensMessage | null {
  if (!data || typeof data !== "object") return null;
  const message = data as Record<string, unknown>;
  if (message.type !== ABRUM_APP_LENS_MESSAGE_TYPE) return null;
  if (typeof message.appId !== "string" || !message.appId.trim()) return null;
  const appId = message.appId.trim();
  if (expectedAppId && appId !== expectedAppId) return null;
  if (!Array.isArray(message.roomIds)) return null;
  const roomIds = [...new Set(
    message.roomIds
      .filter((roomId): roomId is string => typeof roomId === "string")
      .map((roomId) => roomId.trim())
      .filter(Boolean),
  )];
  return {
    type: ABRUM_APP_LENS_MESSAGE_TYPE,
    appId,
    active: message.active === true,
    roomIds,
  };
}

export interface AbrumAppActivityMessage {
  type: typeof ABRUM_APP_ACTIVITY_MESSAGE_TYPE;
  active: boolean;
  /** Short, human-readable context for accessible host UI. */
  label?: string;
  /** Active Agent threads, when the app can identify work more precisely. */
  threadLineageCids?: string[];
}

interface PostAbrumAppActivityContext {
  active: boolean;
  label?: string | null;
  threadLineageCids?: readonly string[] | null;
  win?: Pick<Window, "parent" | "postMessage"> & { parent: unknown };
}

const MAX_APP_ACTIVITY_LABEL_LENGTH = 120;
const MAX_APP_ACTIVITY_THREADS = 32;
const MAX_APP_ACTIVITY_THREAD_ID_LENGTH = 512;

function normalizeAppActivityThreads(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return [...new Set(
    value
      .filter((threadId): threadId is string => typeof threadId === "string")
      .map((threadId) => threadId.trim().slice(0, MAX_APP_ACTIVITY_THREAD_ID_LENGTH))
      .filter(Boolean),
  )].slice(0, MAX_APP_ACTIVITY_THREADS);
}

export function postAbrumAppActivity(ctx: PostAbrumAppActivityContext): boolean {
  const win = ctx.win ?? (typeof window !== "undefined" ? window : undefined);
  if (!win || win.parent === win) return false;
  const label = typeof ctx.label === "string"
    ? ctx.label.trim().slice(0, MAX_APP_ACTIVITY_LABEL_LENGTH)
    : "";
  const threadLineageCids = normalizeAppActivityThreads(ctx.threadLineageCids);
  const message: AbrumAppActivityMessage = {
    type: ABRUM_APP_ACTIVITY_MESSAGE_TYPE,
    active: ctx.active === true,
    label: label || undefined,
    ...(threadLineageCids.length > 0 ? { threadLineageCids } : {}),
  };
  (win.parent as Window).postMessage(message, "*");
  return true;
}

export function readAbrumAppActivity(data: unknown): AbrumAppActivityMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumAppActivityMessage>;
  if (candidate.type !== ABRUM_APP_ACTIVITY_MESSAGE_TYPE || typeof candidate.active !== "boolean") return null;
  const label = typeof candidate.label === "string"
    ? candidate.label.trim().slice(0, MAX_APP_ACTIVITY_LABEL_LENGTH)
    : "";
  const threadLineageCids = normalizeAppActivityThreads(candidate.threadLineageCids);
  return {
    type: ABRUM_APP_ACTIVITY_MESSAGE_TYPE,
    active: candidate.active,
    label: label || undefined,
    ...(threadLineageCids.length > 0 ? { threadLineageCids } : {}),
  };
}

// ---------------------------------------------------------------------------
// Global app navigation. An embedded app declares a small, serializable set of
// destinations and its active item; a capable host renders those destinations
// in its top app bar. Selection travels back down to the source iframe. The
// host binds the declaration to event.source, so the appId is context only.
// ---------------------------------------------------------------------------

export const ABRUM_GLOBAL_NAVIGATION_MESSAGE_TYPE = "abrum:global-navigation" as const;
export const ABRUM_GLOBAL_NAVIGATION_SELECT_MESSAGE_TYPE = "abrum:global-navigation-select" as const;

export interface AbrumGlobalNavigationItem {
  id: string;
  label: string;
  /** Host-known icon token, normally a Lucide name such as "inbox" or "map". */
  icon?: string;
  disabled?: boolean;
}

export interface AbrumGlobalNavigationMessage {
  type: typeof ABRUM_GLOBAL_NAVIGATION_MESSAGE_TYPE;
  appId?: string;
  activeItemId: string;
  items: AbrumGlobalNavigationItem[];
}

export interface AbrumGlobalNavigationSelectMessage {
  type: typeof ABRUM_GLOBAL_NAVIGATION_SELECT_MESSAGE_TYPE;
  itemId: string;
}

interface PostAbrumGlobalNavigationContext {
  appId?: string | null;
  win?: Pick<Window, "parent" | "postMessage"> & { parent: unknown };
}

const MAX_GLOBAL_NAVIGATION_ITEMS = 12;
const MAX_GLOBAL_NAVIGATION_ID_LENGTH = 64;
const MAX_GLOBAL_NAVIGATION_LABEL_LENGTH = 40;

function normalizeGlobalNavigationItem(value: unknown): AbrumGlobalNavigationItem | null {
  if (!value || typeof value !== "object") return null;
  const candidate = value as Partial<AbrumGlobalNavigationItem>;
  const id = typeof candidate.id === "string" ? candidate.id.trim().slice(0, MAX_GLOBAL_NAVIGATION_ID_LENGTH) : "";
  const label = typeof candidate.label === "string" ? candidate.label.trim().slice(0, MAX_GLOBAL_NAVIGATION_LABEL_LENGTH) : "";
  if (!id || !label) return null;
  const icon = typeof candidate.icon === "string" ? candidate.icon.trim().slice(0, MAX_GLOBAL_NAVIGATION_ID_LENGTH) : "";
  return {
    id,
    label,
    icon: icon || undefined,
    disabled: candidate.disabled === true || undefined,
  };
}

export function normalizeAbrumGlobalNavigation(
  input: Pick<AbrumGlobalNavigationMessage, "items" | "activeItemId">,
  appId?: string | null,
): AbrumGlobalNavigationMessage {
  const items: AbrumGlobalNavigationItem[] = [];
  const seen = new Set<string>();
  for (const value of Array.isArray(input.items) ? input.items : []) {
    const item = normalizeGlobalNavigationItem(value);
    if (!item || seen.has(item.id)) continue;
    seen.add(item.id);
    items.push(item);
    if (items.length >= MAX_GLOBAL_NAVIGATION_ITEMS) break;
  }
  const requestedActive = typeof input.activeItemId === "string" ? input.activeItemId.trim() : "";
  const activeItemId = items.some((item) => item.id === requestedActive)
    ? requestedActive
    : items.find((item) => !item.disabled)?.id ?? items[0]?.id ?? "";
  return {
    type: ABRUM_GLOBAL_NAVIGATION_MESSAGE_TYPE,
    appId: appId?.trim() || undefined,
    activeItemId,
    items,
  };
}

export function postAbrumGlobalNavigation(
  navigation: Pick<AbrumGlobalNavigationMessage, "items" | "activeItemId">,
  ctx: PostAbrumGlobalNavigationContext = {},
): boolean {
  const win = ctx.win ?? (typeof window !== "undefined" ? window : undefined);
  if (!win || win.parent === win) return false;
  (win.parent as Window).postMessage(normalizeAbrumGlobalNavigation(navigation, ctx.appId), "*");
  return true;
}

export function readAbrumGlobalNavigation(data: unknown): AbrumGlobalNavigationMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumGlobalNavigationMessage>;
  if (candidate.type !== ABRUM_GLOBAL_NAVIGATION_MESSAGE_TYPE || !Array.isArray(candidate.items)) return null;
  return normalizeAbrumGlobalNavigation(
    { items: candidate.items, activeItemId: typeof candidate.activeItemId === "string" ? candidate.activeItemId : "" },
    typeof candidate.appId === "string" ? candidate.appId : undefined,
  );
}

export function postAbrumGlobalNavigationSelect(
  target: Pick<Window, "postMessage"> | null | undefined,
  itemId: string,
): boolean {
  const normalized = itemId.trim().slice(0, MAX_GLOBAL_NAVIGATION_ID_LENGTH);
  if (!target || !normalized) return false;
  target.postMessage({ type: ABRUM_GLOBAL_NAVIGATION_SELECT_MESSAGE_TYPE, itemId: normalized }, "*");
  return true;
}

export function readAbrumGlobalNavigationSelect(data: unknown): AbrumGlobalNavigationSelectMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumGlobalNavigationSelectMessage>;
  if (candidate.type !== ABRUM_GLOBAL_NAVIGATION_SELECT_MESSAGE_TYPE || typeof candidate.itemId !== "string") return null;
  const itemId = candidate.itemId.trim().slice(0, MAX_GLOBAL_NAVIGATION_ID_LENGTH);
  return itemId ? { type: ABRUM_GLOBAL_NAVIGATION_SELECT_MESSAGE_TYPE, itemId } : null;
}

// ---------------------------------------------------------------------------
// App sidebar navigation. Unlike the compact top-bar contract above, this is a
// bounded hierarchy owned by the app and rendered below its Room rows in the
// native Shell. The host binds every declaration to event.source.
// ---------------------------------------------------------------------------

export const ABRUM_SIDEBAR_NAVIGATION_MESSAGE_TYPE = "abrum:sidebar-navigation" as const;
export const ABRUM_SIDEBAR_NAVIGATION_SELECT_MESSAGE_TYPE = "abrum:sidebar-navigation-select" as const;

export interface AbrumSidebarNavigationItem {
  id: string;
  label: string;
  kind: "account" | "group" | "folder" | "item";
  roomId?: string;
  parentId?: string;
  icon?: string;
  badge?: string;
  disabled?: boolean;
  actions?: AbrumSidebarNavigationAction[];
}

export interface AbrumSidebarNavigationAction {
  id: string;
  label: string;
  icon?: string;
  destructive?: boolean;
  disabled?: boolean;
}

export interface AbrumSidebarNavigationMessage {
  type: typeof ABRUM_SIDEBAR_NAVIGATION_MESSAGE_TYPE;
  appId?: string;
  activeItemId: string;
  items: AbrumSidebarNavigationItem[];
}

export interface AbrumSidebarNavigationSelectMessage {
  type: typeof ABRUM_SIDEBAR_NAVIGATION_SELECT_MESSAGE_TYPE;
  itemId: string;
  /** An app-declared row action; absent for ordinary navigation. */
  actionId?: string;
}

const MAX_SIDEBAR_NAVIGATION_ITEMS = 500;
const MAX_SIDEBAR_NAVIGATION_ID_LENGTH = 180;
const MAX_SIDEBAR_NAVIGATION_LABEL_LENGTH = 80;

function normalizeSidebarNavigationItem(value: unknown): AbrumSidebarNavigationItem | null {
  if (!value || typeof value !== "object") return null;
  const candidate = value as Partial<AbrumSidebarNavigationItem>;
  const id = typeof candidate.id === "string" ? candidate.id.trim().slice(0, MAX_SIDEBAR_NAVIGATION_ID_LENGTH) : "";
  const label = typeof candidate.label === "string" ? candidate.label.trim().slice(0, MAX_SIDEBAR_NAVIGATION_LABEL_LENGTH) : "";
  const kind = candidate.kind === "account" || candidate.kind === "group" || candidate.kind === "folder" || candidate.kind === "item"
    ? candidate.kind
    : null;
  if (!id || !label || !kind) return null;
  const roomId = typeof candidate.roomId === "string" ? candidate.roomId.trim().slice(0, MAX_SIDEBAR_NAVIGATION_ID_LENGTH) : "";
  const parentId = typeof candidate.parentId === "string" ? candidate.parentId.trim().slice(0, MAX_SIDEBAR_NAVIGATION_ID_LENGTH) : "";
  const icon = typeof candidate.icon === "string" ? candidate.icon.trim().slice(0, 40) : "";
  const badge = typeof candidate.badge === "string" ? candidate.badge.trim().slice(0, 20) : "";
  const actions: AbrumSidebarNavigationAction[] = [];
  const actionIds = new Set<string>();
  for (const action of Array.isArray(candidate.actions) ? candidate.actions.slice(0, 32) : []) {
    if (!action || typeof action !== "object") continue;
    const actionId = typeof action.id === "string" ? action.id.trim().slice(0, 64) : "";
    const actionLabel = typeof action.label === "string" ? action.label.trim().slice(0, MAX_SIDEBAR_NAVIGATION_LABEL_LENGTH) : "";
    if (!actionId || !actionLabel || actionIds.has(actionId)) continue;
    actionIds.add(actionId);
    actions.push({ id: actionId, label: actionLabel,
      ...(typeof action.icon === "string" ? { icon: action.icon.trim().slice(0, 40) } : {}),
      ...(action.destructive === true ? { destructive: true } : {}),
      ...(action.disabled === true ? { disabled: true } : {}),
    });
    if (actions.length >= 8) break;
  }
  return {
    id,
    label,
    kind,
    roomId: roomId || undefined,
    parentId: parentId || undefined,
    icon: icon || undefined,
    badge: badge || undefined,
    disabled: candidate.disabled === true || undefined,
    ...(actions.length ? { actions } : {}),
  };
}

export function normalizeAbrumSidebarNavigation(
  input: Pick<AbrumSidebarNavigationMessage, "items" | "activeItemId">,
  appId?: string | null,
): AbrumSidebarNavigationMessage {
  const items: AbrumSidebarNavigationItem[] = [];
  const seen = new Set<string>();
  for (const value of Array.isArray(input.items) ? input.items : []) {
    const item = normalizeSidebarNavigationItem(value);
    if (!item || seen.has(item.id)) continue;
    seen.add(item.id);
    items.push(item);
    if (items.length >= MAX_SIDEBAR_NAVIGATION_ITEMS) break;
  }
  const ids = new Set(items.map((item) => item.id));
  const normalizedItems = items.map((item) => item.parentId && !ids.has(item.parentId)
    ? { ...item, parentId: undefined }
    : item);
  const requestedActive = typeof input.activeItemId === "string" ? input.activeItemId.trim() : "";
  const activeItemId = ids.has(requestedActive) ? requestedActive : "";
  return {
    type: ABRUM_SIDEBAR_NAVIGATION_MESSAGE_TYPE,
    appId: appId?.trim() || undefined,
    activeItemId,
    items: normalizedItems,
  };
}

export function postAbrumSidebarNavigation(
  navigation: Pick<AbrumSidebarNavigationMessage, "items" | "activeItemId">,
  ctx: PostAbrumGlobalNavigationContext = {},
): boolean {
  const win = ctx.win ?? (typeof window !== "undefined" ? window : undefined);
  if (!win || win.parent === win) return false;
  (win.parent as Window).postMessage(normalizeAbrumSidebarNavigation(navigation, ctx.appId), "*");
  return true;
}

export function readAbrumSidebarNavigation(data: unknown): AbrumSidebarNavigationMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumSidebarNavigationMessage>;
  if (candidate.type !== ABRUM_SIDEBAR_NAVIGATION_MESSAGE_TYPE || !Array.isArray(candidate.items)) return null;
  return normalizeAbrumSidebarNavigation(
    { items: candidate.items, activeItemId: typeof candidate.activeItemId === "string" ? candidate.activeItemId : "" },
    typeof candidate.appId === "string" ? candidate.appId : undefined,
  );
}

export function postAbrumSidebarNavigationSelect(
  target: Pick<Window, "postMessage"> | null | undefined,
  itemId: string,
  actionId?: string,
): boolean {
  const normalized = itemId.trim().slice(0, MAX_SIDEBAR_NAVIGATION_ID_LENGTH);
  if (!target || !normalized) return false;
  const action = actionId?.trim().slice(0, 64);
  if (actionId !== undefined && !action) return false;
  target.postMessage({ type: ABRUM_SIDEBAR_NAVIGATION_SELECT_MESSAGE_TYPE, itemId: normalized,
    ...(action ? { actionId: action } : {}),
  }, "*");
  return true;
}

export function readAbrumSidebarNavigationSelect(data: unknown): AbrumSidebarNavigationSelectMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumSidebarNavigationSelectMessage>;
  if (candidate.type !== ABRUM_SIDEBAR_NAVIGATION_SELECT_MESSAGE_TYPE || typeof candidate.itemId !== "string") return null;
  const itemId = candidate.itemId.trim().slice(0, MAX_SIDEBAR_NAVIGATION_ID_LENGTH);
  const actionId = typeof candidate.actionId === "string" ? candidate.actionId.trim().slice(0, 64) : "";
  if (candidate.actionId !== undefined && !actionId) return null;
  return itemId ? { type: ABRUM_SIDEBAR_NAVIGATION_SELECT_MESSAGE_TYPE, itemId,
    ...(actionId ? { actionId } : {}),
  } : null;
}

// ---------------------------------------------------------------------------
// Room action (host → app). The host renders only actions declared by the
// installed app and delivers the stable id to that exact Room's iframe.
// ---------------------------------------------------------------------------

export const ABRUM_ROOM_ACTION_MESSAGE_TYPE = "abrum:room-action" as const;
export const ABRUM_ROOM_ACTIONS_READY_MESSAGE_TYPE = "abrum:room-actions-ready" as const;
export const ABRUM_ROOM_ACTION_RESULT_MESSAGE_TYPE = "abrum:room-action-result" as const;
const MAX_ROOM_ACTION_ID_LENGTH = 64;

export interface AbrumRoomActionMessage {
  type: typeof ABRUM_ROOM_ACTION_MESSAGE_TYPE;
  actionId: string;
  requestId?: string;
}

export interface AbrumRoomActionResult {
  type: typeof ABRUM_ROOM_ACTION_RESULT_MESSAGE_TYPE;
  actionId: string;
  requestId: string;
  status: "completed" | "unsupported" | "failed";
}

export function readAbrumRoomActionResult(data: unknown): AbrumRoomActionResult | null {
  if (!data || typeof data !== "object") return null;
  const r = data as Partial<AbrumRoomActionResult>;
  if (r.type !== ABRUM_ROOM_ACTION_RESULT_MESSAGE_TYPE
    || typeof r.actionId !== "string" || !r.actionId || r.actionId.length > 64
    || typeof r.requestId !== "string" || !r.requestId || r.requestId.length > 128
    || !["completed", "unsupported", "failed"].includes(r.status || "")) return null;
  return { type: ABRUM_ROOM_ACTION_RESULT_MESSAGE_TYPE, actionId: r.actionId,
    requestId: r.requestId, status: r.status! };
}

export interface AbrumRoomActionsReadyMessage {
  type: typeof ABRUM_ROOM_ACTIONS_READY_MESSAGE_TYPE;
}

/** Announce that the embedded app has installed its Room-action listener. */
export function postAbrumRoomActionsReady(
  win: Pick<Window, "parent"> | null | undefined = typeof window !== "undefined" ? window : undefined,
): boolean {
  if (!win || !win.parent || win.parent === win) return false;
  win.parent.postMessage({ type: ABRUM_ROOM_ACTIONS_READY_MESSAGE_TYPE }, "*");
  return true;
}

export function readAbrumRoomActionsReady(data: unknown): AbrumRoomActionsReadyMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumRoomActionsReadyMessage>;
  return candidate.type === ABRUM_ROOM_ACTIONS_READY_MESSAGE_TYPE
    ? { type: ABRUM_ROOM_ACTIONS_READY_MESSAGE_TYPE }
    : null;
}

export function postAbrumRoomAction(
  target: Pick<Window, "postMessage"> | null | undefined,
  actionId: string,
  requestId?: string,
): boolean {
  const normalized = actionId.trim().slice(0, MAX_ROOM_ACTION_ID_LENGTH);
  if (!target || !normalized) return false;
  if (requestId && requestId.length > 128) return false;
  target.postMessage({ type: ABRUM_ROOM_ACTION_MESSAGE_TYPE, actionId: normalized,
    ...(requestId ? { requestId } : {}) }, "*");
  return true;
}

export function readAbrumRoomAction(data: unknown): AbrumRoomActionMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumRoomActionMessage>;
  if (candidate.type !== ABRUM_ROOM_ACTION_MESSAGE_TYPE || typeof candidate.actionId !== "string") return null;
  const actionId = candidate.actionId.trim().slice(0, MAX_ROOM_ACTION_ID_LENGTH);
  if (candidate.requestId !== undefined && (typeof candidate.requestId !== "string"
    || !candidate.requestId || candidate.requestId.length > 128)) return null;
  return actionId ? { type: ABRUM_ROOM_ACTION_MESSAGE_TYPE, actionId,
    ...(candidate.requestId ? { requestId: candidate.requestId } : {}) } : null;
}

// ---------------------------------------------------------------------------
// Assistant runtime preference (host ↔ app).
//
// Which provider, model and reasoning level the assistant answers with is ONE
// device-wide preference, not a per-surface one: the host's chat sidebar and
// the embedded Agent app must always show and send the same selection. The
// host owns the store; an embedded app asks for the current value on mount
// (`-request`), receives it plus every later change (`abrum:agent-runtime-
// preference`), and writes a user pick back through `-set`.
// ---------------------------------------------------------------------------

export const ABRUM_AGENT_RUNTIME_PREFERENCE_MESSAGE_TYPE = "abrum:agent-runtime-preference" as const;
export const ABRUM_AGENT_RUNTIME_PREFERENCE_REQUEST_MESSAGE_TYPE = "abrum:agent-runtime-preference-request" as const;
export const ABRUM_AGENT_RUNTIME_PREFERENCE_SET_MESSAGE_TYPE = "abrum:agent-runtime-preference-set" as const;
const MAX_AGENT_RUNTIME_FIELD_LENGTH = 200;

export interface AbrumAgentRuntimePreference {
  runtime: string;
  model: string;
  reasoningEffort: string;
  /** Host-owned provider classification; absent for legacy/standalone hosts. */
  providerMode?: "managed" | "external";
}

export interface AbrumAgentRuntimePreferenceMessage extends AbrumAgentRuntimePreference {
  type: typeof ABRUM_AGENT_RUNTIME_PREFERENCE_MESSAGE_TYPE;
}

/** Ask the host for the current device-wide assistant runtime preference. */
export function postAbrumAgentRuntimePreferenceRequest(
  win: Pick<Window, "parent"> | null | undefined = typeof window !== "undefined" ? window : undefined,
): boolean {
  if (!win || !win.parent || win.parent === win) return false;
  (win.parent as Window).postMessage(
    { type: ABRUM_AGENT_RUNTIME_PREFERENCE_REQUEST_MESSAGE_TYPE },
    "*",
  );
  return true;
}

/** Report the user's new pick so every surface follows it. */
export function postAbrumAgentRuntimePreferenceSet(
  preference: AbrumAgentRuntimePreference,
  win: Pick<Window, "parent"> | null | undefined = typeof window !== "undefined" ? window : undefined,
): boolean {
  const normalized = normalizeAgentRuntimePreference(preference);
  if (!win || !win.parent || win.parent === win || !normalized) return false;
  (win.parent as Window).postMessage(
    { type: ABRUM_AGENT_RUNTIME_PREFERENCE_SET_MESSAGE_TYPE, ...normalized },
    "*",
  );
  return true;
}

/** Host → app: deliver the current preference to one embedded app. */
export function postAbrumAgentRuntimePreference(
  target: Pick<Window, "postMessage"> | null | undefined,
  preference: AbrumAgentRuntimePreference,
): boolean {
  const normalized = normalizeAgentRuntimePreference(preference);
  if (!target || !normalized) return false;
  try {
    target.postMessage(
      { type: ABRUM_AGENT_RUNTIME_PREFERENCE_MESSAGE_TYPE, ...normalized },
      "*",
    );
  } catch {
    return false; // frame closed
  }
  return true;
}

export function readAbrumAgentRuntimePreference(data: unknown): AbrumAgentRuntimePreferenceMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as { type?: unknown };
  if (candidate.type !== ABRUM_AGENT_RUNTIME_PREFERENCE_MESSAGE_TYPE) return null;
  const normalized = normalizeAgentRuntimePreference(data as Partial<AbrumAgentRuntimePreference>);
  return normalized ? { type: ABRUM_AGENT_RUNTIME_PREFERENCE_MESSAGE_TYPE, ...normalized } : null;
}

export function readAbrumAgentRuntimePreferenceRequest(data: unknown): boolean {
  return Boolean(
    data &&
      typeof data === "object" &&
      (data as { type?: unknown }).type === ABRUM_AGENT_RUNTIME_PREFERENCE_REQUEST_MESSAGE_TYPE,
  );
}

export function readAbrumAgentRuntimePreferenceSet(data: unknown): AbrumAgentRuntimePreference | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as { type?: unknown };
  if (candidate.type !== ABRUM_AGENT_RUNTIME_PREFERENCE_SET_MESSAGE_TYPE) return null;
  return normalizeAgentRuntimePreference(data as Partial<AbrumAgentRuntimePreference>);
}

function normalizeAgentRuntimePreference(
  value: Partial<AbrumAgentRuntimePreference> | null | undefined,
): AbrumAgentRuntimePreference | null {
  const field = (raw: unknown) =>
    typeof raw === "string" ? raw.trim().slice(0, MAX_AGENT_RUNTIME_FIELD_LENGTH) : "";
  const runtime = field(value?.runtime);
  const model = field(value?.model);
  if (!runtime || !model) return null;
  const providerMode = value?.providerMode === "managed" || value?.providerMode === "external"
    ? value.providerMode
    : undefined;
  return {
    runtime,
    model,
    reasoningEffort: field(value?.reasoningEffort) || "default",
    ...(providerMode ? { providerMode } : {}),
  };
}

// ---------------------------------------------------------------------------
// Agent thread selection (host ↔ app).
//
// The desktop's main Agent navigation and the embedded Agent app are two views
// of one Agent Room. New-chat and history selection travel over one bounded
// contract. The independent right-sidebar chat deliberately does not consume
// this selection channel.
// ---------------------------------------------------------------------------

export const ABRUM_AGENT_THREAD_SELECTION_MESSAGE_TYPE = "abrum:agent-thread-selection" as const;
const MAX_AGENT_THREAD_SELECTION_FIELD_LENGTH = 512;

export interface AbrumAgentThreadSelectionMessage {
  type: typeof ABRUM_AGENT_THREAD_SELECTION_MESSAGE_TYPE;
  roomId: string;
  threadLineageCid: string;
  deletedThreadLineageCid?: string;
}

export function readAbrumAgentThreadSelection(
  data: unknown,
): AbrumAgentThreadSelectionMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumAgentThreadSelectionMessage>;
  if (candidate.type !== ABRUM_AGENT_THREAD_SELECTION_MESSAGE_TYPE) return null;
  const field = (raw: unknown) =>
    typeof raw === "string"
      ? raw.trim().slice(0, MAX_AGENT_THREAD_SELECTION_FIELD_LENGTH)
      : "";
  const roomId = field(candidate.roomId);
  const threadLineageCid = field(candidate.threadLineageCid);
  const deletedThreadLineageCid = field(candidate.deletedThreadLineageCid);
  return roomId && threadLineageCid
    ? {
        type: ABRUM_AGENT_THREAD_SELECTION_MESSAGE_TYPE,
        roomId,
        threadLineageCid,
        ...(deletedThreadLineageCid ? { deletedThreadLineageCid } : {}),
      }
    : null;
}

export function postAbrumAgentThreadSelection(
  target: Pick<Window, "postMessage"> | null | undefined,
  selection: Omit<AbrumAgentThreadSelectionMessage, "type">,
): boolean {
  const normalized = readAbrumAgentThreadSelection({
    type: ABRUM_AGENT_THREAD_SELECTION_MESSAGE_TYPE,
    ...selection,
  });
  if (!target || !normalized) return false;
  try {
    target.postMessage(normalized, "*");
  } catch {
    return false;
  }
  return true;
}

// ---------------------------------------------------------------------------
// Native host composer (host -> embedded Agent app). A mobile WebView host
// replaces the page's own composer with a native input. The host dispatches
// prompts and run control through the same window-event channel as thread
// selection (RN `injectJavaScript` → CustomEvent, iframe hosts → postMessage).
// Both sides must never trust payloads: readers re-validate every field.
// ---------------------------------------------------------------------------

export const ABRUM_HOST_PROMPT_MESSAGE_TYPE = "abrum:host-prompt" as const;
const MAX_HOST_PROMPT_LENGTH = 32_000;

export interface AbrumHostPromptMessage {
  type: typeof ABRUM_HOST_PROMPT_MESSAGE_TYPE;
  text: string;
}

export function readAbrumHostPrompt(data: unknown): AbrumHostPromptMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumHostPromptMessage>;
  if (candidate.type !== ABRUM_HOST_PROMPT_MESSAGE_TYPE) return null;
  if (typeof candidate.text !== "string") return null;
  const text = candidate.text.slice(0, MAX_HOST_PROMPT_LENGTH).trim();
  return text ? { type: ABRUM_HOST_PROMPT_MESSAGE_TYPE, text } : null;
}

export const ABRUM_HOST_RUN_CONTROL_MESSAGE_TYPE = "abrum:host-run-control" as const;

export interface AbrumHostRunControlMessage {
  type: typeof ABRUM_HOST_RUN_CONTROL_MESSAGE_TYPE;
  action: "stop";
}

export function readAbrumHostRunControl(data: unknown): AbrumHostRunControlMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumHostRunControlMessage>;
  if (candidate.type !== ABRUM_HOST_RUN_CONTROL_MESSAGE_TYPE) return null;
  return candidate.action === "stop"
    ? { type: ABRUM_HOST_RUN_CONTROL_MESSAGE_TYPE, action: "stop" }
    : null;
}

// ---------------------------------------------------------------------------
// Agent run status (embedded Agent app -> host). Ephemeral UI state, never a
// Twin: the app tells its host whether a Run is currently streaming so a native
// host composer can toggle send/stop. The app detects the host kind itself:
// in a WebView (`window.parent === window`) it emits through the
// `ReactNativeWebView` bridge, in an iframe it posts to `window.parent`.
// ---------------------------------------------------------------------------

export const ABRUM_RUN_STATUS_MESSAGE_TYPE = "abrum:run-status" as const;
const MAX_RUN_STATUS_LABEL_LENGTH = 120;

export interface AbrumRunStatusMessage {
  type: typeof ABRUM_RUN_STATUS_MESSAGE_TYPE;
  running: boolean;
  label?: string;
  threadLineageCid?: string;
  queuedCount?: number;
}

interface PublishRunStatusInput {
  running: boolean;
  label?: string | null;
  threadLineageCid?: string | null;
  queuedCount?: number | null;
  win?: Pick<Window, "parent"> & { parent: unknown; ReactNativeWebView?: { postMessage?(message: string): void } };
}

export function publishAgentRunStatus(input: PublishRunStatusInput): boolean {
  const win = input.win ?? (typeof window !== "undefined" ? window : undefined);
  if (!win) return false;
  const label = typeof input.label === "string"
    ? input.label.trim().slice(0, MAX_RUN_STATUS_LABEL_LENGTH) || undefined
    : undefined;
  const threadLineageCid = typeof input.threadLineageCid === "string"
    ? input.threadLineageCid.trim().slice(0, 512) || undefined
    : undefined;
  const queuedCount = Number.isFinite(input.queuedCount) && (input.queuedCount ?? 0) > 0
    ? Math.floor(input.queuedCount as number)
    : undefined;
  const message: AbrumRunStatusMessage = {
    type: ABRUM_RUN_STATUS_MESSAGE_TYPE,
    running: input.running === true,
    ...(label ? { label } : {}),
    ...(threadLineageCid ? { threadLineageCid } : {}),
    ...(queuedCount ? { queuedCount } : {}),
  };
  if (win.parent !== win) {
    try {
      (win.parent as Window).postMessage(message, "*");
      return true;
    } catch {
      return false;
    }
  }
  const runtimeHost = win as typeof win & { ReactNativeWebView?: { postMessage?(message: string): void } };
  try {
    runtimeHost.ReactNativeWebView?.postMessage?.(JSON.stringify(message));
    return true;
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Agent stream deltas (host -> embedded Agent app).
//
// The desktop owns one long-lived Station SSE connection. Embedded Agent
// surfaces consume that already-authorized Room stream instead of racing a
// second app-runner EventSource. This message grants nothing: the host binds it
// to the abrum.agent frame for the exact Room before posting it.
// ---------------------------------------------------------------------------

export const ABRUM_AGENT_STREAM_DELTA_MESSAGE_TYPE = "abrum:agent-stream-delta" as const;

export interface AgentStreamDeltaEvent {
  roomId: string;
  runID: string;
  text: string;
  kind?: string;
  toolName?: string | null;
  appSurface?: AbrumAppSurfaceReference | null;
}

export interface AbrumAgentStreamDeltaMessage extends AgentStreamDeltaEvent {
  type: typeof ABRUM_AGENT_STREAM_DELTA_MESSAGE_TYPE;
}

export function readAbrumAgentStreamDelta(
  data: unknown,
): AbrumAgentStreamDeltaMessage | null {
  if (!data || typeof data !== "object") return null;
  const candidate = data as Partial<AbrumAgentStreamDeltaMessage>;
  if (candidate.type !== ABRUM_AGENT_STREAM_DELTA_MESSAGE_TYPE) return null;
  const roomId = typeof candidate.roomId === "string" ? candidate.roomId.trim() : "";
  const runID = typeof candidate.runID === "string" ? candidate.runID.trim() : "";
  if (!roomId || !runID) return null;
  const appSurface = candidate.appSurface &&
    typeof candidate.appSurface === "object" &&
    !Array.isArray(candidate.appSurface)
    ? candidate.appSurface
    : null;
  return {
    type: ABRUM_AGENT_STREAM_DELTA_MESSAGE_TYPE,
    roomId,
    runID,
    text: typeof candidate.text === "string" ? candidate.text : "",
    ...(typeof candidate.kind === "string" ? { kind: candidate.kind } : {}),
    toolName: typeof candidate.toolName === "string" ? candidate.toolName : null,
    appSurface,
  };
}

export function postAbrumAgentStreamDelta(
  target: Pick<Window, "postMessage"> | null | undefined,
  event: AgentStreamDeltaEvent,
): boolean {
  const message = readAbrumAgentStreamDelta({
    type: ABRUM_AGENT_STREAM_DELTA_MESSAGE_TYPE,
    ...event,
  });
  if (!target || !message) return false;
  try {
    target.postMessage(message, "*");
  } catch {
    return false;
  }
  return true;
}

// ---------------------------------------------------------------------------
// Agent folder access (host ↔ app).
//
// These names are used both for iframe postMessage traffic and cancellable
// same-document CustomEvents. Trusted React apps share the desktop renderer
// document, so window.parent alone cannot reach the native folder picker.
// ---------------------------------------------------------------------------

export const ABRUM_AGENT_FOLDER_ACCESS_REQUEST_MESSAGE_TYPE = "abrum:agent-folder-access-request" as const;
export const ABRUM_AGENT_FOLDER_ACCESS_RESPONSE_MESSAGE_TYPE = "abrum:agent-folder-access-response" as const;
export const ABRUM_AGENT_FOLDER_ACCESS_REVOKE_MESSAGE_TYPE = "abrum:agent-folder-access-revoke" as const;
export const ABRUM_AGENT_FOLDER_ACCESS_REVOKE_RESPONSE_MESSAGE_TYPE = "abrum:agent-folder-access-revoke-response" as const;

// The Files app owns the reusable, Station-local source catalog. These host
// messages never carry a host path back into the app; only opaque source
// descriptors cross the iframe boundary.
export const ABRUM_FILES_SOURCES_LIST_REQUEST_MESSAGE_TYPE = "abrum:files-sources-list-request" as const;
export const ABRUM_FILES_SOURCES_LIST_RESPONSE_MESSAGE_TYPE = "abrum:files-sources-list-response" as const;
export const ABRUM_FILES_SOURCES_ADD_REQUEST_MESSAGE_TYPE = "abrum:files-sources-add-request" as const;
export const ABRUM_FILES_SOURCES_ADD_RESPONSE_MESSAGE_TYPE = "abrum:files-sources-add-response" as const;
export const ABRUM_FILES_SOURCE_REVOKE_REQUEST_MESSAGE_TYPE = "abrum:files-source-revoke-request" as const;
export const ABRUM_FILES_SOURCE_REVOKE_RESPONSE_MESSAGE_TYPE = "abrum:files-source-revoke-response" as const;
export const ABRUM_FILES_BROWSE_REQUEST_MESSAGE_TYPE = "abrum:files-browse-request" as const;
export const ABRUM_FILES_BROWSE_RESPONSE_MESSAGE_TYPE = "abrum:files-browse-response" as const;
export const ABRUM_FILES_READ_REQUEST_MESSAGE_TYPE = "abrum:files-read-request" as const;
export const ABRUM_FILES_READ_RESPONSE_MESSAGE_TYPE = "abrum:files-read-response" as const;
export const ABRUM_FILES_RESIDENCY_SET_REQUEST_MESSAGE_TYPE = "abrum:files-residency-set-request" as const;
export const ABRUM_FILES_RESIDENCY_SET_RESPONSE_MESSAGE_TYPE = "abrum:files-residency-set-response" as const;

// Provider status/link requests use the same dual transport. An iframe talks
// to its parent with postMessage; a trusted React app is already in the desktop
// document and therefore uses a cancellable CustomEvent instead.
export const ABRUM_AGENT_PROVIDER_REQUEST_MESSAGE_TYPE = "abrum:agent-provider" as const;
export const ABRUM_AGENT_PROVIDER_RESPONSE_MESSAGE_TYPE = "abrum:agent-provider-response" as const;
export const ABRUM_AGENT_PROVIDER_CREDENTIALS_CHANGED_MESSAGE_TYPE = "abrum:agent-provider-credentials-changed" as const;
export const ABRUM_AGENT_CAPABILITIES_CHANGED_MESSAGE_TYPE = "abrum:agent-capabilities-changed" as const;

// ---------------------------------------------------------------------------
// Station-served app route: `/apps/{roomId}/{appId}/...`.
//
// A station can serve an app as a normal browser page, without a native/embed
// host. In that mode the path itself is the canonical runtime context: the app
// is installed in, and should open on, the room named by `{roomId}`.
// ---------------------------------------------------------------------------

export interface AbrumHostedAppRoute {
  stationUrl?: string;
  roomId: string;
  appId: string;
}

interface HostedRouteWindowLike {
  location?: {
    origin?: string;
    pathname?: string;
  };
}

export function readHostedAppRoute(win?: HostedRouteWindowLike): AbrumHostedAppRoute | null {
  const w = win ?? (typeof window !== "undefined" ? (window as HostedRouteWindowLike) : undefined);
  const pathname = w?.location?.pathname ?? "";
  if (!pathname.startsWith("/apps/")) {
    return null;
  }
  const parts = pathname.split("/").filter(Boolean);
  if (parts.length < 3 || parts[0] !== "apps") {
    return null;
  }
  const roomId = decodePathPart(parts[1]);
  const appId = decodePathPart(parts[2]);
  if (!roomId || !appId) {
    return null;
  }
  return {
    stationUrl: w?.location?.origin,
    roomId,
    appId,
  };
}

function decodePathPart(value: string): string {
  try {
    return decodeURIComponent(value).trim();
  } catch {
    return "";
  }
}

// ---------------------------------------------------------------------------
// Selection signal (app → host) — the reverse of the embed signal. An embedded
// app reports which twin the user currently has selected (a calendar event, a
// mail, …) so the host (desktop shell) can pass that as context to the
// assistant. Posted via window.parent.postMessage; the host validates the
// source frame. `selection: null` clears it.
// ---------------------------------------------------------------------------

export const ABRUM_SELECTION_MESSAGE_TYPE = "abrum:selection" as const;

export interface AbrumTwinSelection {
  /** CID (lineage id) of the selected twin. */
  cid: string;
  /** Content `type` of the twin, e.g. "calendar_event" / "mail_message". */
  twinType?: string;
  /** Human label for the selection (event title, mail subject, …). */
  title?: string;
}

export interface AbrumSelectionMessage {
  type: typeof ABRUM_SELECTION_MESSAGE_TYPE;
  /** Room the selection lives in (the app's current room). */
  roomId?: string;
  /** App reporting the selection. */
  appId?: string;
  /** The selected twin, or null to clear the selection. */
  selection: AbrumTwinSelection | null;
}

interface PostSelectionContext {
  roomId?: string | null;
  appId?: string | null;
  /** Override the window (tests); defaults to the global `window`. */
  win?: Pick<Window, "parent" | "postMessage"> & { parent: unknown };
}

/**
 * Report the currently-selected twin to the embedding host. No-op when not
 * embedded (standalone tab: `window.parent === window`). Safe to call on every
 * selection change; pass `selection: null` to clear.
 */
export function postAbrumSelection(
  selection: AbrumTwinSelection | null,
  ctx: PostSelectionContext = {},
): void {
  const win = ctx.win ?? (typeof window !== "undefined" ? window : undefined);
  if (!win || win.parent === win) return;
  const message: AbrumSelectionMessage = {
    type: ABRUM_SELECTION_MESSAGE_TYPE,
    roomId: ctx.roomId ?? undefined,
    appId: ctx.appId ?? undefined,
    selection:
      selection && typeof selection.cid === "string" && selection.cid
        ? {
            cid: selection.cid,
            twinType: selection.twinType || undefined,
            title: selection.title || undefined,
          }
        : null,
  };
  (win.parent as Window).postMessage(message, "*");
}

// ---------------------------------------------------------------------------
// Room-list signal (app → host): room create/rename/archive calls mutate the
// station room registry, not the twin log. The desktop's realtime watcher is
// twin-based, so embedded apps explicitly nudge their host after these registry
// mutations so navigation updates immediately instead of waiting for a poll.
// ---------------------------------------------------------------------------

export const ABRUM_ROOMS_CHANGED_MESSAGE_TYPE = "abrum:rooms-changed" as const;

export type AbrumRoomsChangedAction = "create" | "rename" | "archive";

export interface AbrumRoomsChangedMessage {
  type: typeof ABRUM_ROOMS_CHANGED_MESSAGE_TYPE;
  action: AbrumRoomsChangedAction;
  roomId?: string;
  appId?: string;
}

interface PostRoomsChangedContext {
  action: AbrumRoomsChangedAction;
  roomId?: string | null;
  appId?: string | null;
  /** Override the window (tests); defaults to the global `window`. */
  win?: Pick<Window, "parent" | "postMessage"> & { parent: unknown };
}

export function postAbrumRoomsChanged(ctx: PostRoomsChangedContext): void {
  const win = ctx.win ?? (typeof window !== "undefined" ? window : undefined);
  if (!win || win.parent === win) return;
  const message: AbrumRoomsChangedMessage = {
    type: ABRUM_ROOMS_CHANGED_MESSAGE_TYPE,
    action: ctx.action,
    roomId: ctx.roomId ?? undefined,
    appId: ctx.appId ?? undefined,
  };
  (win.parent as Window).postMessage(message, "*");
}

export function readAbrumRoomsChanged(data: unknown): AbrumRoomsChangedMessage | null {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_ROOMS_CHANGED_MESSAGE_TYPE) return null;
  if (msg.action !== "create" && msg.action !== "rename" && msg.action !== "archive") return null;
  return {
    type: ABRUM_ROOMS_CHANGED_MESSAGE_TYPE,
    action: msg.action,
    roomId: typeof msg.roomId === "string" ? msg.roomId : undefined,
    appId: typeof msg.appId === "string" ? msg.appId : undefined,
  };
}

// ---------------------------------------------------------------------------
// App-Room creation (embedded app -> host): account-style apps can collect all
// configuration first, then ask the native host to create the app-backed Room
// only when the user commits. The host derives the app id from the source frame;
// an embedded app cannot use this request to install an arbitrary app.
// ---------------------------------------------------------------------------

export const ABRUM_APP_ROOM_CREATE_REQUEST_MESSAGE_TYPE = "abrum:app-room-create-request" as const;
export const ABRUM_APP_ROOM_CREATE_RESPONSE_MESSAGE_TYPE = "abrum:app-room-create-response" as const;
export const ABRUM_APP_ROOM_SETUP_MESSAGE_TYPE = "abrum:app-room-setup" as const;

export interface AbrumAppRoomCreateRequestMessage {
  type: typeof ABRUM_APP_ROOM_CREATE_REQUEST_MESSAGE_TYPE;
  requestId: string;
  name: string;
  setup?: AbrumSurfaceJsonValue;
}

export interface AbrumAppRoomSetupMessage {
  type: typeof ABRUM_APP_ROOM_SETUP_MESSAGE_TYPE;
  requestId: string;
  setup: AbrumSurfaceJsonValue;
  /** The freshly created Room the setup must be written into. Optional for
   * older hosts; apps fall back to their hosted Room when absent. */
  roomId?: string;
}

export interface AbrumAppRoomCreateResponseMessage {
  type: typeof ABRUM_APP_ROOM_CREATE_RESPONSE_MESSAGE_TYPE;
  requestId: string;
  ok: boolean;
  roomId?: string;
  error?: string;
  setupState?: "credential_ready" | "confirmation_pending";
}

interface AppRoomCreateRequestContext {
  timeoutMs?: number;
  win?: Pick<Window, "parent" | "postMessage" | "addEventListener" | "removeEventListener"> & { parent: unknown };
}

// Creating an app Room is a two-stage host operation: the Station creates and
// installs the app first, then a Room-scoped app surface persists `setup`.
// Debug Stations can legitimately spend more than 30 seconds in stage one.
const APP_ROOM_CREATE_TIMEOUT_MS = 120_000;

export function postAbrumAppRoomCreate(
  name: string,
  setup: AbrumSurfaceJsonValue,
  ctx: AppRoomCreateRequestContext = {},
): Promise<string> | null {
  const win = ctx.win ?? (typeof window !== "undefined" ? window : undefined);
  const normalizedName = name.trim().slice(0, 160);
  if (!win || win.parent === win || !normalizedName) return null;
  const requestId = `abrum-room-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
  const message: AbrumAppRoomCreateRequestMessage = {
    type: ABRUM_APP_ROOM_CREATE_REQUEST_MESSAGE_TYPE,
    requestId,
    name: normalizedName,
    setup,
  };
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      cleanup();
      reject(new Error("App Room setup did not finish in time"));
    }, ctx.timeoutMs ?? APP_ROOM_CREATE_TIMEOUT_MS);
    const cleanup = () => {
      clearTimeout(timeout);
      win.removeEventListener("message", onMessage);
    };
    const onMessage = (event: MessageEvent) => {
      if (event.source && event.source !== win.parent) return;
      const response = readAbrumAppRoomCreateResponse(event.data);
      if (!response || response.requestId !== requestId) return;
      cleanup();
      if (response.ok && response.roomId) resolve(response.roomId);
      else reject(new Error(response.error || "host rejected app Room creation"));
    };
    win.addEventListener("message", onMessage);
    (win.parent as Window).postMessage(message, "*");
  });
}

export function readAbrumAppRoomCreateRequest(data: unknown): AbrumAppRoomCreateRequestMessage | null {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_APP_ROOM_CREATE_REQUEST_MESSAGE_TYPE) return null;
  if (typeof msg.requestId !== "string" || !msg.requestId.trim()) return null;
  if (typeof msg.name !== "string" || !msg.name.trim()) return null;
  return {
    type: ABRUM_APP_ROOM_CREATE_REQUEST_MESSAGE_TYPE,
    requestId: msg.requestId.trim(),
    name: msg.name.trim().slice(0, 160),
    setup: isSurfaceJsonValue(msg.setup) ? msg.setup : undefined,
  };
}

export function readAbrumAppRoomSetup(data: unknown): AbrumAppRoomSetupMessage | null {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_APP_ROOM_SETUP_MESSAGE_TYPE) return null;
  if (typeof msg.requestId !== "string" || !msg.requestId.trim()) return null;
  if (!isSurfaceJsonValue(msg.setup)) return null;
  return {
    type: ABRUM_APP_ROOM_SETUP_MESSAGE_TYPE,
    requestId: msg.requestId.trim(),
    setup: msg.setup,
    ...(typeof msg.roomId === "string" && msg.roomId.trim() ? { roomId: msg.roomId.trim() } : {}),
  };
}

export function readAbrumAppRoomCreateResponse(data: unknown): AbrumAppRoomCreateResponseMessage | null {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_APP_ROOM_CREATE_RESPONSE_MESSAGE_TYPE) return null;
  if (typeof msg.requestId !== "string" || !msg.requestId.trim()) return null;
  const ok = msg.ok === true;
  const roomId = typeof msg.roomId === "string" && msg.roomId.trim() ? msg.roomId.trim() : undefined;
  if (ok && !roomId) return null;
  return {
    type: ABRUM_APP_ROOM_CREATE_RESPONSE_MESSAGE_TYPE,
    requestId: msg.requestId.trim(),
    ok,
    roomId,
    error: typeof msg.error === "string" ? msg.error : undefined,
    setupState: msg.setupState === "credential_ready" || msg.setupState === "confirmation_pending"
      ? msg.setupState
      : undefined,
  };
}

// ---------------------------------------------------------------------------
// Open-Warden signal (embedded app -> host): an app whose Room waits on a
// Warden decision (credential setup, pending approval) may ask the host to
// bring the Warden up focused on exactly that Room. The host derives the app
// id from the source frame — an embedded app cannot deep-link a foreign app.
// ---------------------------------------------------------------------------

export const ABRUM_OPEN_WARDEN_REQUEST_MESSAGE_TYPE = "abrum:open-warden-request" as const;
export const ABRUM_OPEN_WARDEN_RESPONSE_MESSAGE_TYPE = "abrum:open-warden-response" as const;

export interface AbrumOpenWardenRequestMessage {
  type: typeof ABRUM_OPEN_WARDEN_REQUEST_MESSAGE_TYPE;
  /** Correlates an optional close acknowledgement back to the requesting app. */
  requestId?: string;
  /** Station-issued approval ID; separate from the transport correlation ID. */
  approvalRequestId?: string;
  /** The Room whose pending Warden decision should be focused. */
  roomId?: string;
  /** Exact host-owned flow to focus; embedded apps cannot supply arbitrary routes. */
  focus?: "station_restart" | "pending_approval";
}

export interface AbrumOpenWardenResponseMessage {
  type: typeof ABRUM_OPEN_WARDEN_RESPONSE_MESSAGE_TYPE;
  requestId: string;
  outcome: "closed" | "unavailable";
}

export function postAbrumOpenWardenRequest(roomId?: string): boolean {
  if (typeof window === "undefined" || window.parent === window) return false;
  const message: AbrumOpenWardenRequestMessage = {
    type: ABRUM_OPEN_WARDEN_REQUEST_MESSAGE_TYPE,
    ...(roomId && roomId.trim() ? { roomId: roomId.trim().slice(0, 240) } : {}),
  };
  window.parent.postMessage(message, "*");
  return true;
}

/**
 * Opens Warden and resolves only after the focused window closes. The response
 * deliberately carries no security verdict: the app must re-read its Room to
 * prove whether a sealed credential now exists. Closing without one is cancel.
 */
export function requestAbrumWarden(
  roomId?: string,
  options: { timeoutMs?: number; win?: Window; focus?: "station_restart" | "pending_approval"; approvalRequestId?: string } = {},
): Promise<AbrumOpenWardenResponseMessage> | null {
  const win = options.win ?? (typeof window !== "undefined" ? window : undefined);
  if (!win || win.parent === win) return null;
  const requestId = `warden-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  const timeoutMs = Math.max(1_000, Math.min(options.timeoutMs ?? 30 * 60_000, 60 * 60_000));
  return new Promise((resolve, reject) => {
    const timeoutId = win.setTimeout(() => {
      cleanup();
      reject(new Error("Warden did not close before the request timed out"));
    }, timeoutMs);
    const onMessage = (event: MessageEvent) => {
      if (event.source !== win.parent) return;
      const response = readAbrumOpenWardenResponse(event.data);
      if (!response || response.requestId !== requestId) return;
      cleanup();
      if (response.outcome === "unavailable") {
        reject(new Error("Warden konnte nicht geöffnet werden. Bitte starte den Vorgang erneut."));
        return;
      }
      resolve(response);
    };
    const cleanup = () => {
      win.clearTimeout(timeoutId);
      win.removeEventListener("message", onMessage);
    };
    win.addEventListener("message", onMessage);
    const message: AbrumOpenWardenRequestMessage = {
      type: ABRUM_OPEN_WARDEN_REQUEST_MESSAGE_TYPE,
      requestId,
      ...(roomId && roomId.trim() ? { roomId: roomId.trim().slice(0, 240) } : {}),
      ...(options.approvalRequestId ? { approvalRequestId: options.approvalRequestId.trim().slice(0, 240) } : {}),
      ...(options.focus === "station_restart" || options.focus === "pending_approval" ? { focus: options.focus } : {}),
    };
    win.parent.postMessage(message, "*");
  });
}

export function readAbrumOpenWardenRequest(data: unknown): AbrumOpenWardenRequestMessage | null {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_OPEN_WARDEN_REQUEST_MESSAGE_TYPE) return null;
  return {
    type: ABRUM_OPEN_WARDEN_REQUEST_MESSAGE_TYPE,
    ...(typeof msg.requestId === "string" && msg.requestId.trim()
      ? { requestId: msg.requestId.trim().slice(0, 120) }
      : {}),
    ...(typeof msg.roomId === "string" && msg.roomId.trim()
      ? { roomId: msg.roomId.trim().slice(0, 240) }
      : {}),
    ...(typeof msg.approvalRequestId === "string" && msg.approvalRequestId.trim()
      ? { approvalRequestId: msg.approvalRequestId.trim().slice(0, 240) } : {}),
    ...(msg.focus === "station_restart" || msg.focus === "pending_approval" ? { focus: msg.focus } : {}),
  };
}

export function readAbrumOpenWardenResponse(data: unknown): AbrumOpenWardenResponseMessage | null {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_OPEN_WARDEN_RESPONSE_MESSAGE_TYPE) return null;
  if (typeof msg.requestId !== "string" || !msg.requestId.trim() || (msg.outcome !== "closed" && msg.outcome !== "unavailable")) return null;
  return {
    type: ABRUM_OPEN_WARDEN_RESPONSE_MESSAGE_TYPE,
    requestId: msg.requestId.trim().slice(0, 120),
    outcome: msg.outcome,
  };
}

// ---------------------------------------------------------------------------
// Card 730 temporary Mail credential bridge (embedded abrum.mail -> desktop).
// The host derives the app identity from the source frame and accepts only an
// actor-owned Mail Room. This contract is deliberately not a generic secret
// API and disappears with the Card 729 phone-confirmation replacement.
// ---------------------------------------------------------------------------

export const ABRUM_MAIL_DEV_CREDENTIAL_STATUS_REQUEST_MESSAGE_TYPE = "abrum:mail-dev-credential-status-request" as const;
export const ABRUM_MAIL_DEV_CREDENTIAL_STATUS_RESPONSE_MESSAGE_TYPE = "abrum:mail-dev-credential-status-response" as const;
export const ABRUM_MAIL_DEV_CREDENTIAL_ARM_REQUEST_MESSAGE_TYPE = "abrum:mail-dev-credential-arm-request" as const;
export const ABRUM_MAIL_DEV_CREDENTIAL_ARM_RESPONSE_MESSAGE_TYPE = "abrum:mail-dev-credential-arm-response" as const;
export const ABRUM_MAIL_DEV_CREDENTIAL_SAVE_REQUEST_MESSAGE_TYPE = "abrum:mail-dev-credential-save-request" as const;
export const ABRUM_MAIL_DEV_CREDENTIAL_SAVE_RESPONSE_MESSAGE_TYPE = "abrum:mail-dev-credential-save-response" as const;

export interface AbrumMailDevCredentialStatusResponse {
  type: typeof ABRUM_MAIL_DEV_CREDENTIAL_STATUS_RESPONSE_MESSAGE_TYPE;
  requestId: string;
  ok: boolean;
  active: boolean;
  roomEligible: boolean;
  manualAvailable: boolean;
  reason: string;
  expiresAtMs: number;
  error?: string;
}

export interface AbrumMailDevCredentialArmResponse extends Omit<AbrumMailDevCredentialStatusResponse, "type"> {
  type: typeof ABRUM_MAIL_DEV_CREDENTIAL_ARM_RESPONSE_MESSAGE_TYPE;
}

export interface AbrumMailDevCredentialSaveResponse {
  type: typeof ABRUM_MAIL_DEV_CREDENTIAL_SAVE_RESPONSE_MESSAGE_TYPE;
  requestId: string;
  ok: boolean;
  status?: "sealed";
  expiresAtMs?: number;
  error?: string;
}

function mailDevCredentialRequestId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function postMailDevCredentialRequest<Response>(
  request: Record<string, unknown> & { requestId: string },
  responseType: string,
  timeoutMs: number,
  win: Window,
): Promise<Response> {
  return new Promise((resolve, reject) => {
    const timeoutId = win.setTimeout(() => {
      cleanup();
      reject(new Error("The temporary Mail credential bridge timed out"));
    }, timeoutMs);
    const onMessage = (event: MessageEvent) => {
      if (event.source !== win.parent || !event.data || typeof event.data !== "object") return;
      const response = event.data as Record<string, unknown>;
      if (response.type !== responseType || response.requestId !== request.requestId) return;
      cleanup();
      resolve(response as Response);
    };
    const cleanup = () => {
      win.clearTimeout(timeoutId);
      win.removeEventListener("message", onMessage);
    };
    win.addEventListener("message", onMessage);
    win.parent.postMessage(request, "*");
  });
}

export function requestAbrumMailDevCredentialStatus(
  roomId: string,
  secretId: string,
  win: Window = window,
): Promise<AbrumMailDevCredentialStatusResponse> | null {
  if (!win || win.parent === win) return null;
  const requestId = mailDevCredentialRequestId("mail-dev-status");
  return postMailDevCredentialRequest<AbrumMailDevCredentialStatusResponse>({
    type: ABRUM_MAIL_DEV_CREDENTIAL_STATUS_REQUEST_MESSAGE_TYPE,
    requestId,
    roomId: roomId.trim().slice(0, 240),
    secretId: secretId.trim().slice(0, 512),
  }, ABRUM_MAIL_DEV_CREDENTIAL_STATUS_RESPONSE_MESSAGE_TYPE, 15_000, win);
}

export function armAbrumMailDevCredentialBypass(
  roomId: string,
  secretId: string,
  win: Window = window,
): Promise<AbrumMailDevCredentialArmResponse> | null {
  if (!win || win.parent === win) return null;
  const requestId = mailDevCredentialRequestId("mail-dev-arm");
  return postMailDevCredentialRequest<AbrumMailDevCredentialArmResponse>({
    type: ABRUM_MAIL_DEV_CREDENTIAL_ARM_REQUEST_MESSAGE_TYPE,
    requestId,
    roomId: roomId.trim().slice(0, 240),
    secretId: secretId.trim().slice(0, 512),
  }, ABRUM_MAIL_DEV_CREDENTIAL_ARM_RESPONSE_MESSAGE_TYPE, 15_000, win);
}

export function saveAbrumMailDevCredential(
  input: { roomId: string; secretId: string; username: string; password: string },
  win: Window = window,
): Promise<AbrumMailDevCredentialSaveResponse> | null {
  if (!win || win.parent === win) return null;
  const requestId = mailDevCredentialRequestId("mail-dev-save");
  return postMailDevCredentialRequest<AbrumMailDevCredentialSaveResponse>({
    type: ABRUM_MAIL_DEV_CREDENTIAL_SAVE_REQUEST_MESSAGE_TYPE,
    requestId,
    roomId: input.roomId.trim().slice(0, 240),
    secretId: input.secretId.trim().slice(0, 512),
    username: input.username.trim().slice(0, 320),
    password: input.password.slice(0, 4096),
  }, ABRUM_MAIL_DEV_CREDENTIAL_SAVE_RESPONSE_MESSAGE_TYPE, 60_000, win);
}

export function readAbrumMailDevCredentialStatusRequest(data: unknown) {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_MAIL_DEV_CREDENTIAL_STATUS_REQUEST_MESSAGE_TYPE) return null;
  if (typeof msg.requestId !== "string" || typeof msg.roomId !== "string" || typeof msg.secretId !== "string") return null;
  return {
    type: ABRUM_MAIL_DEV_CREDENTIAL_STATUS_REQUEST_MESSAGE_TYPE,
    requestId: msg.requestId.trim().slice(0, 120),
    roomId: msg.roomId.trim().slice(0, 240),
    secretId: msg.secretId.trim().slice(0, 512),
  };
}

export function readAbrumMailDevCredentialArmRequest(data: unknown) {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_MAIL_DEV_CREDENTIAL_ARM_REQUEST_MESSAGE_TYPE) return null;
  if (typeof msg.requestId !== "string" || typeof msg.roomId !== "string" || typeof msg.secretId !== "string") return null;
  return {
    type: ABRUM_MAIL_DEV_CREDENTIAL_ARM_REQUEST_MESSAGE_TYPE,
    requestId: msg.requestId.trim().slice(0, 120),
    roomId: msg.roomId.trim().slice(0, 240),
    secretId: msg.secretId.trim().slice(0, 512),
  };
}

export function readAbrumMailDevCredentialSaveRequest(data: unknown) {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_MAIL_DEV_CREDENTIAL_SAVE_REQUEST_MESSAGE_TYPE) return null;
  if (typeof msg.requestId !== "string" || typeof msg.roomId !== "string" || typeof msg.secretId !== "string" || typeof msg.username !== "string" || typeof msg.password !== "string") return null;
  return {
    type: ABRUM_MAIL_DEV_CREDENTIAL_SAVE_REQUEST_MESSAGE_TYPE,
    requestId: msg.requestId.trim().slice(0, 120),
    roomId: msg.roomId.trim().slice(0, 240),
    secretId: msg.secretId.trim().slice(0, 512),
    username: msg.username.trim().slice(0, 320),
    password: msg.password.slice(0, 4096),
  };
}

// ---------------------------------------------------------------------------
// App-Room mutation (embedded app -> host): renaming or archiving a Room
// requires Admin, which an app-surface runner key never holds (IK-14). The app
// asks the host to perform the mutation as the native user; the host only
// honors it for Rooms that belong to the requesting app's own lens.
// ---------------------------------------------------------------------------

export const ABRUM_APP_ROOM_MUTATE_REQUEST_MESSAGE_TYPE = "abrum:app-room-mutate-request" as const;
export const ABRUM_APP_ROOM_MUTATE_RESPONSE_MESSAGE_TYPE = "abrum:app-room-mutate-response" as const;

export type AbrumAppRoomMutateAction = "archive" | "rename";

export interface AbrumAppRoomMutateRequestMessage {
  type: typeof ABRUM_APP_ROOM_MUTATE_REQUEST_MESSAGE_TYPE;
  requestId: string;
  roomId: string;
  action: AbrumAppRoomMutateAction;
  /** New Room name — required for "rename", ignored for "archive". */
  name?: string;
}

export interface AbrumAppRoomMutateResponseMessage {
  type: typeof ABRUM_APP_ROOM_MUTATE_RESPONSE_MESSAGE_TYPE;
  requestId: string;
  ok: boolean;
  error?: string;
}

export function postAbrumAppRoomMutate(
  action: AbrumAppRoomMutateAction,
  roomId: string,
  options: { name?: string; timeoutMs?: number; win?: AppRoomCreateRequestContext["win"] } = {},
): Promise<void> | null {
  const win = options.win ?? (typeof window !== "undefined" ? window : undefined);
  const cleanRoomId = roomId.trim();
  const cleanName = options.name?.trim().slice(0, 160) ?? "";
  if (!win || win.parent === win || !cleanRoomId) return null;
  if (action === "rename" && !cleanName) return null;
  const requestId = `abrum-room-mutate-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
  const message: AbrumAppRoomMutateRequestMessage = {
    type: ABRUM_APP_ROOM_MUTATE_REQUEST_MESSAGE_TYPE,
    requestId,
    roomId: cleanRoomId,
    action,
    ...(action === "rename" ? { name: cleanName } : {}),
  };
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      cleanup();
      reject(new Error(`host did not ${action} the app Room`));
    }, options.timeoutMs ?? 30_000);
    const cleanup = () => {
      clearTimeout(timeout);
      win.removeEventListener("message", onMessage);
    };
    const onMessage = (event: MessageEvent) => {
      if (event.source && event.source !== win.parent) return;
      const response = readAbrumAppRoomMutateResponse(event.data);
      if (!response || response.requestId !== requestId) return;
      cleanup();
      if (response.ok) resolve();
      else reject(new Error(response.error || `host rejected the app Room ${action}`));
    };
    win.addEventListener("message", onMessage);
    (win.parent as Window).postMessage(message, "*");
  });
}

export function readAbrumAppRoomMutateRequest(data: unknown): AbrumAppRoomMutateRequestMessage | null {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_APP_ROOM_MUTATE_REQUEST_MESSAGE_TYPE) return null;
  if (typeof msg.requestId !== "string" || !msg.requestId.trim()) return null;
  if (typeof msg.roomId !== "string" || !msg.roomId.trim()) return null;
  if (msg.action !== "archive" && msg.action !== "rename") return null;
  const name = typeof msg.name === "string" && msg.name.trim() ? msg.name.trim().slice(0, 160) : undefined;
  if (msg.action === "rename" && !name) return null;
  return {
    type: ABRUM_APP_ROOM_MUTATE_REQUEST_MESSAGE_TYPE,
    requestId: msg.requestId.trim(),
    roomId: msg.roomId.trim(),
    action: msg.action,
    ...(name ? { name } : {}),
  };
}

export function readAbrumAppRoomMutateResponse(data: unknown): AbrumAppRoomMutateResponseMessage | null {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_APP_ROOM_MUTATE_RESPONSE_MESSAGE_TYPE) return null;
  if (typeof msg.requestId !== "string" || !msg.requestId.trim()) return null;
  return {
    type: ABRUM_APP_ROOM_MUTATE_RESPONSE_MESSAGE_TYPE,
    requestId: msg.requestId.trim(),
    ok: msg.ok === true,
    error: typeof msg.error === "string" ? msg.error : undefined,
  };
}

// ---------------------------------------------------------------------------
// Content-sharing signal (embedded app -> host): app-surface runner keys can
// write app data, but they must not grant room/capability access. In native
// shells the app asks the host to perform the share as the native user.
// ---------------------------------------------------------------------------

export const ABRUM_SHARE_CONTENT_REQUEST_MESSAGE_TYPE = "abrum:share-content-request" as const;
export const ABRUM_SHARE_CONTENT_RESPONSE_MESSAGE_TYPE = "abrum:share-content-response" as const;

/**
 * A selective share carries read access and nothing else. Its signed ShareGrant
 * stays in the source Room; the membrane transports one exact lineage into an
 * ordinary recipient projection Room. The payload used to carry an
 * `accessLevel` the sender could set; the runtime ignored it and wrote "read"
 * regardless, so the field was a promise the flow could not keep. If write-level
 * content shares ever exist, they arrive as a new field with an implementation
 * behind it.
 */
export interface AbrumShareContentRequestPayload {
  action?: "share" | "revoke" | "context";
  roomId: string;
  lineageCid: string;
  sharedWithDid?: string | null;
  recipientStationId?: string | null;
  targetCid?: string | null;
  targetType?: string | null;
  title?: string | null;
}

export interface AbrumShareContentRequestMessage extends AbrumShareContentRequestPayload {
  type: typeof ABRUM_SHARE_CONTENT_REQUEST_MESSAGE_TYPE;
  requestId: string;
  appId?: string;
}

export interface AbrumShareContentResponseMessage {
  type: typeof ABRUM_SHARE_CONTENT_RESPONSE_MESSAGE_TYPE;
  requestId: string;
  ok: boolean;
  result?: unknown;
  error?: string;
}

interface ShareContentRequestContext {
  appId?: string | null;
  timeoutMs?: number;
  win?: (Pick<Window, "parent" | "postMessage" | "addEventListener" | "removeEventListener"> & { parent: unknown });
}

export function postAbrumShareContentRequest(
  payload: AbrumShareContentRequestPayload,
  ctx: ShareContentRequestContext = {},
): Promise<unknown> | null {
  const win = ctx.win ?? (typeof window !== "undefined" ? window : undefined);
  if (!win || win.parent === win) return null;
  const requestId = `abrum-share-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
  const message: AbrumShareContentRequestMessage = {
    type: ABRUM_SHARE_CONTENT_REQUEST_MESSAGE_TYPE,
    requestId,
    action: payload.action ?? "share",
    roomId: payload.roomId,
    lineageCid: payload.lineageCid,
    sharedWithDid: payload.sharedWithDid ?? undefined,
    recipientStationId: payload.recipientStationId ?? undefined,
    targetCid: payload.targetCid ?? undefined,
    targetType: payload.targetType ?? undefined,
    title: payload.title ?? undefined,
    appId: ctx.appId ?? undefined,
  };
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      cleanup();
      reject(new Error("host did not answer content share request"));
    }, ctx.timeoutMs ?? 10_000);
    const cleanup = () => {
      clearTimeout(timeout);
      win.removeEventListener("message", onMessage);
    };
    const onMessage = (event: MessageEvent) => {
      const response = readAbrumShareContentResponse(event.data);
      if (!response || response.requestId !== requestId) return;
      cleanup();
      if (response.ok) {
        resolve(response.result);
      } else {
        reject(new Error(response.error || "host rejected content share request"));
      }
    };
    win.addEventListener("message", onMessage);
    (win.parent as Window).postMessage(message, "*");
  });
}

export function readAbrumShareContentRequest(data: unknown): AbrumShareContentRequestMessage | null {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_SHARE_CONTENT_REQUEST_MESSAGE_TYPE) return null;
  if (typeof msg.requestId !== "string" || !msg.requestId.trim()) return null;
  if (typeof msg.roomId !== "string" || !msg.roomId.trim()) return null;
  if (typeof msg.lineageCid !== "string" || !msg.lineageCid.trim()) return null;
  const action = msg.action === "context" ? "context" : msg.action === "revoke" ? "revoke" : "share";
  const sharedWithDid = typeof msg.sharedWithDid === "string" ? msg.sharedWithDid.trim() : "";
  if (action !== "context" && !sharedWithDid) return null;
  return {
    type: ABRUM_SHARE_CONTENT_REQUEST_MESSAGE_TYPE,
    requestId: msg.requestId,
    action,
    roomId: msg.roomId.trim(),
    lineageCid: msg.lineageCid.trim(),
    sharedWithDid: sharedWithDid || undefined,
    recipientStationId: typeof msg.recipientStationId === "string"
      ? msg.recipientStationId.trim() || undefined
      : undefined,
    targetCid: typeof msg.targetCid === "string" ? msg.targetCid.trim() : undefined,
    targetType: typeof msg.targetType === "string" ? msg.targetType.trim() : undefined,
    title: typeof msg.title === "string" ? msg.title.trim() : undefined,
    appId: typeof msg.appId === "string" ? msg.appId.trim() : undefined,
  };
}

export function readAbrumShareContentResponse(data: unknown): AbrumShareContentResponseMessage | null {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_SHARE_CONTENT_RESPONSE_MESSAGE_TYPE) return null;
  if (typeof msg.requestId !== "string" || !msg.requestId.trim()) return null;
  return {
    type: ABRUM_SHARE_CONTENT_RESPONSE_MESSAGE_TYPE,
    requestId: msg.requestId,
    ok: msg.ok === true,
    result: msg.result,
    error: typeof msg.error === "string" ? msg.error : undefined,
  };
}

// ---------------------------------------------------------------------------
// Reverse of the selection channel: the HOST tells an embedded app to SELECT a
// twin by cid (the chat agent's navigateUi → desktop → iframe path). An app that
// wants to honour agent navigation listens for this and highlights/opens the
// matching object; apps that don't simply ignore it (best-effort).
// ---------------------------------------------------------------------------

export const ABRUM_SELECT_TWIN_MESSAGE_TYPE = "abrum:select-twin" as const;
export const ABRUM_SELECT_TWIN_RESULT_MESSAGE_TYPE = "abrum:select-twin-result" as const;
export const ABRUM_SELECT_TWIN_CANCEL_MESSAGE_TYPE = "abrum:select-twin-cancel" as const;

export interface AbrumSelectTwinResult {
  type: typeof ABRUM_SELECT_TWIN_RESULT_MESSAGE_TYPE;
  requestId: string;
  cid: string;
  roomId: string;
  status: "completed" | "failed" | "cancelled" | "unconfirmed";
  selectedCid?: string;
  title?: string;
}

export function readAbrumSelectTwinResult(data: unknown): AbrumSelectTwinResult | null {
  if (!data || typeof data !== "object") return null;
  const r = data as Partial<AbrumSelectTwinResult>;
  if (r.type !== ABRUM_SELECT_TWIN_RESULT_MESSAGE_TYPE
    || ![r.requestId, r.cid, r.roomId].every((v) => typeof v === "string" && v.length > 0 && v.length <= 256)
    || !["completed", "failed", "cancelled", "unconfirmed"].includes(r.status ?? "")
    || (r.status === "completed" && (typeof r.selectedCid !== "string" || !r.selectedCid))) return null;
  return { type: ABRUM_SELECT_TWIN_RESULT_MESSAGE_TYPE, requestId: r.requestId!, cid: r.cid!, roomId: r.roomId!,
    status: r.status!, selectedCid: r.selectedCid, title: typeof r.title === "string" ? r.title.slice(0, 500) : undefined };
}

export interface AbrumSelectTwinMessage {
  type: typeof ABRUM_SELECT_TWIN_MESSAGE_TYPE;
  /** CID (lineage id) of the twin the host wants the app to select/open. */
  cid: string;
  /** Room the twin lives in (the app's current room). */
  roomId?: string;
  /** Opaque id of the originating navigation intent (de-dupes re-posts). */
  requestId?: string;
}

/**
 * Parse a window `message` event into an {@link AbrumSelectTwinMessage}, or null
 * when it isn't one. Validates the shape so an app can wire a single listener
 * without re-checking fields. Pair with a host-origin check in security-strict
 * apps; the desktop host posts these from the trusted parent frame.
 */
export function readAbrumSelectTwin(data: unknown): AbrumSelectTwinMessage | null {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_SELECT_TWIN_MESSAGE_TYPE) return null;
  if (typeof msg.cid !== "string" || !msg.cid) return null;
  return {
    type: ABRUM_SELECT_TWIN_MESSAGE_TYPE,
    cid: msg.cid,
    roomId: typeof msg.roomId === "string" ? msg.roomId : undefined,
    requestId: typeof msg.requestId === "string" ? msg.requestId : undefined,
  };
}

// ---------------------------------------------------------------------------
// Window channel (app → host): an embedded app asks its host to open one of its
// OWN routes in a separate window. The reusable `openAbrumWindow` helper in
// @abrum/react posts this when embedded in a native host (the abrum desktop), and
// otherwise renders an in-app modal — same call, right behavior in both worlds.
// The route is carried into the spawned window / modal iframe as the `abrumWindow`
// query param (WINDOW_ROUTE_PARAM), which the app reads to render that surface.
// ---------------------------------------------------------------------------

export const ABRUM_OPEN_WINDOW_MESSAGE_TYPE = "abrum:open-window" as const;

export interface AbrumOpenWindowRequest {
  /** App-defined route to render in the new window (e.g. "demo" / "/report"). */
  route: string;
  /** Preferred content size; the host clamps to the display. */
  width?: number;
  height?: number;
  /** Window title (native) / modal heading (standalone). */
  title?: string;
}

export interface AbrumOpenWindowMessage extends AbrumOpenWindowRequest {
  type: typeof ABRUM_OPEN_WINDOW_MESSAGE_TYPE;
  /** Room the requesting app is running in. */
  roomId?: string;
  /** App requesting the window. */
  appId?: string;
}

interface PostOpenWindowContext {
  roomId?: string | null;
  appId?: string | null;
  /** Override the window (tests); defaults to the global `window`. */
  win?: Pick<Window, "parent" | "postMessage"> & { parent: unknown };
}

function positiveInt(value: unknown): number | undefined {
  return typeof value === "number" && Number.isFinite(value) && value > 0 ? Math.round(value) : undefined;
}

/**
 * Ask the embedding host to open `request.route` in a new window. Returns true
 * when the request was posted to a host, false when running standalone (the
 * caller then falls back to an in-app modal). Mirrors {@link postAbrumSelection}.
 */
export function postAbrumOpenWindow(
  request: AbrumOpenWindowRequest,
  ctx: PostOpenWindowContext = {},
): boolean {
  const win = ctx.win ?? (typeof window !== "undefined" ? window : undefined);
  if (!win || win.parent === win) return false;
  const message: AbrumOpenWindowMessage = {
    type: ABRUM_OPEN_WINDOW_MESSAGE_TYPE,
    route: typeof request.route === "string" ? request.route : "",
    width: positiveInt(request.width),
    height: positiveInt(request.height),
    title: request.title || undefined,
    roomId: ctx.roomId ?? undefined,
    appId: ctx.appId ?? undefined,
  };
  (win.parent as Window).postMessage(message, "*");
  return true;
}

/**
 * Parse a window `message` event payload into an {@link AbrumOpenWindowMessage},
 * or null when it isn't one. The host (desktop shell) uses this to validate the
 * request before opening a window; pair it with a source-frame check.
 */
export function readAbrumOpenWindow(data: unknown): AbrumOpenWindowMessage | null {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_OPEN_WINDOW_MESSAGE_TYPE) return null;
  if (typeof msg.route !== "string") return null;
  return {
    type: ABRUM_OPEN_WINDOW_MESSAGE_TYPE,
    route: msg.route,
    width: positiveInt(msg.width),
    height: positiveInt(msg.height),
    title: typeof msg.title === "string" ? msg.title : undefined,
    roomId: typeof msg.roomId === "string" ? msg.roomId : undefined,
    appId: typeof msg.appId === "string" ? msg.appId : undefined,
  };
}

/**
 * Query param carrying the window route into the spawned window / modal iframe.
 * The app reads it (see {@link readAbrumWindowRoute}) to render that surface.
 */
export const WINDOW_ROUTE_PARAM = "abrumWindow";

/** The route the app was opened at, or null for the app's main surface. */
export function readAbrumWindowRoute(win?: { location?: { search?: string } }): string | null {
  const w = win ?? (typeof window !== "undefined" ? window : undefined);
  if (!w?.location) return null;
  try {
    const route = new URLSearchParams(w.location.search ?? "").get(WINDOW_ROUTE_PARAM);
    return route && route.length > 0 ? route : null;
  } catch {
    return null;
  }
}

/**
 * Compose a URL that loads `route` as a window surface — the host-side counterpart
 * of {@link readAbrumWindowRoute}. Sets the `abrumWindow` query param while preserving
 * the existing query + hash (so the embed params and session handoff survive).
 */
export function withAbrumWindowRoute(url: string, route: string): string {
  try {
    const parsed = new URL(url);
    parsed.searchParams.set(WINDOW_ROUTE_PARAM, route);
    return parsed.toString();
  } catch {
    // Relative URL / no base: splice the param in before any '#'.
    const hashIndex = url.indexOf("#");
    const head = hashIndex === -1 ? url : url.slice(0, hashIndex);
    const tail = hashIndex === -1 ? "" : url.slice(hashIndex);
    const separator = head.includes("?") ? "&" : "?";
    return `${head}${separator}${WINDOW_ROUTE_PARAM}=${encodeURIComponent(route)}${tail}`;
  }
}

// ---------------------------------------------------------------------------
// App-surface channel: an app publishes named, typed UI surfaces once and a
// host chooses where to place them (inline chat, modal, or native window). The
// model/app emits only this structured reference; hosts resolve the installed
// manifest and mint the actual authenticated iframe URL themselves.
// ---------------------------------------------------------------------------

export type AbrumAppSurfacePlacement = "app" | "inline" | "modal" | "window";

export type AbrumSurfaceJsonValue =
  | null
  | boolean
  | number
  | string
  | AbrumSurfaceJsonValue[]
  | { [key: string]: AbrumSurfaceJsonValue };

export interface AbrumAppSurfaceReference {
  roomId: string;
  appId: string;
  surfaceId: string;
  input?: AbrumSurfaceJsonValue;
  placement?: AbrumAppSurfacePlacement;
}

export interface AbrumOpenSurfaceRequest {
  /** Target provider app. Omit when opening the current app's own surface. */
  appId?: string;
  surfaceId: string;
  input?: AbrumSurfaceJsonValue;
  placement?: "modal" | "window";
  title?: string;
  width?: number;
  height?: number;
  requestId?: string;
}

export interface AbrumOpenSurfaceMessage extends AbrumOpenSurfaceRequest {
  type: typeof ABRUM_OPEN_SURFACE_MESSAGE_TYPE;
  roomId?: string;
  appId?: string;
}

export const ABRUM_OPEN_SURFACE_MESSAGE_TYPE = "abrum:open-surface" as const;
export const ABRUM_SURFACE_RESULT_MESSAGE_TYPE = "abrum:surface-result" as const;
export const ABRUM_CLOSE_SURFACE_MESSAGE_TYPE = "abrum:close-surface" as const;
export const APP_SURFACE_PARAM = "abrumSurface";
export const MAX_APP_SURFACE_CONTEXT_BYTES = 32 * 1024;

interface PostOpenSurfaceContext {
  roomId?: string | null;
  appId?: string | null;
  win?: Pick<Window, "parent" | "postMessage"> & { parent: unknown };
}

export function postAbrumOpenSurface(
  request: AbrumOpenSurfaceRequest,
  ctx: PostOpenSurfaceContext = {},
): boolean {
  const win = ctx.win ?? (typeof window !== "undefined" ? window : undefined);
  if (!win || win.parent === win || !request.surfaceId.trim()) return false;
  const message: AbrumOpenSurfaceMessage = {
    type: ABRUM_OPEN_SURFACE_MESSAGE_TYPE,
    surfaceId: request.surfaceId.trim(),
    input: request.input,
    placement: request.placement,
    title: request.title || undefined,
    width: positiveInt(request.width),
    height: positiveInt(request.height),
    roomId: ctx.roomId ?? undefined,
    appId: request.appId?.trim() || ctx.appId || undefined,
    requestId: request.requestId?.trim() || undefined,
  };
  (win.parent as Window).postMessage(message, "*");
  return true;
}

export function readAbrumOpenSurface(data: unknown): AbrumOpenSurfaceMessage | null {
  if (!data || typeof data !== "object") return null;
  const msg = data as Record<string, unknown>;
  if (msg.type !== ABRUM_OPEN_SURFACE_MESSAGE_TYPE) return null;
  if (typeof msg.surfaceId !== "string" || !msg.surfaceId.trim()) return null;
  const placement = msg.placement === "modal" || msg.placement === "window" ? msg.placement : undefined;
  return {
    type: ABRUM_OPEN_SURFACE_MESSAGE_TYPE,
    surfaceId: msg.surfaceId.trim(),
    input: isSurfaceJsonValue(msg.input) ? msg.input : undefined,
    placement,
    title: typeof msg.title === "string" ? msg.title : undefined,
    width: positiveInt(msg.width),
    height: positiveInt(msg.height),
    roomId: typeof msg.roomId === "string" ? msg.roomId : undefined,
    appId: typeof msg.appId === "string" ? msg.appId : undefined,
    requestId: typeof msg.requestId === "string" && msg.requestId.trim() ? msg.requestId.trim() : undefined,
  };
}

export interface AbrumSurfaceResultMessage {
  type: typeof ABRUM_SURFACE_RESULT_MESSAGE_TYPE;
  requestId: string;
  result?: AbrumSurfaceJsonValue;
  error?: string;
}

export interface AbrumCloseSurfaceMessage {
  type: typeof ABRUM_CLOSE_SURFACE_MESSAGE_TYPE;
  result?: AbrumSurfaceJsonValue;
}

export function postAbrumCloseSurface(
  result?: AbrumSurfaceJsonValue,
  win = typeof window !== "undefined" ? window : undefined,
): boolean {
  if (!win || win.parent === win) return false;
  win.parent.postMessage({ type: ABRUM_CLOSE_SURFACE_MESSAGE_TYPE, result } satisfies AbrumCloseSurfaceMessage, "*");
  return true;
}

export function readAbrumCloseSurface(data: unknown): AbrumCloseSurfaceMessage | null {
  if (!data || typeof data !== "object") return null;
  const message = data as Record<string, unknown>;
  if (message.type !== ABRUM_CLOSE_SURFACE_MESSAGE_TYPE) return null;
  return {
    type: ABRUM_CLOSE_SURFACE_MESSAGE_TYPE,
    result: isSurfaceJsonValue(message.result) ? message.result : undefined,
  };
}

export function postAbrumSurfaceResult(
  target: Pick<Window, "postMessage"> | null | undefined,
  requestId: string,
  result?: AbrumSurfaceJsonValue,
  error?: string,
): boolean {
  if (!target || !requestId.trim()) return false;
  target.postMessage({
    type: ABRUM_SURFACE_RESULT_MESSAGE_TYPE,
    requestId: requestId.trim(),
    result,
    error: error?.trim() || undefined,
  } satisfies AbrumSurfaceResultMessage, "*");
  return true;
}

export function readAbrumSurfaceResult(data: unknown): AbrumSurfaceResultMessage | null {
  if (!data || typeof data !== "object") return null;
  const message = data as Record<string, unknown>;
  if (message.type !== ABRUM_SURFACE_RESULT_MESSAGE_TYPE) return null;
  if (typeof message.requestId !== "string" || !message.requestId.trim()) return null;
  return {
    type: ABRUM_SURFACE_RESULT_MESSAGE_TYPE,
    requestId: message.requestId.trim(),
    result: isSurfaceJsonValue(message.result) ? message.result : undefined,
    error: typeof message.error === "string" && message.error.trim() ? message.error.trim() : undefined,
  };
}

export function encodeAbrumAppSurface(reference: AbrumAppSurfaceReference): string {
  if (reference.input !== undefined && !isSurfaceJsonValue(reference.input)) {
    throw new Error("abrum app surface input must be finite, acyclic JSON");
  }
  const serialized = JSON.stringify(reference);
  if (new TextEncoder().encode(serialized).byteLength > MAX_APP_SURFACE_CONTEXT_BYTES) {
    throw new Error("abrum app surface context is too large");
  }
  return base64UrlEncode(serialized);
}

export function decodeAbrumAppSurface(encoded: string): AbrumAppSurfaceReference {
  const decoded = JSON.parse(base64UrlDecode(encoded)) as Record<string, unknown>;
  if (typeof decoded.roomId !== "string" || !decoded.roomId.trim()) {
    throw new Error("abrum app surface is missing roomId");
  }
  if (typeof decoded.appId !== "string" || !decoded.appId.trim()) {
    throw new Error("abrum app surface is missing appId");
  }
  if (typeof decoded.surfaceId !== "string" || !decoded.surfaceId.trim()) {
    throw new Error("abrum app surface is missing surfaceId");
  }
  if (decoded.input !== undefined && !isSurfaceJsonValue(decoded.input)) {
    throw new Error("abrum app surface input must be JSON");
  }
  const placement = isAbrumAppSurfacePlacement(decoded.placement) ? decoded.placement : undefined;
  return {
    roomId: decoded.roomId.trim(),
    appId: decoded.appId.trim(),
    surfaceId: decoded.surfaceId.trim(),
    input: decoded.input as AbrumSurfaceJsonValue | undefined,
    placement,
  };
}

export function readAbrumAppSurface(win?: { location?: { search?: string } }): AbrumAppSurfaceReference | null {
  const w = win ?? (typeof window !== "undefined" ? window : undefined);
  const encoded = new URLSearchParams(w?.location?.search ?? "").get(APP_SURFACE_PARAM);
  if (!encoded) return null;
  try {
    return decodeAbrumAppSurface(encoded);
  } catch {
    return null;
  }
}

/** Add a validated surface context to a host-minted app URL. When entrypoint is
 * supplied, replace the route below `/apps/{room}/{app}/` while preserving the
 * embed/session parameters. Standalone dev URLs use the entrypoint as a normal
 * absolute pathname. */
export function withAbrumAppSurface(
  url: string,
  reference: AbrumAppSurfaceReference,
  entrypoint?: string,
): string {
  // Gleicher Guard wie in withAbrumGlobalNavigation: diese Funktion wird aus
  // packages/abrum-react/src/window.tsx mit window.location.href gerufen, das in
  // Tests und eingebetteten Kontexten auch mal kein absoluter URL ist.
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return url;
  }
  if (entrypoint && entrypoint !== "/") {
    const route = entrypoint.replace(/^\/+/, "");
    const hosted = readHostedAppRoute({ location: parsed });
    if (hosted) {
      const marker = `/apps/${encodeURIComponent(hosted.roomId)}/${encodeURIComponent(hosted.appId)}/`;
      const at = parsed.pathname.indexOf(marker);
      if (at >= 0) parsed.pathname = `${parsed.pathname.slice(0, at)}${marker}${route}`;
    } else {
      parsed.pathname = `/${route}`;
    }
  }
  parsed.searchParams.set(APP_SURFACE_PARAM, encodeAbrumAppSurface(reference));
  return parsed.toString();
}

export function isAbrumAppSurfacePlacement(value: unknown): value is AbrumAppSurfacePlacement {
  return value === "app" || value === "inline" || value === "modal" || value === "window";
}

export function isSurfaceJsonValue(value: unknown): value is AbrumSurfaceJsonValue {
  return isSurfaceJsonValueInner(value, new Set<object>(), 0);
}

function isSurfaceJsonValueInner(value: unknown, ancestors: Set<object>, depth: number): value is AbrumSurfaceJsonValue {
  if (depth > 32) return false;
  if (value === null || typeof value === "string" || typeof value === "boolean") return true;
  if (typeof value === "number") return Number.isFinite(value);
  if (Array.isArray(value)) {
    if (ancestors.has(value)) return false;
    ancestors.add(value);
    const valid = value.every((item) => isSurfaceJsonValueInner(item, ancestors, depth + 1));
    ancestors.delete(value);
    return valid;
  }
  if (!value || typeof value !== "object") return false;
  if (ancestors.has(value)) return false;
  ancestors.add(value);
  const valid = Object.values(value as Record<string, unknown>)
    .every((item) => isSurfaceJsonValueInner(item, ancestors, depth + 1));
  ancestors.delete(value);
  return valid;
}

/** Dependency-free JSON-Schema subset used at the host boundary. App surface
 * inputs intentionally stay small: object/array/scalar types, required,
 * properties, items, enum/const and additionalProperties. */
export function validateAbrumAppSurfaceInput(schema: unknown, value: unknown): string[] {
  if (!schema || typeof schema !== "object" || Array.isArray(schema)) return [];
  const errors: string[] = [];
  validateSurfaceSchema(schema as Record<string, unknown>, value, "$", errors);
  return errors;
}

function validateSurfaceSchema(
  schema: Record<string, unknown>,
  value: unknown,
  path: string,
  errors: string[],
): void {
  const supported = new Set([
    "$id", "$schema", "title", "description", "default", "examples", "deprecated", "readOnly", "writeOnly",
    "type", "properties", "required", "additionalProperties", "items", "enum", "const",
  ]);
  for (const key of Object.keys(schema)) {
    if (!supported.has(key)) errors.push(`${path} schema keyword ${key} is not supported for app surfaces`);
  }
  if (schema.type !== undefined && typeof schema.type !== "string") {
    errors.push(`${path} schema type must be one string`);
    return;
  }
  if (schema.additionalProperties !== undefined && typeof schema.additionalProperties !== "boolean") {
    errors.push(`${path} schema additionalProperties must be boolean`);
  }
  if (schema.const !== undefined && value !== schema.const) errors.push(`${path} must equal the declared const`);
  if (Array.isArray(schema.enum) && !schema.enum.some((candidate) => candidate === value)) {
    errors.push(`${path} is not one of the declared enum values`);
  }
  const type = typeof schema.type === "string" ? schema.type : undefined;
  if (type && !matchesSurfaceType(type, value)) {
    errors.push(`${path} must be ${type}`);
    return;
  }
  if (type === "object" && value && typeof value === "object" && !Array.isArray(value)) {
    const object = value as Record<string, unknown>;
    const properties = schema.properties && typeof schema.properties === "object" && !Array.isArray(schema.properties)
      ? schema.properties as Record<string, unknown>
      : {};
    const required = Array.isArray(schema.required)
      ? schema.required.filter((key): key is string => typeof key === "string")
      : [];
    for (const key of required) if (!(key in object)) errors.push(`${path}.${key} is required`);
    if (schema.additionalProperties === false) {
      for (const key of Object.keys(object)) if (!(key in properties)) errors.push(`${path}.${key} is not allowed`);
    }
    for (const [key, childSchema] of Object.entries(properties)) {
      if (key in object && childSchema && typeof childSchema === "object" && !Array.isArray(childSchema)) {
        validateSurfaceSchema(childSchema as Record<string, unknown>, object[key], `${path}.${key}`, errors);
      }
    }
  }
  if (type === "array" && Array.isArray(value) && schema.items && typeof schema.items === "object" && !Array.isArray(schema.items)) {
    value.forEach((item, index) => validateSurfaceSchema(schema.items as Record<string, unknown>, item, `${path}[${index}]`, errors));
  }
}

function matchesSurfaceType(type: string, value: unknown): boolean {
  switch (type) {
    case "object": return Boolean(value) && typeof value === "object" && !Array.isArray(value);
    case "array": return Array.isArray(value);
    case "string": return typeof value === "string";
    case "number": return typeof value === "number" && Number.isFinite(value);
    case "integer": return typeof value === "number" && Number.isInteger(value);
    case "boolean": return typeof value === "boolean";
    case "null": return value === null;
    default: return false;
  }
}

// ---------------------------------------------------------------------------
// The composed URL a host loads to embed an app. Hosts should build the URL
// with this so the embed params + session hash always match what apps decode.
// ---------------------------------------------------------------------------

export interface BuildEmbeddedAppUrlOptions {
  stationUrl: string;
  roomId: string;
  appId: string;
  hideShellChrome?: boolean;
  hostKind?: string;
  debug?: boolean;
  actorPrincipalDid?: string;
  /** Isolates persisted runtime state when one host keeps multiple Room-bound
   * instances of the same app alive at once. */
  sessionId?: string;
  handoff?: AbrumSessionHandoff | null;
  theme?: AbrumEmbedTheme;
  /** Sub-page route for a multi-surface app (e.g. "/rechnungen"). "/" = root. */
  surfaceEntrypoint?: string;
}

export function buildEmbeddedAppUrl(options: BuildEmbeddedAppUrlOptions): string {
  // A non-root surface entrypoint is appended WITHOUT a trailing slash so the
  // app's relative asset base ("./") still resolves to /apps/{room}/{app}/.
  const surface =
    options.surfaceEntrypoint && options.surfaceEntrypoint !== "/"
      ? options.surfaceEntrypoint.replace(/^\/+/, "")
      : "";
  const base = `${options.stationUrl.replace(/\/+$/, "")}/apps/${encodeURIComponent(options.roomId)}/${encodeURIComponent(options.appId)}/${surface}`;
  const params = encodeEmbedParams({
    kind: options.hostKind ?? "native",
    hideShellChrome: options.hideShellChrome ?? true,
    stationUrl: options.stationUrl,
    roomId: options.roomId,
    appId: options.appId,
    theme: options.theme,
  });
  if (options.actorPrincipalDid?.trim()) {
    params.set("actor_principal_did", options.actorPrincipalDid.trim());
  }
  if (options.sessionId?.trim()) params.set("session", options.sessionId.trim());
  if (options.debug) params.set("abrumDebug", "1");
  let url = `${base}?${params.toString()}`;
  if (options.handoff) {
    url += `#${SESSION_HANDOFF_HASH_KEY}=${encodeURIComponent(encodeAbrumSessionHandoff(options.handoff))}`;
  }
  return url;
}

// ---------------------------------------------------------------------------
// base64url (no padding) — used by the session handoff. Kept here so the
// contract module has no dependencies.
// ---------------------------------------------------------------------------

function base64UrlEncode(value: string): string {
  const bytes = new TextEncoder().encode(value);
  let binary = "";
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function base64UrlDecode(value: string): string {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(value.length / 4) * 4, "=");
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return new TextDecoder().decode(bytes);
}
