import type { JsonValue } from "@abrum/web-runtime";

/** An object address, not authority to read or mutate it (concept Spec 36). */
export interface AbrumResourceRef {
  contract: "abrum.resource/v1";
  roomId: string;
  appId: string;
  entityType: string;
  lineageCid: string;
  versionCid: string;
}
export const resourceRefSchema: Record<string, JsonValue>;

export type AbrumAppKind = "web" | "wasm" | "native";
export type AbrumFieldKind = "string" | "number" | "boolean" | "date" | "json" | "any";

export interface AbrumAppField<T = unknown, Required extends boolean = true> {
  readonly __abrumField: true;
  readonly descriptor: {
    readonly kind: AbrumFieldKind;
    readonly required: Required;
    readonly indexed: boolean;
    readonly unique: boolean;
  };
  optional(): AbrumAppField<T, false>;
  index(): AbrumAppField<T, Required>;
  indexed(): AbrumAppField<T, Required>;
  unique(): AbrumAppField<T, Required>;
}

export type AbrumAppFields = Record<string, AbrumAppField<unknown, boolean>>;

export interface AbrumAppAction<
  Input extends AbrumAppFields = AbrumAppFields,
  Output extends AbrumAppFields | undefined = AbrumAppFields | undefined,
> {
  readonly __abrumAction: true;
  readonly description?: string;
  readonly input?: Input;
  readonly output?: Output;
  readonly offer?: string;
  readonly risk?: "low" | "medium" | "high" | (string & {});
  readonly secrets?: AbrumSecretRequirement[];
  readonly humanAdminOnly?: boolean;
  readonly ownerOnly?: boolean;
}

export interface AbrumAppAgentOffer {
  title?: string;
  description?: string;
  risk?: "low" | "medium" | "high" | (string & {});
  modes?: Array<"on_behalf_of_caller" | "delegated_service" | "autonomous">;
  defaultMode?: "on_behalf_of_caller" | "delegated_service" | "autonomous";
  resultPolicies?: string[];
  defaultResultPolicy?: string;
}

export interface AbrumAppEntity<Fields extends AbrumAppFields = AbrumAppFields> {
  readonly __abrumEntity: true;
  readonly fields: Fields;
  readonly schema?: string;
  readonly contentType?: string;
  readonly scope?: "room";
  named(schemaName: string): AbrumAppEntity<Fields>;
  type(contentType: string): AbrumAppEntity<Fields>;
  roomScoped(): AbrumAppEntity<Fields>;
}

export interface AbrumAppBuild {
  command?: string;
  dist?: string;
  entrypoint?: string;
}

export interface AbrumAppInstall {
  grant?: "room" | "user";
  grantedRights?: string[];
  config?: JsonValue;
}

export interface AbrumAppSidebarCreateRoom {
  /** Label used by both the app-row plus button and its menu entry. */
  label: string;
  /** Optional host-known icon token. Unknown tokens are ignored. */
  icon?: string;
  /**
   * App-level action to invoke instead of showing the shell's generic naming
   * dialog. Use this when the app must collect setup data before the Room can
   * be created (for example, an account connection flow).
   */
  actionId?: string;
  /**
   * Room-local action invoked after the host has created and exposed a new
   * Room. Use this for setup that may remain incomplete (for example, adding
   * credentials): the sovereign Room exists independently of setup progress.
   */
  setupActionId?: string;
  /** App-owned failure copy when a collect-before-create setup is rolled back. */
  setupFailureMessage?: string;
  /** Keep newly created app Rooms out of the creator's sidebar by default. */
  hideFromSidebar?: boolean;
  /**
   * Only include Rooms containing this app-owned content type in the app lens.
   * Setup flows can use this to keep empty or rolled-back Rooms from widening
   * every app query.
   */
  activationContentType?: string;
  /**
   * After the app-owned setup succeeds, file one normal Warden intention that
   * grants this declared capability offer to the selected/default Agent Room.
   * The offer remains revocable and no authority is implied by installation.
   */
  defaultAgentOfferId?: string;
  /** Optional imported/companion provider app that owns defaultAgentOfferId.
   * The host resolves the live installed offer in the same newly-created Room;
   * omission keeps the historical app-local behavior. */
  defaultAgentOfferAppId?: string;
  /** Reuse the one accessible Computer Room that publishes this enabled MCP
   * service instead of creating a new empty Room. The host resolves the Room,
   * installs this presentation app there, and then grants the delegated
   * defaultAgentOfferId. Zero or multiple matches fail closed. */
  existingComputerMcpServiceId?: string;
  /** App-owned copy for the shell-rendered Room naming dialog. */
  dialog?: {
    title?: string;
    description?: string;
    nameLabel?: string;
    namePlaceholder?: string;
    submitLabel?: string;
    initialName?: string;
  };
}

export interface AbrumAppSidebarRoomAction {
  /** Show this action as the row's icon button as well as in its menu. */
  primary?: boolean;
  /** May be invoked through navigateUi: opens UI only, never grants effect rights. */
  navigationOnly?: boolean;
  /** Stable app-local action id delivered to the selected room instance. */
  id: string;
  label: string;
  /** Optional host-known icon token. Unknown tokens are ignored. */
  icon?: string;
}

/** Dynamic sidebar title. The host reads `source` when that record exists and otherwise shows `fallback`. */
export interface AbrumAppSidebarContextLabel {
  /** Used until the live record exists. Defaults to the Room name. */
  fallback?: "roomName" | "appTitle";
  source?: {
    contentType: string;
    field: string;
    iconField?: string;
    /** Numeric field used to pick the newest live record. Defaults to updatedAtMs. */
    orderBy?: string;
  };
}

export interface AbrumAppSidebar {
  /** Dynamic row title. Absent records keep the fallback; the shell must not hardcode app fields. */
  contextLabel?: AbrumAppSidebarContextLabel;
  /** Enables creating another sovereign Room for this app. */
  createRoom?: AbrumAppSidebarCreateRoom;
  /** App-owned actions appended to each Room's shell-owned menu. */
  roomActions?: AbrumAppSidebarRoomAction[];
}

/** One durable, Room-local service owned by the Room's Computer companion. */
export interface AbrumComputerService {
  /** Stable service identity within the Room. */
  serviceId: string;
  label: string;
  path?: string;
  protocol: "http" | "mcp";
  port: number;
  /** Idempotent shell program executed inside the private Room Computer. */
  startupScript: string;
  /** Optional bearer token read only by the Computer host from Room state. */
  bearerTokenFile?: string;
}

/**
 * Declarative Computer bootstrap. The host persists these services before it
 * opens the app, so setup does not depend on the web surface mounting first.
 */
export interface AbrumAppComputer {
  services: AbrumComputerService[];
}

/**
 * A function an app exposes to agents (and to itself). Identify it with either
 * `id` (agent tools, called as `<appId>.<id>`) or `name` (station-js endpoints).
 * When present, `input` is a JSON Schema object that becomes the agent tool's
 * parameter schema.
 */
export interface AbrumAppFunction {
  id?: string;
  name?: string;
  description?: string;
  /** Selects one entry from `backends` in a multi-backend app. */
  backend?: "js" | "wasm";
  /** Secrets consumed by this function. Codegen derives the station manifest's
   * reverse `requiredSecrets[].functions` index; app authors never maintain it. */
  secrets?: AbrumSecretRequirement[];
  /** Only a current human Room Admin (or that member's exact delegated app
   * surface) may invoke this function. Agent capability invocations are
   * rejected even when the Agent has provider-room Write access. */
  humanAdminOnly?: boolean;
  /** Only the Room owner, its exact delegated App surface, or an Agent with
   * current Warden authority may invoke this function. */
  ownerOnly?: boolean;
  /** Let an already-connected Agent request one input-bound action from Warden
   * without replacing its standing capability offer. */
  agentWarrant?: {
    scope: string;
    bindInput?: boolean;
    singleUse?: boolean;
    defaultTtlMs?: number;
    reason?: string;
    /** Explicit separate capability offer allowing this action on user request
     * without a per-invocation Warden. Existing offers never gain this implicitly. */
    standingOfferId?: string;
  };
  input?: JsonValue;
  output?: JsonValue;
  [key: string]: JsonValue | AbrumSecretRequirement[] | undefined;
}

/**
 * A semantic, provider-owned permission profile which another Room may request.
 * The Station resolves the offer from the installed provider app and mints an
 * attenuated capability for exactly this function set; consumers never invent
 * provider-specific scopes themselves.
 */
export interface AbrumCapabilityOffer {
  /** Stable app-local identifier, e.g. `brain.read` or `mail.draft`. */
  id: string;
  title: string;
  description?: string;
  /** App function handles covered by the offer. */
  functions: string[];
  /** Execution identities supported by the provider. */
  modes?: Array<"on_behalf_of_caller" | "delegated_service" | "autonomous">;
  defaultMode?: "on_behalf_of_caller" | "delegated_service" | "autonomous";
  /** Provider-defined review class; the Warden renders but does not reinterpret it. */
  risk?: "low" | "medium" | "high" | (string & {});
  defaultTtlMs?: number;
  /** Provider-defined release policies for results returned to the consumer Room. */
  resultPolicies?: string[];
  defaultResultPolicy?: string;
  [key: string]: JsonValue | string[] | undefined;
}

export interface AbrumAppSchemaRef {
  entity: string;
  name: string;
  [key: string]: JsonValue | undefined;
}

export interface AbrumAppImport {
  readonly __abrumModule?: true;
  appId: string;
  package?: string;
  version?: string;
  capabilities?: string[];
  schemas?: AbrumAppSchemaRef[];
  functions?: AbrumAppFunction[];
  capabilityOffers?: AbrumCapabilityOffer[];
  surfaces?: AbrumAppSurface[];
  required?: boolean;
  [key: string]: JsonValue | AbrumAppFunction[] | AbrumAppSchemaRef[] | AbrumAppSurface[] | string[] | boolean | undefined;
}

/** A build-time provider import with an explicit cross-app call allowlist.
 * Codegen resolves every descriptor from the provider package; the consumer
 * names only the functions it actually calls. */
export interface AbrumAppImportSelection {
  package: string;
  functions: string[];
}

/** A surface (entrypoint) the app renders — e.g. a web view in the launcher. */
export interface AbrumAppSurface {
  /** Stable app-local identity used by hosts and agent message parts. */
  id?: string;
  kind: AbrumAppKind | (string & {});
  label?: string;
  /** Icon for this surface's own launcher entry — an AppIcon token name or an
   * image URL. Falls back to the app's icon when omitted. */
  icon?: string;
  entrypoint?: string;
  /** Where a host may place this surface. Omitted means `["app"]` for
   * backward compatibility with existing launcher surfaces. */
  placements?: Array<"app" | "inline" | "modal" | "window">;
  /** JSON Schema for the small reference payload used to select content. */
  input?: JsonValue;
  defaultSize?: { width?: number; height?: number };
  [key: string]: JsonValue | undefined;
}

/** Where an app's non-web code runs (station-side JS, a wasm module, …). */
export interface AbrumAppRuntime {
  kind: "station-js" | "wasm" | (string & {});
  entrypoint?: string;
  engine?: string;
  [key: string]: JsonValue | undefined;
}

/**
 * Public backend declaration. Codegen translates the concise developer-facing
 * names to the station's internal runtime identifiers.
 */
export interface AbrumAppBackend {
  kind: "js" | "wasm";
  entrypoint: string;
  engine?: string;
  timeoutMs?: number;
  [key: string]: JsonValue | undefined;
}

export type AbrumAppBackendOptions = Omit<AbrumAppBackend, "kind">;

export interface AbrumAppBackends {
  js?: AbrumAppBackendOptions;
  wasm?: AbrumAppBackendOptions;
}

/** One optional execution component of a Room-installed app. Code is the
 * immutable source archive at /app; installation-local data lives at /data. */
export interface AbrumAppService {
  id?: string;
  image: string;
  command: string[];
  /** Run without root privileges. Station initializes only this installation's data ownership. */
  user?: string;
  network?: "none" | "public";
  autostart?: boolean;
  http?: { port: number; healthPath: string };
  /** Curated release files to bundle for built-in apps; paths relative to the app. */
  sourceFiles?: string[];
  /** Private compatibility route and one-time, same-Room data migration.
   * Keeps existing signed Computer-service grants/catalogs working without a
   * Computer VM. Data is copied (never deleted) from work/directory to /data/directory. */
  legacyComputer?: {
    directory: string;
    include: string[];
    services: Array<{ serviceId: string; port: number; protocol: "http" | "mcp"; path: string; bearerTokenFile?: string }>;
  };
}

/** Station compute contract. This requests an implementation; Room/Cap/Warden
 * authority still admits every operation. Configuration entities carry an indexed appId. */
export type AbrumHostComputeFeature = {
  id: string;
  contract: "abrum.host.compute/v1";
  placement: "station";
  host: "room-authority";
  operations: Partial<Record<"status" | "start" | "exec" | "stop" | "openService", string>>;
  profileEntity: string;
  serviceEntity: string;
  autostart?: boolean;
  /** App backend functions forwarded to the Room authority before execution. */
  appFunctions?: string[];
  /** Reserved compatibility binding; only abrum.computer/computer-vm may use it. */
  storage?: "legacy-computer-room";
};

/** Versioned, app-authored dynamic tools. Neither this declaration nor a catalog grants rights. */
export type AbrumAgentToolsFeature = {
  id: string;
  contract: "abrum.agent.tools/v1";
  catalogEntity: string;
  discoveryFunction: string;
  callFunction: string;
  /** Optional same-app compute feature used for immutable Agent artifact inputs. */
  computeFeature?: string;
};

/** Stable MCP names and optional business identity routing. Station owns authorization. */
export type AbrumMcpFeature = {
  id: string;
  contract: "abrum.app.mcp/v1";
  namespace: string;
  functions: string[];
  /** Bounded phrases in signed human prose that identify a read source. */
  readSourcePrefixes?: string[];
  selector?: {
    /** Public argument, e.g. account; optional accountRef disambiguates duplicates. */
    name: string;
    contentType: string;
    field: string;
    /** Station fills this argument with the selected object's lineage. */
    inputField: string;
    /** Generated metadata-only inventory tool, e.g. listAccounts. */
    listTool: string;
    /** Local observations only; Station never probes providers during inventory. */
    availability?: Array<{
      contentType: string;
      identityField: string;
      stateField: string;
      observedAtField: string;
      states: Record<string, "ready" | "needs_auth" | "offline" | "unknown">;
      reasonField?: string;
      reasonStates?: Record<string, "ready" | "needs_auth" | "offline" | "unknown">;
      /** Expired observations become unknown. Maximum 24 hours. */
      maxAgeMs: number;
    }>;
    /** Last successful observations by scope; does not assert complete coverage. */
    freshness?: {
      contentType: string;
      identityField: string;
      timestampField: string;
      scopeField?: string;
    };
  };
};

/** Persist in catalogEntity; appId, catalogId and updatedAtMs must be indexed. */
export type AbrumAgentToolCatalog = {
  appId: string;
  catalogId: string;
  revision: string;
  label: string;
  enabled: boolean;
  /** JSON array of {name, description?, inputSchema}; bounded by Station. */
  toolsJson: string;
  updatedAtMs: number;
  /** Optional enabled service belonging to computeFeature. */
  serviceId?: string;
};

export interface AbrumAppSpec<Entities extends Record<string, AbrumAppEntity> = Record<string, AbrumAppEntity>> {
  id: string;
  package?: string;
  title: string;
  /** Host-known icon token or an image URL/path used by launchers. */
  icon?: string;
  description?: string;
  kind?: AbrumAppKind;
  version?: string;
  /** Capability labels exported with the generated build-time module contract. */
  capabilities?: string[];
  /** Station dispatch gate (konzept BR-1/3/4): what the station may execute for this app.
   * Station-side runtimes (station-wasm, effectful station-js) require a declared level —
   * undeclared defaults to schema-only and the station refuses to run them. An app with
   * real network effects (e.g. IMAP/SMTP) declares "effect-declaration"; the egress then
   * rides the effect outbox + Cap reservation (I4). */
  executionLevel?: "schema-only" | "pure-wasm" | "effect-declaration" | "trusted-plugin" | (string & {});
  build?: AbrumAppBuild;
  install?: AbrumAppInstall;
  /** Optional host navigation extensions. Stored in the install config so each
   * installed app instance carries the declaration used by the desktop shell. */
  sidebar?: AbrumAppSidebar;
  service?: AbrumAppService;
  /** Room-local services provisioned through the required abrum.computer companion. */
  computer?: AbrumAppComputer;
  /** Consumer app imports by package name. Prefer a selection for the smallest
   * stable authorization/type surface; a bare package string imports all
   * provider functions for backward compatibility. Codegen resolves every
   * descriptor from the generated `./module`. */
  imports?: Array<string | AbrumAppImportSelection>;
  companions?: string[];
  entities?: Entities;
  /** Concise Agent-callable function declarations. Codegen derives JSON Schema,
   * function entries, capability offers, and the default Agent binding. */
  actions?: Record<string, AbrumAppAction>;
  /** Optional labels/policy overrides for action offer groups. */
  agent?: {
    offers?: Record<string, AbrumAppAgentOffer>;
    defaultOffer?: string;
  };
  schemas?: AbrumAppSchemaRef[];
  features?: JsonValue[];
  functions?: AbrumAppFunction[];
  /** Provider-owned semantic permissions that other Rooms may request. */
  capabilityOffers?: AbrumCapabilityOffer[];
  /** Build-time authoring gate. `complete` requires every declared function to
   * occur in at least one capability offer, preventing silently unreachable
   * agent actions. Omitted stays backward-compatible with legacy apps. */
  capabilityCoverage?: "complete";
  surfaces?: AbrumAppSurface[];
  background?: JsonValue | null;
  /** The app's optional station-side backend. Prefer this over `runtime` in new apps. */
  backend?: AbrumAppBackend | null;
  /** Multiple internal executables owned and published as one app. Functions select one via `backend`. */
  backends?: AbrumAppBackends | null;
  /** @deprecated Compatibility field for existing manifests. New apps use `backend`. */
  runtime?: AbrumAppRuntime | null;
  network?: JsonValue | null;
}

export interface AbrumSecretOptions {
  /** Logical name the app's code refers to. */
  id: string;
  /** Secret class, e.g. "mail.credential" | "provider.apiKey" | "service.oauthToken". */
  kind: string;
  /** Room/account/resource caveats bounding the secret. */
  scope?: JsonValue;
  /** The call-input field the station fills server-side, e.g. "authorization". */
  fillAs: string;
  /** Resolve a concrete secret family member from this call-input field. */
  perInstance?: string;
  /** "use" | "read". */
  access?: string;
  /** Human-auditable preview shown at install. */
  reason?: string;
  /** Raise one Warden approval on first consume, then standing. */
  firstUseWarrant?: boolean;
  /** Opt-in cross-station portability (default false; SK-18 re-wrap append). */
  portable?: boolean;
  /** Signed, operation-specific protection defaults materialized into the
   * secret Twin. Apps declare defaults; the Warden/user owns later changes. */
  protection?: Partial<Record<
    "consume" | "first_consume" | "reveal" | "mutate" | "delete" | "export",
    "none" | "local_presence"
  >>;
  /** Which principals the install mint grants this secret to (konzept 19b I3 /
   * Send-Hard-Gate P6b). Default (absent/empty) = both the per-room agent
   * principal and the room owner. ["owner"] = owner only — the agent principal
   * NEVER holds the grant (structural gate, e.g. mail-credential-send). */
  grantTo?: ("agent" | "owner")[];
}

/** A reusable source-level secret requirement. Attach it to each consuming
 * function with `secrets: [requirement]`; codegen owns the reverse manifest index. */
export interface AbrumSecretRequirement extends AbrumSecretOptions {
  readonly __abrumSecret: true;
}

export interface AbrumDsl {
  app(name: string, entities: Record<string, AbrumAppEntity>): unknown;
  entity<const Fields extends AbrumAppFields>(fields: Fields): AbrumAppEntity<Fields>;
  collection<const Fields extends AbrumAppFields>(fields: Fields): AbrumAppEntity<Fields>;
  action<const Input extends AbrumAppFields = {}, const Output extends AbrumAppFields | undefined = undefined>(options?: {
    description?: string;
    input?: Input;
    output?: Output;
    offer?: string;
    risk?: "low" | "medium" | "high" | (string & {});
    secrets?: AbrumSecretRequirement[];
    humanAdminOnly?: boolean;
    ownerOnly?: boolean;
  }): AbrumAppAction<Input, Output>;
  string(): AbrumAppField<string>;
  number(): AbrumAppField<number>;
  boolean(): AbrumAppField<boolean>;
  date(): AbrumAppField<number | string | Date>;
  createdAt(): AbrumAppField<number | string | Date>;
  updatedAt(): AbrumAppField<number | string | Date>;
  json(): AbrumAppField<JsonValue>;
  any(): AbrumAppField<JsonValue>;
  secret<const Options extends AbrumSecretOptions>(options: Options): Options & AbrumSecretRequirement;
}

export declare const abrum: AbrumDsl;

export declare function defineApp<const Spec extends AbrumAppSpec>(spec: Spec): Spec;
