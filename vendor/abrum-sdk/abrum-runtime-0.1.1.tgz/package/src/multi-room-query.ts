import { roomEventMatchesQuery, type RoomRealtimeEvent } from "./index";

/** Minimal structural contract needed by the platform-neutral multi-Room
 * stores. Host runtimes retain their richer signed-Twin type. */
export interface RoomHeadEntry {
  cid: string;
  seq: number;
  lineageCid?: string;
  sourceRoomId?: string;
  twin: {
    block: {
      previousVersion?: string | null;
    };
  };
}

export interface HeadsQuerySnapshot<Entry extends RoomHeadEntry = RoomHeadEntry> {
  entries: Entry[];
  isLoading: boolean;
  error: string | null;
  /** Per-Room failures never erase data returned by the other Rooms in a lens. */
  roomErrors: Readonly<Record<string, string>>;
}

export interface HeadsQueryConfig<Entry extends RoomHeadEntry = RoomHeadEntry> {
  roomIds: readonly string[];
  contentTypes: readonly string[];
  lineageCids: readonly string[];
  limit: number;
  pull: (
    roomId: string,
    afterSeq: number,
    options: {
      limit: number;
      contentTypes?: string[];
      lineageCids?: string[];
    },
  ) => Promise<{
    cursor: { seq: number };
    entries: Entry[];
  }>;
}

type Listener = () => void;

export interface RoomReadFailure {
  readonly roomId: string;
  readonly error: string;
  readonly cause: unknown;
}

/** Keep diagnostic labels separate from the original failures. Consumers must
 * classify every cause, not guess availability from the joined display text. */
export class RoomReadsFailedError extends AggregateError {
  readonly failures: readonly RoomReadFailure[];

  constructor(failures: readonly RoomReadFailure[]) {
    super(
      failures.map((failure) => failure.cause),
      failures.map((failure) => `${failure.roomId}: ${failure.error}`).join("; "),
    );
    this.name = "RoomReadsFailedError";
    this.failures = [...failures];
  }
}

export type HeadsRealtimeEvent = (RoomRealtimeEvent & { watermark_ms?: number }) | { type: "replay_gap" };

export type HeadsRealtimeRefreshMode = "incremental" | "reset" | null;

/**
 * Translate the runtime's single local/remote realtime signal into the heads
 * query action. Apps never need their own polling or event effect.
 */
export function headsRealtimeRefreshMode(
  event: HeadsRealtimeEvent | null,
  roomIds: readonly string[],
  contentTypes: readonly string[],
): HeadsRealtimeRefreshMode {
  if (!event) return "reset";
  if (event.type === "replay_gap") return "reset";
  const canonicalEvent: RoomRealtimeEvent = {
    type: "twins_inserted",
    room_id: event.room_id,
    cids: event.cids,
    revision: event.revision,
    content_types: event.content_types,
    relation_types: event.relation_types,
  };
  if (!roomIds.some((roomId) => roomEventMatchesQuery(canonicalEvent, roomId, {
    mode: "heads",
    contentTypes,
  }))) return null;

  const broad = event.content_types.length === 0 && event.relation_types.length === 0;
  if (broad || event.relation_types.includes("deletes")) return "reset";
  return "incremental";
}

/**
 * Merge an incremental heads response into one Room's cached projection.
 * A new object head replaces the prior member of the same lineage rather than
 * accumulating immutable versions in browser memory.
 */
export function mergeRoomHeadEntries<Entry extends RoomHeadEntry>(
  current: readonly Entry[],
  roomId: string,
  next: readonly Entry[],
): Entry[] {
  if (next.length === 0) return current as Entry[];

  const replacedLineages = new Set(
    next.flatMap((entry) => entry.lineageCid ? [entry.lineageCid] : []),
  );
  const replacedCids = new Set(
    next.flatMap((entry) => entry.twin.block.previousVersion ? [entry.twin.block.previousVersion] : []),
  );
  const byRoomCid = new Map<string, Entry>();

  for (const entry of current) {
    const belongsToRoom = entry.sourceRoomId === roomId;
    if (
      belongsToRoom
      && (
        (entry.lineageCid && replacedLineages.has(entry.lineageCid))
        || replacedCids.has(entry.cid)
      )
    ) {
      continue;
    }
    byRoomCid.set(roomEntryKey(entry.sourceRoomId, entry.cid), entry);
  }
  for (const entry of next) {
    const tagged = { ...entry, sourceRoomId: roomId } as Entry;
    byRoomCid.set(roomEntryKey(roomId, entry.cid), tagged);
  }
  return [...byRoomCid.values()];
}

function roomEntryKey(roomId: string | null | undefined, cid: string): string {
  return `${roomId ?? ""}\0${cid}`;
}

function replaceRoomHeadEntries<Entry extends RoomHeadEntry>(
  current: readonly Entry[],
  roomId: string,
  next: readonly Entry[],
): Entry[] {
  return mergeRoomHeadEntries(
    current.filter((entry) => entry.sourceRoomId !== roomId),
    roomId,
    next,
  );
}

/**
 * Shared, incremental query store used by all matching React hooks in one
 * runtime. It coalesces simultaneous refreshes, fetches independent Rooms in
 * parallel, and retains already-renderable data during background updates.
 */
export class HeadsQueryStore<Entry extends RoomHeadEntry = RoomHeadEntry> {
  private readonly listeners = new Set<Listener>();
  private readonly cursors = new Map<string, number>();
  private snapshot: HeadsQuerySnapshot<Entry> = {
    entries: [],
    isLoading: false,
    error: null,
    roomErrors: {},
  };
  private inFlight: Promise<Entry[]> | null = null;
  private queuedForce = false;
  private queuedAll = false;
  private queuedRoomIds = new Set<string>();

  constructor(private readonly config: HeadsQueryConfig<Entry>) {}

  readonly getSnapshot = (): HeadsQuerySnapshot<Entry> => this.snapshot;

  readonly subscribe = (listener: Listener): (() => void) => {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  };

  refresh(force = false, targetRoomIds?: readonly string[]): Promise<Entry[]> {
    if (this.inFlight) {
      this.queuedForce ||= force;
      this.queuedAll ||= force && targetRoomIds === undefined;
      for (const roomId of targetRoomIds ?? []) this.queuedRoomIds.add(roomId);
      return this.inFlight;
    }

    this.inFlight = this.refreshLoop(force, targetRoomIds).finally(() => {
      this.inFlight = null;
    });
    return this.inFlight;
  }

  private async refreshLoop(
    initialForce: boolean,
    initialRoomIds?: readonly string[],
  ): Promise<Entry[]> {
    let force = initialForce;
    let targetRoomIds = initialRoomIds;
    let pulled: Entry[] = [];
    let repeat: boolean;
    do {
      this.queuedForce = false;
      this.queuedAll = false;
      this.queuedRoomIds.clear();
      pulled = await this.refreshOnce(force, targetRoomIds);
      force = this.queuedForce;
      targetRoomIds = this.queuedAll ? undefined : [...this.queuedRoomIds];
      repeat = this.queuedForce || this.queuedAll || this.queuedRoomIds.size > 0;
    } while (repeat);
    return pulled;
  }

  private async refreshOnce(
    force: boolean,
    targetRoomIds?: readonly string[],
  ): Promise<Entry[]> {
    const configuredRoomIds = [...new Set(this.config.roomIds.filter(Boolean))];
    if (configuredRoomIds.length === 0) {
      this.cursors.clear();
      this.publish({ entries: [], isLoading: false, error: null, roomErrors: {} });
      return [];
    }
    const targets = targetRoomIds
      ? new Set(targetRoomIds.filter(Boolean))
      : null;
    const roomIds = targets
      ? configuredRoomIds.filter((roomId) => targets.has(roomId))
      : configuredRoomIds;
    if (roomIds.length === 0) return [];

    this.publish({ ...this.snapshot, isLoading: true, error: null, roomErrors: {} });
    try {
      const successful: Array<{ ok: true; roomId: string; entries: Entry[] }> = [];
      const failed: RoomReadFailure[] = [];
      let roomErrors: Readonly<Record<string, string>> = {};
      await Promise.all(roomIds.map(async (roomId) => {
        try {
          let seq = force ? 0 : (this.cursors.get(roomId) ?? 0);
          const entries: Entry[] = [];
          const options = {
            limit: this.config.limit,
            ...(this.config.contentTypes.length > 0
              ? { contentTypes: [...this.config.contentTypes] }
              : {}),
            ...(this.config.lineageCids.length > 0
              ? { lineageCids: [...this.config.lineageCids] }
              : {}),
          };
          for (;;) {
            const page = await this.config.pull(roomId, seq, options);
            entries.push(...page.entries);
            const nextSeq = page.cursor.seq;
            if (
              page.entries.length === 0
              || page.entries.length < this.config.limit
              || nextSeq <= seq
            ) {
              seq = Math.max(seq, nextSeq);
              break;
            }
            seq = nextSeq;
          }
          this.cursors.set(roomId, seq);
          const result = { ok: true as const, roomId, entries };
          successful.push(result);
          const mergedEntries = force
            ? replaceRoomHeadEntries(this.snapshot.entries, roomId, entries)
            : mergeRoomHeadEntries(this.snapshot.entries, roomId, entries);
          this.publish({
            ...this.snapshot,
            entries: mergedEntries,
            isLoading: true,
            error: failed.length > 0
              ? failed.map((failure) => `${failure.roomId}: ${failure.error}`).join("; ")
              : null,
            roomErrors,
          });
          return result;
        } catch (cause) {
          const result = {
            ok: false as const,
            roomId,
            cause,
            error: cause instanceof Error ? cause.message : String(cause),
          };
          failed.push(result);
          roomErrors = { ...roomErrors, [roomId]: result.error };
          this.publish({
            ...this.snapshot,
            isLoading: true,
            error: failed.map((failure) => `${failure.roomId}: ${failure.error}`).join("; "),
            roomErrors,
          });
          return result;
        }
      }));
      const pulled = successful.flatMap((result) => result.entries);
      const error = failed.length > 0
        ? failed.map((result) => `${result.roomId}: ${result.error}`).join("; ")
        : null;
      this.publish({ ...this.snapshot, isLoading: false, error, roomErrors });
      if (successful.length === 0 && failed.length > 0) {
        throw new RoomReadsFailedError(failed);
      }
      return pulled;
    } catch (cause) {
      const error = cause instanceof Error ? cause.message : String(cause);
      this.publish({ ...this.snapshot, isLoading: false, error });
      throw cause;
    }
  }

  private publish(snapshot: HeadsQuerySnapshot<Entry>): void {
    this.snapshot = snapshot;
    for (const listener of this.listeners) listener();
  }
}

export interface BoundedHeadsQueryConfig<Entry extends RoomHeadEntry = RoomHeadEntry> {
  roomIds: readonly string[];
  query: (roomId: string) => Promise<{ entries: Entry[] }>;
}

export interface InfiniteHeadsQueryCursor {
  value: string | number | boolean;
  lineageCid: string;
}

export interface InfiniteHeadsQuerySnapshot<Entry extends RoomHeadEntry = RoomHeadEntry> extends HeadsQuerySnapshot<Entry> {
  hasMore: boolean;
  isLoadingMore: boolean;
  /** True after this exact query key has completed its first bounded page. */
  hasLoaded: boolean;
}

export interface InfiniteHeadsQueryConfig<Entry extends RoomHeadEntry = RoomHeadEntry> {
  roomIds: readonly string[];
  pageSize: number;
  /** Coalesce realtime invalidations; explicit refresh/loadMore remain immediate. */
  realtimeRefreshDelayMs?: number;
  query: (
    roomId: string,
    after?: InfiniteHeadsQueryCursor,
  ) => Promise<{ entries: Entry[] }>;
  cursor: (entry: Entry) => InfiniteHeadsQueryCursor | null;
}

/**
 * Per-Room keyset pagination for large App lenses. Every Room advances its own
 * stable `(order value, lineageCid)` cursor, so consolidated lists neither skip
 * equal timestamps nor impose an offset scan on SQLite.
 */
export class InfiniteHeadsQueryStore<Entry extends RoomHeadEntry = RoomHeadEntry> {
  private readonly listeners = new Set<Listener>();
  private readonly cursors = new Map<string, InfiniteHeadsQueryCursor>();
  private readonly exhaustedRooms = new Set<string>();
  private snapshot: InfiniteHeadsQuerySnapshot<Entry>;
  private inFlight: Promise<Entry[]> | null = null;
  private queuedRoomIds = new Set<string>();
  private invalidatedRoomIds = new Set<string>();
  private invalidationTimer: ReturnType<typeof setTimeout> | null = null;

  constructor(private readonly config: InfiniteHeadsQueryConfig<Entry>) {
    this.snapshot = {
      entries: [],
      isLoading: config.roomIds.length > 0,
      isLoadingMore: false,
      hasMore: false,
      hasLoaded: config.roomIds.length === 0,
      error: null,
      roomErrors: {},
    };
  }

  readonly getSnapshot = (): InfiniteHeadsQuerySnapshot<Entry> => this.snapshot;

  readonly subscribe = (listener: Listener): (() => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
      if (this.listeners.size === 0) {
        this.invalidatedRoomIds.clear();
        if (this.invalidationTimer !== null) clearTimeout(this.invalidationTimer);
        this.invalidationTimer = null;
      }
    };
  };

  refresh(targetRoomIds?: readonly string[]): Promise<Entry[]> {
    return this.run("reset", targetRoomIds);
  }

  loadMore(): Promise<Entry[]> {
    return this.run("more");
  }

  /** Background notifications must not extend an explicit refresh promise.
   * Keep a fixed batching window (not a sliding debounce) so continuous sync
   * still becomes visible. Notifications arriving during I/O get a later round. */
  invalidate(targetRoomIds?: readonly string[]): void {
    if (!this.config.realtimeRefreshDelayMs) {
      void this.refresh(targetRoomIds).catch(() => undefined);
      return;
    }
    for (const roomId of targetRoomIds ?? this.config.roomIds) {
      if (this.config.roomIds.includes(roomId)) this.invalidatedRoomIds.add(roomId);
    }
    this.scheduleInvalidations();
  }

  private scheduleInvalidations(): void {
    if (this.inFlight || this.invalidationTimer !== null || this.invalidatedRoomIds.size === 0) return;
    this.invalidationTimer = setTimeout(() => {
      this.invalidationTimer = null;
      if (this.inFlight || this.invalidatedRoomIds.size === 0) return;
      // fetchPage consumes only invalidations known before that Room's read.
      // A new invalidation during the read must survive until the next round.
      void this.refresh([...this.invalidatedRoomIds]).catch(() => undefined);
    }, this.config.realtimeRefreshDelayMs);
  }

  private run(
    mode: "reset" | "more",
    targetRoomIds?: readonly string[],
  ): Promise<Entry[]> {
    if (this.inFlight) {
      if (mode === "reset") {
        for (const roomId of targetRoomIds ?? this.config.roomIds) this.queuedRoomIds.add(roomId);
      }
      return this.inFlight;
    }
    this.inFlight = this.fetchLoop(mode, targetRoomIds).finally(() => {
      this.inFlight = null;
      this.scheduleInvalidations();
    });
    return this.inFlight;
  }

  private async fetchLoop(
    initialMode: "reset" | "more",
    initialRoomIds?: readonly string[],
  ): Promise<Entry[]> {
    let mode = initialMode;
    let targetRoomIds = initialRoomIds;
    let pulled: Entry[] = [];
    do {
      this.queuedRoomIds.clear();
      pulled = await this.fetchPage(mode, targetRoomIds);
      mode = "reset";
      targetRoomIds = [...this.queuedRoomIds];
    } while (targetRoomIds.length > 0);
    return pulled;
  }

  private async fetchPage(
    mode: "reset" | "more",
    targetRoomIds?: readonly string[],
  ): Promise<Entry[]> {
    const roomIds = [...new Set(this.config.roomIds.filter(Boolean))];
    if (roomIds.length === 0) {
      this.cursors.clear();
      this.exhaustedRooms.clear();
      this.publish({
        entries: [],
        isLoading: false,
        isLoadingMore: false,
        hasMore: false,
        hasLoaded: true,
        error: null,
        roomErrors: {},
      });
      return [];
    }
    const requested = targetRoomIds ? new Set(targetRoomIds.filter(Boolean)) : null;
    const targetRooms = mode === "more"
      ? roomIds.filter((roomId) => !this.exhaustedRooms.has(roomId))
      : requested
        ? roomIds.filter((roomId) => requested.has(roomId))
        : roomIds;
    if (targetRooms.length === 0) return [];
    if (mode === "reset") {
      for (const roomId of targetRooms) {
        this.invalidatedRoomIds.delete(roomId);
        this.cursors.delete(roomId);
        this.exhaustedRooms.delete(roomId);
      }
    }

    this.publish({
      ...this.snapshot,
      isLoading: mode === "reset" && !this.snapshot.hasLoaded,
      isLoadingMore: mode === "more",
      error: null,
      roomErrors: {},
    });
    const successful: Array<{ ok: true; roomId: string; entries: Entry[] }> = [];
    const failed: RoomReadFailure[] = [];
    let roomErrors: Readonly<Record<string, string>> = {};
    await Promise.all(targetRooms.map(async (roomId) => {
      try {
        const result = await this.config.query(
          roomId,
          mode === "more" ? this.cursors.get(roomId) : undefined,
        );
        const settled = { ok: true as const, roomId, entries: result.entries };
        successful.push(settled);
        const entries = mode === "reset"
          ? replaceRoomHeadEntries(this.snapshot.entries, roomId, result.entries)
          : mergeRoomHeadEntries(this.snapshot.entries, roomId, result.entries);
        const last = result.entries.at(-1);
        const cursor = last ? this.config.cursor(last) : null;
        if (result.entries.length < this.config.pageSize || !cursor) {
          this.exhaustedRooms.add(roomId);
          this.cursors.delete(roomId);
        } else {
          this.exhaustedRooms.delete(roomId);
          this.cursors.set(roomId, cursor);
        }
        this.publish({
          ...this.snapshot,
          entries,
          isLoading: mode === "reset" && !this.snapshot.hasLoaded,
          isLoadingMore: mode === "more",
          hasMore: roomIds.some((candidate) => !this.exhaustedRooms.has(candidate)),
          error: failed.length > 0
            ? failed.map((failure) => `${failure.roomId}: ${failure.error}`).join("; ")
            : null,
          roomErrors,
        });
        return settled;
      } catch (cause) {
        const settled = {
          ok: false as const,
          roomId,
          cause,
          error: cause instanceof Error ? cause.message : String(cause),
        };
        failed.push(settled);
        roomErrors = { ...roomErrors, [roomId]: settled.error };
        this.publish({
          ...this.snapshot,
          isLoading: mode === "reset" && !this.snapshot.hasLoaded,
          isLoadingMore: mode === "more",
          error: failed.map((failure) => `${failure.roomId}: ${failure.error}`).join("; "),
          roomErrors,
        });
        return settled;
      }
    }));
    const error = failed.length > 0
      ? failed.map((result) => `${result.roomId}: ${result.error}`).join("; ")
      : null;
    this.publish({
      ...this.snapshot,
      isLoading: false,
      isLoadingMore: false,
      hasMore: roomIds.some((roomId) => !this.exhaustedRooms.has(roomId)),
      hasLoaded: true,
      error,
      roomErrors,
    });
    if (successful.length === 0 && failed.length > 0) {
      throw new RoomReadsFailedError(failed);
    }
    return successful.flatMap((result) => result.entries);
  }

  private publish(snapshot: InfiniteHeadsQuerySnapshot<Entry>): void {
    this.snapshot = snapshot;
    for (const listener of this.listeners) listener();
  }
}

/** Shared snapshot cache for predicate/order/limit queries. A matching Twin can
 * leave the result set after an update, so realtime refreshes replace each
 * Room's slice instead of attempting cursor merges. */
export class BoundedHeadsQueryStore<Entry extends RoomHeadEntry = RoomHeadEntry> {
  private readonly listeners = new Set<Listener>();
  private snapshot: HeadsQuerySnapshot<Entry> = {
    entries: [],
    isLoading: false,
    error: null,
    roomErrors: {},
  };
  private inFlight: Promise<Entry[]> | null = null;
  private queued = false;
  private queuedAll = false;
  private queuedRoomIds = new Set<string>();
  private hasLoaded = false;

  constructor(private readonly config: BoundedHeadsQueryConfig<Entry>) {}

  readonly getSnapshot = (): HeadsQuerySnapshot<Entry> => this.snapshot;

  readonly subscribe = (listener: Listener): (() => void) => {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  };

  refresh(targetRoomIds?: readonly string[]): Promise<Entry[]> {
    if (this.inFlight) {
      this.queued = true;
      this.queuedAll ||= targetRoomIds === undefined;
      for (const roomId of targetRoomIds ?? []) this.queuedRoomIds.add(roomId);
      return this.inFlight;
    }
    this.inFlight = this.refreshLoop(targetRoomIds).finally(() => {
      this.inFlight = null;
    });
    return this.inFlight;
  }

  private async refreshLoop(initialRoomIds?: readonly string[]): Promise<Entry[]> {
    let targetRoomIds = initialRoomIds;
    let pulled: Entry[] = [];
    do {
      this.queued = false;
      this.queuedAll = false;
      this.queuedRoomIds.clear();
      pulled = await this.refreshOnce(targetRoomIds);
      targetRoomIds = this.queuedAll ? undefined : [...this.queuedRoomIds];
    } while (this.queued);
    return pulled;
  }

  private async refreshOnce(targetRoomIds?: readonly string[]): Promise<Entry[]> {
    const configuredRoomIds = [...new Set(this.config.roomIds.filter(Boolean))];
    if (configuredRoomIds.length === 0) {
      this.publish({ entries: [], isLoading: false, error: null, roomErrors: {} });
      return [];
    }
    const targets = targetRoomIds
      ? new Set(targetRoomIds.filter(Boolean))
      : null;
    const roomIds = targets
      ? configuredRoomIds.filter((roomId) => targets.has(roomId))
      : configuredRoomIds;
    if (roomIds.length === 0) return [];
    // Realtime invalidations are background refreshes once this query has
    // produced its first snapshot. Keeping `isLoading` as the cold-load signal
    // prevents every synced Twin from making buttons and empty states flicker.
    this.publish({
      ...this.snapshot,
      isLoading: !this.hasLoaded,
      error: null,
      roomErrors: {},
    });
    const results = await Promise.all(roomIds.map(async (roomId) => {
      try {
        const result = await this.config.query(roomId);
        return { ok: true as const, roomId, entries: result.entries };
      } catch (cause) {
        return {
          ok: false as const,
          roomId,
          cause,
          error: cause instanceof Error ? cause.message : String(cause),
        };
      }
    }));
    const successful = results.filter((result) => result.ok);
    const failed = results.filter((result) => !result.ok);
    let entries = this.snapshot.entries;
    for (const result of successful) {
      entries = replaceRoomHeadEntries(entries, result.roomId, result.entries);
    }
    const roomErrors = Object.fromEntries(failed.map((result) => [result.roomId, result.error]));
    const error = failed.length > 0
      ? failed.map((result) => `${result.roomId}: ${result.error}`).join("; ")
      : null;
    this.hasLoaded = true;
    this.publish({ entries, isLoading: false, error, roomErrors });
    if (successful.length === 0 && failed.length > 0) {
      throw new RoomReadsFailedError(failed);
    }
    return successful.flatMap((result) => result.entries);
  }

  private publish(snapshot: HeadsQuerySnapshot<Entry>): void {
    this.snapshot = snapshot;
    for (const listener of this.listeners) listener();
  }
}
