import { palettes } from "@oreo-design/avatar";

/**
 * Platform-neutral Agent avatar identity. Both the React DOM and the React
 * Native AgentAvatar render the exact same Flare from this seed, so an Agent
 * Room keeps one stable avatar across desktop, web, and Pocket Station.
 */
export interface AgentAvatarTheme {
  shape: "flare";
  paletteId: string;
  variantId: string;
}

/** FNV-1a hash — the same stable seed derivation used by every host renderer. */
export function hashRoomId(value: string): number {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

/**
 * An Agent Room's immutable id is its avatar seed. The palette therefore
 * survives reloads, renames and recipe versions without another identity twin.
 */
export function agentAvatarTheme(roomId: string, paletteId?: string): AgentAvatarTheme {
  const stableRoomId = roomId.trim() || "abrum-agent";
  const selectedPalette = paletteId
    ? palettes.find((palette) => palette.id === paletteId)
    : undefined;
  const palette = selectedPalette ?? palettes[hashRoomId(stableRoomId) % palettes.length];
  return {
    shape: "flare",
    paletteId: palette.id,
    variantId: stableRoomId,
  };
}
