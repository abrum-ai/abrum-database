export type RoomResidency = "ephemeral" | "pinned";
/** User-facing placement choice. `stream` keeps only an evictable verified
 * cache; `replicate` asks the local Station to maintain complete offline
 * custody. Apps describe the choice, while each host owns the transport. */
export type RoomDeliveryMode = "stream" | "replicate";
export type StationPresence = "local" | "online" | "stale" | "offline" | "unknown";
export type StationDeviceKind = "laptop" | "desktop" | "server" | "phone" | "unknown";

/** The Station currently responsible for serving a Room-backed resource.
 * `ownerDid` names the person/Room owner, never a transport identity. */
export interface RoomOrigin {
  stationId: string;
  stationName: string;
  deviceKind?: StationDeviceKind | null;
  hostname?: string | null;
  ownerDid: string;
  ownerName?: string | null;
  isLocal: boolean;
  presence: StationPresence;
}

/** Reusable placement projection for Rooms and app-owned sidecars such as
 * Files. It deliberately contains no host path or transport ticket. */
export interface RoomPlacementState {
  roomId: string;
  mode: RoomDeliveryMode;
  origin: RoomOrigin | null;
  available: boolean;
  cached: boolean;
  complete: boolean;
  syncing?: boolean;
  lastSyncedAtMs?: number | null;
  error?: string | null;
}
export type RoomAvailability = "connecting" | "live" | "cached" | "stale" | "unavailable";
export type RoomObservationSource = "local" | "remote" | "cache";
export type RoomQueryMode = "log" | "heads" | "objects";
export type RoomQueryOperator = "eq" | "in" | "gt" | "gte" | "lt" | "lte" | "contains";

export interface RoomQueryPredicate {
  field: string;
  operator: RoomQueryOperator;
  value: unknown;
}

export interface RoomQueryCursor {
  value: unknown;
  lineageCid: string;
}

/** Canonical data interest. Residency and transport deliberately stay outside it. */
export interface RoomQuery {
  mode: RoomQueryMode;
  afterSeq?: number;
  contentType?: string;
  contentTypes?: readonly string[];
  schemaCids?: readonly string[];
  lineageCids?: readonly string[];
  predicates?: readonly RoomQueryPredicate[];
  order?: { field: string; descending: boolean };
  after?: RoomQueryCursor;
  limit?: number;
}

export interface RoomSelector {
  roomIds?: readonly string[];
  installedAppIds?: readonly string[];
  roomKinds?: readonly string[];
}

export type RoomQueryPriority = "selected" | "visible" | "lens" | "background";

/** Dynamic actor-scoped multi-Room interest. Identity Roots route this demand;
 * every returned Room is still independently authorized by the Station. */
export interface RoomLensDemand {
  actorDid: string;
  selector?: RoomSelector;
  query: RoomQuery;
  priority?: RoomQueryPriority;
  projector?: { id: string };
}

export interface RoomLensDescriptor {
  id: string;
  name: string;
  purpose: string;
  roomKind?: string;
  room_kind?: string;
  parentRoomId?: string | null;
  actorAccessLevel?: string | null;
  [key: string]: unknown;
}

export interface RoomLensEntry<TTwin = unknown, TDescriptor = RoomLensDescriptor> {
  roomId: string;
  descriptor: TDescriptor;
  result: RoomQueryPage<TTwin>;
}

export interface RoomLensSnapshot<TTwin = unknown, TDescriptor = RoomLensDescriptor> {
  entries: RoomLensEntry<TTwin, TDescriptor>[];
  revision: number;
  projection?: {
    projectorId: string;
    value: unknown;
  };
}

export type RoomLinkProjectionState =
  | "awaiting_approval"
  | "awaiting_target_authority"
  | "secret_materialization_pending"
  | "ready"
  | "revoked";

/** Rebuildable Contract read model. It explains Room-link readiness but is
 * never an authorization input or a second source of Contract truth. */
export interface RoomLinkProjectionStatus {
  contractLineageCid: string;
  contractVersionCid: string;
  contractVersion: number;
  profile: string;
  sourceRoomLineageCid: string;
  targetRoomLineageCid: string;
  sourceRoomId?: string;
  sourceRoomName?: string;
  targetRoomId?: string;
  targetRoomName?: string;
  state: RoomLinkProjectionState;
  approvalStatus: "valid" | "awaiting_approval" | "stale_authority";
  desiredGrantCount: number;
  materializedGrantCount: number;
  pendingGrantCount: number;
  desiredSecretCount: number;
  materializedSecretCount: number;
  pendingSecretCount: number;
}

export function roomLinkProjectionStatuses<TTwin, TDescriptor>(
  snapshot: Pick<RoomLensSnapshot<TTwin, TDescriptor>, "projection">,
): RoomLinkProjectionStatus[] {
  if (snapshot.projection?.projectorId !== "room-link-status.v1") return [];
  const value = snapshot.projection.value;
  if (!value || typeof value !== "object" || !Array.isArray((value as { links?: unknown }).links)) {
    return [];
  }
  return (value as { links: unknown[] }).links.filter((link): link is RoomLinkProjectionStatus => (
    Boolean(link)
    && typeof link === "object"
    && typeof (link as RoomLinkProjectionStatus).contractLineageCid === "string"
    && typeof (link as RoomLinkProjectionStatus).contractVersionCid === "string"
    && typeof (link as RoomLinkProjectionStatus).state === "string"
  ));
}

export interface RoomLensChangeSet {
  revision: number;
  roomIds?: string[];
  contentTypes?: string[];
  directoryChanged?: boolean;
}

export type RoomLensEvent<TTwin = unknown, TDescriptor = RoomLensDescriptor> =
  | {
      type: "snapshot";
      demand: RoomLensDemand;
      snapshot: RoomLensSnapshot<TTwin, TDescriptor>;
    }
  | { type: "invalidated"; change: RoomLensChangeSet };

export interface RoomAccessState {
  accessible: boolean;
  residency: RoomResidency;
  availability: RoomAvailability;
  source?: RoomObservationSource | null;
  localTwinCount: number;
  advertisedTwinCount: number;
  complete: boolean;
}

export interface RoomQueryEntry<TTwin = unknown> {
  seq: number;
  cid: string;
  twin: TTwin;
  lineageCid?: string;
}

/** Provenance of one actor-scoped Room view. Revisions are comparable only
 * when every identity field except `revision` matches. */
export interface RoomViewToken {
  protocolVersion: 1;
  roomId: string;
  actorDid: string;
  servingStationDid: string;
  streamEpoch: string;
  revision: number;
  authorizationGlobalEpoch: number;
  authorizationRoomEpoch: number;
  projector: string;
}

export interface RoomQueryPage<TTwin = unknown> {
  cursor: { room_id: string; seq: number };
  head: { room_id: string; seq: number };
  entries: RoomQueryEntry<TTwin>[];
  /** Older peers may omit this additive provenance token. */
  viewToken?: RoomViewToken;
}

export interface RoomQueryResponse<TTwin = unknown> {
  roomId: string;
  state: RoomAccessState;
  result: RoomQueryPage<TTwin>;
}

/**
 * One causal Room change, emitted by every host adapter in this exact shape.
 * `revision` is the monotonic Room-log head, never a client wall clock.
 */
export interface RoomRealtimeEvent {
  type: "twins_inserted";
  room_id: string;
  cids: string[];
  revision: number;
  content_types: string[];
  relation_types: string[];
  /** Numeric revisions never compare across different stream epochs. */
  stream_epoch?: string;
}

export interface RoomDataPlane<TTwin = unknown> {
  queryRoom(roomId: string, query: RoomQuery): Promise<RoomQueryResponse<TTwin>>;
  subscribeRoomEvents(listener: (event: RoomRealtimeEvent) => void): () => void;
  retainRoomObservation?(roomId: string, query: RoomQuery): void | Promise<void>;
  releaseRoomObservation?(roomId: string, query: RoomQuery): void | Promise<void>;
  queryRoomLens?<TDescriptor = RoomLensDescriptor>(
    demand: RoomLensDemand,
  ): Promise<RoomLensSnapshot<TTwin, TDescriptor>>;
  subscribeRoomLensEvents?<TDescriptor = RoomLensDescriptor>(
    listener: (event: RoomLensEvent<TTwin, TDescriptor>) => void,
  ): () => void;
  retainRoomLens?(demand: RoomLensDemand): void | Promise<void>;
  releaseRoomLens?(demand: RoomLensDemand): void | Promise<void>;
}

export interface RoomQueryError {
  code: "offline" | "forbidden" | "invalid" | "unknown";
  message: string;
  cause?: unknown;
}

export interface RoomQuerySnapshot<TTwin = unknown> {
  entries: RoomQueryEntry<TTwin>[];
  /** True only before the first renderable snapshot exists. */
  isPending: boolean;
  /** Background refresh; existing entries remain renderable. */
  isRefreshing: boolean;
  hasSnapshot: boolean;
  availability: RoomAvailability;
  source: RoomObservationSource | null;
  error: RoomQueryError | null;
  revision: number;
  viewToken: RoomViewToken | null;
  cursor: number;
  updatedAtMs: number | null;
}

export interface RoomLensStoreSnapshot<TTwin = unknown, TDescriptor = RoomLensDescriptor> {
  entries: RoomLensEntry<TTwin, TDescriptor>[];
  projection?: RoomLensSnapshot<TTwin, TDescriptor>["projection"];
  isPending: boolean;
  isRefreshing: boolean;
  hasSnapshot: boolean;
  error: RoomQueryError | null;
  revision: number;
  updatedAtMs: number | null;
}

export interface AsyncResourceSnapshot<T> {
  data: T | null;
  isPending: boolean;
  isRefreshing: boolean;
  hasSnapshot: boolean;
  error: unknown | null;
  updatedAtMs: number | null;
}

type Listener = () => void;

/**
 * Small platform-neutral stale-while-revalidate store for native resources
 * that are not Rooms themselves (for example the Station roster/catalog).
 * It has the same no-flicker loading contract as RoomQueryStore.
 */
export class AsyncResourceStore<T> {
  private readonly listeners = new Set<Listener>();
  private snapshot: AsyncResourceSnapshot<T> = {
    data: null,
    isPending: true,
    isRefreshing: false,
    hasSnapshot: false,
    error: null,
    updatedAtMs: null,
  };
  private inFlight: Promise<AsyncResourceSnapshot<T>> | null = null;
  private loader: () => Promise<T>;

  constructor(loader: () => Promise<T>) {
    this.loader = loader;
  }

  setLoader(loader: () => Promise<T>): void {
    this.loader = loader;
  }

  readonly getSnapshot = (): AsyncResourceSnapshot<T> => this.snapshot;

  readonly subscribe = (listener: Listener): (() => void) => {
    this.listeners.add(listener);
    if (this.listeners.size === 1 && !this.snapshot.hasSnapshot && !this.inFlight) {
      void this.refresh().catch(() => undefined);
    }
    return () => this.listeners.delete(listener);
  };

  refresh(): Promise<AsyncResourceSnapshot<T>> {
    if (this.inFlight) return this.inFlight;
    this.publish({
      ...this.snapshot,
      isPending: !this.snapshot.hasSnapshot,
      isRefreshing: this.snapshot.hasSnapshot,
      error: null,
    });
    this.inFlight = this.loader()
      .then((data) => {
        this.publish({
          data,
          isPending: false,
          isRefreshing: false,
          hasSnapshot: true,
          error: null,
          updatedAtMs: Date.now(),
        });
        return this.snapshot;
      })
      .catch((error: unknown) => {
        this.publish({
          ...this.snapshot,
          isPending: false,
          isRefreshing: false,
          error,
        });
        return this.snapshot;
      })
      .finally(() => {
        this.inFlight = null;
      });
    return this.inFlight;
  }

  mutate(value: T | ((current: T | null) => T)): void {
    const data = typeof value === "function"
      ? (value as (current: T | null) => T)(this.snapshot.data)
      : value;
    this.publish({
      data,
      isPending: false,
      isRefreshing: this.snapshot.isRefreshing,
      hasSnapshot: true,
      error: null,
      updatedAtMs: Date.now(),
    });
  }

  private publish(snapshot: AsyncResourceSnapshot<T>): void {
    this.snapshot = snapshot;
    for (const listener of this.listeners) listener();
  }
}

const EMPTY_SNAPSHOT: RoomQuerySnapshot<never> = Object.freeze({
  entries: [],
  isPending: true,
  isRefreshing: false,
  hasSnapshot: false,
  availability: "connecting",
  source: null,
  error: null,
  revision: 0,
  viewToken: null,
  cursor: 0,
  updatedAtMs: null,
});

/** Stable normalization shared by browser, desktop, and React Native query registries. */
export function normalizeRoomQuery(query: RoomQuery): RoomQuery {
  const unique = (values: readonly string[] | undefined) => (
    [...new Set((values ?? []).map((value) => value.trim()).filter(Boolean))].sort()
  );
  const contentType = query.contentType?.trim() || undefined;
  return {
    mode: query.mode,
    afterSeq: Math.max(0, Math.trunc(query.afterSeq ?? 0)),
    ...(contentType ? { contentType } : {}),
    ...(unique(query.contentTypes).length ? { contentTypes: unique(query.contentTypes) } : {}),
    ...(unique(query.schemaCids).length ? { schemaCids: unique(query.schemaCids) } : {}),
    ...(unique(query.lineageCids).length ? { lineageCids: unique(query.lineageCids) } : {}),
    ...(query.predicates?.length ? {
      predicates: [...query.predicates]
        .map((predicate) => ({ ...predicate, field: predicate.field.trim() }))
        .filter((predicate) => predicate.field.length > 0)
        .sort((left, right) => stableStringify(left).localeCompare(stableStringify(right))),
    } : {}),
    ...(query.order ? { order: { ...query.order, field: query.order.field.trim() } } : {}),
    ...(query.after ? { after: { ...query.after, lineageCid: query.after.lineageCid.trim() } } : {}),
    limit: Math.min(
      query.mode === "heads" ? 50_000 : 500,
      Math.max(1, Math.trunc(query.limit ?? 100)),
    ),
  };
}

/** Collapse several consumer interests into one lossless host observation.
 * Exact predicates, ordering and pagination remain consumer queries; the host
 * observation only needs to cover every change that could invalidate them. */
export function mergeRoomObservationQueries(queries: readonly RoomQuery[]): RoomQuery | null {
  if (queries.length === 0) return null;
  const normalized = queries.map(normalizeRoomQuery);
  const requestedTypes = normalized.map((query) => [
    ...(query.contentType ? [query.contentType] : []),
    ...(query.contentTypes ?? []),
  ]);
  const contentTypes = [...new Set(requestedTypes.flat())].sort();
  const mode = normalized.some((query) => query.mode === "log") ? "log" : "heads";
  const everyQueryIsTypeBounded = requestedTypes.every((types) => types.length > 0);
  return {
    mode,
    ...(everyQueryIsTypeBounded && contentTypes.length > 0 ? { contentTypes } : {}),
    limit: mode === "heads" ? 50_000 : 500,
  };
}

export function roomQueryKey(roomId: string, query: RoomQuery): string {
  return `${roomId.trim()}\0${stableStringify(normalizeRoomQuery(query))}`;
}

export function normalizeRoomLensDemand(demand: RoomLensDemand): RoomLensDemand {
  const unique = (values: readonly string[] | undefined) => (
    [...new Set((values ?? []).map((value) => value.trim()).filter(Boolean))].sort()
  );
  const roomIds = unique(demand.selector?.roomIds);
  const installedAppIds = unique(demand.selector?.installedAppIds);
  const roomKinds = unique(demand.selector?.roomKinds);
  return {
    actorDid: demand.actorDid.trim(),
    selector: {
      ...(roomIds.length ? { roomIds } : {}),
      ...(installedAppIds.length ? { installedAppIds } : {}),
      ...(roomKinds.length ? { roomKinds } : {}),
    },
    query: normalizeRoomQuery(demand.query),
    priority: demand.priority ?? "lens",
    ...(demand.projector?.id.trim()
      ? { projector: { id: demand.projector.id.trim() } }
      : {}),
  };
}

export function roomLensKey(demand: RoomLensDemand): string {
  return stableStringify(normalizeRoomLensDemand(demand));
}

export function roomEventMatchesQuery(event: RoomRealtimeEvent, roomId: string, query: RoomQuery): boolean {
  if (event.room_id !== roomId) return false;
  if (event.content_types.length === 0 && event.relation_types.length === 0) return true;
  if (event.relation_types.includes("deletes")) return true;
  const normalized = normalizeRoomQuery(query);
  const requested = [normalized.contentType, ...(normalized.contentTypes ?? [])]
    .filter((value): value is string => Boolean(value));
  return requested.length === 0
    || event.content_types.some((contentType) => requested.includes(contentType));
}

/**
 * Cross-platform stale-while-revalidate Room store.
 *
 * The first subscriber retains one native/server observation. Matching event
 * bursts are collapsed into one refresh, concurrent refreshes share a promise,
 * and transport failures never erase the last verified snapshot.
 */
export class RoomQueryStore<TTwin = unknown> {
  private readonly listeners = new Set<Listener>();
  private readonly query: RoomQuery;
  private snapshot: RoomQuerySnapshot<TTwin> = EMPTY_SNAPSHOT as RoomQuerySnapshot<TTwin>;
  private unsubscribeEvents: (() => void) | null = null;
  private inFlight: Promise<RoomQuerySnapshot<TTwin>> | null = null;
  private queued = false;
  private eventRefreshQueued = false;
  private retained = false;
  private latestEventRevision = 0;
  private latestEventStreamEpoch: string | null = null;
  private causalRetryTimer: ReturnType<typeof setTimeout> | null = null;
  private causalRetryAttempt = 0;

  constructor(
    private readonly plane: RoomDataPlane<TTwin>,
    readonly roomId: string,
    query: RoomQuery,
  ) {
    this.query = normalizeRoomQuery(query);
  }

  readonly getSnapshot = (): RoomQuerySnapshot<TTwin> => this.snapshot;

  readonly subscribe = (listener: Listener): (() => void) => {
    this.listeners.add(listener);
    if (this.listeners.size === 1) this.start();
    return () => {
      this.listeners.delete(listener);
      if (this.listeners.size === 0) this.stop();
    };
  };

  refresh(): Promise<RoomQuerySnapshot<TTwin>> {
    if (this.inFlight) {
      this.queued = true;
      return this.inFlight;
    }
    this.inFlight = this.refreshLoop().finally(() => {
      this.inFlight = null;
    });
    return this.inFlight;
  }

  dispose(): void {
    this.listeners.clear();
    this.stop();
  }

  private start(): void {
    if (!this.unsubscribeEvents) {
      this.unsubscribeEvents = this.plane.subscribeRoomEvents((event) => this.onRoomEvent(event));
    }
    if (!this.retained) {
      this.retained = true;
      void this.plane.retainRoomObservation?.(this.roomId, this.query);
    }
    if (!this.snapshot.hasSnapshot && !this.inFlight) {
      void this.refresh().catch(() => undefined);
    }
  }

  private stop(): void {
    this.unsubscribeEvents?.();
    this.unsubscribeEvents = null;
    if (this.retained) {
      this.retained = false;
      void this.plane.releaseRoomObservation?.(this.roomId, this.query);
    }
    if (this.causalRetryTimer) {
      clearTimeout(this.causalRetryTimer);
      this.causalRetryTimer = null;
    }
  }

  private onRoomEvent(event: RoomRealtimeEvent): void {
    if (!roomEventMatchesQuery(event, this.roomId, this.query)) return;
    const streamEpoch = event.stream_epoch?.trim() || null;
    if (streamEpoch && streamEpoch !== this.latestEventStreamEpoch) {
      const changed = this.latestEventStreamEpoch !== null;
      this.latestEventStreamEpoch = streamEpoch;
      this.latestEventRevision = 0;
      this.causalRetryAttempt = 0;
      if (changed && this.snapshot.hasSnapshot) {
        this.publish({ ...this.snapshot, availability: "stale" });
      }
    }
    if (event.revision > 0 && event.revision <= this.latestEventRevision) return;
    this.latestEventRevision = Math.max(this.latestEventRevision, event.revision);
    if (this.eventRefreshQueued) return;
    this.eventRefreshQueued = true;
    enqueueMicrotask(() => {
      this.eventRefreshQueued = false;
      void this.refresh().catch(() => undefined);
    });
  }

  private async refreshLoop(): Promise<RoomQuerySnapshot<TTwin>> {
    let next = this.snapshot;
    do {
      this.queued = false;
      next = await this.refreshOnce();
    } while (this.queued);
    return next;
  }

  private async refreshOnce(): Promise<RoomQuerySnapshot<TTwin>> {
    this.publish({
      ...this.snapshot,
      isPending: !this.snapshot.hasSnapshot,
      isRefreshing: this.snapshot.hasSnapshot,
      error: null,
    });
    try {
      const response = await this.plane.queryRoom(this.roomId, this.query);
      const revision = response.result.head.seq;
      const viewToken = response.result.viewToken ?? null;
      const wrongView = viewToken !== null && (
        viewToken.roomId !== this.roomId
        || viewToken.actorDid.trim().length === 0
        || viewToken.revision !== revision
      );
      if (wrongView) {
        throw new Error("station returned a mismatched Room view token");
      }
      const wrongEpoch = this.latestEventStreamEpoch !== null
        && viewToken !== null
        && viewToken.streamEpoch !== this.latestEventStreamEpoch;
      const behindEvent = this.latestEventRevision > 0 && revision < this.latestEventRevision;
      const needsCausalCatchUp = wrongEpoch || behindEvent;
      const availability = needsCausalCatchUp ? "stale" : response.state.availability;
      this.publish({
        entries: response.result.entries,
        isPending: false,
        isRefreshing: false,
        hasSnapshot: true,
        availability,
        source: response.state.source ?? null,
        error: null,
        revision,
        viewToken,
        cursor: response.result.cursor.seq,
        updatedAtMs: Date.now(),
      });
      if (needsCausalCatchUp) {
        this.scheduleCausalRetry();
      } else {
        this.causalRetryAttempt = 0;
        if (this.causalRetryTimer) {
          clearTimeout(this.causalRetryTimer);
          this.causalRetryTimer = null;
        }
      }
    } catch (cause) {
      const error = normalizeRoomQueryError(cause);
      this.publish({
        ...this.snapshot,
        isPending: false,
        isRefreshing: false,
        availability: this.snapshot.hasSnapshot ? "stale" : "unavailable",
        error,
      });
    }
    return this.snapshot;
  }

  private scheduleCausalRetry(): void {
    if (this.listeners.size === 0 || this.causalRetryTimer || this.causalRetryAttempt >= 6) return;
    const delayMs = Math.min(2_000, 100 * (2 ** this.causalRetryAttempt));
    this.causalRetryAttempt += 1;
    this.causalRetryTimer = setTimeout(() => {
      this.causalRetryTimer = null;
      void this.refresh().catch(() => undefined);
    }, delayMs);
  }

  private publish(snapshot: RoomQuerySnapshot<TTwin>): void {
    this.snapshot = snapshot;
    for (const listener of this.listeners) listener();
  }
}

const EMPTY_LENS_SNAPSHOT: RoomLensStoreSnapshot<never, never> = Object.freeze({
  entries: [],
  isPending: true,
  isRefreshing: false,
  hasSnapshot: false,
  error: null,
  revision: 0,
  updatedAtMs: null,
});

/** Shared dynamic Room-lens store used by HTTP/SSE, Electron IPC and native
 * Pocket Station adapters. Full snapshots replace directory membership while
 * transport failures preserve the last verified result. */
export class RoomLensStore<TTwin = unknown, TDescriptor = RoomLensDescriptor> {
  private readonly listeners = new Set<Listener>();
  private readonly demand: RoomLensDemand;
  private readonly key: string;
  private snapshot = EMPTY_LENS_SNAPSHOT as RoomLensStoreSnapshot<TTwin, TDescriptor>;
  private unsubscribeEvents: (() => void) | null = null;
  private inFlight: Promise<RoomLensStoreSnapshot<TTwin, TDescriptor>> | null = null;
  private queued = false;
  private eventRefreshQueued = false;
  private retained = false;

  constructor(private readonly plane: RoomDataPlane<TTwin>, demand: RoomLensDemand) {
    this.demand = normalizeRoomLensDemand(demand);
    this.key = roomLensKey(this.demand);
  }

  readonly getSnapshot = (): RoomLensStoreSnapshot<TTwin, TDescriptor> => this.snapshot;

  readonly subscribe = (listener: Listener): (() => void) => {
    this.listeners.add(listener);
    if (this.listeners.size === 1) this.start();
    return () => {
      this.listeners.delete(listener);
      if (this.listeners.size === 0) this.stop();
    };
  };

  refresh(): Promise<RoomLensStoreSnapshot<TTwin, TDescriptor>> {
    if (this.inFlight) {
      this.queued = true;
      return this.inFlight;
    }
    this.inFlight = this.refreshLoop().finally(() => {
      this.inFlight = null;
    });
    return this.inFlight;
  }

  dispose(): void {
    this.listeners.clear();
    this.stop();
  }

  private start(): void {
    if (!this.unsubscribeEvents && this.plane.subscribeRoomLensEvents) {
      this.unsubscribeEvents = this.plane.subscribeRoomLensEvents<TDescriptor>((event) => {
        this.onEvent(event);
      });
    }
    if (!this.snapshot.hasSnapshot && !this.inFlight) {
      void this.refresh()
        .catch(() => undefined)
        .finally(() => this.retain());
    } else {
      this.retain();
    }
  }

  private retain(): void {
    if (this.retained) return;
    this.retained = true;
    void this.plane.retainRoomLens?.(this.demand);
  }

  private stop(): void {
    this.unsubscribeEvents?.();
    this.unsubscribeEvents = null;
    if (this.retained) {
      this.retained = false;
      void this.plane.releaseRoomLens?.(this.demand);
    }
  }

  private onEvent(event: RoomLensEvent<TTwin, TDescriptor>): void {
    if (event.type === "snapshot") {
      if (roomLensKey(event.demand) !== this.key) return;
      this.publishResult(event.snapshot);
      return;
    }
    if (event.change.revision > 0 && event.change.revision <= this.snapshot.revision) return;
    const selectedRoomIds = this.demand.selector?.roomIds ?? [];
    if (
      !event.change.directoryChanged
      && selectedRoomIds.length > 0
      && (event.change.roomIds ?? []).length > 0
      && !(event.change.roomIds ?? []).some((roomId) => selectedRoomIds.includes(roomId))
    ) return;
    const changedTypes = event.change.contentTypes ?? [];
    if (!event.change.directoryChanged && changedTypes.length > 0) {
      const requested = [
        this.demand.query.contentType,
        ...(this.demand.query.contentTypes ?? []),
      ].filter((value): value is string => Boolean(value));
      if (requested.length > 0 && !changedTypes.some((type) => requested.includes(type))) return;
    }
    if (this.eventRefreshQueued) return;
    this.eventRefreshQueued = true;
    enqueueMicrotask(() => {
      this.eventRefreshQueued = false;
      void this.refresh().catch(() => undefined);
    });
  }

  private async refreshLoop(): Promise<RoomLensStoreSnapshot<TTwin, TDescriptor>> {
    let next = this.snapshot;
    do {
      this.queued = false;
      next = await this.refreshOnce();
    } while (this.queued);
    return next;
  }

  private async refreshOnce(): Promise<RoomLensStoreSnapshot<TTwin, TDescriptor>> {
    this.publish({
      ...this.snapshot,
      isPending: !this.snapshot.hasSnapshot,
      isRefreshing: this.snapshot.hasSnapshot,
      error: null,
    });
    try {
      if (!this.plane.queryRoomLens) throw new Error("Room lens data plane is unavailable");
      const result = await this.plane.queryRoomLens<TDescriptor>(this.demand);
      this.publishResult(result);
    } catch (cause) {
      this.publish({
        ...this.snapshot,
        isPending: false,
        isRefreshing: false,
        error: normalizeRoomQueryError(cause),
      });
    }
    return this.snapshot;
  }

  private publishResult(result: RoomLensSnapshot<TTwin, TDescriptor>): void {
    if (result.revision > 0 && result.revision < this.snapshot.revision) return;
    this.publish({
      entries: [...result.entries].sort((left, right) => left.roomId.localeCompare(right.roomId)),
      projection: result.projection,
      isPending: false,
      isRefreshing: false,
      hasSnapshot: true,
      error: null,
      revision: Math.max(this.snapshot.revision, result.revision),
      updatedAtMs: Date.now(),
    });
  }

  private publish(snapshot: RoomLensStoreSnapshot<TTwin, TDescriptor>): void {
    this.snapshot = snapshot;
    for (const listener of this.listeners) listener();
  }
}

export class RoomRuntime<TTwin = unknown> {
  private readonly stores = new Map<string, RoomQueryStore<TTwin>>();
  private readonly lensStores = new Map<string, RoomLensStore<TTwin, unknown>>();

  constructor(readonly dataPlane: RoomDataPlane<TTwin>) {}

  query(roomId: string, query: RoomQuery): RoomQueryStore<TTwin> {
    const key = roomQueryKey(roomId, query);
    let store = this.stores.get(key);
    if (!store) {
      store = new RoomQueryStore(this.dataPlane, roomId, query);
      this.stores.set(key, store);
    }
    return store;
  }

  lens<TDescriptor = RoomLensDescriptor>(
    demand: RoomLensDemand,
  ): RoomLensStore<TTwin, TDescriptor> {
    const key = roomLensKey(demand);
    let store = this.lensStores.get(key) as RoomLensStore<TTwin, TDescriptor> | undefined;
    if (!store) {
      store = new RoomLensStore<TTwin, TDescriptor>(this.dataPlane, demand);
      this.lensStores.set(key, store as RoomLensStore<TTwin, unknown>);
    }
    return store;
  }

  dispose(): void {
    for (const store of this.stores.values()) store.dispose();
    for (const store of this.lensStores.values()) store.dispose();
    this.stores.clear();
    this.lensStores.clear();
  }
}

export function normalizeRoomQueryError(cause: unknown): RoomQueryError {
  const raw = cause instanceof Error ? cause.message : String(cause);
  if (/403|forbidden|lacks (?:read|write)|not authorized/i.test(raw)) {
    return { code: "forbidden", message: "Du hast keinen Zugriff auf diesen Room.", cause };
  }
  if (/timeout|timed out|offline|unavailable|unreachable|no snapshot|stream closed|connect/i.test(raw)) {
    return {
      code: "offline",
      message: "Der Room ist gerade nicht erreichbar. Verifizierte lokale Daten bleiben verfügbar.",
      cause,
    };
  }
  if (/invalid|malformed|missing/i.test(raw)) {
    return { code: "invalid", message: "Die Room-Anfrage ist ungültig.", cause };
  }
  return { code: "unknown", message: "Der Room konnte nicht aktualisiert werden.", cause };
}

function stableStringify(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(record[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

export * from "./multi-room-query";
export * from "./agent-avatar-theme";
export * from "./agent-avatar-image";

function enqueueMicrotask(callback: () => void): void {
  if (typeof queueMicrotask === "function") queueMicrotask(callback);
  else void Promise.resolve().then(callback);
}
