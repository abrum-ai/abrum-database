/**
 * Shared back-off for a transiently failing uploaded Agent image. The browser
 * host uses it to remount the image with a fresh cache key; native hosts can
 * reuse the same schedule when they render remote URLs.
 */
export const AGENT_AVATAR_RETRY_DELAYS_MS = [1_000, 2_000, 4_000, 8_000, 16_000, 30_000] as const;

/**
 * Give an immutable Station blob URL a fresh cache key after a transient load
 * failure. Data/blob URLs are already local and cannot use query parameters
 * safely, so remounting the image is enough for those.
 */
export function retryableAgentAvatarUrl(imageUrl: string, retryAttempt: number): string {
  const attempt = Math.max(0, Math.trunc(retryAttempt));
  if (attempt === 0 || /^(?:blob|data):/i.test(imageUrl)) return imageUrl;

  const fragmentIndex = imageUrl.indexOf("#");
  const base = fragmentIndex >= 0 ? imageUrl.slice(0, fragmentIndex) : imageUrl;
  const fragment = fragmentIndex >= 0 ? imageUrl.slice(fragmentIndex) : "";
  const separator = base.includes("?") ? "&" : "?";
  return `${base}${separator}abrum-avatar-retry=${attempt}${fragment}`;
}
