import { useEffect, useMemo, useRef } from "react";
import {
  postAbrumSidebarNavigation,
  readEmbedSignal,
  readAbrumSidebarNavigationSelect,
  type AbrumSidebarNavigationItem,
} from "@abrum/web-runtime/contracts";

export type { AbrumSidebarNavigationItem } from "@abrum/web-runtime/contracts";

export interface UseAbrumSidebarNavigationOptions {
  items: readonly AbrumSidebarNavigationItem[];
  activeItemId: string;
  onSelect: (itemId: string) => void;
  enabled?: boolean;
}

/** Publish an app-owned hierarchy into a host that explicitly owns the left tree. */
export function useAbrumSidebarNavigation({
  items,
  activeItemId,
  onSelect,
  enabled = true,
}: UseAbrumSidebarNavigationOptions): boolean {
  const embed = useMemo(() => readEmbedSignal(), []);
  const supported = Boolean(
    enabled
      && embed?.sidebarNavigation
      && typeof window !== "undefined"
      && window.parent !== window,
  );
  const onSelectRef = useRef(onSelect);
  const itemsRef = useRef(items);
  const activeItemIdRef = useRef(activeItemId);

  useEffect(() => {
    onSelectRef.current = onSelect;
    itemsRef.current = items;
    activeItemIdRef.current = activeItemId;
  }, [activeItemId, items, onSelect]);

  useEffect(() => {
    if (!supported) return;
    postAbrumSidebarNavigation({ items: [...items], activeItemId }, { appId: embed?.appId });
  }, [activeItemId, embed?.appId, items, supported]);

  useEffect(() => {
    if (!supported) return;
    const onMessage = (event: MessageEvent) => {
      if (event.source !== window.parent) return;
      if (event.data?.type === "abrum:surface-status-request") {
        postAbrumSidebarNavigation({ items: [...itemsRef.current], activeItemId: activeItemIdRef.current }, { appId: embed?.appId });
        return;
      }
      const selection = readAbrumSidebarNavigationSelect(event.data);
      if (!selection) return;
      const item = itemsRef.current.find((candidate) => candidate.id === selection.itemId);
      if (!item || item.disabled) return;
      onSelectRef.current(item.id);
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [embed?.appId, supported]);

  useEffect(() => {
    if (!supported) return;
    return () => {
      postAbrumSidebarNavigation({ items: [], activeItemId: "" }, { appId: embed?.appId });
    };
  }, [embed?.appId, supported]);

  return supported;
}
