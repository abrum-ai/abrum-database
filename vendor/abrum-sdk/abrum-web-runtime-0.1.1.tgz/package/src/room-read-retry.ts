/** Stable client-side classification until every transport carries typed errors.
 * Keep protocol wording here, never in components or translation catalogs. */
export function roomReadErrorCode(reason: unknown): "room.authorization_changed" | null {
  const message = reason instanceof Error ? reason.message : String(reason ?? "");
  return message.includes("Room authorization changed while the view was being evaluated; retry the query")
    ? "room.authorization_changed" : null;
}

/** Read-only recovery: one fresh authorized query, never a write or stale cache.
 * A second conflict, revocation, or other error remains a real failure. */
export async function retryRoomAuthorizationRead<T>(read: () => Promise<T>): Promise<T> {
  try { return await read(); }
  catch (reason) {
    if (roomReadErrorCode(reason) !== "room.authorization_changed") throw reason;
    return read();
  }
}
