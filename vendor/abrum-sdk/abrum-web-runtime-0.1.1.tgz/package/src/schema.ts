import type { JsonValue, SignedTwin, SyncPushResult, TwinLogEntry } from "./index";

export type AbrumFieldKind = "string" | "number" | "boolean" | "date" | "json" | "any";

export interface AbrumFieldDescriptor {
  kind: AbrumFieldKind;
  required: boolean;
  indexed: boolean;
  unique: boolean;
}

export type AbrumFieldValue<F> = F extends AbrumField<infer T, boolean> ? T : never;

export class AbrumField<T, Required extends boolean = true> {
  readonly descriptor: AbrumFieldDescriptor;
  // Phantom brand: makes the `Required` type param structurally significant. Without
  // it, AbrumField<T,true> and AbrumField<T,false> are identical types, so
  // RequiredFieldKeys matches EVERY field and OptionalFieldKeys collapses to `never`
  // — `.optional()` had no effect on AbrumEntityInput and every create() demanded all
  // fields (the #476 root cause: apps padded placeholders like portableValue: null,
  // or casted past the check). `declare` keeps it type-only: nothing at runtime.
  declare readonly __required__: Required;

  private constructor(descriptor: AbrumFieldDescriptor) {
    this.descriptor = descriptor;
  }

  static of<T>(kind: AbrumFieldKind): AbrumField<T, true> {
    return new AbrumField<T, true>({
      kind,
      required: true,
      indexed: false,
      unique: false,
    });
  }

  optional(): AbrumField<T, false> {
    return new AbrumField<T, false>({ ...this.descriptor, required: false });
  }

  index(): AbrumField<T, Required> {
    return new AbrumField<T, Required>({ ...this.descriptor, indexed: true });
  }

  indexed(): AbrumField<T, Required> {
    return this.index();
  }

  unique(): AbrumField<T, Required> {
    return new AbrumField<T, Required>({ ...this.descriptor, indexed: true, unique: true });
  }
}

export type AbrumEntityFields = Record<string, AbrumField<unknown, boolean>>;

export interface AbrumEntityOptions {
  schemaName?: string;
  contentType?: string;
  scope: "room";
}

export class AbrumEntity<Fields extends AbrumEntityFields> {
  readonly fields: Fields;
  readonly options: AbrumEntityOptions;

  constructor(fields: Fields, options?: Partial<AbrumEntityOptions>) {
    this.fields = fields;
    this.options = {
      scope: "room",
      ...options,
    };
  }

  roomScoped(): AbrumEntity<Fields> {
    return new AbrumEntity(this.fields, { ...this.options, scope: "room" });
  }

  named(schemaName: string): AbrumEntity<Fields> {
    return new AbrumEntity(this.fields, { ...this.options, schemaName });
  }

  type(contentType: string): AbrumEntity<Fields> {
    return new AbrumEntity(this.fields, { ...this.options, contentType });
  }
}

export type AbrumEntities = Record<string, AbrumEntity<AbrumEntityFields>>;

/**
 * A function an app registers in its manifest. The same declaration drives the
 * agent tool the assistant calls AND the typed UI binding (`useAbrumActions`) —
 * both round-trip through `/api/apps/run` → the station's `run_app_function`.
 * `Input` is a phantom carrier for the function's argument type; it is never
 * present at runtime.
 */
export interface AbrumAppFunctionDef<Input = JsonValue, Output = JsonValue> {
  name: string;
  runtime?: string;
  description?: string;
  readonly __input?: Input;
  readonly __output?: Output;
}

// The record value uses `AbrumAppFunctionDef<any>` so a concrete input type
// (e.g. `AbrumAppFunctionDef<QueueTaskInput>`) is assignable to the constraint —
// pinning it to the `JsonValue` default would reject every typed function.
export type AbrumAppFunctions = Record<string, AbrumAppFunctionDef<any, any>>;

/** A named UI surface published by an app module. `Input` is generated from
 * the provider's JSON Schema and exists only for compile-time checking. */
export interface AbrumAppSurfaceDef<Input = JsonValue> {
  name: string;
  readonly __input?: Input;
}

export type AbrumAppSurfaces = Record<string, AbrumAppSurfaceDef<any>>;

export interface AbrumApp<
  Entities extends AbrumEntities,
  // Defaults to the permissive function map (not `Record<string, never>`) so
  // bounds written `AbrumApp<AbrumEntities>` (e.g. useAbrumDb) still accept apps that
  // declare functions. Function-less apps remain assignable: their
  // `Record<string, never>` functions map satisfies this because `never` is
  // assignable to `AbrumAppFunctionDef<any>`.
  Functions extends AbrumAppFunctions = AbrumAppFunctions,
  Surfaces extends AbrumAppSurfaces = AbrumAppSurfaces,
> {
  name: string;
  entities: Entities;
  functions: Functions;
  surfaces: Surfaces;
}

type RequiredFieldKeys<Fields extends AbrumEntityFields> = {
  [Key in keyof Fields]: Fields[Key] extends AbrumField<unknown, true> ? Key : never;
}[keyof Fields];

type OptionalFieldKeys<Fields extends AbrumEntityFields> = Exclude<keyof Fields, RequiredFieldKeys<Fields>>;

type EntityInputValue<Field> = Field extends AbrumField<infer Value, boolean> ? Value : never;
type EntityStoredValue<Field> = Field extends AbrumField<infer Value, boolean> ? StoredFieldValue<Value> : never;
type StoredFieldValue<Value> = Exclude<Value, Date> | (Extract<Value, Date> extends never ? never : string);

export type AbrumEntityInput<Entity> = Entity extends AbrumEntity<infer Fields>
  ? {
      [Key in RequiredFieldKeys<Fields>]: EntityInputValue<Fields[Key]>;
    } & {
      [Key in OptionalFieldKeys<Fields>]?: EntityInputValue<Fields[Key]> | null;
    }
  : never;

export type AbrumEntityData<Entity> = Entity extends AbrumEntity<infer Fields>
  ? {
      [Key in RequiredFieldKeys<Fields>]: EntityStoredValue<Fields[Key]>;
    } & {
      [Key in OptionalFieldKeys<Fields>]?: EntityStoredValue<Fields[Key]> | null;
    }
  : never;

export type AbrumEntityRecord<Entity> = AbrumEntityData<Entity> & {
  readonly $: {
    cid: string;
    seq: number;
    schemaCid: string | null;
    twin: SignedTwin;
    /** Root of this record's lineage — the stable identity to share, cite or
     * revoke by. Never reconstruct it from `twin.block.previousVersion`. */
    lineageCid?: string;
    /** Room this record was read from when an App Lens aggregates sources. */
    sourceRoomId?: string;
    /** Room whose authority validates mutations and shares for this projection. */
    authorityRoomId?: string;
    /** Every Room represented by this projection. Usually one; never infer
     * authority by comparing it with whichever Room the UI currently selects. */
    sourceRoomIds: readonly string[];
    /** How the current actor received this record, when the runtime can prove it. */
    shareProvenance: "owned" | "room-membership" | "direct" | "unknown";
    /** Explicit policy input for UI affordances; not inferred from selection. */
    sharedWithMe: boolean;
  };
};

export type AbrumWhere<Data> = {
  [Key in keyof Data]?: Data[Key] | {
    eq?: Data[Key];
    gt?: Data[Key];
    gte?: Data[Key];
    lt?: Data[Key];
    lte?: Data[Key];
    contains?: string;
  };
};

export interface AbrumUseManyOptions<Data> {
  where?: AbrumWhere<Data>;
  order?: [keyof Data, "asc" | "desc"];
  limit?: number;
}

export interface AbrumCreateEntityResult {
  cid: string;
  twin: SignedTwin;
  schema: SignedTwin;
  /** @deprecated Room membership is intrinsic to the Room store. */
  contains?: SignedTwin;
  push: SyncPushResult;
}

export interface AbrumUpdateEntityResult {
  cid: string;
  twin: SignedTwin;
  push: SyncPushResult;
}

export const abrum = {
  app<
    const Entities extends AbrumEntities,
    const Functions extends AbrumAppFunctions = Record<string, never>,
    const Surfaces extends AbrumAppSurfaces = Record<string, never>,
  >(
    name: string,
    entities: Entities,
    options?: { functions?: Functions; surfaces?: Surfaces },
  ): AbrumApp<Entities, Functions, Surfaces> {
    return {
      name,
      entities,
      functions: (options?.functions ?? {}) as Functions,
      surfaces: (options?.surfaces ?? {}) as Surfaces,
    };
  },

  entity<const Fields extends AbrumEntityFields>(fields: Fields): AbrumEntity<Fields> {
    return new AbrumEntity(fields);
  },

  string(): AbrumField<string> {
    return AbrumField.of<string>("string");
  },

  number(): AbrumField<number> {
    return AbrumField.of<number>("number");
  },

  boolean(): AbrumField<boolean> {
    return AbrumField.of<boolean>("boolean");
  },

  date(): AbrumField<number | string | Date> {
    return AbrumField.of<number | string | Date>("date");
  },

  json(): AbrumField<JsonValue> {
    return AbrumField.of<JsonValue>("json");
  },

  any(): AbrumField<JsonValue> {
    return AbrumField.of<JsonValue>("any");
  },
};

export const abrumSystemApp = abrum.app("abrum.system", {
  app: abrum.entity({
    appId: abrum.string().index(),
    title: abrum.string(),
    icon: abrum.string().optional(),
    description: abrum.string().optional(),
    kind: abrum.string(),
    appVersion: abrum.string().optional(),
    version: abrum.number(),
    schemas: abrum.json().optional(),
    imports: abrum.json().optional(),
    requiredSecrets: abrum.json().optional(),
    features: abrum.json().optional(),
    functions: abrum.json().optional(),
    surfaces: abrum.json().optional(),
    background: abrum.json().optional(),
    runtime: abrum.json().optional(),
    backends: abrum.json().optional(),
    artifact: abrum.json().optional(),
    executionLevel: abrum.string().optional(),
    network: abrum.json().optional(),
    updatedAtMs: abrum.date().index(),
  }).named("schema-app-v1").type("app").roomScoped(),
  appInstall: abrum.entity({
    appId: abrum.string().index(),
    appLineageCid: abrum.string().index(),
    blueprintVersionCid: abrum.string().optional().index(),
    blueprintSource: abrum.json().optional(),
    versionSelector: abrum.string().optional(),
    title: abrum.string().optional(),
    roomId: abrum.string().index(),
    enabled: abrum.boolean(),
    grant: abrum.string(),
    grantedRights: abrum.json().optional(),
    config: abrum.json().optional(),
    runtimeStatus: abrum.string().optional(),
    version: abrum.number(),
    updatedAtMs: abrum.date().index(),
  }).named("schema-app-install-v1").type("app_install").roomScoped(),
  // SK-19 · the secret schema at the RUNTIME level so `provisionSecret` can write a
  // secret twin without any app cross-importing abrum.secrets' binding ("Seam vor
  // Store": an app provisions via the seam, never the store's schema). Field set
  // MUST match abrum.secrets `schema-abrum-secret-v1` byte-for-byte so the schema CID —
  // and the station's server-side fill (try_open_secret_content) — is identical.
  secret: abrum.entity({
    name: abrum.string().index(),
    value: abrum.string(),
    label: abrum.string().optional(),
    kind: abrum.string().optional(),
    secretId: abrum.string().optional().index(),
    requiredByAppId: abrum.string().optional().index(),
    sealedValue: abrum.json().optional(),
    sealedForStationX25519: abrum.string().optional(),
    portableValue: abrum.json().optional(),
    functionsJson: abrum.json().optional(),
    firstUseWarrant: abrum.boolean().optional(),
    portable: abrum.boolean().optional(),
    createdAtMs: abrum.date().index(),
    updatedAtMs: abrum.date(),
  }).named("schema-abrum-secret-v1").type("secret").roomScoped(),
  // SK-19/DP9b · a per-account CREDENTIAL REQUEST (declaration, no value): Mail's
  // Add-account writes one via `requestSecret` so Secrets can render a generic
  // "Missing" card and offer the mapping — without Secrets ever importing the
  // mail_account schema (Seam vor Store, in the DECLARE direction). NOT a secret
  // (no sealedValue) → distinct schema/type → not AR-8-gated (the gate keys on
  // schema-abrum-secret-v1). Tombstoned when the owning account is removed.
  secret_request: abrum.entity({
    secretId: abrum.string().index(),
    requiredByAppId: abrum.string().optional().index(),
    kind: abrum.string().optional(),
    label: abrum.string().optional(),
    createdAtMs: abrum.date().index(),
    updatedAtMs: abrum.date(),
  }).named("schema-abrum-secret-request-v1").type("secret_request").roomScoped(),
});

export function entitySchemaName<App extends AbrumApp<AbrumEntities>, Name extends keyof App["entities"] & string>(
  app: App,
  entityName: Name,
): string {
  return app.entities[entityName].options.schemaName ?? `${app.name}.${entityName}.v1`;
}

export function entityContentType<App extends AbrumApp<AbrumEntities>, Name extends keyof App["entities"] & string>(
  app: App,
  entityName: Name,
): string {
  return app.entities[entityName].options.contentType ?? entityName;
}

export function entityJsonSchema<App extends AbrumApp<AbrumEntities>, Name extends keyof App["entities"] & string>(
  app: App,
  entityName: Name,
): JsonValue {
  const entity = app.entities[entityName];
  const properties: Record<string, JsonValue> = {
    type: { const: entityContentType(app, entityName) },
  };
  const required = ["type"];
  const indexed: string[] = [];
  const unique: string[] = [];

  for (const [fieldName, field] of Object.entries(entity.fields)) {
    properties[fieldName] = fieldJsonSchema(field.descriptor);
    if (field.descriptor.required) {
      required.push(fieldName);
    }
    if (field.descriptor.indexed) {
      indexed.push(fieldName);
    }
    if (field.descriptor.unique) {
      unique.push(fieldName);
    }
  }

  return {
    type: "object",
    required,
    properties,
    additionalProperties: true,
    "x-abrum": {
      app: app.name,
      entity: entityName,
      schemaName: entitySchemaName(app, entityName),
      scope: entity.options.scope,
      indexed,
      unique,
    },
  };
}

export function entityContent<App extends AbrumApp<AbrumEntities>, Name extends keyof App["entities"] & string>(
  app: App,
  entityName: Name,
  input: Record<string, unknown>,
): Record<string, JsonValue> {
  const entity = app.entities[entityName];
  const content: Record<string, JsonValue> = {
    type: entityContentType(app, entityName),
  };

  for (const [fieldName, field] of Object.entries(entity.fields)) {
    const value = input[fieldName];
    if (value === undefined || value === null) {
      if (field.descriptor.required) {
        throw new Error(`${String(entityName)}.${fieldName} is required`);
      }
      if (value === null) {
        content[fieldName] = null;
      }
      continue;
    }
    content[fieldName] = normalizeEntityField(fieldName, field.descriptor, value);
  }

  return content;
}

export function selectEntityRecords<App extends AbrumApp<AbrumEntities>, Name extends keyof App["entities"] & string>(
  app: App,
  entityName: Name,
  entries: TwinLogEntry[],
  options: AbrumUseManyOptions<AbrumEntityData<App["entities"][Name]>> = {},
): AbrumEntityRecord<App["entities"][Name]>[] {
  let records = materializeEntityRecords(app, entityName, entries, false);
  const where = options.where;
  if (where) {
    records = records.filter((record) => matchesWhere(record, where));
  }
  if (options.order) {
    const [fieldName, direction] = options.order;
    records = [...records].sort((a, b) => compareValues(a[fieldName], b[fieldName], direction));
  }
  if (options.limit !== undefined) {
    records = records.slice(0, options.limit);
  }
  return records;
}

/** Decode a Station-owned object-head projection into typed app records.
 * Predicate, ordering, limits, lineage reduction, and tombstones have already
 * been applied by Rust; this function deliberately performs no second query
 * implementation in JavaScript. */
export function decodeProjectedEntityRecords<App extends AbrumApp<AbrumEntities>, Name extends keyof App["entities"] & string>(
  app: App,
  entityName: Name,
  entries: TwinLogEntry[],
): AbrumEntityRecord<App["entities"][Name]>[] {
  return materializeEntityRecords(app, entityName, entries, true);
}

/** Merge already-projected object heads from multiple Rooms into one app lens.
 * Rust owns lineage reduction, tombstones and predicates inside each Room.
 * The cross-Room presentation layer only reapplies the requested global order
 * and limit because no individual sovereign Room can decide either globally. */
export function mergeProjectedEntityRecords<App extends AbrumApp<AbrumEntities>, Name extends keyof App["entities"] & string>(
  app: App,
  entityName: Name,
  entries: TwinLogEntry[],
  options: Pick<AbrumUseManyOptions<AbrumEntityData<App["entities"][Name]>>, "order" | "limit"> = {},
): AbrumEntityRecord<App["entities"][Name]>[] {
  let records = decodeProjectedEntityRecords(app, entityName, entries);
  if (options.order) {
    const [fieldName, direction] = options.order;
    records = [...records].sort((a, b) => compareValues(a[fieldName], b[fieldName], direction));
  }
  if (options.limit !== undefined) {
    records = records.slice(0, options.limit);
  }
  return records;
}

function materializeEntityRecords<App extends AbrumApp<AbrumEntities>, Name extends keyof App["entities"] & string>(
  app: App,
  entityName: Name,
  entries: TwinLogEntry[],
  projectionApplied: boolean,
): AbrumEntityRecord<App["entities"][Name]>[] {
  const entity = app.entities[entityName];
  const contentType = entityContentType(app, entityName);
  const schemaName = entitySchemaName(app, entityName);
  const schemaCids = new Set(
    entries
      .filter((entry) => {
        const content = asJsonRecord(entry.twin.block.content);
        return entry.twin.block.kind === "schema" && content?.name === schemaName;
      })
      .map((entry) => entry.cid),
  );

  // Superseded versions (their cid is another twin's previousVersion) and
  // tombstoned twins (a `deletes` relation targets their cid) must not surface
  // as separate records — otherwise old versions and deleted objects linger.
  const supersededCids = new Set<string>();
  const tombstonedCids = new Set<string>();
  if (!projectionApplied) {
    for (const entry of entries) {
      const block = entry.twin.block;
      if (block.previousVersion) {
        supersededCids.add(block.previousVersion);
      }
      if (block.kind === "relation") {
        const relation = asJsonRecord(block.content);
        if (relation && relation.relationType === "deletes" && typeof relation.target === "string") {
          tombstonedCids.add(relation.target);
        }
      }
    }
  }

  return entries.flatMap((entry): AbrumEntityRecord<App["entities"][Name]>[] => {
    if (entry.twin.block.kind !== "object") {
      return [];
    }
    if (supersededCids.has(entry.cid) || tombstonedCids.has(entry.cid)) {
      return [];
    }
    const content = asJsonRecord(entry.twin.block.content);
    if (!content) {
      return [];
    }
    const hasKnownSchema = entry.twin.block.schema !== null && schemaCids.has(entry.twin.block.schema);
    if (!hasKnownSchema && content.type !== contentType && content.type !== entityName) {
      return [];
    }

    const data: Record<string, JsonValue> = {};
    for (const [fieldName, field] of Object.entries(entity.fields)) {
      const value = content[fieldName];
      if (value === undefined) {
        if (field.descriptor.required) {
          return [];
        }
        continue;
      }
      data[fieldName] = value;
    }

    return [{
      ...(data as AbrumEntityData<App["entities"][Name]>),
      $: {
        cid: entry.cid,
        seq: entry.seq,
        schemaCid: entry.twin.block.schema,
        twin: entry.twin,
        lineageCid: entry.lineageCid,
        sourceRoomId: entry.sourceRoomId,
        authorityRoomId: entry.sourceRoomId,
        sourceRoomIds: entry.sourceRoomId ? [entry.sourceRoomId] : [],
        shareProvenance: "unknown",
        sharedWithMe: false,
      },
    }];
  });

}

function fieldJsonSchema(field: AbrumFieldDescriptor): JsonValue {
  const meta: Record<string, JsonValue> = {
    "x-abrum-indexed": field.indexed,
    "x-abrum-unique": field.unique,
  };
  switch (field.kind) {
    case "string":
      return { type: "string", ...meta };
    case "number":
      return { type: "integer", ...meta };
    case "boolean":
      return { type: "boolean", ...meta };
    case "date":
      return {
        anyOf: [{ type: "integer" }, { type: "string", format: "date-time" }],
        ...meta,
      };
    case "json":
    case "any":
      return meta;
  }
}

function normalizeEntityField(fieldName: string, field: AbrumFieldDescriptor, value: unknown): JsonValue {
  if (value instanceof Date) {
    if (field.kind !== "date") {
      throw new Error(`${fieldName} does not accept Date values`);
    }
    return value.toISOString();
  }
  switch (field.kind) {
    case "string":
      if (typeof value !== "string") {
        throw new Error(`${fieldName} must be a string`);
      }
      return value;
    case "number":
      if (typeof value !== "number" || !Number.isSafeInteger(value)) {
        throw new Error(`${fieldName} must be a safe integer`);
      }
      return value;
    case "boolean":
      if (typeof value !== "boolean") {
        throw new Error(`${fieldName} must be a boolean`);
      }
      return value;
    case "date":
      if (typeof value === "number") {
        if (!Number.isSafeInteger(value)) {
          throw new Error(`${fieldName} timestamp must be a safe integer`);
        }
        return value;
      }
      if (typeof value === "string") {
        return value;
      }
      throw new Error(`${fieldName} must be a timestamp, ISO date string, or Date`);
    case "json":
    case "any":
      if (!isJsonValue(value)) {
        throw new Error(`${fieldName} must be JSON-serializable`);
      }
      return value;
  }
}

function isJsonValue(value: unknown): value is JsonValue {
  if (value === null || typeof value === "string" || typeof value === "boolean") {
    return true;
  }
  if (typeof value === "number") {
    return Number.isSafeInteger(value);
  }
  if (Array.isArray(value)) {
    return value.every(isJsonValue);
  }
  if (typeof value === "object") {
    return Object.values(value as Record<string, unknown>).every(isJsonValue);
  }
  return false;
}

function asJsonRecord(value: JsonValue): Record<string, JsonValue> | null {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, JsonValue>
    : null;
}

function matchesWhere<Data>(record: Data, where: AbrumWhere<Data>): boolean {
  return Object.entries(where).every(([fieldName, expected]) => {
    const actual = (record as Record<string, unknown>)[fieldName];
    if (isOperatorWhere(expected)) {
      return matchesOperatorWhere(actual, expected);
    }
    return actual === expected;
  });
}

function isOperatorWhere(value: unknown): value is Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    return false;
  }
  return ["eq", "gt", "gte", "lt", "lte", "contains"].some((key) => key in value);
}

function matchesOperatorWhere(actual: unknown, expected: Record<string, unknown>): boolean {
  if ("eq" in expected && actual !== expected.eq) {
    return false;
  }
  if ("contains" in expected && (typeof actual !== "string" || !actual.includes(String(expected.contains)))) {
    return false;
  }
  if ("gt" in expected && !comparePredicate(actual, expected.gt, (a, b) => a > b)) {
    return false;
  }
  if ("gte" in expected && !comparePredicate(actual, expected.gte, (a, b) => a >= b)) {
    return false;
  }
  if ("lt" in expected && !comparePredicate(actual, expected.lt, (a, b) => a < b)) {
    return false;
  }
  if ("lte" in expected && !comparePredicate(actual, expected.lte, (a, b) => a <= b)) {
    return false;
  }
  return true;
}

function comparePredicate(
  actual: unknown,
  expected: unknown,
  predicate: (actual: number | string, expected: number | string) => boolean,
): boolean {
  if ((typeof actual !== "number" && typeof actual !== "string") || (typeof expected !== "number" && typeof expected !== "string")) {
    return false;
  }
  return predicate(actual, expected);
}

function compareValues(left: unknown, right: unknown, direction: "asc" | "desc"): number {
  const multiplier = direction === "asc" ? 1 : -1;
  if (left === right) {
    return 0;
  }
  if (left === undefined || left === null) {
    return 1;
  }
  if (right === undefined || right === null) {
    return -1;
  }
  return left > right ? multiplier : -multiplier;
}
