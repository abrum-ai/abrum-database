// Secret sealing primitives — the TypeScript mirror of `abrum-core::seal`.
//
// Implements the scheme in docs/secret-sealing.md (XChaCha20-Poly1305 + X25519
// + HKDF-SHA256) and is kept byte-for-byte compatible with the Rust host via the
// shared vectors in test-vectors/seal.json (see seal.test.ts).

import { x25519 } from "@noble/curves/ed25519";
import { hkdf } from "@noble/hashes/hkdf";
import { sha256 } from "@noble/hashes/sha2";
import { xchacha20poly1305 } from "@noble/ciphers/chacha";

/** AEAD algorithm tag stored in every envelope. */
export const AEAD_ALGORITHM = "xchacha20poly1305-v1";

const NONCE_LEN = 24;
const KEY_LEN = 32;
const X25519_INFO = utf8("abrum-x25519-v1");
const KEYWRAP_INFO = utf8("abrum-keywrap-v1");
const KEYWRAP_AAD = utf8("abrum-keywrap-v1");

/** A sealed value: AEAD ciphertext (with tag) plus nonce, all lowercase hex. */
export interface SealedEnvelope {
  algorithm: string;
  nonce: string;
  ciphertext: string;
}

/** A content-encryption key wrapped to one recipient's X25519 public key. */
export interface WrappedKey {
  algorithm: string;
  epk: string;
  nonce: string;
  ciphertext: string;
}

/** Seal `plaintext` under `key`, binding `aad`, with a fresh random nonce. */
export function seal(key: Uint8Array, plaintext: Uint8Array, aad: Uint8Array): SealedEnvelope {
  return sealWithNonce(key, randomBytes(NONCE_LEN), plaintext, aad);
}

/** Seal with a caller-supplied nonce (deterministic; for tests/vectors). */
export function sealWithNonce(
  key: Uint8Array,
  nonce: Uint8Array,
  plaintext: Uint8Array,
  aad: Uint8Array,
): SealedEnvelope {
  const ciphertext = xchacha20poly1305(key, nonce, aad).encrypt(plaintext);
  return { algorithm: AEAD_ALGORITHM, nonce: toHex(nonce), ciphertext: toHex(ciphertext) };
}

/** Open a sealed envelope. Throws on tag mismatch, wrong key, or bad algorithm. */
export function open(key: Uint8Array, envelope: SealedEnvelope, aad: Uint8Array): Uint8Array {
  if (envelope.algorithm !== AEAD_ALGORITHM) {
    throw new Error(`unsupported seal algorithm ${envelope.algorithm}`);
  }
  const nonce = fromHex(envelope.nonce);
  if (nonce.length !== NONCE_LEN) {
    throw new Error(`bad nonce length ${nonce.length}`);
  }
  try {
    return xchacha20poly1305(key, nonce, aad).decrypt(fromHex(envelope.ciphertext));
  } catch {
    throw new Error("secret decryption failed (wrong key or tampered ciphertext)");
  }
}

/** Generate a fresh random 32-byte content-encryption key. */
export function generateCek(): Uint8Array {
  return randomBytes(KEY_LEN);
}

/**
 * Deterministically derive a 32-byte key from input key material via
 * HKDF-SHA256 (empty salt). Same inputs always yield the same key — useful for
 * an anchor (e.g. a room creator) that must recompute a key without storing it.
 */
export function deriveKey(ikm: Uint8Array, info: string): Uint8Array {
  return hkdf(sha256, ikm, new Uint8Array(0), utf8(info), KEY_LEN);
}

/**
 * Derive a principal's X25519 keypair from its 32-byte identity seed. The stored
 * `secret` is the raw HKDF output (clamping happens at DH/public time, matching
 * x25519-dalek's `to_bytes`), so it round-trips identically with the Rust host.
 */
export function x25519KeypairFromSeed(seed: Uint8Array): { secret: Uint8Array; public: Uint8Array } {
  const secret = hkdf(sha256, seed, new Uint8Array(0), X25519_INFO, KEY_LEN);
  return { secret, public: x25519.getPublicKey(secret) };
}

/** X25519 public key for a given secret. */
export function x25519Public(secret: Uint8Array): Uint8Array {
  return x25519.getPublicKey(secret);
}

/** Wrap a CEK to `recipientPublic` using a fresh ephemeral key. */
export function wrapKey(recipientPublic: Uint8Array, cek: Uint8Array): WrappedKey {
  return wrapKeyWith(randomBytes(KEY_LEN), randomBytes(NONCE_LEN), recipientPublic, cek);
}

/** Deterministic wrap with caller-supplied ephemeral secret and nonce. */
export function wrapKeyWith(
  ephemeralSecret: Uint8Array,
  nonce: Uint8Array,
  recipientPublic: Uint8Array,
  cek: Uint8Array,
): WrappedKey {
  const epk = x25519.getPublicKey(ephemeralSecret);
  const shared = x25519.getSharedSecret(ephemeralSecret, recipientPublic);
  const wrapKeyBytes = deriveWrapKey(shared, epk, recipientPublic);
  const env = sealWithNonce(wrapKeyBytes, nonce, cek, KEYWRAP_AAD);
  return { algorithm: AEAD_ALGORITHM, epk: toHex(epk), nonce: env.nonce, ciphertext: env.ciphertext };
}

/** Unwrap a CEK with the recipient's X25519 secret. */
export function unwrapKey(recipientSecret: Uint8Array, wrapped: WrappedKey): Uint8Array {
  if (wrapped.algorithm !== AEAD_ALGORITHM) {
    throw new Error(`unsupported keywrap algorithm ${wrapped.algorithm}`);
  }
  const epk = fromHex(wrapped.epk);
  const recipientPublic = x25519.getPublicKey(recipientSecret);
  const shared = x25519.getSharedSecret(recipientSecret, epk);
  const wrapKeyBytes = deriveWrapKey(shared, epk, recipientPublic);
  const cek = open(
    wrapKeyBytes,
    { algorithm: wrapped.algorithm, nonce: wrapped.nonce, ciphertext: wrapped.ciphertext },
    KEYWRAP_AAD,
  );
  if (cek.length !== KEY_LEN) {
    throw new Error("unwrapped key has wrong length");
  }
  return cek;
}

/** A value sealed under a fresh CEK, with that CEK wrapped to one recipient. */
export interface ConveyedSecret {
  sealed: SealedEnvelope;
  wrappedKey: WrappedKey;
}

/** A value sealed once under one CEK plus the CEK wraps for authorized Stations. */
export interface PortableSecret {
  sealed: SealedEnvelope;
  wrapSet: WrappedKey[];
  recipientKeyRefs?: string[];
}

export function portableRecipientKeyRef(recipientPublic: Uint8Array): string {
  return `x25519:sha256:${toHex(sha256(recipientPublic))}`;
}

/**
 * Convey a secret to one recipient: value sealed under a fresh CEK + that CEK
 * wrapped to the recipient's X25519 public key, bound to `context` as AAD.
 * Mirrors Rust `seal::convey_secret` and the CLI helper.
 */
export function conveySecret(recipientPublic: Uint8Array, context: Uint8Array, value: Uint8Array): ConveyedSecret {
  const cek = generateCek();
  try {
    return {
      sealed: seal(cek, value, context),
      wrappedKey: wrapKey(recipientPublic, cek),
    };
  } finally {
    cek.fill(0);
  }
}

/** Open a conveyed secret with the recipient's X25519 secret. */
export function openConveyedSecret(recipientSecret: Uint8Array, context: Uint8Array, conveyed: ConveyedSecret): Uint8Array {
  const cek = unwrapKey(recipientSecret, conveyed.wrappedKey);
  try {
    return open(cek, conveyed.sealed, context);
  } finally {
    cek.fill(0);
  }
}

/** Seal once and wrap the CEK to each explicitly supplied Station key. */
export function sealPortableSecret(
  recipientPublics: Uint8Array[],
  context: Uint8Array,
  value: Uint8Array,
): PortableSecret {
  if (recipientPublics.length === 0) {
    throw new Error("portable secret requires at least one recipient");
  }
  const cek = generateCek();
  try {
    return {
      sealed: seal(cek, value, context),
      wrapSet: recipientPublics.map((recipientPublic) => wrapKey(recipientPublic, cek)),
      recipientKeyRefs: [...new Set(recipientPublics.map(portableRecipientKeyRef))].sort(),
    };
  } finally {
    cek.fill(0);
  }
}

// HKDF-SHA256(shared, salt = epk || recipientPublic, info = keywrap) → 32 bytes.
function deriveWrapKey(shared: Uint8Array, epk: Uint8Array, recipientPublic: Uint8Array): Uint8Array {
  const salt = new Uint8Array(epk.length + recipientPublic.length);
  salt.set(epk, 0);
  salt.set(recipientPublic, epk.length);
  return hkdf(sha256, shared, salt, KEYWRAP_INFO, KEY_LEN);
}

function utf8(s: string): Uint8Array {
  return new TextEncoder().encode(s);
}

function randomBytes(n: number): Uint8Array {
  const buf = new Uint8Array(n);
  globalThis.crypto.getRandomValues(buf);
  return buf;
}

export function toHex(bytes: Uint8Array): string {
  let out = "";
  for (const b of bytes) {
    out += b.toString(16).padStart(2, "0");
  }
  return out;
}

export function fromHex(hex: string): Uint8Array {
  if (hex.length % 2 !== 0) {
    throw new Error("odd-length hex string");
  }
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i += 1) {
    out[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  }
  return out;
}
