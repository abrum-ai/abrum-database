// Room-scoped secret vault: composes the seal primitives (seal.ts) into the
// operations an app needs to store secrets as synced twins that any member of a
// room can read. See docs/secret-sealing.md.
//
// Pure logic only — no twin/station I/O — so it is fully unit-testable. The
// runtime layers persistence on top (creating/reading the twins below).

import {
  AEAD_ALGORITHM,
  deriveKey,
  fromHex,
  generateCek,
  open,
  seal,
  toHex,
  unwrapKey,
  wrapKey,
  x25519KeypairFromSeed,
  type SealedEnvelope,
} from "./seal";

export const SPACE_KEY_SCHEMA = "schema-room-key-v1";
export const SPACE_KEY_TYPE = "room_key";

/** Content of a `schema-room-key-v1` twin: the room CEK wrapped to one member. */
export interface RoomKeyContent {
  type: typeof SPACE_KEY_TYPE;
  roomId: string;
  recipientDid: string;
  algorithm: string;
  epk: string;
  nonce: string;
  ciphertext: string;
  version: number;
}

/** A room member we can wrap the CEK to. */
export interface MemberKey {
  did: string;
  /** X25519 public key (hex), published in the member's principal/profile. */
  publicKeyX25519: string;
}

/**
 * The room creator's content-encryption key, derived deterministically from
 * the creator's own X25519 secret + the room id. Because it's recomputed (not
 * randomly minted and stored), the creator always lands on the same CEK across
 * reloads — eliminating the race where a fresh local view mints a competing key.
 * Only the creator can compute it; others receive it wrapped (see wrapCekFor).
 */
export function creatorCek(creatorSecretHex: string, roomId: string): Uint8Array {
  return deriveKey(fromHex(creatorSecretHex), `abrum-room-cek-v1:${roomId}`);
}

/** The identity's X25519 keypair derived from its seed (hex in, hex out). */
export function identityX25519(seedHex: string): { secret: Uint8Array; secretHex: string; publicHex: string } {
  const kp = x25519KeypairFromSeed(fromHex(seedHex));
  return { secret: kp.secret, secretHex: toHex(kp.secret), publicHex: toHex(kp.public) };
}

/**
 * Create a fresh room CEK and wrap it to every member, yielding one
 * `room_key` twin content per member. Returns the raw CEK so the caller can
 * immediately seal secrets without a round-trip.
 */
export function createRoomKey(
  roomId: string,
  members: MemberKey[],
): { cek: Uint8Array; roomKeys: RoomKeyContent[] } {
  const cek = generateCek();
  return { cek, roomKeys: members.map((m) => wrapCekFor(roomId, m, cek)) };
}

/** Wrap an existing CEK to one member (used when adding a member to a room). */
export function wrapCekFor(roomId: string, member: MemberKey, cek: Uint8Array): RoomKeyContent {
  const wrapped = wrapKey(fromHex(member.publicKeyX25519), cek);
  return {
    type: SPACE_KEY_TYPE,
    roomId,
    recipientDid: member.did,
    algorithm: wrapped.algorithm,
    epk: wrapped.epk,
    nonce: wrapped.nonce,
    ciphertext: wrapped.ciphertext,
    version: 1,
  };
}

/**
 * Members who have published an X25519 key but don't yet have a wrapped CEK.
 * The CEK-holder uses this to grant access to newly-invited members.
 */
export function recipientsNeedingKey(
  members: MemberKey[],
  existingRecipientDids: Iterable<string>,
): MemberKey[] {
  const have = new Set(existingRecipientDids);
  const seen = new Set<string>();
  const out: MemberKey[] = [];
  for (const m of members) {
    if (!m.did || !m.publicKeyX25519 || have.has(m.did) || seen.has(m.did)) continue;
    seen.add(m.did);
    out.push(m);
  }
  return out;
}

/** Recover the room CEK from the `room_key` twin addressed to me. */
export function cekFromRoomKey(mySeedHex: string, roomKey: RoomKeyContent): Uint8Array {
  const { secret } = identityX25519(mySeedHex);
  return unwrapKey(secret, {
    algorithm: roomKey.algorithm,
    epk: roomKey.epk,
    nonce: roomKey.nonce,
    ciphertext: roomKey.ciphertext,
  });
}

/**
 * Seal a secret value under the room CEK. `secretId` is bound as AAD so a
 * sealed value can't be transplanted onto a different secret.
 */
export function sealSecret(cek: Uint8Array, secretId: string, value: string): SealedEnvelope {
  return seal(cek, new TextEncoder().encode(value), new TextEncoder().encode(secretId));
}

/** Open a sealed secret value. Throws if the ciphertext is wrong/tampered. */
export function openSecret(cek: Uint8Array, secretId: string, envelope: SealedEnvelope): string {
  return new TextDecoder().decode(open(cek, envelope, new TextEncoder().encode(secretId)));
}

/** True if a value looks like a sealed envelope (vs a legacy plaintext field). */
export function isSealedEnvelope(value: unknown): value is SealedEnvelope {
  return (
    typeof value === "object" &&
    value !== null &&
    (value as SealedEnvelope).algorithm === AEAD_ALGORITHM &&
    typeof (value as SealedEnvelope).ciphertext === "string" &&
    typeof (value as SealedEnvelope).nonce === "string"
  );
}
