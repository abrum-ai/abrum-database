import { ed25519 } from "@noble/curves/ed25519";
import { retryRoomAuthorizationRead } from "./room-read-retry";
export { roomReadErrorCode } from "./room-read-retry";
import { sha256 } from "@noble/hashes/sha2";
import { bytesToHex, randomBytes } from "@noble/hashes/utils";
import { mnemonicToEntropy } from "@scure/bip39";
import { wordlist } from "@scure/bip39/wordlists/english";
import { entityContent, entityJsonSchema, entitySchemaName, abrumSystemApp } from "./schema";
import {
  conveySecret,
  deriveKey,
  fromHex,
  open as openSealedValue,
  seal as sealValue,
  toHex,
  unwrapKey,
  wrapKey,
  x25519KeypairFromSeed,
  type ConveyedSecret,
  type SealedEnvelope,
  type WrappedKey,
} from "./seal";
import type {
  AbrumApp,
  AbrumCreateEntityResult,
  AbrumEntities,
  AbrumEntityInput,
  AbrumEntityRecord,
  AbrumUpdateEntityResult,
} from "./schema";

import {
  decodeAbrumSessionHandoff,
  postAbrumShareContentRequest,
  readEmbedSignal,
  postAbrumRoomsChanged,
  readHostedAppRoute,
  abrumStorageKeyForStation,
  type AgentStreamDeltaEvent,
  type AbrumAppSurfaceReference,
  type AbrumSessionHandoff,
} from "./contracts";
import { actorHttpSignaturePayload, withoutSignedActorBodyFields } from "./signed-actor";
import type {
  RoomLensDemand,
  RoomLensDescriptor,
  RoomLensSnapshot,
  RoomViewToken,
} from "@abrum/runtime";

export * from "./schema";
export * from "./contracts";
export { actorHttpSignaturePayload, withoutSignedActorBodyFields } from "./signed-actor";
export * as seal from "./seal";
export * as secretVault from "./secret-vault";

export type TwinKind = "object" | "relation" | "schema" | "principal";
export type JsonValue =
  | null
  | boolean
  | number
  | string
  | JsonValue[]
  | { [key: string]: JsonValue };

export type JsonRecord = { [key: string]: JsonValue };

export type AbrumDebugStatus = "pending" | "ok" | "error";
export type AbrumDebugKind = "http" | "runtime" | "console" | "error";

export interface AbrumDebugEntry {
  id: string;
  kind: AbrumDebugKind;
  label: string;
  status: AbrumDebugStatus;
  startedAtMs: number;
  durationMs?: number;
  args?: JsonValue;
  result?: JsonValue;
  error?: string;
}

type AbrumDebugListener = (entries: AbrumDebugEntry[]) => void;

class AbrumDebugStore {
  private entries: AbrumDebugEntry[] = [];
  private listeners = new Set<AbrumDebugListener>();
  private nextId = 1;

  subscribe(listener: AbrumDebugListener): () => void {
    this.listeners.add(listener);
    listener(this.entries);
    return () => this.listeners.delete(listener);
  }

  snapshot(): AbrumDebugEntry[] {
    return this.entries;
  }

  begin(input: { kind: AbrumDebugKind; label: string; args?: JsonValue }): string {
    const id = `abrum-debug-${this.nextId++}`;
    const entry: AbrumDebugEntry = {
      id,
      kind: input.kind,
      label: input.label,
      status: "pending",
      startedAtMs: Date.now(),
      args: input.args,
    };
    this.entries = [entry, ...this.entries].slice(0, 200);
    this.emit();
    return id;
  }

  end(id: string, outcome: { status: "ok"; result?: JsonValue } | { status: "error"; error: string }): void {
    const index = this.entries.findIndex((entry) => entry.id === id);
    if (index < 0) return;
    const previous = this.entries[index];
    const next: AbrumDebugEntry = {
      ...previous,
      status: outcome.status,
      durationMs: Date.now() - previous.startedAtMs,
      ...(outcome.status === "ok" ? { result: outcome.result } : { error: outcome.error }),
    };
    this.entries = [...this.entries.slice(0, index), next, ...this.entries.slice(index + 1)];
    this.emit();
  }

  log(input: { kind: AbrumDebugKind; label: string; status: AbrumDebugStatus; args?: JsonValue; result?: JsonValue; error?: string }): void {
    this.entries = [{
      id: `abrum-debug-${this.nextId++}`,
      kind: input.kind,
      label: input.label,
      status: input.status,
      startedAtMs: Date.now(),
      durationMs: 0,
      args: input.args,
      result: input.result,
      error: input.error,
    }, ...this.entries].slice(0, 200);
    this.emit();
  }

  clear(): void {
    this.entries = [];
    this.emit();
  }

  private emit(): void {
    const snapshot = this.entries;
    for (const listener of this.listeners) listener(snapshot);
  }
}

export const abrumDebug = new AbrumDebugStore();

export function isAbrumDebugEnabled(): boolean {
  if (typeof window === "undefined") return false;
  const params = new URLSearchParams(window.location.search);
  return params.get("abrumDebug") === "1" || window.localStorage.getItem("abrum.debug") === "1";
}

export function installAbrumConsoleDebugCapture(): void {
  if (typeof window === "undefined" || !isAbrumDebugEnabled()) return;
  const target = window as typeof window & { __abrumConsoleDebugInstalled?: boolean };
  if (target.__abrumConsoleDebugInstalled) return;
  target.__abrumConsoleDebugInstalled = true;
  for (const level of ["log", "warn", "error"] as const) {
    const original = console[level].bind(console);
    console[level] = (...args: unknown[]) => {
      abrumDebug.log({
        kind: level === "error" ? "error" : "console",
        label: `console.${level}`,
        status: level === "error" ? "error" : "ok",
        result: args.map(debugJsonValue) as JsonValue,
        error: level === "error" ? args.map(String).join(" ") : undefined,
      });
      original(...args);
    };
  }
  window.addEventListener("error", (event) => {
    abrumDebug.log({ kind: "error", label: "window.error", status: "error", error: event.message });
  });
  window.addEventListener("unhandledrejection", (event) => {
    abrumDebug.log({ kind: "error", label: "unhandledrejection", status: "error", error: String(event.reason) });
  });
}

export interface TwinBlock {
  kind: TwinKind;
  schema: string | null;
  issuer: string;
  content: JsonValue;
  previousVersion: string | null;
  mergedFrom: string[];
}

export interface SignedTwin {
  cid: string;
  payloadCid?: string;
  storageCid?: string;
  signature: string;
  block: TwinBlock;
}

export interface PrincipalIdentity {
  did: string;
  publicKeyHex: string;
  seedHex: string;
}

export type SchemaClass = "well-known" | "user" | "station";

export interface AbrumProtocolCore {
  identityFromSeed(seed: Uint8Array): PrincipalIdentity;
  identityFromRecoveryPhrase(phrase: string): PrincipalIdentity;
  userPrincipalTwin(identity: PrincipalIdentity, displayName: string, createdAtMs?: number): SignedTwin;
  identityRootDid(identityRootCid: string): string;
  identityRootTwin(
    identity: PrincipalIdentity,
    rootKind: "user" | "station" | "warden" | "service",
    label?: string | null,
    createdAtMs?: number,
  ): SignedTwin;
  deviceKeyTwin(
    identity: PrincipalIdentity,
    identityRootCid: string,
    label?: string | null,
    createdAtMs?: number,
  ): SignedTwin;
  schemaTwinForIdentity(
    identity: PrincipalIdentity,
    name: string,
    schemaClass: SchemaClass,
    jsonSchema: JsonValue,
  ): SignedTwin;
  objectTwin(
    identity: PrincipalIdentity,
    schemaCid: string,
    content: JsonValue,
    previousVersion?: string | null,
  ): SignedTwin;
  relationTwin(identity: PrincipalIdentity, spec: RelationSpec): SignedTwin;
  signBlock(identity: PrincipalIdentity, block: TwinBlock): SignedTwin;
  signUtf8(identity: PrincipalIdentity, payload: string): string;
  canonicalBytes(block: TwinBlock): Uint8Array;
  computeCid(bytes: Uint8Array): string;
  computePayloadCid(bytes: Uint8Array): string;
  computeStorageCid(bytes: Uint8Array): string;
  actorHttpSignaturePayload(method: string, routeScope: string, actorDid: string, timestampMs: number, nonce: string, bodyText: string): string;
  deriveKey(ikm: Uint8Array, info: Uint8Array): Uint8Array;
  identityX25519(seedHex: string): { secretHex: string; publicHex: string };
  sealValue(key: Uint8Array, plaintext: Uint8Array, aad: Uint8Array): SealedEnvelope;
  openValue(key: Uint8Array, envelope: SealedEnvelope, aad: Uint8Array): Uint8Array;
  wrapKey(recipientPublic: Uint8Array, cek: Uint8Array): WrappedKey;
  unwrapKey(recipientSecret: Uint8Array, wrapped: WrappedKey): Uint8Array;
  conveySecret(recipientPublic: Uint8Array, context: Uint8Array, value: Uint8Array): ConveyedSecret;
}

export interface AbrumWasmProtocolModule {
  identityFromSeedHex(seedHex: string): string;
  identityFromRecoveryPhrase(phrase: string): string;
  userPrincipalTwin(seedHex: string, displayName: string, createdAtMs: bigint): string;
  identityRootDid(identityRootCid: string): string;
  identityRootTwin(seedHex: string, rootKind: string, label: string | null, createdAtMs: bigint): string;
  deviceKeyTwin(seedHex: string, identityRootCid: string, label: string | null, createdAtMs: bigint): string;
  schemaTwin(seedHex: string, name: string, schemaClass: SchemaClass, jsonSchemaJson: string): string;
  objectTwin(seedHex: string, schemaCid: string, contentJson: string, previousVersion?: string | null): string;
  relationTwin(
    seedHex: string,
    source: string,
    target: string,
    relationType: string,
    inheritsAccess: boolean,
    extraJson?: string | null,
  ): string;
  signBlock(seedHex: string, blockJson: string): string;
  canonicalBytes(blockJson: string): Uint8Array;
  signUtf8(seedHex: string, payload: string): string;
  computeCid(bytes: Uint8Array): string;
  computePayloadCid(bytes: Uint8Array): string;
  computeStorageCid(bytes: Uint8Array): string;
  actorHttpSignaturePayload(method: string, routeScope: string, actorDid: string, timestampMs: bigint, nonce: string, bodyText: string): string;
  deriveKey(ikm: Uint8Array, info: Uint8Array): Uint8Array;
  identityX25519(seedHex: string): string;
  sealValue(key: Uint8Array, plaintext: Uint8Array, aad: Uint8Array): string;
  openValue(key: Uint8Array, envelopeJson: string, aad: Uint8Array): Uint8Array;
  wrapKey(recipientPublic: Uint8Array, cek: Uint8Array): string;
  unwrapKey(recipientSecret: Uint8Array, wrappedJson: string): Uint8Array;
  conveySecret(recipientPublic: Uint8Array, context: Uint8Array, value: Uint8Array): string;
}

export interface StationIdentity {
  name: string;
  station_did?: string;
  station_identity_root_cid?: string;
  station_identity_root_did?: string;
  station_device_did?: string;
  x25519_public_key?: string;
  principal_did: string;
  station_twin_cid: string;
  endpoint_id: string;
  protocol: string;
  transports: Array<Record<string, JsonValue>>;
}

/**
 * The stable identity of a twin's lineage — what you share, cite or revoke by.
 *
 * Apps used to write `twin.block.previousVersion ?? cid`, which is the PARENT
 * version, not the root. It agreed with the station only until the second edit;
 * after that a share receipt and the lookup for it named different cids and the
 * share silently disappeared from the UI. Read the projection's value instead,
 * and fall back to the twin's own cid only for a first version that has not
 * been projected yet (where the two are the same thing anyway).
 */
export { activeContentSharesFromEntries } from "./content-sharing-state";
import { activeContentSharesFromEntries } from "./content-sharing-state";

function sortContacts(contacts: AbrumContact[]): AbrumContact[] {
  return [...contacts].sort((left, right) =>
    (left.displayName ?? left.did).localeCompare(right.displayName ?? right.did),
  );
}

export function lineageCidOf(ref: { lineageCid?: string | null; cid: string }): string {
  return ref.lineageCid?.trim() || ref.cid;
}

export interface TwinLogEntry {
  seq: number;
  cid: string;
  twin: SignedTwin;
  /** Root of this twin's lineage, as the station's object projection knows it.
   * Present on object heads. Do NOT derive this from `previousVersion` — that
   * is the PARENT version, so anything keyed on it drifts apart on the second
   * edit. */
  lineageCid?: string;
  /** Local projection metadata supplied by a multi-Room app lens. It is not
   * part of the signed Twin and is never serialized back into substance. */
  sourceRoomId?: string;
}

export interface PullTwinsResult {
  cursor: { room_id: string; seq: number };
  head: { room_id: string; seq: number };
  entries: TwinLogEntry[];
  viewToken?: RoomViewToken;
}

export interface PullHeadsOptions {
  limit?: number;
  contentTypes?: string[];
  schemaCids?: string[];
  lineageCids?: string[];
}

export interface RoomHeadsQuery {
  contentType: string;
  where?: JsonRecord;
  order?: [string, "asc" | "desc"];
  after?: { value: JsonValue; lineageCid: string };
  limit: number;
}

export interface RecoveryAuditResult {
  roomId: string;
  generatedAtMs: number;
  highRiskCapabilities: Record<string, string>;
  policies: JsonRecord[];
  successions: JsonRecord[];
  frozenGrants: JsonRecord[];
  reservedEffects: JsonRecord[];
}

export interface SyncPushResult {
  inserted: string[];
  waiting: SyncPushIssue[];
  quarantined: SyncPushIssue[];
  rejected: SyncPushIssue[];
  validation_complete: boolean;
  watermark_ms: number;
}

export interface SyncPushIssue {
  cid: string;
  stage: string;
  reason: string;
  code?: string;
  retryable?: boolean;
  dependency_kind?: string;
  dependency_cid?: string;
}

export type AbrumPushErrorCode = "conflict" | "rejected" | "quarantined" | "waiting";

export class AbrumPushError extends Error {
  readonly code: AbrumPushErrorCode;
  readonly rejected: readonly SyncPushIssue[];
  readonly quarantined: readonly SyncPushIssue[];
  readonly waiting: readonly SyncPushIssue[];

  constructor(
    result: Pick<SyncPushResult, "rejected" | "waiting"> & {
      quarantined?: readonly SyncPushIssue[];
    },
  ) {
    const quarantined = result.quarantined ?? [];
    const conflict = result.rejected.some((issue) =>
      /cannot evolve lineage|lineage.+head|stale/i.test(issue.reason)
    );
    const code: AbrumPushErrorCode = conflict
      ? "conflict"
      : result.rejected.length > 0
        ? "rejected"
        : quarantined.length > 0
          ? "quarantined"
          : "waiting";
    const summary = conflict
      ? "This record changed on another writer. Refresh it and apply the edit again."
      : "The Station did not accept the complete mutation.";
    super(summary);
    this.name = "AbrumPushError";
    this.code = code;
    this.rejected = result.rejected;
    this.quarantined = quarantined;
    this.waiting = result.waiting;
  }
}

export interface RealtimeStreamEvent {
  offset: number;
  /** Persisted Station stream identity. Offsets compare only within it. */
  stream_epoch?: string;
  event: {
    type: "twins_inserted";
    room_id: string;
    cids: string[];
    watermark_ms: number;
    /** Monotonic Room-log head. Zero is the compatibility value for an older
     * Station or a same-surface optimistic invalidation. */
    revision: number;
    content_types: string[];
    relation_types: string[];
    stream_epoch?: string;
  } | {
    type: "replay_gap";
  };
}

/** Build the same typed invalidation the Station publishes for a successful
 * local insertion. This makes a write visible to the calling surface even when
 * its realtime stream is reconnecting. */
export function localTwinsInsertedEvent(
  roomId: string,
  twins: readonly SignedTwin[],
  push: Pick<SyncPushResult, "inserted" | "watermark_ms">,
): Extract<RealtimeStreamEvent["event"], { type: "twins_inserted" }> | null {
  if (push.inserted.length === 0) {
    return null;
  }
  const inserted = new Set(push.inserted);
  const contentTypes = new Set<string>();
  const relationTypes = new Set<string>();
  for (const twin of twins) {
    if (!inserted.has(twin.cid)) continue;
    const content = asRecordOrNull(twin.block.content);
    const contentType = asOptionalString(content?.type);
    if (contentType) contentTypes.add(contentType);
    if (twin.block.kind === "relation") {
      const relationType = asOptionalString(content?.relationType);
      if (relationType) relationTypes.add(relationType);
    }
  }
  return {
    type: "twins_inserted",
    room_id: roomId,
    cids: [...push.inserted],
    watermark_ms: push.watermark_ms,
    revision: 0,
    content_types: [...contentTypes].sort(),
    relation_types: [...relationTypes].sort(),
  };
}

/** Normalize the Station's `event: twins` SSE payload. The SSE event name is
 * the discriminator, so the JSON body remains backward-compatible without a
 * duplicate `type` field. */
export function parseTwinsInsertedEvent(
  data: string,
): Extract<RealtimeStreamEvent["event"], { type: "twins_inserted" }> | null {
  try {
    const parsed = JSON.parse(data) as Partial<Extract<RealtimeStreamEvent["event"], { type: "twins_inserted" }>>;
    if (
      typeof parsed.room_id !== "string"
      || (parsed.type !== undefined && parsed.type !== "twins_inserted")
    ) {
      return null;
    }
    return {
      type: "twins_inserted",
      room_id: parsed.room_id,
      cids: Array.isArray(parsed.cids)
        ? parsed.cids.filter((value): value is string => typeof value === "string")
        : [],
      watermark_ms: typeof parsed.watermark_ms === "number" ? parsed.watermark_ms : 0,
      revision: typeof parsed.revision === "number" && Number.isSafeInteger(parsed.revision)
        ? Math.max(0, parsed.revision)
        : 0,
      content_types: Array.isArray(parsed.content_types)
        ? parsed.content_types.filter((value): value is string => typeof value === "string")
        : [],
      relation_types: Array.isArray(parsed.relation_types)
        ? parsed.relation_types.filter((value): value is string => typeof value === "string")
        : [],
      ...(typeof parsed.stream_epoch === "string" && parsed.stream_epoch.trim()
        ? { stream_epoch: parsed.stream_epoch.trim() }
        : {}),
    };
  } catch {
    return null;
  }
}

export function reconcileRealtimeCursor(
  currentEpoch: string | null,
  currentOffset: number,
  incomingEpoch: string,
): { epoch: string | null; offset: number; reset: boolean } {
  const epoch = incomingEpoch.trim();
  if (!epoch) return { epoch: currentEpoch, offset: currentOffset, reset: false };
  const reset = currentEpoch !== epoch && (currentEpoch !== null || currentOffset > 0);
  return { epoch, offset: reset ? 0 : currentOffset, reset };
}

/** Bounded exponential delay used when rebuilding an authenticated realtime
 * subscription. The rebuilt URL gets a fresh timestamp, nonce and signature. */
export function abrumRealtimeReconnectDelayMs(attempt: number): number {
  return Math.min(1_000 * (2 ** Math.min(Math.max(0, attempt), 4)), 15_000);
}

/**
 * How this surface subscribes to Station's realtime stream. Every surface
 * subscribes — a surface without a subscription sees only its own writes, so
 * work started somewhere else (an Agent run from the desktop sidebar) never
 * streams into it and its result twins never arrive.
 *
 * "live" is the embedded form: an app frame in the desktop shares a Station
 * with the shell and every other frame, and its own heads pull already loaded
 * the history it renders, so it skips the historical replay that made a boot
 * with many frames crawl. "replay" is the standalone form, where the surface
 * is the only reader and needs the history to catch up.
 */
export function abrumRealtimeSubscriptionMode(win?: {
  abrumContainer?: { kind?: string };
  location?: { search?: string; pathname?: string; origin?: string };
}): "live" | "replay" {
  const embeddedAppFrame =
    readEmbedSignal(win)?.kind === "electron" && Boolean(readHostedAppRoute(win));
  return embeddedAppFrame ? "live" : "replay";
}

/** One ephemeral Agent output delta from the Station SSE stream. Durable
 * history still lives in sandbox_message twins; this only closes the latency
 * gap until the next durable projection is docked. */
export function parseAgentStreamDeltaEvent(data: string): AgentStreamDeltaEvent | null {
  try {
    const parsed = JSON.parse(data) as Record<string, JsonValue>;
    const roomId = typeof parsed.room_id === "string" ? parsed.room_id : "";
    const runID = typeof parsed.run_id === "string" ? parsed.run_id : "";
    if (!roomId || !runID) return null;
    return {
      roomId,
      runID,
      text: typeof parsed.text === "string" ? parsed.text : "",
      ...(typeof parsed.kind === "string" ? { kind: parsed.kind } : {}),
      toolName: typeof parsed.tool_name === "string" ? parsed.tool_name : null,
      appSurface:
        parsed.app_surface && typeof parsed.app_surface === "object" && !Array.isArray(parsed.app_surface)
          ? (parsed.app_surface as unknown as AbrumAppSurfaceReference)
          : null,
    };
  } catch {
    return null;
  }
}

export interface RoomDescriptor {
  id: string;
  name: string;
  share_key: string;
  key_epoch?: number;
  root_collection_cid: string;
  created_by: string;
  created_at_ms: number;
  purpose: string;
  room_kind: string;
  authority_room_id?: string;
  operator_principal_did?: string;
  content_schema_cid?: string;
  parent_room_id?: string;
  archived_at_ms?: number;
  /** Strongest right the REQUESTING actor holds here. Response-only — it
   *  describes the asker, not the Room. */
  actor_access_level?: RoomAccessLevel;
}

/**
 * May the current actor write in this Room?
 *
 * Apps used to answer this with "am I signed in and is a Room selected", which
 * is not the same question — a viewer passed that test, wrote anyway, and the
 * station replied 403. Absent level means an older station: assume writable, so
 * this cannot silently disable a working app.
 */
export function canWriteRoom(room: { actor_access_level?: RoomAccessLevel } | null | undefined): boolean {
  return room?.actor_access_level !== "read";
}

export type RoomAccessLevel = "read" | "write" | "admin";

export interface RoomMemberGrant {
  cid: string;
  principal_did: string;
  relation_type: "owns" | "admins" | "writes" | "reads" | "controls";
  issuer: string;
  created_at_ms?: number | null;
}

export interface AbrumInstallAppOptions {
  appId: string;
  title: string;
  icon?: string;
  description?: string;
  kind?: "web" | "wasm" | "native";
  appVersion?: string;
  executionLevel?: "schema-only" | "pure-wasm" | "effect-declaration" | "trusted-plugin" | (string & {});
  schemas?: JsonValue[];
  imports?: JsonValue[];
  requiredSecrets?: JsonValue[];
  features?: JsonValue[];
  functions?: JsonValue[];
  surfaces?: JsonValue[];
  background?: JsonValue;
  runtime?: JsonValue;
  backends?: JsonValue;
  artifact?: JsonValue;
  network?: JsonValue;
  versionSelector?: "latest" | "pinned";
  config?: JsonValue;
  grantedRights?: string[];
}

export interface AbrumInstalledApp {
  appId: string;
  appCid: string;
  installCid: string;
  alreadyInstalled: boolean;
  push?: SyncPushResult;
}

export interface AbrumAppRunResult<Data = JsonValue> {
  app_id: string;
  /** The Room the call was routed to and where its emits docked. Optional so a
   * client still typechecks against a station that predates the field. */
  room_id?: string;
  function: string;
  logs?: string[];
  schemas: SignedTwin[];
  objects: SignedTwin[];
  relations: SignedTwin[];
  /** Return payload from read/query functions; absent for write-only functions. */
  data?: Data;
  push: SyncPushResult;
}

export interface AbrumRunAppFunctionOptions {
  sourceAppId?: string | null;
}

export interface AbrumUserProfile {
  did: string;
  identityRootDid?: string | null;
  displayName: string;
  bio?: string | null;
  avatarFileLineageCid?: string | null;
  principalCid?: string;
  profileCid?: string;
}

export interface AbrumContact {
  did: string;
  displayName?: string | null;
  stationId?: string | null;
  stationName?: string | null;
}

export interface AbrumPeerStationStatus {
  stationId: string;
  name?: string | null;
  principalDid?: string | null;
  lastSeenMs?: number | null;
  connected: boolean;
  /** Shared transport-presence vocabulary used by desktop and mobile. */
  presence?: "online" | "stale" | "offline" | "unknown";
  servedUsers: string[];
  sharedRooms: string[];
  sharedUsersByRoom: Record<string, string[]>;
}

export interface AbrumPeersStatus {
  stationId: string;
  connectedCount: number;
  connected: string[];
  stations: AbrumPeerStationStatus[];
}

export interface AbrumDirectLineageInviteInput {
  sourceRoomId: string;
  lineageCid: string;
  shareGrantCid: string;
  peerId: string;
}

export interface AbrumDirectLineageInviteResult {
  sent: number;
}

export interface AbrumDirectShareResult {
  sourceRoomId: string;
  lineageCid: string;
  recipientDid: string;
  /** First endpoint reached for backwards-compatible UI hints. Authority is Root-bound. */
  recipientStationId?: string | null;
  /** Every currently authenticated endpoint reached by the background projection. */
  recipientStationIds: string[];
  shareGrantCid: string;
  delivery: "replicate" | "on_demand";
  /** True while the Root grant is durable but no recipient endpoint is online yet. */
  deliveryPending: boolean;
  sent: number;
  reused: boolean;
}

export interface AbrumDirectShareRevokeResult {
  sourceRoomId: string;
  lineageCid: string;
  recipientDid: string;
  revokedGrants: number;
  notifiedStations: number;
  deliveredBytesRemain: boolean;
}

export interface AbrumShareContentInput {
  roomId?: string;
  lineageCid: string;
  targetCid?: string | null;
  targetType?: string | null;
  title?: string | null;
  sharedWithDid: string;
  recipientStationId?: string | null;
  /** @deprecated Direct content shares are lineage-scoped and read-only. */
  accessLevel?: RoomAccessLevel;
}

export interface AbrumShareContentResult {
  roomId: string;
  lineageCid: string;
  sharedWithDid: string;
  accessLevel: RoomAccessLevel;
  granted: boolean;
  grant?: SyncPushResult;
  directShare?: AbrumDirectShareResult;
  receipt: SignedTwin;
  push: SyncPushResult;
}

export interface AbrumRevokeContentShareInput {
  roomId?: string;
  lineageCid: string;
  sharedWithDid: string;
  recipientStationId?: string | null;
}

export interface AbrumRevokeContentShareResult {
  roomId: string;
  lineageCid: string;
  sharedWithDid: string;
  directShare: AbrumDirectShareRevokeResult;
  receipt: SignedTwin;
  push: SyncPushResult;
}

export interface AbrumContentShareRecord {
  cid: string;
  lineageCid: string;
  targetCid?: string | null;
  targetType?: string | null;
  title?: string | null;
  sharedByDid: string;
  sharedWithDid: string;
  accessLevel: RoomAccessLevel;
  deliveryMode: string;
  createdAtMs: number;
  updatedAtMs: number;
}

export interface RuntimeSnapshot {
  stationUrl: string;
  stationIdentity: StationIdentity | null;
  stationClaimed: boolean;
  user: PrincipalIdentity | null;
  displayName: string | null;
  hostedRoomId: string | null;
  selectedRoomId: string | null;
  rooms: RoomDescriptor[];
  cursorByRoom: Record<string, number>;
  realtimeEventOffset: number;
  realtimeStreamEpoch: string | null;
  realtimeRevision: number;
  lastRealtimeEvent: RealtimeStreamEvent["event"] | null;
  status: "opening" | "ready" | "error";
  error: string | null;
}

export interface AbrumAgentChatMessage {
  id: string;
  runID: string;
  runStatus: string;
  queueRequested: boolean;
  runtime?: string;
  model?: string;
  reasoningEffort?: string;
  role: "user" | "assistant" | "system" | string;
  text: string;
  finalized: boolean;
  seq: number;
  attachments?: Array<{ blobHash: string; name: string; mime: string; size: number }>;
  parts?: Array<{
    kind: string;
    text?: string;
    toolName?: string;
    done?: boolean;
    input?: JsonValue;
    output?: JsonValue;
    failed?: boolean;
    appSurface?: JsonValue;
  }>;
}

export interface AbrumAgentBrainBindingGrant {
  brainRoomId: string;
  holderDid: string;
  capCid: string;
  access: "read" | "contribute";
  functions: string[];
}

export interface AbrumAgentCapabilityBindingGrant {
  providerRoomId: string;
  appId: string;
  offerId: string;
  holderDid: string;
  capCid: string;
  mode: "on_behalf_of_caller" | "delegated_service" | "autonomous";
  resultPolicy: string;
  functions: string[];
}

export interface AbrumAgentCapabilityOffer {
  id: string;
  title: string;
  description?: string;
  functions: string[];
  modes: Array<"on_behalf_of_caller" | "delegated_service" | "autonomous">;
  defaultMode: "on_behalf_of_caller" | "delegated_service" | "autonomous";
  risk?: string;
  resultPolicies: string[];
  defaultResultPolicy: string;
}

export interface AbrumAgentCapabilityProvider {
  roomId: string;
  roomName: string;
  appId: string;
  appTitle: string;
  icon?: string;
  offers: AbrumAgentCapabilityOffer[];
}

export interface RuntimeOptions {
  station: string;
  storageKey?: string;
  core?: AbrumProtocolCore;
  /** Optional platform data plane. Desktop/Web use the Station HTTP client;
   * native hosts can provide the Pocket Station binding without changing app
   * hooks or query semantics. */
  roomDataPlane?: AbrumRoomDataPlane;
}

export interface AbrumRoomDataPlane {
  pullTwinsSince(
    roomId: string,
    actorDid: string,
    afterSeq: number,
    limit?: number,
    signer?: HttpActorSigner,
  ): Promise<PullTwinsResult>;
  pullHeadsSince(
    roomId: string,
    actorDid: string,
    afterSeq: number,
    options?: PullHeadsOptions,
    signer?: HttpActorSigner,
  ): Promise<PullTwinsResult>;
  queryRoomHeads(
    roomId: string,
    actorDid: string,
    query: RoomHeadsQuery,
    signer?: HttpActorSigner,
  ): Promise<PullTwinsResult>;
  queryRoomLens?<TDescriptor = RoomLensDescriptor>(
    demand: RoomLensDemand,
    signer?: HttpActorSigner,
  ): Promise<RoomLensSnapshot<SignedTwin, TDescriptor>>;
  subscribeRoomEvents?(
    listener: (event: RealtimeStreamEvent["event"]) => void,
  ): () => void;
}

// Session-handoff + base64url moved to ./contracts (the host↔app contract);
// re-exported via `export * from "./contracts"` above.

export function importAbrumSessionHandoff(storageKey: string, encoded: string): AbrumSessionHandoff {
  const handoff = decodeAbrumSessionHandoff(encoded);
  const existing = readStoredSession(storageKey);
  writeStoredSession(storageKey, {
    ...existing,
    // App surface runner identity — never a mnemonic. Drop any stale phrase so a
    // re-handoff can't leave an old user identity behind.
    phrase: undefined,
    deviceKeySeedHex: handoff.deviceKeySeedHex,
    actorDid: handoff.actorDid,
    displayName: handoff.displayName ?? existing?.displayName,
    hostedRoomId: handoff.hostedRoomId ?? existing?.hostedRoomId ?? null,
    selectedRoomId: handoff.selectedRoomId ?? existing?.selectedRoomId ?? handoff.hostedRoomId ?? null,
    cursorByRoom: handoff.cursorByRoom ?? existing?.cursorByRoom ?? {},
    bootstrap: handoff.bootstrap ?? null,
  });
  return handoff;
}

const DAG_CBOR_CODEC = 0x71;
const SHA2_256_CODE = 0x12;
const SCHEMA_IDENTITY_ROOT_CID = "bafyreih6qqbjjg52rtgoqukqmgstmkbylkvxc5x4din6yfilpuflfyq2xy";
const SCHEMA_DEVICE_KEY_CID = "bafyreifedh2n2lqucoobux6wefargng3kshsjprznpvkfn7wipfycskwei";
const SCHEMA_USER_CID = "bafyreieih3m37ngfneju4s2tx4gn53udy57xdotsxrl3yxiqnjwbijzxzq";
const SCHEMA_USER_PROFILE_CID = "bafyreidzgcfhcpjqxnmkoqvz34yto4nm4etihe2fhrqgnnirt6la4zxvea";
const SCHEMA_RELATION_CID = "bafyreig22dlstzonpwyrebonjdn2yeqsd4hfiols2wugqyhghdpqs72ihy";
const CONTENT_SHARE_SCHEMA_NAME = "schema-content-share-v1";
const CONTENT_SHARE_REVOCATION_SCHEMA_NAME = "schema-content-share-revocation-v1";

const textEncoder = new TextEncoder();
const BLOCK_CID_DOMAIN = textEncoder.encode("abrum:block:v1");
const PAYLOAD_CID_DOMAIN = textEncoder.encode("abrum:payload:v1");
const STORAGE_CID_DOMAIN = textEncoder.encode("abrum:storage:v1");
const base32Alphabet = "abcdefghijklmnopqrstuvwxyz234567";

export class AbrumRuntime {
  readonly stationUrl: string;
  readonly storageKey: string;
  readonly station: HttpStationClient;
  readonly roomDataPlane: AbrumRoomDataPlane;
  private readonly protocolCore: AbrumProtocolCore;
  private listeners = new Set<() => void>();
  private agentStreamListeners = new Set<(event: AgentStreamDeltaEvent) => void>();
  private snapshotValue: RuntimeSnapshot;
  private events: EventSource | null = null;
  private realtimePaused = false;
  private eventsActorDid: string | null = null;
  private eventsReconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private eventsReconnectAttempt = 0;
  private roomDataUnsubscribe: (() => void) | null = null;
  private closed = false;
  private installAppPromises = new Map<string, Promise<AbrumInstalledApp>>();
  private blobUrls = new Map<string, { url: string; signedAt: number }>();

  private constructor(
    options: Required<Pick<RuntimeOptions, "station" | "storageKey" | "core">>
      & Pick<RuntimeOptions, "roomDataPlane">,
  ) {
    this.stationUrl = options.station.replace(/\/+$/, "");
    this.storageKey = options.storageKey;
    this.station = new HttpStationClient(this.stationUrl);
    this.roomDataPlane = options.roomDataPlane ?? this.station;
    this.protocolCore = options.core;
    this.snapshotValue = {
      stationUrl: this.stationUrl,
      stationIdentity: null,
      stationClaimed: false,
      user: null,
      displayName: null,
      hostedRoomId: null,
      selectedRoomId: null,
      rooms: [],
      cursorByRoom: {},
      realtimeEventOffset: 0,
      realtimeStreamEpoch: null,
      realtimeRevision: 0,
      lastRealtimeEvent: null,
      status: "opening",
      error: null,
    };
  }

  static async open(options: RuntimeOptions): Promise<AbrumRuntime> {
    installAbrumConsoleDebugCapture();
    const station = options.station.replace(/\/+$/, "");
    const runtime = new AbrumRuntime({
      station,
      storageKey: options.storageKey ?? abrumStorageKeyForStation(station),
      core: options.core ?? currentProtocolCore,
      roomDataPlane: options.roomDataPlane,
    });
    await runtime.open();
    return runtime;
  }

  snapshot(): RuntimeSnapshot {
    return {
      ...this.snapshotValue,
      cursorByRoom: { ...this.snapshotValue.cursorByRoom },
    };
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  subscribeAgentStream(listener: (event: AgentStreamDeltaEvent) => void): () => void {
    this.agentStreamListeners.add(listener);
    return () => this.agentStreamListeners.delete(listener);
  }

  /** Release transport subscriptions owned by this runtime instance.
   *
   * Trusted app hosts can be replaced as Rooms or app revisions change. A
   * closed runtime must never reconnect its signed EventSource in the
   * background after its surface has unmounted.
   */
  close(): void {
    if (this.closed) return;
    this.closed = true;
    this.events?.close();
    this.events = null;
    if (this.eventsReconnectTimer) {
      clearTimeout(this.eventsReconnectTimer);
      this.eventsReconnectTimer = null;
    }
    this.roomDataUnsubscribe?.();
    this.roomDataUnsubscribe = null;
    this.eventsActorDid = null;
    this.agentStreamListeners.clear();
    this.listeners.clear();
  }

  /** Cached UI keeps its state, not a permanent HTTP/1 connection. Resuming
   * uses the existing signed reconnect/cursor recovery, never a replayed URL. */
  setRealtimeActive(active: boolean): void {
    if (this.closed || this.realtimePaused === !active) return;
    this.realtimePaused = !active;
    if (active) {
      this.startRealtime(true);
      return;
    }
    this.events?.close();
    this.events = null;
    if (this.eventsReconnectTimer) clearTimeout(this.eventsReconnectTimer);
    this.eventsReconnectTimer = null;
    this.roomDataUnsubscribe?.();
    this.roomDataUnsubscribe = null;
  }

  /**
   * The current user's X25519 keypair (hex), derived from the identity seed.
   * Used by the secret vault to wrap/unwrap the per-room content key (the
   * `publicKeyX25519` is what other members wrap to). Null when no user is set.
   */
  identityX25519(): { did: string; secretHex: string; publicKeyX25519: string } | null {
    const user = this.snapshotValue.user;
    if (!user) {
      return null;
    }
    const kp = this.protocolCore.identityX25519(user.seedHex);
    return { did: user.did, secretHex: kp.secretHex, publicKeyX25519: kp.publicHex };
  }

  /** Rust-owned crypto operations used by the Secrets app. They execute in the
   * browser WASM sandbox; neither key material nor plaintext crosses to the
   * Station. */
  deriveRoomCek(secretHex: string, roomId: string): Uint8Array {
    return this.protocolCore.deriveKey(
      fromHex(secretHex),
      new TextEncoder().encode(`abrum-room-cek-v1:${roomId}`),
    );
  }

  wrapRoomCek(recipientPublicHex: string, cek: Uint8Array): WrappedKey {
    return this.protocolCore.wrapKey(fromHex(recipientPublicHex), cek);
  }

  unwrapRoomCek(recipientSecretHex: string, wrapped: WrappedKey): Uint8Array {
    return this.protocolCore.unwrapKey(fromHex(recipientSecretHex), wrapped);
  }

  sealSecretValue(cek: Uint8Array, secretId: string, value: string): SealedEnvelope {
    const encoder = new TextEncoder();
    return this.protocolCore.sealValue(cek, encoder.encode(value), encoder.encode(secretId));
  }

  openSecretValue(cek: Uint8Array, secretId: string, envelope: SealedEnvelope): string {
    return new TextDecoder().decode(
      this.protocolCore.openValue(cek, envelope, new TextEncoder().encode(secretId)),
    );
  }

  conveySecretValue(recipientPublicHex: string, context: string, value: string): ConveyedSecret {
    const encoder = new TextEncoder();
    return this.protocolCore.conveySecret(
      fromHex(recipientPublicHex),
      encoder.encode(context),
      encoder.encode(value),
    );
  }

  sessionHandoff(): AbrumSessionHandoff | null {
    const stored = readStoredSession(this.storageKey);
    // Only an app-surface runner identity with an explicit actor binding is ever
    // re-handed-off (IK-15).
    if (!stored?.deviceKeySeedHex || !stored?.actorDid) {
      return null;
    }
    return {
      deviceKeySeedHex: stored.deviceKeySeedHex,
      actorDid: stored.actorDid,
      displayName: stored.displayName ?? this.snapshotValue.displayName,
      hostedRoomId: stored.hostedRoomId ?? this.snapshotValue.hostedRoomId,
      selectedRoomId: stored.selectedRoomId ?? this.snapshotValue.selectedRoomId,
      cursorByRoom: stored.cursorByRoom ?? this.snapshotValue.cursorByRoom,
      bootstrap: stored.bootstrap ?? null,
    };
  }

  async createUser(displayName = "abrum web user"): Promise<{ user: PrincipalIdentity }> {
    const seed = randomBytes(32);
    const user = this.protocolCore.identityFromSeed(seed);
    this.patch({ user, displayName });
    this.persist({ deviceKeySeedHex: user.seedHex, phrase: undefined, displayName });
    this.startRealtime();
    return { user };
  }

  /**
   * One-time compatibility import for installations whose BIP39 entropy was
   * historically used as the signing seed. New product enrollment must never
   * call this method. The phrase is converted immediately and is not persisted.
   * @deprecated Use device enrollment and a host-provided Device Key instead.
   */
  async restoreUser(phrase: string, displayName = "abrum web user"): Promise<PrincipalIdentity> {
    const user = this.protocolCore.identityFromRecoveryPhrase(phrase);
    this.patch({ user, displayName });
    this.persist({ deviceKeySeedHex: user.seedHex, phrase: undefined, displayName });
    this.startRealtime();
    if (this.snapshotValue.stationIdentity) {
      await this.loadRooms();
    }
    return user;
  }

  async pair(displayName = "abrum web user"): Promise<string> {
    const user = this.requireUser();
    const stationIdentity = this.requireStation();
    const pairing = await this.station.startPairing();
    const qrPayload = asRecord(pairing.qr_payload, "pairing qr_payload");
    const challenge = asString(qrPayload.challenge, "pairing challenge");
    const pairingSecret = asString(qrPayload.pairingSecret, "pairing secret");
    // Mint the user's own identity-root + deviceKey (self-signed by the user;
    // the station never holds the user key) so ownership binds to the did:abrum
    // root (IK-2) instead of the bare deviceKey DID. The station validates and
    // docks them at claim; pairing-v2 stations that ignore the extra fields fall
    // back to bare-did ownership. Built via the same wasm core the station uses,
    // so the twin CIDs match.
    const createdAtMs = Date.now();
    const identityRoot = this.protocolCore.identityRootTwin(user, "user", displayName, createdAtMs);
    const deviceKey = this.protocolCore.deviceKeyTwin(
      user,
      identityRoot.cid,
      displayName,
      createdAtMs + 1,
    );
    const userRootDid = `did:abrum:${identityRoot.cid}`;
    const completed = await this.station.completePairing({
      pairing_id: asString(pairing.pairing_id, "pairing id"),
      pairing_secret: pairingSecret,
      user_principal_did: user.did,
      user_principal_twin: this.protocolCore.userPrincipalTwin(user, displayName),
      owns_relation: this.protocolCore.relationTwin(user, {
        source: userRootDid,
        target: stationIdentity.station_twin_cid,
        relationType: "owns",
        inheritsAccess: true,
      }),
      pairing_signature: this.protocolCore.signUtf8(user, challenge),
      user_identity_root: identityRoot,
      user_device_key: deviceKey,
    });
    if (completed.accepted !== true) {
      throw new Error("station rejected pairing");
    }
    const hostedRoom = asRecord(completed.hostedRoom, "hostedRoom");
    const hostedRoomId = asString(hostedRoom.id, "hostedRoom.id");
    this.patch({ hostedRoomId, selectedRoomId: hostedRoomId });
    this.persist();
    await this.loadRooms();
    await this.updateUserProfile({ displayName, identityRootDid: userRootDid });
    await this.refreshStationClaim();
    return hostedRoomId;
  }

  async ensureUserProfile(displayName = this.snapshotValue.displayName ?? "abrum web user"): Promise<SignedTwin | null> {
    if (!this.snapshotValue.selectedRoomId && !this.snapshotValue.hostedRoomId) {
      return null;
    }
    return this.updateUserProfile({ displayName });
  }

  /**
   * The room the canonical user profile is written to. Prefer the user's
   * hidden private Profile Room. Existing installations may still expose the
   * legacy `public` purpose. Never fall back to a selected work Room: profile
   * data has its own authority and replication boundary.
   */
  private profileRoomId(): string {
    const profileRoom = this.snapshotValue.rooms.find((room) => room.purpose === "profile")
      ?? this.snapshotValue.rooms.find((room) => room.purpose === "public");
    if (!profileRoom) {
      throw new Error("The user's private Profile Room is not available");
    }
    return profileRoom.id;
  }

  async updateUserProfile(input: {
    displayName?: string;
    identityRootDid?: string | null;
    avatarFileLineageCid?: string | null;
    bio?: string | null;
  }): Promise<SignedTwin> {
    const user = this.requireUser();
    const roomId = this.profileRoomId();
    const existing = await this.pull(roomId, 0);
    const current = findUserProfile(existing.entries, user.did);
    const currentContent = current ? asRecordOrNull(current.block.content) : null;
    const now = Date.now();
    const displayName = input.displayName?.trim()
      || asOptionalString(currentContent?.displayName)
      || this.snapshotValue.displayName
      || "abrum web user";
    const avatarFileLineageCid = input.avatarFileLineageCid === undefined
      ? asOptionalString(currentContent?.avatarFileLineageCid)
      : input.avatarFileLineageCid;
    const identityRootDid = input.identityRootDid === undefined
      ? asOptionalString(currentContent?.identityRootDid)
      : input.identityRootDid;
    const bio = input.bio === undefined ? asOptionalString(currentContent?.bio) : input.bio;
    if (
      current &&
      displayName === asOptionalString(currentContent?.displayName) &&
      (identityRootDid ?? null) === (asOptionalString(currentContent?.identityRootDid) ?? null) &&
      (bio ?? null) === (asOptionalString(currentContent?.bio) ?? null) &&
      (avatarFileLineageCid ?? null) === (asOptionalString(currentContent?.avatarFileLineageCid) ?? null)
    ) {
      this.patch({ displayName });
      this.persist({ displayName });
      return current;
    }
    const [profile] = await this.objectInRoomTwins(
      SCHEMA_USER_PROFILE_CID,
      withoutUndefined({
        type: "userProfile",
        userDid: user.did,
        identityRootDid: identityRootDid || undefined,
        displayName,
        bio: bio || undefined,
        avatarFileLineageCid: avatarFileLineageCid || undefined,
        createdAtMs: asOptionalNumber(currentContent?.createdAtMs) ?? now,
        updatedAtMs: now,
        version: (asOptionalNumber(currentContent?.version) ?? 0) + 1,
      }),
      current?.cid ?? null,
      roomId,
    );
    await this.putTwins([profile], roomId);
    this.patch({ displayName });
    this.persist({ displayName });
    return profile;
  }

  async putTwins(
    twins: SignedTwin[],
    roomId = this.requireSelectedRoom(),
    expectedObjectHeads: readonly string[] = [],
  ): Promise<SyncPushResult> {
    const user = this.requireUser();
    const batchCids = new Set(twins.map((twin) => twin.cid));
    const expectedHeads = [...new Set([
      ...expectedObjectHeads,
      ...twins.flatMap((twin) =>
        twin.block.kind === "object"
          && twin.block.previousVersion
          && !batchCids.has(twin.block.previousVersion)
          ? [twin.block.previousVersion]
          : [],
      ),
    ])];
    const result = await this.station.push({
      room_id: roomId,
      actor_principal_did: user.did,
      twins,
      expected_object_heads: expectedHeads,
    }, {
      actor: user,
      signUtf8: (payload) => this.protocolCore.signUtf8(user, payload),
    });
    const validationComplete = result.validation_complete
      ?? (result.rejected.length === 0
        && result.waiting.length === 0
        && (result.quarantined?.length ?? 0) === 0);
    if (!validationComplete) {
      throw new AbrumPushError({
        rejected: result.rejected,
        waiting: result.waiting,
        quarantined: result.quarantined ?? [],
      });
    }
    this.invalidateLocalTwins(roomId, twins, result);
    return result;
  }

  async pull(roomId = this.requireSelectedRoom(), afterSeq?: number): Promise<PullTwinsResult> {
    const user = this.requireUser();
    const seq = afterSeq ?? this.snapshotValue.cursorByRoom[roomId] ?? 0;
    const result = await this.roomDataPlane.pullTwinsSince(roomId, user.did, seq, 500, this.httpActorSigner(user));
    this.snapshotValue.cursorByRoom[roomId] = result.cursor.seq;
    this.persist();
    this.emit();
    return result;
  }

  async pullHeads(
    roomId = this.requireSelectedRoom(),
    afterSeq = 0,
    options: PullHeadsOptions = {},
  ): Promise<PullTwinsResult> {
    const user = this.requireUser();
    return retryRoomAuthorizationRead(() => {
      const current = this.requireUser();
      if (current.did !== user.did) throw new Error("Room read identity changed");
      return this.roomDataPlane.pullHeadsSince(roomId, current.did, afterSeq, options, this.httpActorSigner(current));
    });
  }

  async queryHeads(
    query: RoomHeadsQuery,
    roomId = this.requireSelectedRoom(),
  ): Promise<PullTwinsResult> {
    const user = this.requireUser();
    return retryRoomAuthorizationRead(() => {
      const current = this.requireUser();
      if (current.did !== user.did) throw new Error("Room read identity changed");
      return this.roomDataPlane.queryRoomHeads(roomId, current.did, query, this.httpActorSigner(current));
    });
  }

  async queryRoomLens<TDescriptor = RoomLensDescriptor>(
    demand: RoomLensDemand,
  ): Promise<RoomLensSnapshot<SignedTwin, TDescriptor>> {
    const user = this.requireUser();
    const query = this.roomDataPlane.queryRoomLens?.bind(this.roomDataPlane)
      ?? this.station.queryRoomLens.bind(this.station);
    return retryRoomAuthorizationRead(() => {
      const current = this.requireUser();
      if (current.did !== user.did) throw new Error("Room read identity changed");
      return query<TDescriptor>({ ...demand, actorDid: current.did }, this.httpActorSigner(current));
    });
  }

  async agentMessages(
    threadLineageCid: string,
    roomId = this.requireSelectedRoom(),
    runId?: string,
  ): Promise<AbrumAgentChatMessage[]> {
    const user = this.requireUser();
    return this.station.agentMessages(
      roomId,
      user.did,
      threadLineageCid,
      this.httpActorSigner(user),
      runId,
    );
  }

  async agentProcesses(
    roomId = this.requireSelectedRoom(),
  ): Promise<Array<Record<string, JsonValue>>> {
    const user = this.requireUser();
    return this.station.agentProcesses(roomId, user.did, this.httpActorSigner(user));
  }

  async harnessProcessLive(roomId: string, runId: string, viewerRoomId = this.requireSelectedRoom()): Promise<Record<string, JsonValue>> {
    const user = this.requireUser();
    return this.station.harnessProcessLive(roomId, runId, viewerRoomId, user.did, this.httpActorSigner(user));
  }

  async harnessProcessDefinition(viewerRoomId = this.requireSelectedRoom()): Promise<Record<string, JsonValue>> {
    const user = this.requireUser();
    return this.station.harnessProcessDefinition(viewerRoomId, user.did, this.httpActorSigner(user));
  }

  async harnessDebugRooms(viewerRoomId = this.requireSelectedRoom()): Promise<Record<string, JsonValue>> {
    const user = this.requireUser();
    return this.station.harnessDebugRooms(viewerRoomId, user.did, this.httpActorSigner(user));
  }

  async harnessDebugRuns(roomId: string, viewerRoomId = this.requireSelectedRoom()): Promise<Record<string, JsonValue>> {
    const user = this.requireUser();
    return this.station.harnessDebugRuns(roomId, viewerRoomId, user.did, this.httpActorSigner(user));
  }

  async loadRecoveryAudit(roomId = this.requireSelectedRoom()): Promise<RecoveryAuditResult> {
    const user = this.requireUser();
    return this.station.recoveryAudit(roomId, user.did, this.httpActorSigner(user));
  }

  async realtimeEvents(afterOffset = 0, limit = 100): Promise<RealtimeStreamEvent[]> {
    const user = this.requireUser();
    return this.station.realtimeEvents(user.did, afterOffset, limit, this.httpActorSigner(user));
  }

  private async catchUpRealtimeEvents(invalidate = false): Promise<number> {
    const user = this.snapshotValue.user;
    if (!user) {
      return 0;
    }
    let offset = this.snapshotValue.realtimeEventOffset;
    let seen = 0;
    for (;;) {
      const events = await this.station.realtimeEvents(user.did, offset, 500, this.httpActorSigner(user));
      if (events.length === 0) {
        break;
      }
      const epochs = [...new Set(events
        .map((event) => event.stream_epoch?.trim())
        .filter((epoch): epoch is string => Boolean(epoch)))];
      if (epochs.length > 1) {
        throw new Error("station mixed realtime stream epochs in one replay page");
      }
      if (epochs[0] && this.applyRealtimeStreamEpoch(epochs[0])) {
        offset = 0;
        seen = 0;
        continue;
      }
      seen += events.length;
      offset = Math.max(offset, ...events.map((event) => event.offset));
      if (events.length < 500) {
        break;
      }
    }
    const nextOffset = Math.max(offset, this.snapshotValue.realtimeEventOffset);
    if (nextOffset !== this.snapshotValue.realtimeEventOffset) {
      this.snapshotValue.realtimeEventOffset = nextOffset;
      this.persist();
    }
    if (invalidate && seen > 0) {
      // A reconnect may contain changes for several Room/content-type pairs.
      // Null is the deliberate broad invalidation marker; consumers must not
      // collapse the missed batch to only its final typed event.
      this.patch({
        lastRealtimeEvent: null,
        realtimeRevision: this.snapshotValue.realtimeRevision + 1,
      });
    }
    return seen;
  }

  async createRoom(name: string, purpose?: string): Promise<RoomDescriptor> {
    const user = this.requireUser();
    const descriptor = await this.station.createRoom({
      actor_principal_did: user.did,
      name,
      purpose,
    }, this.httpActorSigner(user));
    await this.loadRooms();
    this.patch({ selectedRoomId: descriptor.id });
    this.persist();
    this.postRoomsChanged("create", descriptor.id);
    return descriptor;
  }

  async renameRoom(roomId: string, name: string): Promise<RoomDescriptor> {
    const user = this.requireUser();
    const descriptor = await this.station.patchRoom(roomId, {
      actor_principal_did: user.did,
      name,
    }, this.httpActorSigner(user));
    await this.loadRooms();
    this.postRoomsChanged("rename", roomId);
    return descriptor;
  }

  async archiveRoom(roomId: string): Promise<RoomDescriptor> {
    const user = this.requireUser();
    const descriptor = await this.station.patchRoom(roomId, {
      actor_principal_did: user.did,
      archived: true,
    }, this.httpActorSigner(user));
    const wasSelected = this.snapshotValue.selectedRoomId === roomId;
    this.postRoomsChanged("archive", roomId);
    await this.loadRooms();
    if (wasSelected) {
      const next = this.snapshotValue.rooms.find((room) => room.id !== roomId) ?? null;
      this.patch({ selectedRoomId: next?.id ?? null });
      this.persist();
    }
    return descriptor;
  }

  /** Short-lived signed URL for a blob. The Station checks current Room read
   * rights on each fetch. Pass `filename` when the URL is used to DOWNLOAD it: a
   * blob is addressed by hash and has no name of its own, and an anchor's
   * `download` attribute is ignored cross-origin (an app frame is always a
   * different origin than the Station), so the name has to travel with the
   * request or the file lands as a bare hash without an extension. */
  blobUrl(hash: string, filename?: string): string {
    const user = this.requireUser();
    const routeScope = `/api/blobs/${encodeURIComponent(hash)}`;
    const name = filename?.trim() ?? "";
    const cacheKey = `${user.did}\u0000${hash}\u0000${name}`;
    const cached = this.blobUrls.get(cacheKey);
    if (cached && Date.now() - cached.signedAt < 4 * 60_000) return cached.url;
    const params = new URLSearchParams({ actor_principal_did: user.did });
    if (name) params.set("filename", name);
    this.appendSignedGetParams(params, user, routeScope);
    const url = `${this.stationUrl}${routeScope}?${params.toString()}`;
    if (this.blobUrls.size > 256) this.blobUrls.clear();
    this.blobUrls.set(cacheKey, { url, signedAt: Date.now() });
    return url;
  }

  async uploadBlob(blob: Blob): Promise<{ hash: string; url: string }> {
    const result = await this.station.uploadBlob(blob);
    return { hash: result.hash, url: this.blobUrl(result.hash) };
  }

  async uploadUserAvatar(blob: Blob): Promise<SignedTwin> {
    const processed = await cropAndResizeImage(blob);
    const { hash } = await this.uploadBlob(processed);
    return this.updateUserProfile({ avatarFileLineageCid: hash });
  }

  async loadRooms(): Promise<RoomDescriptor[]> {
    const user = this.requireUser();
    const signer = this.httpActorSigner(user);
    const [rooms, stationClaimed] = await Promise.all([
      this.station.listRooms(user.did, signer),
      this.station.isServingUser(user.did),
    ]);
    const hostedRoomId = this.snapshotValue.hostedRoomId;
    const current = this.snapshotValue.selectedRoomId ?? hostedRoomId;
    // Keep the handoff-provided host Room selected while talking to an older
    // Station that does not yet project an app runner's Room-bound delegation
    // into `listRooms`. Current Stations list only the Rooms that delegation
    // reaches, but the fallback keeps mixed-version desktop upgrades usable.
    const selectedRoomId = current && (rooms.some((room) => room.id === current) || current === hostedRoomId)
      ? current
      : rooms[0]?.id ?? null;
    this.patch({ rooms, selectedRoomId, stationClaimed });
    this.persist();
    return rooms;
  }

  async loadAgentCapabilityProviders(
    consumerRoomId = this.requireSelectedRoom(),
  ): Promise<AbrumAgentCapabilityProvider[]> {
    const user = this.requireUser();
    return this.station.listAgentCapabilityProviders(
      consumerRoomId,
      user.did,
      this.httpActorSigner(user),
    );
  }

  async refreshStationClaim(): Promise<boolean> {
    const user = this.snapshotValue.user;
    if (!user) {
      this.patch({ stationClaimed: false });
      return false;
    }
    const stationClaimed = await this.station.isServingUser(user.did);
    this.patch({ stationClaimed });
    return stationClaimed;
  }

  async loadRoomMembers(roomId = this.requireSelectedRoom()): Promise<RoomMemberGrant[]> {
    const user = this.requireUser();
    return this.station.listRoomMembers(roomId, user.did, this.httpActorSigner(user));
  }

  async loadContacts(): Promise<AbrumContact[]> {
    const user = this.requireUser();
    return this.station.listContacts(user.did, this.httpActorSigner(user));
  }

  async loadPeersStatus(): Promise<AbrumPeersStatus> {
    const user = this.requireUser();
    return this.station.peersStatus(user.did, this.httpActorSigner(user));
  }

  async grantRoomAccess(
    principalDid: string,
    level: RoomAccessLevel,
    roomId = this.requireSelectedRoom(),
  ): Promise<SyncPushResult> {
    // Human access grants require the native host's Pocket presence flow. An
    // app frame cannot mint a portable Warden proof with its own signing key.
    if (typeof window !== "undefined" && window.parent !== window) {
      const requestId = crypto.randomUUID();
      const result = await new Promise<{ grantCid: string }>((resolve, reject) => {
        const timeout = window.setTimeout(() => {
          window.removeEventListener("message", onMessage);
          reject(new Error("Warden grant timed out"));
        }, 120_000);
        function onMessage(event: MessageEvent) {
          if (event.source !== window.parent || event.data?.type !== "abrum:room-grant-response"
              || event.data?.requestId !== requestId) return;
          window.clearTimeout(timeout);
          window.removeEventListener("message", onMessage);
          if (event.data.ok && typeof event.data.grantCid === "string") resolve(event.data);
          else reject(new Error(String(event.data.error || "Warden grant failed")));
        }
        window.addEventListener("message", onMessage);
        window.parent.postMessage({ type: "abrum:room-grant-request", requestId,
          roomId, principalDid: principalDid.trim(), level }, "*");
      });
      await this.loadRooms();
      return { inserted: [result.grantCid], waiting: [], quarantined: [], rejected: [],
        validation_complete: true, watermark_ms: Date.now() };
    }
    throw new Error("Room access grants require the Warden desktop host");
  }

  async provisionAgentBrainAccess(
    agentRoomId: string,
    brainRoomId: string,
    access: "read" | "contribute" = "read",
  ): Promise<AbrumAgentBrainBindingGrant> {
    const user = this.requireUser();
    const brainRoom = this.requireRoom(brainRoomId);
    if (!this.snapshotValue.rooms.some((room) => room.id === agentRoomId)) {
      throw new Error(`agent room ${agentRoomId} is not accessible`);
    }
    const readFunctions = [
      "abrum.brain/prepareAgentContext",
      "abrum.brain/getRecoveryContext",
      "abrum.brain/queryBrain",
      "abrum.brain/drillDownThought",
      "abrum.brain/listDomains",
      "abrum.brain/neighborhood",
      "abrum.brain/spine",
      "abrum.brain/route",
      "abrum.brain/lineage",
      "abrum.brain/healthCheck",
    ];
    const functions = access === "contribute"
      ? [...readFunctions, "abrum.brain/contributeToBrain", "abrum.brain/ingestAgentTurn"]
      : readFunctions;
    const provisioned = await this.station.provisionRoomAgent({
      roomId: brainRoomId,
      functions,
      ttlMs: 60 * 60 * 1000,
    }, user.did, this.httpActorSigner(user));
    if (provisioned.approvalRequired) {
      throw new Error(
        `Warden approval requested (${provisioned.requestId ?? "pending"}). Approve it in Warden; the connection will then be added automatically.`,
      );
    }
    const holderDid = provisioned.holderDid?.trim();
    const capCid = provisioned.brainAccessCapabilityCid?.trim();
    if (!holderDid || !capCid) {
      throw new Error("station did not return a Brain service principal and capability");
    }
    const rights = this.protocolCore.relationTwin(user, {
      source: holderDid,
      target: brainRoom.root_collection_cid,
      relationType: "writes",
      inheritsAccess: true,
    });
    const capability = this.protocolCore.relationTwin(user, {
      source: holderDid,
      target: capCid,
      relationType: "grantsCapability",
      inheritsAccess: false,
      extra: { roomId: brainRoomId, agentRoomId, functions, access },
    });
    await this.putTwins([rights, capability], brainRoomId);
    return { brainRoomId, holderDid, capCid, access, functions };
  }

  async provisionAgentRoomCapability(input: {
    consumerRoomId: string;
    providerRoomId: string;
    appId: string;
    offerId: string;
    mode?: "on_behalf_of_caller" | "delegated_service" | "autonomous";
    resultPolicy?: string;
    functions?: string[];
    ttlMs?: number;
  }): Promise<AbrumAgentCapabilityBindingGrant> {
    const user = this.requireUser();
    const providerRoom = this.requireRoom(input.providerRoomId);
    if (!this.snapshotValue.rooms.some((room) => room.id === input.consumerRoomId)) {
      throw new Error(`consumer room ${input.consumerRoomId} is not accessible`);
    }
    const provisioned = await this.station.provisionRoomAgent({
      roomId: input.providerRoomId,
      consumerRoomId: input.consumerRoomId,
      appId: input.appId,
      offerId: input.offerId,
      mode: input.mode,
      resultPolicy: input.resultPolicy,
      functions: input.functions,
      ttlMs: input.ttlMs,
    }, user.did, this.httpActorSigner(user));
    if (provisioned.approvalRequired) {
      throw new Error(
        `Warden approval requested (${provisioned.requestId ?? "pending"}). Approve it in Warden; the connection will then be added automatically.`,
      );
    }
    const holderDid = provisioned.holderDid?.trim();
    const capCid = provisioned.appAccessCapabilityCid?.trim();
    const mode = provisioned.mode?.trim() as AbrumAgentCapabilityBindingGrant["mode"] | undefined;
    const resultPolicy = provisioned.resultPolicy?.trim();
    const functions = Array.isArray(provisioned.functions)
      ? provisioned.functions.filter((value): value is string => typeof value === "string")
      : [];
    if (!holderDid || !capCid || !mode || !resultPolicy || functions.length === 0) {
      throw new Error("station did not return a complete app capability grant");
    }
    const rights = this.protocolCore.relationTwin(user, {
      source: holderDid,
      target: providerRoom.root_collection_cid,
      relationType: "writes",
      inheritsAccess: true,
    });
    const capability = this.protocolCore.relationTwin(user, {
      source: holderDid,
      target: capCid,
      relationType: "grantsCapability",
      inheritsAccess: false,
      extra: {
        roomId: input.providerRoomId,
        consumerRoomId: input.consumerRoomId,
        appId: input.appId,
        offerId: input.offerId,
        mode,
        resultPolicy,
        functions,
      },
    });
    await this.putTwins([rights, capability], input.providerRoomId);
    return {
      providerRoomId: input.providerRoomId,
      appId: input.appId,
      offerId: input.offerId,
      holderDid,
      capCid,
      mode,
      resultPolicy,
      functions,
    };
  }

  /**
   * The desktop host performs sharing on the app's behalf when the app runs
   * embedded: the station call needs the actor's signer, which an embedded app
   * does not hold. Every share path asks this ONE question — the component that
   * draws the dialog must never ask it again, or the two can disagree about
   * which half of the flow they are in.
   */
  private hostShareRequest(payload: Parameters<typeof postAbrumShareContentRequest>[0]): Promise<unknown> | null {
    const hosted = readHostedAppRoute();
    if (!hosted || readEmbedSignal()?.kind !== "electron") return null;
    return postAbrumShareContentRequest(payload, { appId: hosted.appId });
  }

  /**
   * Who this item is shared with right now, and who it could be shared with.
   * Routed like every other share call, and reduced by the one projection, so
   * an embedded app and a browser tab see the same answer.
   */
  async contentShareContext(input: {
    roomId?: string;
    lineageCid: string;
  }): Promise<{ contacts: AbrumContact[]; shares: AbrumContentShareRecord[] }> {
    const user = this.requireUser();
    const roomId = input.roomId ?? this.requireSelectedRoom();
    const lineageCid = input.lineageCid.trim();
    if (!lineageCid) {
      throw new Error("lineageCid is required");
    }
    const hostResult = this.hostShareRequest({ action: "context", roomId, lineageCid });
    if (hostResult) {
      const raw = await hostResult as { contacts?: unknown; entries?: unknown };
      const contacts = Array.isArray(raw?.contacts) ? raw.contacts as AbrumContact[] : [];
      const entries = Array.isArray(raw?.entries) ? raw.entries as TwinLogEntry[] : [];
      return {
        contacts: sortContacts(contacts),
        shares: activeContentSharesFromEntries(entries, lineageCid),
      };
    }
    void user;
    const [contacts, heads] = await Promise.all([
      this.loadContacts(),
      this.pullHeads(roomId, 0, { contentTypes: ["contentShare", "contentShareRevocation"] }),
    ]);
    return {
      contacts: sortContacts(contacts),
      shares: activeContentSharesFromEntries(heads.entries, lineageCid),
    };
  }

  async shareContent(input: AbrumShareContentInput): Promise<AbrumShareContentResult> {
    const user = this.requireUser();
    const roomId = input.roomId ?? this.requireSelectedRoom();
    const sharedWithDid = input.sharedWithDid.trim();
    const lineageCid = input.lineageCid.trim();
    const accessLevel: RoomAccessLevel = "read";
    if (!sharedWithDid) {
      throw new Error("sharedWithDid is required");
    }
    if (!lineageCid) {
      throw new Error("lineageCid is required");
    }

    const hostResult = this.hostShareRequest({
      roomId,
      lineageCid,
      sharedWithDid,
      recipientStationId: input.recipientStationId?.trim() || undefined,
      targetCid: input.targetCid?.trim() || undefined,
      targetType: input.targetType?.trim() || undefined,
      title: input.title?.trim() || undefined,
    });
    if (hostResult) {
      return normalizeShareContentResult(await hostResult, {
        roomId,
        lineageCid,
        sharedWithDid,
        accessLevel,
      });
    }

    const directShare = await this.station.directShare({
      actor_principal_did: user.did,
      source_room_id: roomId,
      lineage_cid: lineageCid,
      recipient_did: sharedWithDid,
      recipient_station_id: input.recipientStationId?.trim() || undefined,
    }, this.httpActorSigner(user));

    const schema = await this.schemaTwin(CONTENT_SHARE_SCHEMA_NAME, contentShareJsonSchema());
    const now = Date.now();
    // The station normalizes any lineage member to the canonical root before it
    // scopes the source-Room ShareGrant. The receipt has to record THAT value, or a
    // later lookup keyed on a different member of the same lineage finds
    // nothing and the share becomes invisible (and unrevocable) in the UI.
    const canonicalLineageCid = directShare.lineageCid || lineageCid;
    const [receipt] = await this.objectInRoomTwins(
      schema.cid,
      withoutUndefined({
        type: "contentShare",
        lineageCid: canonicalLineageCid,
        targetCid: input.targetCid?.trim() || undefined,
        targetType: input.targetType?.trim() || undefined,
        title: input.title?.trim() || undefined,
        sharedByDid: user.did,
        sharedWithDid,
        accessLevel,
        deliveryMode: "direct-lineage",
        createdAtMs: now,
        updatedAtMs: now,
        version: 1,
      }),
      null,
      roomId,
    );
    const push = await this.putTwins([schema, receipt], roomId);
    return {
      roomId,
      lineageCid: canonicalLineageCid,
      sharedWithDid,
      accessLevel,
      granted: false,
      directShare,
      receipt,
      push,
    };
  }

  async revokeContentShare(input: AbrumRevokeContentShareInput): Promise<AbrumRevokeContentShareResult> {
    const user = this.requireUser();
    const roomId = input.roomId ?? this.requireSelectedRoom();
    const sharedWithDid = input.sharedWithDid.trim();
    const lineageCid = input.lineageCid.trim();
    if (!sharedWithDid) {
      throw new Error("sharedWithDid is required");
    }
    if (!lineageCid) {
      throw new Error("lineageCid is required");
    }

    const hostResult = this.hostShareRequest({
      action: "revoke",
      roomId,
      lineageCid,
      sharedWithDid,
      recipientStationId: input.recipientStationId?.trim() || undefined,
    });
    if (hostResult) {
      return normalizeRevokeContentShareResult(await hostResult, {
        roomId,
        lineageCid,
        sharedWithDid,
      });
    }

    const directShare = await this.station.directShareRevoke({
      actor_principal_did: user.did,
      source_room_id: roomId,
      lineage_cid: lineageCid,
      recipient_did: sharedWithDid,
      recipient_station_id: input.recipientStationId?.trim() || undefined,
    }, this.httpActorSigner(user));
    const schema = await this.schemaTwin(
      CONTENT_SHARE_REVOCATION_SCHEMA_NAME,
      contentShareRevocationJsonSchema(),
    );
    // Same canonicalization as the share receipt — a revocation keyed on a
    // different lineage member would never cancel the share it belongs to.
    const canonicalLineageCid = directShare.lineageCid || lineageCid;
    const [receipt] = await this.objectInRoomTwins(
      schema.cid,
      {
        type: "contentShareRevocation",
        lineageCid: canonicalLineageCid,
        sharedByDid: user.did,
        sharedWithDid,
        deliveredBytesRemain: directShare.deliveredBytesRemain,
        revokedAtMs: Date.now(),
        version: 1,
      },
      null,
      roomId,
    );
    const push = await this.putTwins([schema, receipt], roomId);
    return {
      roomId,
      lineageCid: canonicalLineageCid,
      sharedWithDid,
      directShare,
      receipt,
      push,
    };
  }

  async sendDirectLineageInvite(input: AbrumDirectLineageInviteInput): Promise<AbrumDirectLineageInviteResult> {
    const user = this.requireUser();
    return this.station.directLineageInvite(
      {
        actor_principal_did: user.did,
        source_room_id: input.sourceRoomId,
        lineage_cid: input.lineageCid,
        share_grant_cid: input.shareGrantCid,
        peer_id: input.peerId,
      },
      this.httpActorSigner(user),
    );
  }

  stationTicket(): Promise<string> {
    const user = this.requireUser();
    return this.station.claimTicket(user.did, this.httpActorSigner(user));
  }

  async connectStation(ticket: string): Promise<void> {
    const user = this.requireUser();
    await this.station.connectStation(ticket, user.did, this.httpActorSigner(user));
    this.patch({ realtimeRevision: this.snapshotValue.realtimeRevision + 1 });
  }

  async revokeRoomAccess(grantCid: string, roomId = this.requireSelectedRoom()): Promise<SyncPushResult> {
    const user = this.requireUser();
    const relation = this.protocolCore.relationTwin(user, {
      source: user.did,
      target: grantCid,
      relationType: "deletes",
      inheritsAccess: false,
    });
    const result = await this.putTwins([relation], roomId);
    await this.loadRooms();
    return result;
  }

  /** Tombstone an object twin (e.g. an app entity) by its head cid. The twin
   * stays in the log but is excluded from entity queries via the `deletes`
   * relation. Authorized when the caller authored the target or has admin. */
  async deleteEntity(cid: string, roomId = this.requireSelectedRoom()): Promise<SyncPushResult> {
    const user = this.requireUser();
    const relation = this.protocolCore.relationTwin(user, {
      source: user.did,
      target: cid,
      relationType: "deletes",
      inheritsAccess: false,
    });
    return this.putTwins([relation], roomId, [cid]);
  }

  async runAppFunction(
    appId: string,
    functionName: string,
    input: JsonValue,
    roomId = this.requireSelectedRoom(),
    options: AbrumRunAppFunctionOptions = {},
  ): Promise<AbrumAppRunResult> {
    const user = this.requireUser();
    const result = await this.station.runAppFunction(
      {
        actor_principal_did: user.did,
        room_id: roomId,
        app_id: appId,
        function: functionName,
        input,
        source_app_id: options.sourceAppId ?? undefined,
      },
      {
        actor: user,
        signUtf8: (payload) => this.protocolCore.signUtf8(user, payload),
      },
    );
    this.invalidateLocalTwins(
      roomId,
      [...result.schemas, ...result.objects, ...result.relations],
      result.push,
    );
    return result;
  }

  selectRoom(roomId: string): void {
    if (!this.snapshotValue.rooms.some((room) => room.id === roomId)) {
      throw new Error(`room ${roomId} is not accessible`);
    }
    this.patch({ selectedRoomId: roomId });
    this.persist();
  }

  async schemaTwin(name: string, jsonSchema: JsonValue): Promise<SignedTwin> {
    return this.protocolCore.schemaTwinForIdentity(this.requireUser(), name, "user", jsonSchema);
  }

  async entitySchemaTwin<App extends AbrumApp<AbrumEntities>, Name extends keyof App["entities"] & string>(
    app: App,
    entityName: Name,
  ): Promise<SignedTwin> {
    return this.protocolCore.schemaTwinForIdentity(
      this.requireUser(),
      entitySchemaName(app, entityName),
      "user",
      entityJsonSchema(app, entityName),
    );
  }

  async createEntity<App extends AbrumApp<AbrumEntities>, Name extends keyof App["entities"] & string>(
    app: App,
    entityName: Name,
    input: AbrumEntityInput<App["entities"][Name]>,
    roomId = this.requireSelectedRoom(),
  ): Promise<AbrumCreateEntityResult> {
    const schema = await this.entitySchemaTwin(app, entityName);
    const [twin] = await this.objectInRoomTwins(
      schema.cid,
      entityContent(app, entityName, input as Record<string, unknown>),
      null,
      roomId,
    );
    const push = await this.putTwins([schema, twin], roomId);
    return {
      cid: twin.cid,
      twin,
      schema,
      push,
    };
  }

  /** Append a new head to an entity's existing Room-local lineage. The record
   * carries its authority Room, so an App Lens cannot accidentally write the
   * currently selected Room instead. Containment belongs to the lineage and is
   * therefore not re-emitted for every version. */
  async updateEntity<App extends AbrumApp<AbrumEntities>, Name extends keyof App["entities"] & string>(
    app: App,
    entityName: Name,
    record: AbrumEntityRecord<App["entities"][Name]>,
    patch: Partial<AbrumEntityInput<App["entities"][Name]>>,
    roomId?: string,
  ): Promise<AbrumUpdateEntityResult> {
    const recordRoomId = record.$.authorityRoomId ?? record.$.sourceRoomId;
    if (roomId && recordRoomId && roomId !== recordRoomId) {
      throw new Error(
        `${String(entityName)} ${record.$.cid} belongs to Room ${recordRoomId}, not ${roomId}`,
      );
    }
    const authorityRoomId = roomId ?? recordRoomId;
    if (!authorityRoomId) {
      throw new Error(
        `${String(entityName)} ${record.$.cid} has no authority Room; pass { roomId } explicitly`,
      );
    }
    const schemaCid = record.$.schemaCid;
    if (!schemaCid) {
      throw new Error(`${String(entityName)} ${record.$.cid} has no schema`);
    }
    const current = record.$.twin.block.content;
    if (!current || typeof current !== "object" || Array.isArray(current)) {
      throw new Error(`${String(entityName)} ${record.$.cid} has invalid object content`);
    }
    const input: Record<string, unknown> = {};
    for (const fieldName of Object.keys(app.entities[entityName].fields)) {
      input[fieldName] = Object.prototype.hasOwnProperty.call(patch, fieldName)
        ? (patch as Record<string, unknown>)[fieldName]
        : (current as Record<string, unknown>)[fieldName];
    }
    const twin = this.protocolCore.objectTwin(
      this.requireUser(),
      schemaCid,
      entityContent(app, entityName, input),
      record.$.cid,
    );
    const push = await this.putTwins([twin], authorityRoomId);
    return { cid: twin.cid, twin, push };
  }

  /** Append several heads as one Station batch. Every record must have the same
   * authority Room; cross-Room batches fail before any twin is signed. */
  async updateEntities<App extends AbrumApp<AbrumEntities>, Name extends keyof App["entities"] & string>(
    app: App,
    entityName: Name,
    updates: ReadonlyArray<{
      record: AbrumEntityRecord<App["entities"][Name]>;
      patch: Partial<AbrumEntityInput<App["entities"][Name]>>;
    }>,
    roomId?: string,
  ): Promise<SyncPushResult> {
    if (updates.length === 0) {
      throw new Error(`${String(entityName)}.updateMany requires at least one record`);
    }
    const authorityRoomIds = new Set(updates.map(({ record }) =>
      record.$.authorityRoomId ?? record.$.sourceRoomId
    ).filter((value): value is string => Boolean(value)));
    if (authorityRoomIds.size > 1) {
      throw new Error(`${String(entityName)}.updateMany cannot cross Room authority boundaries`);
    }
    const recordRoomId = authorityRoomIds.values().next().value as string | undefined;
    if (roomId && recordRoomId && roomId !== recordRoomId) {
      throw new Error(`${String(entityName)}.updateMany belongs to Room ${recordRoomId}, not ${roomId}`);
    }
    const authorityRoomId = roomId ?? recordRoomId;
    if (!authorityRoomId) {
      throw new Error(
        `${String(entityName)}.updateMany has a record without Room authority; pass one Room explicitly`,
      );
    }
    const twins = updates.map(({ record, patch }) => {
      const schemaCid = record.$.schemaCid;
      if (!schemaCid) {
        throw new Error(`${String(entityName)} ${record.$.cid} has no schema`);
      }
      const current = record.$.twin.block.content;
      if (!current || typeof current !== "object" || Array.isArray(current)) {
        throw new Error(`${String(entityName)} ${record.$.cid} has invalid object content`);
      }
      const input: Record<string, unknown> = {};
      for (const fieldName of Object.keys(app.entities[entityName].fields)) {
        input[fieldName] = Object.prototype.hasOwnProperty.call(patch, fieldName)
          ? (patch as Record<string, unknown>)[fieldName]
          : (current as Record<string, unknown>)[fieldName];
      }
      return this.protocolCore.objectTwin(
        this.requireUser(),
        schemaCid,
        entityContent(app, entityName, input),
        record.$.cid,
      );
    });
    return this.putTwins(twins, authorityRoomId);
  }

  /** Tombstone several current entity heads atomically within one Room. */
  async deleteEntities<Entity>(
    records: ReadonlyArray<AbrumEntityRecord<Entity>>,
    roomId?: string,
  ): Promise<SyncPushResult> {
    if (records.length === 0) {
      throw new Error("deleteMany requires at least one record");
    }
    const authorityRoomIds = new Set(records.map((record) =>
      record.$.authorityRoomId ?? record.$.sourceRoomId
    ).filter((value): value is string => Boolean(value)));
    if (authorityRoomIds.size > 1) {
      throw new Error("deleteMany cannot cross Room authority boundaries");
    }
    const recordRoomId = authorityRoomIds.values().next().value as string | undefined;
    if (roomId && recordRoomId && roomId !== recordRoomId) {
      throw new Error(`deleteMany records belong to Room ${recordRoomId}, not ${roomId}`);
    }
    const authorityRoomId = roomId ?? recordRoomId;
    if (!authorityRoomId) {
      throw new Error("deleteMany has a record without Room authority; pass one Room explicitly");
    }
    const user = this.requireUser();
    const relations = records.map((record) => this.protocolCore.relationTwin(user, {
      source: user.did,
      target: record.$.cid,
      relationType: "deletes",
      inheritsAccess: false,
    }));
    return this.putTwins(
      relations,
      authorityRoomId,
      records.map((record) => record.$.cid),
    );
  }

  /**
   * SK-19 · Provision-seam ("Seam vor Store"): write a Warden-gated `secret` twin for
   * a declared `requiredSecret`, WITHOUT the caller importing abrum.secrets' schema. The
   * plaintext is sealed HERE to the station's X25519 key (AAD = the secretId — exactly
   * the form the station's server-side fill opens); it never lands on a non-secret twin.
   * Any app that declares a requiredSecret provisions through this one primitive; the
   * write trips the station's AR-8 mutation gate (fresh single-use Warden 2FA) at sync.
   */
  async provisionSecret(
    input: {
      name: string;
      secretId: string;
      kind: string;
      plaintext: string;
      requiredByAppId?: string;
      functions?: JsonValue;
      firstUseWarrant?: boolean;
      portable?: boolean;
      label?: string;
    },
    roomId = this.requireSelectedRoom(),
  ): Promise<AbrumCreateEntityResult> {
    const stationX = this.snapshotValue.stationIdentity?.x25519_public_key;
    if (!stationX) throw new Error("station X25519 key not available — cannot seal the secret");
    if (!input.secretId.trim()) throw new Error("secretId is required to provision a secret");
    const sealedValue = this.conveySecretValue(
      stationX,
      input.secretId,
      input.plaintext,
    ) as unknown as JsonValue;
    const now = Date.now();
    // Per #476: DO NOT write `portableValue: null` next to a real `sealedValue` — omit it.
    // `value` is the local-vault field (UI reveal); an app credential is server-side-fill
    // only, so it stays empty.
    return this.createEntity(
      abrumSystemApp,
      "secret",
      {
        name: input.name,
        value: "",
        label: input.label ?? "",
        kind: input.kind,
        secretId: input.secretId,
        requiredByAppId: input.requiredByAppId ?? "",
        sealedValue,
        sealedForStationX25519: stationX,
        functionsJson: input.functions ?? [],
        firstUseWarrant: input.firstUseWarrant ?? false,
        portable: input.portable ?? false,
        createdAtMs: now,
        updatedAtMs: now,
      } as AbrumEntityInput<(typeof abrumSystemApp)["entities"]["secret"]>,
      roomId,
    );
  }

  // SK-19/DP9b · declare a per-account credential REQUEST (the DECLARE side of the
  // seam; `provisionSecret` is the WRITE side). No sealing — a request carries no
  // value, only the need. Secrets renders it as a "Missing" card and maps it.
  async requestSecret(
    input: { secretId: string; requiredByAppId?: string; kind?: string; label?: string },
    roomId = this.requireSelectedRoom(),
  ): Promise<AbrumCreateEntityResult> {
    if (!input.secretId.trim()) throw new Error("secretId is required to request a secret");
    const now = Date.now();
    return this.createEntity(
      abrumSystemApp,
      "secret_request",
      {
        secretId: input.secretId,
        requiredByAppId: input.requiredByAppId ?? "",
        kind: input.kind ?? "",
        label: input.label ?? "",
        createdAtMs: now,
        updatedAtMs: now,
      } as AbrumEntityInput<(typeof abrumSystemApp)["entities"]["secret_request"]>,
      roomId,
    );
  }

  async ensureAppInstalled(options: AbrumInstallAppOptions, roomId = this.requireSelectedRoom()): Promise<AbrumInstalledApp> {
    const appId = options.appId.trim();
    if (!appId) {
      throw new Error("appId is required");
    }
    const installKey = `${roomId}:${appId}`;
    const pendingInstall = this.installAppPromises.get(installKey);
    if (pendingInstall) {
      return pendingInstall;
    }
    const install = this.installAppOnce(appId, options, roomId).finally(() => {
      this.installAppPromises.delete(installKey);
    });
    this.installAppPromises.set(installKey, install);
    return install;
  }

  private async installAppOnce(
    appId: string,
    options: AbrumInstallAppOptions,
    roomId: string,
  ): Promise<AbrumInstalledApp> {
    const existing = await this.pull(roomId, 0);
    const existingInstall = findInstalledApp(existing.entries, appId, roomId);
    if (existingInstall) {
      const source = asRecordOrNull(existingInstall.installContent.blueprintSource);
      if (source?.kind === "room" && source.roomId !== roomId) {
        // Mounting a consumer app must not rewrite its reviewed release pin
        // from package defaults. Updates are accepted through the Station.
        return existingInstall;
      }
      const latestApp = findLatestAppTwin(existing.entries, appId);
      const latestAppContent = latestApp ? asRecordOrNull(latestApp.block.content) : null;
      const currentArtifact = latestAppContent?.artifact ?? null;
      const currentNetwork = latestAppContent?.network ?? null;
      const currentImports = latestAppContent?.imports ?? [];
      const currentRequiredSecrets = latestAppContent?.requiredSecrets ?? [];
      const currentBackends = latestAppContent?.backends ?? null;
      const currentExecutionLevel = latestAppContent?.executionLevel ?? null;
      const nextArtifact = options.artifact === undefined
        ? currentArtifact
        : mergeJsonValue(currentArtifact, options.artifact);
      const nextNetwork = options.network === undefined
        ? currentNetwork
        : mergeJsonValue(currentNetwork, options.network);
      const nextImports = options.imports === undefined ? currentImports : options.imports;
      const nextRequiredSecrets = options.requiredSecrets === undefined ? currentRequiredSecrets : options.requiredSecrets;
      const nextBackends = options.backends === undefined ? currentBackends : options.backends;
      const nextExecutionLevel = options.executionLevel === undefined ? currentExecutionLevel : options.executionLevel;
      const artifactChanged = options.artifact !== undefined && !jsonValuesEqual(currentArtifact, nextArtifact);
      const networkChanged = options.network !== undefined && !jsonValuesEqual(currentNetwork, nextNetwork);
      const importsChanged = options.imports !== undefined && !jsonValuesEqual(currentImports, nextImports);
      const requiredSecretsChanged = options.requiredSecrets !== undefined && !jsonValuesEqual(currentRequiredSecrets, nextRequiredSecrets);
      const backendsChanged = options.backends !== undefined && !jsonValuesEqual(currentBackends, nextBackends);
      const executionLevelChanged = options.executionLevel !== undefined
        && !jsonValuesEqual(currentExecutionLevel, nextExecutionLevel);
      const selectorChanged = existingInstall.versionSelector !== "pinned"
        || typeof existingInstall.installContent.blueprintVersionCid !== "string";
      if (artifactChanged || networkChanged || importsChanged || requiredSecretsChanged || backendsChanged || executionLevelChanged || selectorChanged) {
        const user = this.requireUser();
        this.requireRoom(roomId);
        const appSchema = artifactChanged || networkChanged || importsChanged || requiredSecretsChanged || backendsChanged || executionLevelChanged
          ? await this.entitySchemaTwin(abrumSystemApp, "app")
          : null;
        const installSchema = selectorChanged || appSchema
          ? await this.entitySchemaTwin(abrumSystemApp, "appInstall")
          : null;
        const now = Date.now();
        const twins: SignedTwin[] = [];
        let app: SignedTwin | null = null;
        if (appSchema) {
          app = this.protocolCore.objectTwin(
            user,
            appSchema.cid,
            entityContent(abrumSystemApp, "app", {
              appId,
              title: options.title,
              description: options.description ?? "",
              kind: options.kind ?? "web",
              appVersion: options.appVersion ?? "0.1.0",
              version: 1,
              schemas: options.schemas ?? [],
              imports: nextImports,
              requiredSecrets: nextRequiredSecrets,
              features: options.features ?? [],
              functions: options.functions ?? [],
              surfaces: options.surfaces ?? [],
              background: options.background ?? null,
              runtime: options.runtime ?? null,
              backends: nextBackends,
              artifact: nextArtifact,
              executionLevel: nextExecutionLevel,
              network: nextNetwork,
              updatedAtMs: now,
            }),
            latestApp?.cid ?? existingInstall.appCid,
          );
          twins.push(appSchema, app);
        }
        if (installSchema) {
          const blueprintVersionCid = app?.cid ?? existingInstall.appCid;
          const install = this.protocolCore.objectTwin(
            user,
            installSchema.cid,
            entityContent(abrumSystemApp, "appInstall", {
              ...existingInstall.installContent,
              blueprintVersionCid,
              blueprintSource: { kind: "room", roomId },
              versionSelector: "pinned",
              updatedAtMs: now,
              version: (asOptionalNumber(existingInstall.installContent.version) ?? 0) + 1,
            }),
            existingInstall.installCid,
          );
          twins.push(installSchema, install);
        }
        const push = await this.putTwins(twins, roomId);
        return {
          ...existingInstall,
          appCid: app?.cid ?? existingInstall.appCid,
          push,
        };
      }
      return existingInstall;
    }

    const user = this.requireUser();
    this.requireRoom(roomId);
    const now = Date.now();
    const appSchema = await this.entitySchemaTwin(abrumSystemApp, "app");
    const installSchema = await this.entitySchemaTwin(abrumSystemApp, "appInstall");
    const app = this.protocolCore.objectTwin(
      user,
      appSchema.cid,
      entityContent(abrumSystemApp, "app", {
        appId,
        title: options.title,
        description: options.description ?? "",
        kind: options.kind ?? "web",
        appVersion: options.appVersion ?? "0.1.0",
        version: 1,
        schemas: options.schemas ?? [],
        imports: options.imports ?? [],
        requiredSecrets: options.requiredSecrets ?? [],
        features: options.features ?? [],
        functions: options.functions ?? [],
        surfaces: options.surfaces ?? [],
        background: options.background ?? null,
        runtime: options.runtime ?? null,
        backends: options.backends ?? null,
        artifact: options.artifact ?? null,
        executionLevel: options.executionLevel ?? null,
        network: options.network ?? null,
        updatedAtMs: now,
      }),
      null,
    );
    const install = this.protocolCore.objectTwin(
      user,
      installSchema.cid,
      entityContent(abrumSystemApp, "appInstall", {
        appId,
        appLineageCid: app.cid,
        blueprintVersionCid: app.cid,
        blueprintSource: { kind: "room", roomId },
        versionSelector: "pinned",
        title: options.title,
        roomId,
        enabled: true,
        grant: "user",
        grantedRights: options.grantedRights ?? ["read", "write"],
        config: options.config ?? {},
        runtimeStatus: "installed",
        version: 1,
        updatedAtMs: now,
      }),
      null,
    );
    const push = await this.putTwins([appSchema, installSchema, app, install], roomId);
    return {
      appId,
      appCid: app.cid,
      installCid: install.cid,
      alreadyInstalled: false,
      push,
    };
  }

  async objectTwin(schemaCid: string, content: JsonValue, previousVersion: string | null = null): Promise<SignedTwin> {
    return this.protocolCore.objectTwin(this.requireUser(), schemaCid, content, previousVersion);
  }

  async objectInRoomTwins(
    schemaCid: string,
    content: JsonValue,
    previousVersion: string | null = null,
    roomId = this.requireSelectedRoom(),
  ): Promise<[SignedTwin]> {
    const user = this.requireUser();
    this.requireRoom(roomId);
    const object = this.protocolCore.objectTwin(user, schemaCid, content, previousVersion);
    return [object];
  }

  async relationTwin(spec: RelationSpec): Promise<SignedTwin> {
    return this.protocolCore.relationTwin(this.requireUser(), spec);
  }

  private async open(): Promise<void> {
    try {
      this.restorePersisted();
      const bootstrap = readStoredSession(this.storageKey)?.bootstrap;
      if (bootstrap?.stationIdentity && bootstrap.room) {
        this.patch({
          stationIdentity: bootstrap.stationIdentity,
          stationClaimed: bootstrap.stationClaimed === true,
          rooms: [bootstrap.room],
          selectedRoomId: this.snapshotValue.selectedRoomId ?? bootstrap.room.id,
          status: "ready",
          error: null,
        });
      } else {
        const stationIdentity = await this.station.identity();
        this.patch({ stationIdentity, status: "ready", error: null });
      }
      if (this.snapshotValue.user) {
        if (bootstrap?.stationIdentity && bootstrap.room) {
          // The selected embedded surface can paint immediately. Refresh the
          // complete actor-scoped Room list off the critical path so lenses and
          // late-arriving shares still converge normally.
          void this.loadRooms().catch(() => undefined);
        } else {
          await this.loadRooms();
        }
        // Every embedded app used to open its own FULL replay during boot
        // (hidden app frames included), which could starve Station before the
        // UI became usable. Dropping the subscription entirely went too far:
        // an embedded app then only saw its own mutations, so Agent runs
        // started in the desktop sidebar never streamed and their result twins
        // never arrived. Embedded apps therefore subscribe live-only — no
        // historical replay, no per-event room reload — while standalone
        // surfaces keep the full replaying subscription.
        this.startRealtime();
      }
    } catch (error) {
      this.patch({
        status: "error",
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  private requireStation(): StationIdentity {
    if (!this.snapshotValue.stationIdentity) {
      throw new Error("station identity is not loaded");
    }
    return this.snapshotValue.stationIdentity;
  }

  private requireUser(): PrincipalIdentity {
    if (!this.snapshotValue.user) {
      throw new Error("create or restore a user first");
    }
    return this.snapshotValue.user;
  }

  private httpActorSigner(user: PrincipalIdentity): HttpActorSigner {
    return {
      actor: user,
      signUtf8: (payload) => this.protocolCore.signUtf8(user, payload),
      signaturePayload: (...args) => this.protocolCore.actorHttpSignaturePayload(...args),
    };
  }

  private appendSignedGetParams(params: URLSearchParams, user: PrincipalIdentity, routeScope: string): void {
    const signer = this.httpActorSigner(user);
    const timestampMs = Date.now();
    const nonce = `nonce-${bytesToHex(randomBytes(8))}`;
    const payload = signer.signaturePayload?.("GET", routeScope, signer.actor.did, timestampMs, nonce, "")
      ?? actorHttpSignaturePayload("GET", routeScope, signer.actor.did, timestampMs, nonce, "");
    params.set("x-abrum-actor-principal-did", signer.actor.did);
    params.set("x-abrum-request-timestamp-ms", String(timestampMs));
    params.set("x-abrum-request-nonce", nonce);
    params.set("x-abrum-request-signature", signer.signUtf8(payload));
  }

  private requireSelectedRoom(): string {
    const roomId = this.snapshotValue.selectedRoomId ?? this.snapshotValue.hostedRoomId;
    if (!roomId) {
      throw new Error("pair with a station and select a room first");
    }
    return roomId;
  }

  private requireRoom(roomId: string): RoomDescriptor {
    const room = this.snapshotValue.rooms.find((candidate) => candidate.id === roomId);
    if (!room) {
      throw new Error(`room ${roomId} is not accessible`);
    }
    return room;
  }

  private invalidateLocalTwins(
    roomId: string,
    twins: readonly SignedTwin[],
    push: Pick<SyncPushResult, "inserted" | "watermark_ms">,
  ): void {
    const event = localTwinsInsertedEvent(roomId, twins, push);
    if (!event) return;
    this.patch({
      lastRealtimeEvent: event,
      realtimeRevision: this.snapshotValue.realtimeRevision + 1,
    });
  }

  /** Native and HTTP transports converge here. App query stores only observe
   * this typed invalidation and never need to know which transport produced it. */
  ingestRealtimeEvent(event: RealtimeStreamEvent["event"] | null, offset?: number): void {
    if (event?.type === "twins_inserted" && event.stream_epoch) {
      this.applyRealtimeStreamEpoch(event.stream_epoch);
    }
    if (offset !== undefined && Number.isSafeInteger(offset)) {
      this.snapshotValue.realtimeEventOffset = Math.max(
        this.snapshotValue.realtimeEventOffset,
        offset,
      );
      this.persist();
    }
    this.patch({
      lastRealtimeEvent: event,
      realtimeRevision: this.snapshotValue.realtimeRevision + 1,
    });
  }

  private scheduleRealtimeReconnect(actorDid: string): void {
    if (this.closed || this.realtimePaused || this.eventsReconnectTimer || this.snapshotValue.user?.did !== actorDid) {
      return;
    }
    const attempt = this.eventsReconnectAttempt++;
    const delay = abrumRealtimeReconnectDelayMs(attempt);
    this.eventsReconnectTimer = setTimeout(() => {
      this.eventsReconnectTimer = null;
      if (this.snapshotValue.user?.did === actorDid) {
        this.startRealtime(true);
      }
    }, delay);
  }

  private startRealtime(recoverMissedEvents = false): void {
    if (this.closed || this.realtimePaused) return;
    const user = this.snapshotValue.user;
    if (!user) {
      return;
    }
    if (this.roomDataPlane.subscribeRoomEvents) {
      if (this.roomDataUnsubscribe && this.eventsActorDid === user.did) return;
      this.roomDataUnsubscribe?.();
      this.eventsActorDid = user.did;
      this.roomDataUnsubscribe = this.roomDataPlane.subscribeRoomEvents((event) => {
        if (this.snapshotValue.user?.did === user.did) this.ingestRealtimeEvent(event);
      });
      return;
    }
    if (typeof EventSource === "undefined") return;
    if (this.events && this.eventsActorDid === user.did) {
      return;
    }
    this.events?.close();
    if (this.eventsReconnectTimer) {
      clearTimeout(this.eventsReconnectTimer);
      this.eventsReconnectTimer = null;
    }
    if (this.eventsActorDid !== user.did) {
      this.eventsReconnectAttempt = 0;
    }
    this.eventsActorDid = user.did;
    const liveOnly = abrumRealtimeSubscriptionMode() === "live";
    const params = new URLSearchParams({
      actor_principal_did: user.did,
      after_offset: String(this.snapshotValue.realtimeEventOffset),
      ...(liveOnly ? { replay: "false" } : {}),
    });
    this.appendSignedGetParams(params, user, "/api/sync/subscribe");
    const events = new EventSource(`${this.stationUrl}/api/sync/subscribe?${params}`);
    this.events = events;
    // A replay can contain a long history. Running a full catch-up and room
    // reload for every event creates an N-squared request storm precisely when
    // the Station is busiest. Coalesce all notifications that arrive while one
    // refresh is in progress into one follow-up pass.
    let syncInFlight = false;
    let syncQueued = false;
    // open() just loaded the rooms; only a replaying subscription has a reason
    // to redo that work as its history drains.
    let lastRoomLoadMs = liveOnly ? Date.now() : 0;
    const syncBookkeeping = () => {
      syncQueued = true;
      if (syncInFlight) return;
      syncInFlight = true;
      void (async () => {
        try {
          do {
            syncQueued = false;
            // A live-only frame uses its persisted cursor only after a
            // reconnect; during steady state it does not replay. Reloading the
            // room list per event is the authorization scan that made a boot
            // with many app frames crawl, so keep that refresh on a one-minute
            // floor.
            if (!liveOnly) await this.catchUpRealtimeEvents();
            if (!liveOnly || Date.now() - lastRoomLoadMs > 60_000) {
              lastRoomLoadMs = Date.now();
              await this.loadRooms();
            }
          } while (syncQueued);
        } catch (error) {
          this.patch({ error: error instanceof Error ? error.message : String(error) });
        } finally {
          syncInFlight = false;
        }
      })();
    };
    events.addEventListener("open", () => {
      if (this.events !== events) return;
      if (recoverMissedEvents && liveOnly) {
        void this.catchUpRealtimeEvents(true)
          .then(() => {
            if (this.events === events) this.eventsReconnectAttempt = 0;
          })
          .catch(() => {
            if (this.events !== events) return;
            events.close();
            this.events = null;
            this.scheduleRealtimeReconnect(user.did);
          });
      } else {
        this.eventsReconnectAttempt = 0;
      }
    });
    events.addEventListener("stream", (event) => {
      if (this.events !== events || !("data" in event) || typeof event.data !== "string") return;
      try {
        const parsed = JSON.parse(event.data) as { stream_epoch?: unknown };
        if (typeof parsed.stream_epoch !== "string") return;
        if (this.applyRealtimeStreamEpoch(parsed.stream_epoch)) {
          events.close();
          this.events = null;
          this.startRealtime(true);
        }
      } catch {
        // A malformed metadata event cannot authorize advancing a durable cursor.
      }
    });
    events.addEventListener("twins", (event) => {
      if (this.events !== events) return;
      const streamOffset = "lastEventId" in event && typeof event.lastEventId === "string"
        ? Number(event.lastEventId)
        : NaN;
      if (Number.isSafeInteger(streamOffset) && streamOffset > this.snapshotValue.realtimeEventOffset) {
        // Persist immediately so a disconnect fetches only the missed durable
        // suffix instead of replaying events this live stream already handled.
        this.snapshotValue.realtimeEventOffset = streamOffset;
        this.persist();
      }
      const realtimeEvent = "data" in event && typeof event.data === "string"
        ? parseTwinsInsertedEvent(event.data)
        : null;
      if (realtimeEvent?.stream_epoch && this.applyRealtimeStreamEpoch(realtimeEvent.stream_epoch)) {
        events.close();
        this.events = null;
        this.startRealtime(true);
        return;
      }
      this.patch({
        lastRealtimeEvent: realtimeEvent,
        realtimeRevision: this.snapshotValue.realtimeRevision + 1,
      });
      syncBookkeeping();
    });
    events.addEventListener("agent_stream_delta", (event) => {
      if (this.events !== events) return;
      if (!("data" in event) || typeof event.data !== "string") return;
      const delta = parseAgentStreamDeltaEvent(event.data);
      if (!delta) return;
      for (const listener of this.agentStreamListeners) listener(delta);
    });
    events.addEventListener("state", () => {
      if (this.events !== events || liveOnly) return;
      // `state` is a legacy, attribution-free Station UI nudge. Peer liveness
      // and duplicate sync traffic can emit it many times per second, but it
      // says nothing about which Room or projection changed. Embedded frames
      // already receive typed `twins` and `rooms` events, so broad-invalidating
      // them here creates a query storm. Keep the legacy standalone refresh,
      // where this surface is the only reader, and match the desktop watcher by
      // ignoring `state` in the embedded/live path.
      this.patch({
        lastRealtimeEvent: null,
        realtimeRevision: this.snapshotValue.realtimeRevision + 1,
      });
      syncBookkeeping();
    });
    events.addEventListener("error", () => {
      if (this.events !== events) return;
      // Native EventSource would retry the identical URL. That URL carries a
      // single-use signed actor nonce and timestamp, so it can never be reused.
      // Rebuild it explicitly and recover the durable suffix after it opens.
      events.close();
      this.events = null;
      this.scheduleRealtimeReconnect(user.did);
    });
    syncBookkeeping();
  }

  private patch(patch: Partial<RuntimeSnapshot>): void {
    if (this.closed) return;
    this.snapshotValue = { ...this.snapshotValue, ...patch };
    this.emit();
  }

  private emit(): void {
    for (const listener of this.listeners) {
      listener();
    }
  }

  private persist(extra?: Pick<StoredSession, "deviceKeySeedHex" | "phrase" | "displayName">): void {
    const existing = readStoredSession(this.storageKey);
    writeStoredSession(this.storageKey, {
      ...existing,
      ...extra,
      hostedRoomId: this.snapshotValue.hostedRoomId,
      selectedRoomId: this.snapshotValue.selectedRoomId,
      cursorByRoom: this.snapshotValue.cursorByRoom,
      realtimeEventOffset: this.snapshotValue.realtimeEventOffset,
      realtimeStreamEpoch: this.snapshotValue.realtimeStreamEpoch,
    });
  }

  /** Accept a Station stream identity and reset any cursor that cannot be
   * proven to belong to it. Returns true when callers must reconnect/replay. */
  private applyRealtimeStreamEpoch(epoch: string): boolean {
    const reconciled = reconcileRealtimeCursor(
      this.snapshotValue.realtimeStreamEpoch,
      this.snapshotValue.realtimeEventOffset,
      epoch,
    );
    this.snapshotValue.realtimeStreamEpoch = reconciled.epoch;
    this.snapshotValue.realtimeEventOffset = reconciled.offset;
    if (reconciled.reset) {
      this.patch({
        lastRealtimeEvent: null,
        realtimeRevision: this.snapshotValue.realtimeRevision + 1,
      });
    }
    this.persist();
    return reconciled.reset;
  }

  private postRoomsChanged(action: "create" | "rename" | "archive", roomId: string): void {
    const hosted = readHostedAppRoute();
    postAbrumRoomsChanged({ action, roomId, appId: hosted?.appId });
  }

  private restorePersisted(): void {
    const stored = readStoredSession(this.storageKey);
    const hosted = readHostedAppRoute();
    if (!stored && !hosted) {
      return;
    }
    let user = stored?.deviceKeySeedHex
      ? this.protocolCore.identityFromSeed(hexToBytes(stored.deviceKeySeedHex))
      : null;
    if (!user && stored?.phrase) {
      // Migrate the historical mnemonic-as-seed record once without changing
      // the DID. The phrase must not survive the successful conversion.
      user = this.protocolCore.identityFromRecoveryPhrase(stored.phrase);
      const { phrase: _legacyPhrase, ...migrated } = stored;
      writeStoredSession(this.storageKey, {
        ...migrated,
        deviceKeySeedHex: user.seedHex,
      });
    }
    const hostedRoomId = hosted?.roomId ?? stored?.hostedRoomId ?? null;
    this.snapshotValue = {
      ...this.snapshotValue,
      user,
      displayName: stored?.displayName ?? null,
      hostedRoomId,
      selectedRoomId: hosted?.roomId ?? stored?.selectedRoomId ?? stored?.hostedRoomId ?? null,
      cursorByRoom: stored?.cursorByRoom ?? {},
      realtimeEventOffset: stored?.realtimeEventOffset ?? 0,
      realtimeStreamEpoch: stored?.realtimeStreamEpoch ?? null,
    };
  }
}

export class HttpStationClient {
  readonly baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  identity(): Promise<StationIdentity> {
    return this.getJson("/api/identity");
  }

  startPairing(): Promise<Record<string, JsonValue>> {
    return this.postJson("/api/users/pairing/start", undefined);
  }

  completePairing(request: unknown): Promise<Record<string, JsonValue>> {
    return this.postJson("/api/users/pairing/complete", request);
  }

  async claimTicket(actorDid: string, signer?: HttpActorSigner): Promise<string> {
    const params = new URLSearchParams({ actor_principal_did: actorDid });
    const path = `/api/station/claim-ticket?${params}`;
    const result = signer
      ? await this.signedGetJson<{ ticket?: string }>(path, signer, "/api/station/claim-ticket")
      : await this.getJson<{ ticket?: string }>(path);
    if (!result.ticket) {
      throw new Error("station did not return a ticket");
    }
    return result.ticket;
  }

  async isServingUser(principalDid: string): Promise<boolean> {
    const params = new URLSearchParams({ principal_did: principalDid });
    const result = await this.getJson<{ serving?: boolean }>(`/api/station/serving-user?${params}`);
    return result.serving === true;
  }

  async connectStation(ticket: string, actorDid: string, signer?: HttpActorSigner): Promise<void> {
    const request = {
      ticket,
      actor_principal_did: actorDid,
    };
    if (signer) {
      await this.signedPostJson<{ connected?: boolean }>("/api/station/connect", request, signer);
      return;
    }
    await this.postJson<{ connected?: boolean }>("/api/station/connect", request);
  }

  listRooms(actorDid: string, signer?: HttpActorSigner): Promise<RoomDescriptor[]> {
    const params = new URLSearchParams({ actor_principal_did: actorDid });
    const path = `/api/rooms?${params}`;
    return signer
      ? this.signedGetJson(path, signer, "/api/rooms")
      : this.getJson(path);
  }

  async listAgentCapabilityProviders(
    consumerRoomId: string,
    actorDid: string,
    signer?: HttpActorSigner,
  ): Promise<AbrumAgentCapabilityProvider[]> {
    const params = new URLSearchParams({
      actor_principal_did: actorDid,
      consumer_room_id: consumerRoomId,
    });
    const path = `/api/apps/capability-providers?${params}`;
    const result = signer
      ? await this.signedGetJson<{ providers?: AbrumAgentCapabilityProvider[] }>(
          path,
          signer,
          "/api/apps/capability-providers",
        )
      : await this.getJson<{ providers?: AbrumAgentCapabilityProvider[] }>(path);
    return Array.isArray(result.providers) ? result.providers : [];
  }

  provisionRoomAgent(
    request: {
      roomId: string;
      consumerRoomId?: string;
      appId?: string;
      offerId?: string;
      mode?: string;
      resultPolicy?: string;
      functions?: string[];
      ttlMs?: number;
      approvalRequestId?: string;
    },
    _actorDid: string,
    signer: HttpActorSigner,
  ): Promise<{
    holderDid?: string;
    brainAccessCapabilityCid?: string;
    appAccessCapabilityCid?: string;
    approvalRequired?: boolean;
    requestId?: string;
    appId?: string;
    offerId?: string;
    mode?: string;
    resultPolicy?: string;
    functions?: string[];
    granted?: boolean;
  }> {
    return this.signedPostJson("/api/mcp/agent-tokens", {
      room_id: request.roomId,
      consumer_room_id: request.consumerRoomId,
      app_id: request.appId,
      offer_id: request.offerId,
      mode: request.mode,
      result_policy: request.resultPolicy,
      functions: request.functions ?? [],
      ttl_ms: request.ttlMs ?? 0,
      approval_request_id: request.approvalRequestId,
    }, signer);
  }

  createRoom(request: {
    actor_principal_did: string;
    name: string;
    purpose?: string;
  }, signer?: HttpActorSigner): Promise<RoomDescriptor> {
    return signer
      ? this.signedPostJson<RoomDescriptor>("/api/rooms", request, signer)
      : this.postJson<RoomDescriptor>("/api/rooms", request);
  }

  patchRoom(
    roomId: string,
    patch: { actor_principal_did: string; name?: string; archived?: boolean },
    signer?: HttpActorSigner,
  ): Promise<RoomDescriptor> {
    const path = `/api/rooms/${encodeURIComponent(roomId)}`;
    return signer
      ? this.signedRequestJson<RoomDescriptor>("PATCH", path, patch, signer)
      : this.requestJson<RoomDescriptor>("PATCH", path, patch);
  }

  async uploadBlob(blob: Blob): Promise<{ hash: string }> {
    const url = `${this.baseUrl}/api/blobs`;
    const response = await fetch(url, {
      method: "POST",
      mode: "cors",
      credentials: "omit",
      cache: "no-store",
      headers: { "content-type": blob.type || "application/octet-stream" },
      body: blob,
    });
    return parseResponse<{ hash: string }>(response);
  }

  async listRoomMembers(roomId: string, actorDid: string, signer?: HttpActorSigner): Promise<RoomMemberGrant[]> {
    const params = new URLSearchParams({ actor_principal_did: actorDid });
    const encodedRoomId = encodeURIComponent(roomId);
    const path = `/api/rooms/${encodedRoomId}/members?${params}`;
    const result = signer
      ? await this.signedGetJson<{ members?: RoomMemberGrant[] }>(path, signer, `/api/rooms/${encodedRoomId}/members`)
      : await this.getJson<{ members?: RoomMemberGrant[] }>(path);
    return result.members ?? [];
  }

  async listContacts(actorDid: string, signer?: HttpActorSigner): Promise<AbrumContact[]> {
    const params = new URLSearchParams({ actor_principal_did: actorDid });
    const path = `/api/contacts?${params}`;
    const result = signer
      ? await this.signedGetJson<{ contacts?: AbrumContact[] }>(path, signer, "/api/contacts")
      : await this.getJson<{ contacts?: AbrumContact[] }>(path);
    return result.contacts ?? [];
  }

  async peersStatus(actorDid: string, signer?: HttpActorSigner): Promise<AbrumPeersStatus> {
    const params = new URLSearchParams({ actor_principal_did: actorDid });
    const path = `/api/peers?${params}`;
    const result = signer
      ? await this.signedGetJson<Partial<AbrumPeersStatus>>(path, signer, "/api/peers")
      : await this.getJson<Partial<AbrumPeersStatus>>(path);
    return normalizePeersStatus(result);
  }

  async push(
    request: {
      room_id: string;
      actor_principal_did: string;
      twins: SignedTwin[];
      expected_object_heads?: string[];
    },
    signer?: HttpActorSigner,
  ): Promise<SyncPushResult> {
    const result = signer
      ? await this.signedPostJson<Partial<SyncPushResult>>("/api/sync", request, signer)
      : await this.postJson<Partial<SyncPushResult>>("/api/sync", request);
    return {
      inserted: result.inserted ?? [],
      waiting: result.waiting ?? [],
      quarantined: result.quarantined ?? [],
      rejected: result.rejected ?? [],
      validation_complete: result.validation_complete
        ?? ((result.waiting?.length ?? 0) === 0
          && (result.quarantined?.length ?? 0) === 0
          && (result.rejected?.length ?? 0) === 0),
      watermark_ms: result.watermark_ms ?? 0,
    };
  }

  async directLineageInvite(request: {
    actor_principal_did: string;
    source_room_id: string;
    lineage_cid: string;
    share_grant_cid: string;
    peer_id: string;
  }, signer?: HttpActorSigner): Promise<AbrumDirectLineageInviteResult> {
    const result = signer
      ? await this.signedPostJson<Partial<AbrumDirectLineageInviteResult>>("/api/shares/lineages/deliver", request, signer)
      : await this.postJson<Partial<AbrumDirectLineageInviteResult>>("/api/shares/lineages/deliver", request);
    return { sent: typeof result.sent === "number" ? result.sent : 0 };
  }

  async directShare(request: {
    actor_principal_did: string;
    source_room_id: string;
    lineage_cid: string;
    recipient_did: string;
    recipient_station_id?: string;
  }, signer?: HttpActorSigner): Promise<AbrumDirectShareResult> {
    const result = signer
      ? await this.signedPostJson<Partial<AbrumDirectShareResult>>("/api/shares/lineages", request, signer)
      : await this.postJson<Partial<AbrumDirectShareResult>>("/api/shares/lineages", request);
    if (!result.sourceRoomId || !result.lineageCid || !result.recipientDid
      || !result.shareGrantCid) {
      throw new Error("station returned an incomplete direct-share result");
    }
    return {
      sourceRoomId: result.sourceRoomId,
      lineageCid: result.lineageCid,
      recipientDid: result.recipientDid,
      recipientStationId: typeof result.recipientStationId === "string"
        ? result.recipientStationId
        : undefined,
      recipientStationIds: Array.isArray(result.recipientStationIds)
        ? result.recipientStationIds.filter((stationId): stationId is string => typeof stationId === "string" && stationId.length > 0)
        : typeof result.recipientStationId === "string" ? [result.recipientStationId] : [],
      shareGrantCid: result.shareGrantCid,
      delivery: result.delivery === "on_demand" ? "on_demand" : "replicate",
      deliveryPending: result.deliveryPending === true,
      sent: typeof result.sent === "number" ? result.sent : 0,
      reused: result.reused === true,
    };
  }

  async directShareRevoke(request: {
    actor_principal_did: string;
    source_room_id: string;
    lineage_cid: string;
    recipient_did: string;
    recipient_station_id?: string;
  }, signer?: HttpActorSigner): Promise<AbrumDirectShareRevokeResult> {
    const result = signer
      ? await this.signedPostJson<Partial<AbrumDirectShareRevokeResult>>("/api/shares/lineages/revoke", request, signer)
      : await this.postJson<Partial<AbrumDirectShareRevokeResult>>("/api/shares/lineages/revoke", request);
    if (!result.sourceRoomId || !result.lineageCid || !result.recipientDid) {
      throw new Error("station returned an incomplete direct-share revoke result");
    }
    return {
      sourceRoomId: result.sourceRoomId,
      lineageCid: result.lineageCid,
      recipientDid: result.recipientDid,
      revokedGrants: typeof result.revokedGrants === "number" ? result.revokedGrants : 0,
      notifiedStations: typeof result.notifiedStations === "number" ? result.notifiedStations : 0,
      deliveredBytesRemain: result.deliveredBytesRemain === true,
    };
  }

  pullTwinsSince(
    roomId: string,
    actorDid: string,
    afterSeq: number,
    limit?: number,
    signer?: HttpActorSigner,
  ): Promise<PullTwinsResult> {
    const params = new URLSearchParams({
      actor_principal_did: actorDid,
      after_seq: String(afterSeq),
    });
    if (limit !== undefined) {
      params.set("limit", String(limit));
    }
    const encodedRoomId = encodeURIComponent(roomId);
    const path = `/api/rooms/${encodedRoomId}/twins?${params}`;
    const routeScope = `/api/rooms/${encodedRoomId}/twins`;
    return signer
      ? this.signedGetJson(path, signer, routeScope)
      : this.getJson(path);
  }

  pullHeadsSince(
    roomId: string,
    actorDid: string,
    afterSeq: number,
    options: PullHeadsOptions = {},
    signer?: HttpActorSigner,
  ): Promise<PullTwinsResult> {
    const params = new URLSearchParams({
      actor_principal_did: actorDid,
      after_seq: String(afterSeq),
    });
    if (options.limit !== undefined) {
      params.set("limit", String(options.limit));
    }
    if (options.contentTypes?.length) {
      params.set("content_type", options.contentTypes.join(","));
    }
    if (options.schemaCids?.length) {
      params.set("schema_cid", options.schemaCids.join(","));
    }
    if (options.lineageCids?.length) {
      params.set("lineage_cid", options.lineageCids.join(","));
    }
    const encodedRoomId = encodeURIComponent(roomId);
    const path = `/api/rooms/${encodedRoomId}/heads?${params}`;
    const routeScope = `/api/rooms/${encodedRoomId}/heads`;
    return signer
      ? this.signedGetJson(path, signer, routeScope)
      : this.getJson(path);
  }

  queryRoomHeads(
    roomId: string,
    actorDid: string,
    query: RoomHeadsQuery,
    signer?: HttpActorSigner,
  ): Promise<PullTwinsResult> {
    const encodedRoomId = encodeURIComponent(roomId);
    const path = `/api/rooms/${encodedRoomId}/query`;
    const request = {
      actor_principal_did: actorDid,
      contentType: query.contentType,
      ...(query.where ? { where: query.where } : {}),
      ...(query.order ? { order: query.order } : {}),
      ...(query.after ? { after: query.after } : {}),
      limit: query.limit,
    };
    return signer
      ? this.signedPostJson(path, request, signer)
      : this.postJson(path, request);
  }

  queryRoomLens<TDescriptor = RoomLensDescriptor>(
    demand: RoomLensDemand,
    signer?: HttpActorSigner,
  ): Promise<RoomLensSnapshot<SignedTwin, TDescriptor>> {
    const path = "/api/room-lenses/query";
    return signer
      ? this.signedPostJson(path, demand, signer)
      : this.postJson(path, demand);
  }

  agentMessages(
    roomId: string,
    actorDid: string,
    threadLineageCid: string,
    signer?: HttpActorSigner,
    runId?: string,
  ): Promise<AbrumAgentChatMessage[]> {
    const encodedRoomId = encodeURIComponent(roomId);
    const routeScope = `/api/rooms/${encodedRoomId}/agent-messages`;
    const params = new URLSearchParams({
      actor_principal_did: actorDid,
      thread_lineage_cid: threadLineageCid,
    });
    if (runId) params.set("run_id", runId);
    const path = `${routeScope}?${params}`;
    return signer
      ? this.signedGetJson(path, signer, routeScope)
      : this.getJson(path);
  }

  agentProcesses(
    roomId: string,
    actorDid: string,
    signer?: HttpActorSigner,
  ): Promise<Array<Record<string, JsonValue>>> {
    const encodedRoomId = encodeURIComponent(roomId);
    const routeScope = `/api/rooms/${encodedRoomId}/agent-processes`;
    const params = new URLSearchParams({ actor_principal_did: actorDid });
    const path = `${routeScope}?${params}`;
    return signer
      ? this.signedGetJson(path, signer, routeScope)
      : this.getJson(path);
  }

  harnessProcessLive(
    roomId: string,
    runId: string,
    viewerRoomId: string,
    actorDid: string,
    signer: HttpActorSigner,
  ): Promise<Record<string, JsonValue>> {
    const routeScope = "/api/agents/harness-process/live";
    const params = new URLSearchParams({
      actor_principal_did: actorDid,
      room_id: roomId,
      viewer_room_id: viewerRoomId,
      run_id: runId,
    });
    return this.signedGetJson(`${routeScope}?${params}`, signer, routeScope);
  }

  harnessProcessDefinition(viewerRoomId: string, actorDid: string, signer: HttpActorSigner): Promise<Record<string, JsonValue>> {
    const routeScope = "/api/agents/harness-process/definition";
    const params = new URLSearchParams({ actor_principal_did: actorDid, viewer_room_id: viewerRoomId });
    return this.signedGetJson(`${routeScope}?${params}`, signer, routeScope);
  }

  harnessDebugRooms(viewerRoomId: string, actorDid: string, signer: HttpActorSigner): Promise<Record<string, JsonValue>> {
    const routeScope = "/api/agents/harness-process/rooms";
    const params = new URLSearchParams({ actor_principal_did: actorDid, viewer_room_id: viewerRoomId });
    return this.signedGetJson(`${routeScope}?${params}`, signer, routeScope);
  }

  harnessDebugRuns(roomId: string, viewerRoomId: string, actorDid: string, signer: HttpActorSigner): Promise<Record<string, JsonValue>> {
    const routeScope = "/api/agents/harness-process/runs";
    const params = new URLSearchParams({ actor_principal_did: actorDid, viewer_room_id: viewerRoomId, room_id: roomId });
    return this.signedGetJson(`${routeScope}?${params}`, signer, routeScope);
  }

  recoveryAudit(roomId: string, actorDid: string, signer?: HttpActorSigner): Promise<RecoveryAuditResult> {
    const params = new URLSearchParams({ actor_principal_did: actorDid });
    const encodedRoomId = encodeURIComponent(roomId);
    const path = `/api/rooms/${encodedRoomId}/recovery-audit?${params}`;
    return signer
      ? this.signedGetJson(path, signer, `/api/rooms/${encodedRoomId}/recovery-audit`)
      : this.getJson(path);
  }

  realtimeEvents(
    actorDid: string,
    afterOffset: number,
    limit?: number,
    signer?: HttpActorSigner,
  ): Promise<RealtimeStreamEvent[]> {
    const params = new URLSearchParams({
      actor_principal_did: actorDid,
      after_offset: String(afterOffset),
    });
    if (limit !== undefined) {
      params.set("limit", String(limit));
    }
    const path = `/api/sync/events?${params}`;
    return signer
      ? this.signedGetJson(path, signer, "/api/sync/events")
      : this.getJson(path);
  }

  async runAppFunction(request: {
    actor_principal_did: string;
    room_id: string;
    app_id: string;
    function: string;
    input: JsonValue;
    source_app_id?: string;
  }, signer?: HttpActorSigner): Promise<AbrumAppRunResult> {
    const debugId = isAbrumDebugEnabled()
      ? abrumDebug.begin({ kind: "http", label: `runAppFunction ${request.app_id}.${request.function}`, args: redactDebugValue(request) })
      : null;
    let result: AbrumAppRunResult;
    try {
      result = signer
        ? await this.signedPostJson<AbrumAppRunResult>("/api/apps/run", request, signer)
        : await this.postJson<AbrumAppRunResult>("/api/apps/run", request);
      if (debugId) abrumDebug.end(debugId, { status: "ok", result: redactDebugValue(result) });
    } catch (error) {
      if (debugId) abrumDebug.end(debugId, { status: "error", error: error instanceof Error ? error.message : String(error) });
      throw error;
    }
    return {
      app_id: result.app_id,
      function: result.function,
      logs: result.logs ?? [],
      schemas: result.schemas ?? [],
      objects: result.objects ?? [],
      relations: result.relations ?? [],
      data: result.data,
      push: {
        inserted: result.push?.inserted ?? [],
        waiting: result.push?.waiting ?? [],
        quarantined: result.push?.quarantined ?? [],
        rejected: result.push?.rejected ?? [],
        validation_complete: result.push?.validation_complete
          ?? ((result.push?.waiting?.length ?? 0) === 0
            && (result.push?.quarantined?.length ?? 0) === 0
            && (result.push?.rejected?.length ?? 0) === 0),
        watermark_ms: result.push?.watermark_ms ?? 0,
      },
    };
  }

  private async getJson<T>(path: string): Promise<T> {
    const response = await fetch(`${this.baseUrl}${path}`, {
      mode: "cors",
      credentials: "omit",
      cache: "no-store",
    });
    return parseResponse<T>(response);
  }

  private postJson<T>(path: string, body: unknown): Promise<T> {
    return this.requestJson<T>("POST", path, body);
  }

  private async signedPostJson<T>(path: string, body: unknown, signer: HttpActorSigner): Promise<T> {
    return this.signedRequestJson<T>("POST", path, body, signer);
  }

  private async signedGetJson<T>(path: string, signer: HttpActorSigner, routeScope = path.split("?")[0]): Promise<T> {
    const url = `${this.baseUrl}${path}`;
    for (let attempt = 0; attempt < 2; attempt += 1) {
      const timestampMs = Date.now();
      const nonce = `nonce-${bytesToHex(randomBytes(8))}`;
      const payload = signer.signaturePayload?.("GET", routeScope, signer.actor.did, timestampMs, nonce, "")
        ?? actorHttpSignaturePayload("GET", routeScope, signer.actor.did, timestampMs, nonce, "");
      let response: Response;
      try {
        response = await fetch(url, {
          method: "GET",
          mode: "cors",
          credentials: "omit",
          cache: "no-store",
          headers: {
            "x-abrum-actor-principal-did": signer.actor.did,
            "x-abrum-request-timestamp-ms": String(timestampMs),
            "x-abrum-request-nonce": nonce,
            "x-abrum-request-signature": signer.signUtf8(payload),
          },
        });
      } catch (error) {
        throw new Error(`GET ${url} signed request failed: ${error instanceof Error ? error.message : String(error)}`);
      }
      if (attempt === 0 && await isExpiredRequestSignatureResponse(response)) continue;
      return parseResponse<T>(response);
    }
    throw new Error(`GET ${url} signed request retry exhausted`);
  }

  private async signedRequestJson<T>(
    method: "POST" | "PATCH",
    path: string,
    body: unknown,
    signer: HttpActorSigner,
  ): Promise<T> {
    const bodyText = JSON.stringify(withoutSignedActorBodyFields(body));
    const url = `${this.baseUrl}${path}`;
    for (let attempt = 0; attempt < 2; attempt += 1) {
      const timestampMs = Date.now();
      const nonce = `nonce-${bytesToHex(randomBytes(8))}`;
      const payload = signer.signaturePayload?.(method, path, signer.actor.did, timestampMs, nonce, bodyText)
        ?? actorHttpSignaturePayload(method, path, signer.actor.did, timestampMs, nonce, bodyText);
      let response: Response;
      try {
        response = await fetch(url, {
          method,
          mode: "cors",
          credentials: "omit",
          cache: "no-store",
          headers: {
            "content-type": "application/json",
            "x-abrum-actor-principal-did": signer.actor.did,
            "x-abrum-request-timestamp-ms": String(timestampMs),
            "x-abrum-request-nonce": nonce,
            "x-abrum-request-signature": signer.signUtf8(payload),
          },
          body: bodyText,
        });
      } catch (error) {
        throw new Error(`${method} ${url} signed request failed: ${error instanceof Error ? error.message : String(error)}`);
      }
      if (attempt === 0 && await isExpiredRequestSignatureResponse(response)) continue;
      return parseResponse<T>(response);
    }
    throw new Error(`${method} ${url} signed request retry exhausted`);
  }

  private async requestJson<T>(method: string, path: string, body: unknown): Promise<T> {
    const url = `${this.baseUrl}${path}`;
    let response: Response;
    try {
      response = await fetch(url, {
        method,
        mode: "cors",
        credentials: "omit",
        cache: "no-store",
        headers: body === undefined ? undefined : { "content-type": "application/json" },
        body: body === undefined ? undefined : JSON.stringify(body),
      });
    } catch (error) {
      throw new Error(`${method} ${url} failed: ${error instanceof Error ? error.message : String(error)}`);
    }
    return parseResponse<T>(response);
  }
}

export type HttpActorSigner = {
  actor: PrincipalIdentity;
  signUtf8: (payload: string) => string;
  signaturePayload?: (
    method: string,
    routeScope: string,
    actorDid: string,
    timestampMs: number,
    nonce: string,
    bodyText: string,
  ) => string;
};

export interface RelationSpec {
  source: string;
  target: string;
  relationType: string;
  inheritsAccess: boolean;
  extra?: Record<string, JsonValue>;
}

/** @deprecated Legacy mnemonic-as-seed migration only. */
export function identityFromRecoveryPhrase(phrase: string): PrincipalIdentity {
  return currentProtocolCore.identityFromRecoveryPhrase(phrase);
}

export async function userPrincipalTwin(
  identity: PrincipalIdentity,
  displayName: string,
  createdAtMs = Date.now(),
): Promise<SignedTwin> {
  return currentProtocolCore.userPrincipalTwin(identity, displayName, createdAtMs);
}

export function identityRootDid(identityRootCid: string): string {
  return currentProtocolCore.identityRootDid(identityRootCid);
}

export async function identityRootTwin(
  identity: PrincipalIdentity,
  rootKind: "user" | "station" | "warden" | "service",
  label: string | null = null,
  createdAtMs = Date.now(),
): Promise<SignedTwin> {
  return currentProtocolCore.identityRootTwin(identity, rootKind, label, createdAtMs);
}

export async function deviceKeyTwin(
  identity: PrincipalIdentity,
  identityRootCid: string,
  label: string | null = null,
  createdAtMs = Date.now(),
): Promise<SignedTwin> {
  return currentProtocolCore.deviceKeyTwin(identity, identityRootCid, label, createdAtMs);
}

export async function schemaTwinForIdentity(
  identity: PrincipalIdentity,
  name: string,
  schemaClass: SchemaClass,
  jsonSchema: JsonValue,
): Promise<SignedTwin> {
  return currentProtocolCore.schemaTwinForIdentity(identity, name, schemaClass, jsonSchema);
}

export async function objectTwin(
  identity: PrincipalIdentity,
  schemaCid: string,
  content: JsonValue,
  previousVersion: string | null = null,
): Promise<SignedTwin> {
  return currentProtocolCore.objectTwin(identity, schemaCid, content, previousVersion);
}

export async function relationTwin(identity: PrincipalIdentity, spec: RelationSpec): Promise<SignedTwin> {
  return currentProtocolCore.relationTwin(identity, spec);
}

export function buildUserDirectory(entries: TwinLogEntry[]): Record<string, AbrumUserProfile> {
  const directory: Record<string, AbrumUserProfile> = {};
  for (const entry of entries) {
    if (entry.twin.block.kind !== "principal" || entry.twin.block.schema !== SCHEMA_USER_CID) {
      continue;
    }
    const content = asRecordOrNull(entry.twin.block.content);
    const did = asOptionalString(content?.did);
    const displayName = asOptionalString(content?.displayName);
    if (!did || !displayName) {
      continue;
    }
    directory[did] = {
      did,
      identityRootDid: null,
      displayName,
      // `avatarCid` on the principal is deprecated and never written; the
      // canonical avatar comes from the user-profile object below.
      avatarFileLineageCid: null,
      principalCid: entry.cid,
      profileCid: directory[did]?.profileCid,
    };
  }

  // A user can have more than one profile lineage during the transition to a
  // single Public-room profile (old per-room profiles still sync). Pick the
  // most recently updated one per did so the canonical profile wins.
  const profileUpdatedAt: Record<string, number> = {};
  for (const entry of latestObjectEntries(entries)) {
    if (entry.twin.block.schema !== SCHEMA_USER_PROFILE_CID) {
      continue;
    }
    const content = asRecordOrNull(entry.twin.block.content);
    if (content?.type !== "userProfile") {
      continue;
    }
    const did = asOptionalString(content.userDid);
    const displayName = asOptionalString(content.displayName);
    if (!did || !displayName) {
      continue;
    }
    const updatedAt = asOptionalNumber(content.updatedAtMs) ?? asOptionalNumber(content.createdAtMs) ?? 0;
    if (did in profileUpdatedAt && profileUpdatedAt[did] >= updatedAt) {
      continue;
    }
    profileUpdatedAt[did] = updatedAt;
    directory[did] = {
      did,
      identityRootDid: asOptionalString(content.identityRootDid) ?? directory[did]?.identityRootDid ?? null,
      displayName,
      bio: asOptionalString(content.bio) ?? null,
      avatarFileLineageCid: asOptionalString(content.avatarFileLineageCid) ?? null,
      principalCid: directory[did]?.principalCid,
      profileCid: entry.cid,
    };
  }

  // A user can author from several stations. Their device DIDs are different,
  // but the public profile carries the stable Identity Root DID shared by all
  // of those stations. Keep the device-DID entries for backwards compatibility
  // and add a root alias so UI consumers can resolve a station-issued twin to
  // the same person instead of displaying the device DID.
  for (const profile of Object.values(directory)) {
    const rootDid = profile.identityRootDid?.trim();
    if (rootDid && !directory[rootDid]) {
      directory[rootDid] = profile;
    }
  }
  return directory;
}

/**
 * Center-crop an image Blob to a square and downscale it to `size`×`size`,
 * returning a JPEG Blob. Avatars are stored square and rendered round via CSS
 * (`border-radius`), so this keeps the uploaded blob small and uniform. Runs in
 * the browser/Electron renderer (uses `createImageBitmap` + `<canvas>`).
 */
export async function cropAndResizeImage(blob: Blob, size = 256): Promise<Blob> {
  const bitmap = await createImageBitmap(blob);
  try {
    const side = Math.min(bitmap.width, bitmap.height);
    const sx = Math.max(0, (bitmap.width - side) / 2);
    const sy = Math.max(0, (bitmap.height - side) / 2);
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      throw new Error("canvas 2d context unavailable");
    }
    ctx.drawImage(bitmap, sx, sy, side, side, 0, 0, size, size);
    // PNG (not JPEG) so a transparent source image keeps its transparency
    // instead of getting a black fill; the avatar is clipped to a circle by CSS.
    return await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob(
        (out) => (out ? resolve(out) : reject(new Error("avatar encoding failed"))),
        "image/png",
      );
    });
  } finally {
    bitmap.close?.();
  }
}

export async function signBlock(identity: PrincipalIdentity, block: TwinBlock): Promise<SignedTwin> {
  return currentProtocolCore.signBlock(identity, block);
}

export function signUtf8(identity: PrincipalIdentity, payload: string): string {
  return currentProtocolCore.signUtf8(identity, payload);
}

export function canonicalBytes(block: TwinBlock): Uint8Array {
  return currentProtocolCore.canonicalBytes(block);
}

export function computeCid(bytes: Uint8Array): string {
  return currentProtocolCore.computeCid(bytes);
}

export function computePayloadCid(bytes: Uint8Array): string {
  return currentProtocolCore.computePayloadCid(bytes);
}

export function computeStorageCid(bytes: Uint8Array): string {
  return currentProtocolCore.computeStorageCid(bytes);
}

export function configureAbrumProtocolCore(core: AbrumProtocolCore): void {
  currentProtocolCore = core;
}

export function createAbrumWasmProtocolCore(wasm: AbrumWasmProtocolModule): AbrumProtocolCore {
  return {
    identityFromSeed(seed) {
      return parseWasmJson(wasm.identityFromSeedHex(bytesToHex(seed)), "identityFromSeedHex");
    },
    identityFromRecoveryPhrase(phrase) {
      return parseWasmJson(wasm.identityFromRecoveryPhrase(phrase), "identityFromRecoveryPhrase");
    },
    userPrincipalTwin(identity, displayName, createdAtMs = Date.now()) {
      return parseWasmJson(wasm.userPrincipalTwin(identity.seedHex, displayName, BigInt(createdAtMs)), "userPrincipalTwin");
    },
    identityRootDid(identityRootCid) {
      return wasm.identityRootDid(identityRootCid);
    },
    identityRootTwin(identity, rootKind, label = null, createdAtMs = Date.now()) {
      return parseWasmJson(
        wasm.identityRootTwin(identity.seedHex, rootKind, label, BigInt(createdAtMs)),
        "identityRootTwin",
      );
    },
    deviceKeyTwin(identity, identityRootCid, label = null, createdAtMs = Date.now()) {
      return parseWasmJson(
        wasm.deviceKeyTwin(identity.seedHex, identityRootCid, label, BigInt(createdAtMs)),
        "deviceKeyTwin",
      );
    },
    schemaTwinForIdentity(identity, name, schemaClass, jsonSchema) {
      return parseWasmJson(
        wasm.schemaTwin(identity.seedHex, name, schemaClass, JSON.stringify(jsonSchema)),
        "schemaTwin",
      );
    },
    objectTwin(identity, schemaCid, content, previousVersion = null) {
      return parseWasmJson(
        wasm.objectTwin(identity.seedHex, schemaCid, JSON.stringify(content), previousVersion),
        "objectTwin",
      );
    },
    relationTwin(identity, spec) {
      return parseWasmJson(
        wasm.relationTwin(
          identity.seedHex,
          spec.source,
          spec.target,
          spec.relationType,
          spec.inheritsAccess,
          spec.extra ? JSON.stringify(spec.extra) : null,
        ),
        "relationTwin",
      );
    },
    signBlock(identity, block) {
      return parseWasmJson(wasm.signBlock(identity.seedHex, JSON.stringify(block)), "signBlock");
    },
    signUtf8(identity, payload) {
      return wasm.signUtf8(identity.seedHex, payload);
    },
    canonicalBytes(block) {
      return wasm.canonicalBytes(JSON.stringify(block));
    },
    computeCid(bytes) {
      return wasm.computeCid(bytes);
    },
    computePayloadCid(bytes) {
      return wasm.computePayloadCid(bytes);
    },
    computeStorageCid(bytes) {
      return wasm.computeStorageCid(bytes);
    },
    actorHttpSignaturePayload(method, routeScope, actorDid, timestampMs, nonce, bodyText) {
      return wasm.actorHttpSignaturePayload(method, routeScope, actorDid, BigInt(timestampMs), nonce, bodyText);
    },
    deriveKey(ikm, info) {
      return wasm.deriveKey(ikm, info);
    },
    identityX25519(seedHex) {
      return parseWasmJson(wasm.identityX25519(seedHex), "identityX25519");
    },
    sealValue(key, plaintext, aad) {
      return parseWasmJson(wasm.sealValue(key, plaintext, aad), "sealValue");
    },
    openValue(key, envelope, aad) {
      return wasm.openValue(key, JSON.stringify(envelope), aad);
    },
    wrapKey(recipientPublic, cek) {
      return parseWasmJson(wasm.wrapKey(recipientPublic, cek), "wrapKey");
    },
    unwrapKey(recipientSecret, wrapped) {
      return wasm.unwrapKey(recipientSecret, JSON.stringify(wrapped));
    },
    conveySecret(recipientPublic, context, value) {
      return parseWasmJson(wasm.conveySecret(recipientPublic, context, value), "conveySecret");
    },
  };
}

const defaultProtocolCore: AbrumProtocolCore = {
  identityFromSeed,
  identityFromRecoveryPhrase(phrase) {
    return identityFromSeed(mnemonicToEntropy(phrase.trim(), wordlist));
  },
  userPrincipalTwin(identity, displayName, createdAtMs = Date.now()) {
    return this.signBlock(identity, {
      kind: "principal",
      schema: SCHEMA_USER_CID,
      issuer: identity.did,
      content: withoutUndefined({
        did: identity.did,
        publicKeyEd25519: identity.publicKeyHex,
        displayName,
        createdAtMs,
      }),
      previousVersion: null,
      mergedFrom: [],
    });
  },
  identityRootDid(identityRootCid) {
    return `did:abrum:${identityRootCid}`;
  },
  identityRootTwin(identity, rootKind, label = null, createdAtMs = Date.now()) {
    if (!["user", "station", "warden", "service"].includes(rootKind)) {
      throw new Error(`unsupported identity root kind ${rootKind}`);
    }
    return this.objectTwin(
      identity,
      SCHEMA_IDENTITY_ROOT_CID,
      withoutUndefined({
        type: "identity_root",
        rootKind,
        label: label ?? undefined,
        createdAtMs,
        version: 1,
      }),
      null,
    );
  },
  deviceKeyTwin(identity, identityRootCid, label = null, createdAtMs = Date.now()) {
    if (!identityRootCid.startsWith("b")) {
      throw new Error("identityRoot must be a CID");
    }
    return this.objectTwin(
      identity,
      SCHEMA_DEVICE_KEY_CID,
      withoutUndefined({
        type: "device_key",
        identityRoot: identityRootCid,
        deviceDid: identity.did,
        publicKeyEd25519: identity.publicKeyHex,
        label: label ?? undefined,
        status: "active",
        createdAtMs,
        version: 1,
      }),
      null,
    );
  },
  schemaTwinForIdentity(identity, name, schemaClass, jsonSchema) {
    return this.signBlock(identity, {
      kind: "schema",
      schema: null,
      issuer: identity.did,
      content: {
        name,
        schemaClass,
        jsonSchema,
      },
      previousVersion: null,
      mergedFrom: [],
    });
  },
  objectTwin(identity, schemaCid, content, previousVersion = null) {
    return this.signBlock(identity, {
      kind: "object",
      schema: schemaCid,
      issuer: identity.did,
      content,
      previousVersion,
      mergedFrom: [],
    });
  },
  relationTwin(identity, spec) {
    return this.signBlock(identity, {
      kind: "relation",
      schema: SCHEMA_RELATION_CID,
      issuer: identity.did,
      content: {
        source: spec.source,
        target: spec.target,
        relationType: spec.relationType,
        inheritsAccess: spec.inheritsAccess,
        createdAtMs: Date.now(),
        ...(spec.extra ?? {}),
      },
      previousVersion: null,
      mergedFrom: [],
    });
  },
  signBlock(identity, block) {
    const bytes = this.canonicalBytes(block);
    const cid = this.computeCid(bytes);
    const payloadCid = this.computePayloadCid(canonicalValueBytes(block.content));
    const storageCid = this.computeStorageCid(bytes);
    const signature = ed25519.sign(textEncoder.encode(cid), hexToBytes(identity.seedHex));
    return {
      cid,
      payloadCid,
      storageCid,
      signature: `ed25519:${bytesToHex(signature)}`,
      block,
    };
  },
  signUtf8(identity, payload) {
    return bytesToHex(ed25519.sign(textEncoder.encode(payload), hexToBytes(identity.seedHex)));
  },
  canonicalBytes(block) {
    return canonicalValueBytes(block);
  },
  computeCid(bytes) {
    return computeDomainCid(BLOCK_CID_DOMAIN, bytes);
  },
  computePayloadCid(bytes) {
    return computeDomainCid(PAYLOAD_CID_DOMAIN, bytes);
  },
  computeStorageCid(bytes) {
    return computeDomainCid(STORAGE_CID_DOMAIN, bytes);
  },
  actorHttpSignaturePayload(method, routeScope, actorDid, timestampMs, nonce, bodyText) {
    return actorHttpSignaturePayload(method, routeScope, actorDid, timestampMs, nonce, bodyText);
  },
  deriveKey(ikm, info) {
    return deriveKey(ikm, new TextDecoder().decode(info));
  },
  identityX25519(seedHex) {
    const pair = x25519KeypairFromSeed(fromHex(seedHex));
    return { secretHex: toHex(pair.secret), publicHex: toHex(pair.public) };
  },
  sealValue(key, plaintext, aad) {
    return sealValue(key, plaintext, aad);
  },
  openValue(key, envelope, aad) {
    return openSealedValue(key, envelope, aad);
  },
  wrapKey(recipientPublic, cek) {
    return wrapKey(recipientPublic, cek);
  },
  unwrapKey(recipientSecret, wrapped) {
    return unwrapKey(recipientSecret, wrapped);
  },
  conveySecret(recipientPublic, context, value) {
    return conveySecret(recipientPublic, context, value);
  },
};

function computeDomainCid(domain: Uint8Array, bytes: Uint8Array): string {
  const domainSeparatedDigest = sha256(concatBytes(domain, Uint8Array.from([0]), bytes));
  const cidBytes = concatBytes(
    varint(1),
    varint(DAG_CBOR_CODEC),
    varint(SHA2_256_CODE),
    varint(domainSeparatedDigest.length),
    domainSeparatedDigest,
  );
  return `b${base32NoPad(cidBytes)}`;
}

let currentProtocolCore = defaultProtocolCore;

function identityFromSeed(seed: Uint8Array): PrincipalIdentity {
  if (seed.length !== 32) {
    throw new Error(`identity seed must be 32 bytes, got ${seed.length}`);
  }
  const publicKeyHex = bytesToHex(ed25519.getPublicKey(seed));
  return {
    did: `did:key:ed25519:${publicKeyHex}`,
    publicKeyHex,
    seedHex: bytesToHex(seed),
  };
}

function normalizeCanonical(value: unknown): unknown {
  if (value === null || typeof value === "boolean") {
    return value;
  }
  if (typeof value === "string") {
    return value.normalize("NFC");
  }
  if (typeof value === "number") {
    if (!Number.isInteger(value) || !Number.isSafeInteger(value)) {
      throw new Error(`canonical TwinBlocks only support safe integers, got ${value}`);
    }
    return value;
  }
  if (Array.isArray(value)) {
    return value.map(normalizeCanonical);
  }
  if (typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>)
        .filter(([, child]) => child !== undefined)
        .map(([key, child]) => [key.normalize("NFC"), normalizeCanonical(child)] as const)
        .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)),
    );
  }
  throw new Error(`unsupported canonical value ${String(value)}`);
}

function canonicalValueBytes(value: unknown): Uint8Array {
  return encodeCborValue(normalizeCanonical(value));
}

function encodeCborValue(value: unknown): Uint8Array {
  if (value === null) {
    return Uint8Array.from([0xf6]);
  }
  if (value === false) {
    return Uint8Array.from([0xf4]);
  }
  if (value === true) {
    return Uint8Array.from([0xf5]);
  }
  if (typeof value === "number") {
    if (value >= 0) {
      return cborHeader(0, value);
    }
    return cborHeader(1, -1 - value);
  }
  if (typeof value === "string") {
    const bytes = textEncoder.encode(value);
    return concatBytes(cborHeader(3, bytes.length), bytes);
  }
  if (Array.isArray(value)) {
    return concatBytes(cborHeader(4, value.length), ...value.map(encodeCborValue));
  }
  if (typeof value === "object") {
    const entries = Object.entries(value as Record<string, unknown>)
      .map(([key, child]) => [encodeCborValue(key), encodeCborValue(child)] as const)
      .sort(([left], [right]) => compareBytesForMapKey(left, right));
    return concatBytes(
      cborHeader(5, entries.length),
      ...entries.flatMap(([key, child]) => [key, child]),
    );
  }
  throw new Error(`unsupported canonical value ${String(value)}`);
}

function cborHeader(major: number, value: number): Uint8Array {
  const prefix = major << 5;
  if (value <= 23) {
    return Uint8Array.from([prefix | value]);
  }
  if (value <= 0xff) {
    return Uint8Array.from([prefix | 24, value]);
  }
  if (value <= 0xffff) {
    return Uint8Array.from([prefix | 25, value >> 8, value & 0xff]);
  }
  if (value <= 0xffffffff) {
    return Uint8Array.from([
      prefix | 26,
      (value >>> 24) & 0xff,
      (value >>> 16) & 0xff,
      (value >>> 8) & 0xff,
      value & 0xff,
    ]);
  }
  const bytes = new Uint8Array(9);
  bytes[0] = prefix | 27;
  let next = BigInt(value);
  for (let index = 8; index >= 1; index -= 1) {
    bytes[index] = Number(next & 0xffn);
    next >>= 8n;
  }
  return bytes;
}

function compareBytesForMapKey(left: Uint8Array, right: Uint8Array): number {
  if (left.length !== right.length) {
    return left.length - right.length;
  }
  for (let index = 0; index < left.length; index += 1) {
    if (left[index] !== right[index]) {
      return left[index] - right[index];
    }
  }
  return 0;
}

function varint(value: number): Uint8Array {
  const out: number[] = [];
  let next = value;
  while (next >= 0x80) {
    out.push((next & 0xff) | 0x80);
    next >>= 7;
  }
  out.push(next);
  return Uint8Array.from(out);
}

function base32NoPad(bytes: Uint8Array): string {
  let bits = 0;
  let value = 0;
  let output = "";
  for (const byte of bytes) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      output += base32Alphabet[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) {
    output += base32Alphabet[(value << (5 - bits)) & 31];
  }
  return output;
}

function concatBytes(...parts: Uint8Array[]): Uint8Array {
  const total = parts.reduce((sum, part) => sum + part.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}

function hexToBytes(hex: string): Uint8Array {
  if (hex.length % 2 !== 0) {
    throw new Error("hex string must have even length");
  }
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i += 1) {
    bytes[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  }
  return bytes;
}

async function parseResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`${response.status} ${response.statusText}: ${text}`);
  }
  return response.json() as Promise<T>;
}

async function isExpiredRequestSignatureResponse(response: Response): Promise<boolean> {
  if (response.status !== 403) return false;
  try {
    const text = await response.clone().text();
    return text.includes("request signature timestamp is outside the accepted window");
  } catch {
    return false;
  }
}

function asRecord(value: JsonValue | undefined, label: string): Record<string, JsonValue> {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`${label} is not an object`);
  }
  return value as Record<string, JsonValue>;
}

function debugJsonValue(value: unknown): JsonValue {
  if (value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    return value;
  }
  if (Array.isArray(value)) {
    return value.map(debugJsonValue);
  }
  if (value instanceof Error) {
    return { name: value.name, message: value.message, stack: value.stack ?? "" };
  }
  if (typeof value === "object") {
    try {
      return JSON.parse(JSON.stringify(value)) as JsonValue;
    } catch {
      return String(value);
    }
  }
  return String(value);
}

function redactDebugValue(value: unknown): JsonValue {
  const json = debugJsonValue(value);
  if (Array.isArray(json)) return json.map(redactDebugValue) as JsonValue;
  if (json && typeof json === "object") {
    const out: Record<string, JsonValue> = {};
    for (const [key, child] of Object.entries(json)) {
      out[key] = /password|secret|token|recovery|phrase/i.test(key)
        ? "..."
        : redactDebugValue(child);
    }
    return out;
  }
  return json;
}

function asString(value: JsonValue | undefined, label: string): string {
  if (typeof value !== "string") {
    throw new Error(`${label} is not a string`);
  }
  return value;
}

function parseWasmJson<T>(raw: string, label: string): T {
  try {
    return JSON.parse(raw) as T;
  } catch (error) {
    throw new Error(`${label} returned invalid JSON: ${error instanceof Error ? error.message : String(error)}`);
  }
}

interface FoundInstalledApp extends AbrumInstalledApp {
  versionSelector: string;
  installContent: Record<string, JsonValue>;
}

function findInstalledApp(entries: TwinLogEntry[], appId: string, roomId: string): FoundInstalledApp | null {
  for (let index = entries.length - 1; index >= 0; index -= 1) {
    const entry = entries[index];
    if (entry.twin.block.kind !== "object") {
      continue;
    }
    const content = asRecordOrNull(entry.twin.block.content);
    if (
      content?.type === "app_install" &&
      content.appId === appId &&
      content.roomId === roomId &&
      content.enabled === true &&
      typeof content.appLineageCid === "string"
    ) {
      return {
        appId,
        appCid: asOptionalString(content.blueprintVersionCid) ?? content.appLineageCid,
        installCid: entry.cid,
        alreadyInstalled: true,
        versionSelector: asOptionalString(content.versionSelector) ?? "latest",
        installContent: content,
      };
    }
  }
  return null;
}

function findLatestAppTwin(entries: TwinLogEntry[], appId: string): SignedTwin | null {
  for (let index = entries.length - 1; index >= 0; index -= 1) {
    const entry = entries[index];
    if (entry.twin.block.kind !== "object") {
      continue;
    }
    const content = asRecordOrNull(entry.twin.block.content);
    if (content?.type === "app" && content.appId === appId) {
      return entry.twin;
    }
  }
  return null;
}

function findUserProfile(entries: TwinLogEntry[], did: string): SignedTwin | null {
  for (const entry of latestObjectEntries(entries)) {
    if (entry.twin.block.schema !== SCHEMA_USER_PROFILE_CID) {
      continue;
    }
    const content = asRecordOrNull(entry.twin.block.content);
    if (content?.type === "userProfile" && content.userDid === did) {
      return entry.twin;
    }
  }
  return null;
}

function latestObjectEntries(entries: TwinLogEntry[]): TwinLogEntry[] {
  const parents = new Set(entries.map((entry) => entry.twin.block.previousVersion).filter(Boolean));
  return entries.filter((entry) => entry.twin.block.kind === "object" && !parents.has(entry.cid));
}

function mergeJsonValue(base: JsonValue | undefined, patch: JsonValue): JsonValue {
  const baseRecord = asRecordOrNull(base ?? null);
  const patchRecord = asRecordOrNull(patch);
  if (!baseRecord || !patchRecord) {
    return patch;
  }
  const merged: Record<string, JsonValue> = { ...baseRecord };
  for (const [key, value] of Object.entries(patchRecord)) {
    merged[key] = mergeJsonValue(baseRecord[key], value);
  }
  return merged;
}

function jsonValuesEqual(left: JsonValue | undefined, right: JsonValue | undefined): boolean {
  return JSON.stringify(left ?? null) === JSON.stringify(right ?? null);
}

function asRecordOrNull(value: JsonValue | undefined): Record<string, JsonValue> | null {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, JsonValue>
    : null;
}

function asOptionalString(value: JsonValue | undefined): string | null {
  return typeof value === "string" ? value : null;
}

function asOptionalNumber(value: JsonValue | undefined): number | null {
  return typeof value === "number" ? value : null;
}

function normalizeShareContentResult(
  value: unknown,
  fallback: Pick<AbrumShareContentResult, "roomId" | "lineageCid" | "sharedWithDid" | "accessLevel">,
): AbrumShareContentResult {
  if (!value || typeof value !== "object") {
    throw new Error("host returned an invalid content share result");
  }
  const record = value as Record<string, unknown>;
  const receipt = record.receipt;
  if (!isSignedTwin(receipt)) {
    throw new Error("host content share result is missing receipt twin");
  }
  return {
    roomId: typeof record.roomId === "string" && record.roomId ? record.roomId : fallback.roomId,
    lineageCid: typeof record.lineageCid === "string" && record.lineageCid ? record.lineageCid : fallback.lineageCid,
    sharedWithDid: typeof record.sharedWithDid === "string" && record.sharedWithDid ? record.sharedWithDid : fallback.sharedWithDid,
    accessLevel: isRoomAccessLevel(record.accessLevel) ? record.accessLevel : fallback.accessLevel,
    granted: typeof record.granted === "boolean" ? record.granted : true,
    grant: isSyncPushResult(record.grant) ? record.grant : undefined,
    directShare: normalizeDirectShareResult(record.directShare),
    receipt,
    push: isSyncPushResult(record.push) ? record.push : emptySyncPushResult(),
  };
}

function normalizeRevokeContentShareResult(
  value: unknown,
  fallback: Pick<AbrumRevokeContentShareResult, "roomId" | "lineageCid" | "sharedWithDid">,
): AbrumRevokeContentShareResult {
  if (!value || typeof value !== "object") {
    throw new Error("host returned an invalid content share revoke result");
  }
  const record = value as Record<string, unknown>;
  const receipt = record.receipt;
  const directShare = normalizeDirectShareRevokeResult(record.directShare);
  if (!isSignedTwin(receipt) || !directShare) {
    throw new Error("host content share revoke result is incomplete");
  }
  return {
    roomId: typeof record.roomId === "string" && record.roomId ? record.roomId : fallback.roomId,
    lineageCid: typeof record.lineageCid === "string" && record.lineageCid ? record.lineageCid : fallback.lineageCid,
    sharedWithDid: typeof record.sharedWithDid === "string" && record.sharedWithDid
      ? record.sharedWithDid
      : fallback.sharedWithDid,
    directShare,
    receipt,
    push: isSyncPushResult(record.push) ? record.push : emptySyncPushResult(),
  };
}

function normalizeDirectShareResult(value: unknown): AbrumDirectShareResult | undefined {
  if (!value || typeof value !== "object") return undefined;
  const record = value as Record<string, unknown>;
  if (typeof record.sourceRoomId !== "string"
    || typeof record.lineageCid !== "string"
    || typeof record.recipientDid !== "string"
    || typeof record.shareGrantCid !== "string") {
    return undefined;
  }
  const recipientStationId = typeof record.recipientStationId === "string"
    ? record.recipientStationId
    : undefined;
  return {
    sourceRoomId: record.sourceRoomId,
    lineageCid: record.lineageCid,
    recipientDid: record.recipientDid,
    recipientStationId,
    recipientStationIds: Array.isArray(record.recipientStationIds)
      ? record.recipientStationIds.filter((stationId): stationId is string => typeof stationId === "string" && stationId.length > 0)
      : recipientStationId ? [recipientStationId] : [],
    shareGrantCid: record.shareGrantCid,
    delivery: record.delivery === "on_demand" ? "on_demand" : "replicate",
    deliveryPending: record.deliveryPending === true,
    sent: typeof record.sent === "number" ? record.sent : 0,
    reused: record.reused === true,
  };
}

function normalizeDirectShareRevokeResult(value: unknown): AbrumDirectShareRevokeResult | undefined {
  if (!value || typeof value !== "object") return undefined;
  const record = value as Record<string, unknown>;
  if (typeof record.sourceRoomId !== "string"
    || typeof record.lineageCid !== "string"
    || typeof record.recipientDid !== "string") {
    return undefined;
  }
  return {
    sourceRoomId: record.sourceRoomId,
    lineageCid: record.lineageCid,
    recipientDid: record.recipientDid,
    revokedGrants: typeof record.revokedGrants === "number" ? record.revokedGrants : 0,
    notifiedStations: typeof record.notifiedStations === "number" ? record.notifiedStations : 0,
    deliveredBytesRemain: record.deliveredBytesRemain === true,
  };
}

function isSignedTwin(value: unknown): value is SignedTwin {
  if (!value || typeof value !== "object") return false;
  const record = value as Record<string, unknown>;
  return typeof record.cid === "string"
    && typeof record.signature === "string"
    && Boolean(record.block && typeof record.block === "object");
}

function isSyncPushResult(value: unknown): value is SyncPushResult {
  if (!value || typeof value !== "object") return false;
  const record = value as Record<string, unknown>;
  return Array.isArray(record.inserted)
    && Array.isArray(record.waiting)
    && Array.isArray(record.rejected);
}

function emptySyncPushResult(): SyncPushResult {
  return {
    inserted: [],
    waiting: [],
    quarantined: [],
    rejected: [],
    validation_complete: true,
    watermark_ms: 0,
  };
}

function isRoomAccessLevel(value: unknown): value is RoomAccessLevel {
  return value === "read" || value === "write" || value === "admin";
}

function contentShareJsonSchema(): JsonValue {
  return {
    type: "object",
    required: [
      "type",
      "lineageCid",
      "sharedByDid",
      "sharedWithDid",
      "accessLevel",
      "deliveryMode",
      "createdAtMs",
      "updatedAtMs",
      "version",
    ],
    properties: {
      type: { const: "contentShare" },
      lineageCid: { type: "string" },
      targetCid: { type: "string" },
      targetType: { type: "string" },
      title: { type: "string" },
      sharedByDid: { type: "string" },
      sharedWithDid: { type: "string" },
      accessLevel: { enum: ["read", "write", "admin"] },
      deliveryMode: { enum: ["room-grant", "direct-lineage"] },
      createdAtMs: { type: "integer" },
      updatedAtMs: { type: "integer" },
      version: { type: "integer" },
    },
  };
}

function contentShareRevocationJsonSchema(): JsonValue {
  return {
    type: "object",
    required: [
      "type",
      "lineageCid",
      "sharedByDid",
      "sharedWithDid",
      "deliveredBytesRemain",
      "revokedAtMs",
      "version",
    ],
    properties: {
      type: { const: "contentShareRevocation" },
      lineageCid: { type: "string" },
      sharedByDid: { type: "string" },
      sharedWithDid: { type: "string" },
      deliveredBytesRemain: { type: "boolean" },
      revokedAtMs: { type: "integer" },
      version: { type: "integer" },
    },
  };
}

function normalizePeersStatus(value: Partial<AbrumPeersStatus>): AbrumPeersStatus {
  const stations: unknown[] = Array.isArray(value.stations) ? value.stations as unknown[] : [];
  return {
    stationId: typeof value.stationId === "string" ? value.stationId : "",
    connectedCount: typeof value.connectedCount === "number" ? value.connectedCount : 0,
    connected: Array.isArray(value.connected) ? value.connected.filter((item): item is string => typeof item === "string") : [],
    stations: stations
      .filter((station): station is Record<string, unknown> => station !== null && typeof station === "object")
      .map((station) => {
        const connected = station.connected === true;
        const lastSeenMs = typeof station.lastSeenMs === "number" ? station.lastSeenMs : null;
        const rawPresence = station.presence;
        const presence = rawPresence === "online" || rawPresence === "stale" || rawPresence === "offline" || rawPresence === "unknown"
          ? rawPresence
          : connected
            ? "online"
            : lastSeenMs === null
              ? "unknown"
              : Date.now() - lastSeenMs <= 90_000
                ? "stale"
                : "offline";
        return {
        stationId: typeof station.stationId === "string" ? station.stationId : "",
        name: typeof station.name === "string" ? station.name : null,
        principalDid: typeof station.principalDid === "string" ? station.principalDid : null,
        lastSeenMs,
        connected,
        presence,
        servedUsers: Array.isArray(station.servedUsers)
          ? station.servedUsers.filter((item): item is string => typeof item === "string")
          : [],
        sharedRooms: Array.isArray(station.sharedRooms)
          ? station.sharedRooms.filter((item): item is string => typeof item === "string")
          : [],
        sharedUsersByRoom: station.sharedUsersByRoom !== null
          && typeof station.sharedUsersByRoom === "object"
          && !Array.isArray(station.sharedUsersByRoom)
          ? Object.fromEntries(
            Object.entries(station.sharedUsersByRoom).flatMap(([roomId, users]) =>
              Array.isArray(users)
                ? [[roomId, users.filter((item): item is string => typeof item === "string")]]
                : [],
            ),
          )
          : {},
        };
      }),
  };
}

function withoutUndefined<T extends Record<string, JsonValue | undefined>>(value: T): Record<string, JsonValue> {
  return Object.fromEntries(Object.entries(value).filter(([, child]) => child !== undefined)) as Record<
    string,
    JsonValue
  >;
}

interface StoredSession {
  // `phrase` is read only for one-time migration of the historical
  // mnemonic-as-seed format. New sessions persist a Device Key seed.
  phrase?: string;
  deviceKeySeedHex?: string;
  actorDid?: string;
  displayName?: string;
  hostedRoomId?: string | null;
  selectedRoomId?: string | null;
  cursorByRoom?: Record<string, number>;
  realtimeEventOffset?: number;
  realtimeStreamEpoch?: string | null;
  bootstrap?: AbrumSessionHandoff["bootstrap"];
}

function readStoredSession(key: string): StoredSession | null {
  if (!hasLocalStorage()) {
    return null;
  }
  const raw = window.localStorage.getItem(key);
  if (!raw) {
    return null;
  }
  return JSON.parse(raw) as StoredSession;
}

function writeStoredSession(key: string, value: StoredSession): void {
  if (!hasLocalStorage()) {
    return;
  }
  window.localStorage.setItem(key, JSON.stringify(value));
}

function hasLocalStorage(): boolean {
  return typeof window !== "undefined" && "localStorage" in window;
}
