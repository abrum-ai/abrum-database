import { sha256 } from "@noble/hashes/sha2";
import { bytesToHex } from "@noble/hashes/utils";

const textEncoder = new TextEncoder();

export function withoutSignedActorBodyFields(body: unknown): unknown {
  if (body === null || typeof body !== "object" || Array.isArray(body)) {
    return body;
  }
  const { actor_principal_did: _snake, actorPrincipalDid: _camel, ...rest } =
    body as Record<string, unknown>;
  return rest;
}

export function actorHttpSignaturePayload(
  method: string,
  routeScope: string,
  actorDid: string,
  timestampMs: number,
  nonce: string,
  bodyText: string,
): string {
  const bodyHash = bytesToHex(sha256(textEncoder.encode(bodyText)));
  return [
    "abrum-http-request-v1",
    method.toUpperCase(),
    routeScope,
    actorDid.trim(),
    String(timestampMs),
    nonce,
    bodyHash,
  ].join("\n");
}
