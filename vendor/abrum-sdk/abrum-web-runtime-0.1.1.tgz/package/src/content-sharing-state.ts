import type {
  JsonValue,
  RoomAccessLevel,
  TwinLogEntry,
  AbrumContentShareRecord,
} from "./index";

/**
 * Which direct shares are still live, replayed in log order.
 *
 * Pass a `lineageCid` for one item's shares (an app's share dialog), or omit it
 * for every share in the room (Warden's overview). Warden used to have no way
 * to ask this at all, which is why it could show a grant it could not undo.
 */
export function activeContentSharesFromEntries(
  entries: TwinLogEntry[],
  lineageCid?: string | null,
): AbrumContentShareRecord[] {
  const needle = lineageCid?.trim() || null;
  const active = new Map<string, AbrumContentShareRecord>();
  const key = (share: { lineageCid: string; sharedWithDid: string }) =>
    `${share.lineageCid}\u0000${share.sharedWithDid}`;
  for (const entry of [...entries].sort((left, right) => left.seq - right.seq)) {
    const share = contentShareFromEntry(entry);
    if (share && (needle === null || share.lineageCid === needle)) {
      active.set(key(share), share);
      continue;
    }
    const revocation = contentShareRevocationFromEntry(entry);
    if (revocation && (needle === null || revocation.lineageCid === needle)) {
      active.delete(key(revocation));
    }
  }
  return [...active.values()].sort((left, right) => right.updatedAtMs - left.updatedAtMs);
}

function contentShareRevocationFromEntry(
  entry: TwinLogEntry,
): { lineageCid: string; sharedWithDid: string } | null {
  const content = asRecord(entry.twin.block.content);
  if (content?.type !== "contentShareRevocation") {
    return null;
  }
  const lineageCid = stringValue(content.lineageCid);
  const sharedWithDid = stringValue(content.sharedWithDid);
  return lineageCid && sharedWithDid ? { lineageCid, sharedWithDid } : null;
}

function contentShareFromEntry(entry: TwinLogEntry): AbrumContentShareRecord | null {
  const content = asRecord(entry.twin.block.content);
  if (content?.type !== "contentShare") {
    return null;
  }
  const accessLevel = stringValue(content.accessLevel);
  const createdAtMs = numberValue(content.createdAtMs);
  const updatedAtMs = numberValue(content.updatedAtMs);
  const lineageCid = stringValue(content.lineageCid);
  const sharedByDid = stringValue(content.sharedByDid);
  const sharedWithDid = stringValue(content.sharedWithDid);
  if (!lineageCid || !sharedByDid || !sharedWithDid
    || !isRoomAccessLevel(accessLevel) || createdAtMs === null || updatedAtMs === null) {
    return null;
  }
  return {
    cid: entry.cid,
    lineageCid,
    targetCid: stringValue(content.targetCid),
    targetType: stringValue(content.targetType),
    title: stringValue(content.title),
    sharedByDid,
    sharedWithDid,
    accessLevel,
    deliveryMode: stringValue(content.deliveryMode) ?? "room-grant",
    createdAtMs,
    updatedAtMs,
  };
}

function isRoomAccessLevel(value: string | null): value is RoomAccessLevel {
  return value === "read" || value === "write" || value === "admin";
}

function asRecord(value: JsonValue): Record<string, JsonValue> | null {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, JsonValue>
    : null;
}

function stringValue(value: JsonValue | undefined): string | null {
  return typeof value === "string" ? value : null;
}

function numberValue(value: JsonValue | undefined): number | null {
  return typeof value === "number" ? value : null;
}
