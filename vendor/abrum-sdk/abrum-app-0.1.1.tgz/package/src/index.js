import { materializeService } from "./service.js";
export { resourceRefSchema } from "./resource.js";
import { validateResourceFeatures } from "./resource.js";

function withFieldMethods(field) {
  return Object.assign(field, {
    optional() {
      return withFieldMethods({ ...field, descriptor: { ...field.descriptor, required: false } });
    },
    index() {
      return withFieldMethods({ ...field, descriptor: { ...field.descriptor, indexed: true } });
    },
    indexed() {
      return this.index();
    },
    unique() {
      return withFieldMethods({ ...field, descriptor: { ...field.descriptor, indexed: true, unique: true } });
    },
  });
}

function fieldJsonSchema(fieldDef) {
  const descriptor = fieldDef?.descriptor ?? fieldDef;
  switch (descriptor?.kind) {
    case "string":
      return { type: "string" };
    case "number":
      // Twins deliberately reject floating point JSON numbers.
      return { type: "integer" };
    case "boolean":
      return { type: "boolean" };
    case "date":
      return { anyOf: [{ type: "integer" }, { type: "string", format: "date-time" }] };
    case "json":
    case "any":
      return {};
    default:
      throw new Error("abrum.action input/output fields must be created with abrum.string(), number(), boolean(), date(), json(), or any()");
  }
}

function fieldsJsonSchema(fields, label) {
  if (!fields || typeof fields !== "object" || Array.isArray(fields)) {
    throw new Error(`${label} must be an object of abrum fields`);
  }
  const properties = {};
  const required = [];
  for (const [name, fieldDef] of Object.entries(fields)) {
    if (!fieldDef || fieldDef.__abrumField !== true) {
      throw new Error(`${label}.${name} must be an abrum field`);
    }
    properties[name] = fieldJsonSchema(fieldDef);
    if ((fieldDef.descriptor ?? fieldDef).required !== false) required.push(name);
  }
  return {
    type: "object",
    properties,
    required,
    additionalProperties: false,
  };
}

function titleCase(value) {
  return String(value)
    .split(/[^a-z0-9]+/i)
    .filter(Boolean)
    .map((part) => `${part.charAt(0).toUpperCase()}${part.slice(1)}`)
    .join(" ");
}

function materializeActions(spec) {
  const actions = spec.actions ?? {};
  if (!actions || typeof actions !== "object" || Array.isArray(actions)) {
    throw new Error("`actions` must be an object mapping action names to abrum.action({...})");
  }
  const actionEntries = Object.entries(actions);
  if (actionEntries.length === 0) return spec;

  const generatedFunctions = [];
  const grouped = new Map();
  for (const [id, action] of actionEntries) {
    if (!action || action.__abrumAction !== true) {
      throw new Error(`action ${JSON.stringify(id)} must be defined with abrum.action({...})`);
    }
    const {
      __abrumAction: _marker,
      input = {},
      output,
      offer = "use",
      risk: _risk,
      ...functionOptions
    } = action;
    generatedFunctions.push({
      id,
      ...functionOptions,
      input: fieldsJsonSchema(input, `actions.${id}.input`),
      ...(output === undefined
        ? {}
        : { output: fieldsJsonSchema(output, `actions.${id}.output`) }),
    });
    const offerId = String(offer).trim() || "use";
    const entry = grouped.get(offerId) ?? { functions: [], risks: [] };
    entry.functions.push(id);
    if (typeof action.risk === "string" && action.risk.trim()) entry.risks.push(action.risk.trim());
    grouped.set(offerId, entry);
  }

  const explicitFunctions = Array.isArray(spec.functions) ? spec.functions : [];
  const duplicate = generatedFunctions.find((generated) =>
    explicitFunctions.some((fn) => (fn?.id ?? fn?.name) === generated.id)
  );
  if (duplicate) {
    throw new Error(`action ${JSON.stringify(duplicate.id)} duplicates an entry in functions[]`);
  }

  const configuredOffers = spec.agent?.offers ?? {};
  const generatedOffers = [...grouped.entries()].map(([name, group]) => {
    const configured = configuredOffers[name] ?? {};
    const risk = configured.risk
      ?? (group.risks.includes("high") ? "high" : group.risks.includes("medium") ? "medium" : "low");
    return {
      id: `${spec.id}.${name}`,
      title: configured.title ?? `${titleCase(name)} ${spec.title}`,
      description: configured.description ?? `Use ${spec.title}'s ${titleCase(name).toLowerCase()} actions in an Agent context.`,
      functions: group.functions,
      modes: configured.modes ?? ["on_behalf_of_caller"],
      defaultMode: configured.defaultMode ?? "on_behalf_of_caller",
      risk,
      resultPolicies: configured.resultPolicies ?? ["agent_room"],
      defaultResultPolicy: configured.defaultResultPolicy ?? "agent_room",
    };
  });
  const explicitOffers = Array.isArray(spec.capabilityOffers) ? spec.capabilityOffers : [];
  const defaultOffer = spec.agent?.defaultOffer ?? grouped.keys().next().value;

  return {
    kind: "web",
    build: { command: "vite build", dist: "dist", entrypoint: "index.html" },
    install: { grant: "room", grantedRights: ["read", "write"] },
    backend: { kind: "js", entrypoint: "backend/actions.js" },
    executionLevel: "trusted-plugin",
    surfaces: [{ kind: "web", label: spec.title, entrypoint: "/" }],
    background: null,
    capabilityCoverage: "complete",
    ...spec,
    functions: [...explicitFunctions, ...generatedFunctions],
    capabilityOffers: [...explicitOffers, ...generatedOffers],
    sidebar: spec.sidebar ?? {
      createRoom: {
        label: `Add ${spec.title}`,
        defaultAgentOfferId: `${spec.id}.${defaultOffer}`,
      },
    },
  };
}

function field(kind) {
  return withFieldMethods({
    __abrumField: true,
    descriptor: {
      kind,
      required: true,
      indexed: false,
      unique: false,
    },
  });
}

function withEntityMethods(entityDef) {
  return Object.assign(entityDef, {
    named(schemaName) {
      return withEntityMethods({
        ...entityDef,
        schema: schemaName,
        options: { ...entityDef.options, schemaName },
      });
    },
    type(contentType) {
      return withEntityMethods({
        ...entityDef,
        contentType,
        options: { ...entityDef.options, contentType },
      });
    },
    roomScoped() {
      return withEntityMethods({
        ...entityDef,
        scope: "room",
        options: { ...entityDef.options, scope: "room" },
      });
    },
  });
}

export const abrum = {
  app(name, entities) {
    return { name, entities };
  },
  entity(fields) {
    return withEntityMethods({
      __abrumEntity: true,
      fields,
      scope: "room",
      options: { scope: "room" },
    });
  },
  collection(fields) {
    return withEntityMethods({
      __abrumEntity: true,
      fields,
      scope: "room",
      options: { scope: "room" },
    });
  },
  action(options = {}) {
    return { __abrumAction: true, ...options };
  },
  string: () => field("string"),
  number: () => field("number"),
  boolean: () => field("boolean"),
  date: () => field("date"),
  createdAt: () => field("date").index(),
  updatedAt: () => field("date"),
  json: () => field("json"),
  any: () => field("any"),
  secret(options) {
    return {
      __abrumSecret: true,
      ...options,
    };
  },
};

export function defineApp(spec) {
  const result = materializeService(materializeActions(spec));
  validateResourceFeatures(result.features, result.functions);
  return result;
}
