/** Validate the app-owned public MCP view. It never grants execution rights. */
export function validateMcpFeatures(features = [], functions = []) {
  const declarations = features.filter(f => f?.contract?.startsWith("abrum.app.mcp/"));
  if (!declarations.length) return;
  const fail = message => { throw new Error(`invalid abrum.app.ts: MCP ${message}`); };
  if (declarations.length !== 1) fail("requires exactly one declaration");
  const f = declarations[0];
  if (f.contract !== "abrum.app.mcp/v1") fail("contract version is unsupported");
  const token = v => typeof v === "string" && /^[A-Za-z][A-Za-z0-9_]*$/.test(v) && v.length <= 40;
  if (!token(f.namespace)) fail("namespace must be a short identifier");
  const known = new Map(functions.map(fn => [fn.id ?? fn.name ?? fn, fn]));
  if (!Array.isArray(f.functions) || !f.functions.length || new Set(f.functions).size !== f.functions.length)
    fail("functions must be a non-empty unique list");
  for (const name of f.functions) if (!token(name) || !known.has(name)) fail(`unknown or invalid function ${name}`);
  if (!f.selector) return;
  const s = f.selector;
  for (const key of ["name", "contentType", "field", "inputField", "listTool"])
    if (!token(s[key])) fail(`selector.${key} must be an identifier`);
  if (f.functions.includes(s.listTool)) fail("listTool collides with an app function");
  if (s.name === s.inputField || s.inputField === `${s.name}Ref`) fail("selector input names collide");
  if (s.availability !== undefined && (!Array.isArray(s.availability) || s.availability.length > 4))
    fail("availability must contain at most four local observation sources");
  for (const source of s.availability ?? []) {
    for (const field of ["contentType", "identityField", "stateField", "observedAtField"])
      if (!token(source?.[field])) fail(`availability.${field} must be an identifier`);
    for (const field of ["states", "reasonStates"]) {
      if (field === "reasonStates" && source[field] === undefined) continue;
      const states = source[field];
      if (!states || typeof states !== "object" || Array.isArray(states) || !Object.keys(states).length
        || Object.keys(states).length > 32 || Object.entries(states).some(([key, value]) =>
          key.length > 80 || !["ready", "needs_auth", "offline", "unknown"].includes(value)))
        fail(`availability.${field} must map bounded labels to known states`);
    }
    if ((source.reasonStates !== undefined || source.reasonField !== undefined) && !token(source.reasonField)) fail("availability.reasonField is required");
    if (!Number.isSafeInteger(source.maxAgeMs) || source.maxAgeMs < 1 || source.maxAgeMs > 86400000)
      fail("availability.maxAgeMs must be an integer in 1..86400000");
  }
  if (s.freshness !== undefined) {
    for (const field of ["contentType", "identityField", "timestampField"])
      if (!token(s.freshness?.[field])) fail(`freshness.${field} must be an identifier`);
    if (s.freshness.scopeField !== undefined && !token(s.freshness.scopeField)) fail("freshness.scopeField must be an identifier");
  }
  for (const name of f.functions) {
    const properties = known.get(name)?.input?.properties ?? {};
    if (Object.hasOwn(properties, s.name) || Object.hasOwn(properties, `${s.name}Ref`))
      fail(`selector name collides with ${name}'s public input`);
  }
}
