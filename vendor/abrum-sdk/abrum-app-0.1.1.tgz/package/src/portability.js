import { readFile, stat } from "node:fs/promises";
import path from "node:path";

// Clone portability is part of the published app/codegen contract.
const DEPENDENCY_SECTIONS = [
  "dependencies",
  "devDependencies",
  "optionalDependencies",
  "peerDependencies",
];

export async function inspectAppPortability(appDir) {
  const root = path.resolve(appDir);
  const boundary = await findProjectBoundary(root);
  const issues = [];
  const pkg = await readJson(path.join(root, "package.json"), {});

  for (const section of DEPENDENCY_SECTIONS) {
    for (const [name, spec] of Object.entries(pkg?.[section] ?? {})) {
      const target = dependencyPath(spec, root);
      if (target && !isWithin(boundary, target)) {
        issues.push({
          code: "external-dependency-path",
          location: `package.json#${section}.${name}`,
          value: spec,
          target,
          message: `${name} resolves outside the app repository`,
        });
      }
    }
  }

  for (const [name, script] of Object.entries(pkg?.scripts ?? {})) {
    for (const token of scriptPathTokens(script)) {
      const target = path.resolve(root, token);
      if (!isWithin(boundary, target)) {
        issues.push({
          code: "external-script-path",
          location: `package.json#scripts.${name}`,
          value: token,
          target,
          message: `script ${name} resolves ${token} outside the app repository`,
        });
      }
    }
    const absolute = absoluteHostPath(script);
    if (absolute) {
      issues.push({
        code: "absolute-script-path",
        location: `package.json#scripts.${name}`,
        value: absolute,
        target: absolute,
        message: `script ${name} contains a machine-specific absolute path`,
      });
    }
  }

  const lockPath = path.join(root, "package-lock.json");
  if (await fileExists(lockPath)) {
    const lock = await readJson(lockPath);
    visitStrings(lock, "package-lock.json", (value, location) => {
      const target = lockPathTarget(value, root);
      if (target && !isWithin(boundary, target)) {
        issues.push({
          code: "external-lockfile-path",
          location,
          value,
          target,
          message: "package-lock.json retains a dependency outside the app repository",
        });
      }
    });
  }

  return {
    appDir: root,
    boundary,
    portable: issues.length === 0,
    issues: dedupeIssues(issues),
  };
}

export async function assertAppPortable(appDir) {
  const report = await inspectAppPortability(appDir);
  if (report.portable) return report;
  const details = report.issues
    .map((issue) => `  - ${issue.location}: ${JSON.stringify(issue.value)} (${issue.message})`)
    .join("\n");
  throw new Error(
    `abrum app is not clone-portable; remove paths outside ${report.boundary}:\n${details}\n` +
      "Use versioned @abrum packages, or commit SDK tarballs below this repository and reference those instead.",
  );
}

async function findProjectBoundary(root) {
  let current = root;
  let workspaceRoot = null;
  while (true) {
    if (await fileExists(path.join(current, ".git"))) return current;
    const pkg = await readJson(path.join(current, "package.json"), null);
    const workspaces = Array.isArray(pkg?.workspaces) ? pkg.workspaces : pkg?.workspaces?.packages;
    if (Array.isArray(workspaces)) workspaceRoot = current;
    const parent = path.dirname(current);
    if (parent === current) return workspaceRoot ?? root;
    current = parent;
  }
}

function dependencyPath(spec, root) {
  if (typeof spec !== "string") return null;
  const value = spec.trim();
  if (value.startsWith("file:") || value.startsWith("link:")) {
    return path.resolve(root, value.slice(value.indexOf(":") + 1));
  }
  if (value.startsWith("../") || value.startsWith("./") || value.startsWith("..\\") || value.startsWith(".\\")) {
    return path.resolve(root, value);
  }
  if (path.isAbsolute(value) || /^[A-Za-z]:[\\/]/.test(value)) return path.resolve(value);
  return null;
}

function scriptPathTokens(script) {
  if (typeof script !== "string") return [];
  const matches = script.match(/(?:\.\.?[/\\])[^\s"';&|)]+/g) ?? [];
  return matches.map((value) => value.replace(/[,:]$/, ""));
}

function absoluteHostPath(script) {
  if (typeof script !== "string") return null;
  return script.match(/(?:\/Users\/|\/home\/|[A-Za-z]:\\)[^\s"';&|)]+/)?.[0] ?? null;
}

function lockPathTarget(value, root) {
  if (typeof value !== "string") return null;
  if (value.startsWith("file:") || value.startsWith("link:")) {
    return path.resolve(root, value.slice(value.indexOf(":") + 1));
  }
  if (value.startsWith("../") || value.startsWith("..\\")) return path.resolve(root, value);
  if (value.startsWith("/Users/") || value.startsWith("/home/") || /^[A-Za-z]:[\\/]/.test(value)) {
    return path.resolve(value);
  }
  return null;
}

function visitStrings(value, location, visit) {
  if (typeof value === "string") {
    visit(value, location);
    return;
  }
  if (Array.isArray(value)) {
    value.forEach((item, index) => visitStrings(item, `${location}[${index}]`, visit));
    return;
  }
  if (!value || typeof value !== "object") return;
  for (const [key, child] of Object.entries(value)) {
    visitStrings(child, `${location}#${key}`, visit);
  }
}

function isWithin(boundary, target) {
  const relative = path.relative(path.resolve(boundary), path.resolve(target));
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

function dedupeIssues(issues) {
  const seen = new Set();
  return issues.filter((issue) => {
    const key = `${issue.code}\0${issue.location}\0${issue.value}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function readJson(file, fallback) {
  try {
    return JSON.parse(await readFile(file, "utf8"));
  } catch (error) {
    if (arguments.length > 1 && error?.code === "ENOENT") return fallback;
    throw error;
  }
}

async function fileExists(file) {
  try {
    await stat(file);
    return true;
  } catch {
    return false;
  }
}
