// Declarative execution component of an ordinary Room-installed app.
// The declaration requests Station compute; it never supplies authority.
export function materializeService(spec) {
  if (spec.service === undefined) return spec;
  const service = spec.service;
  if (!service || typeof service !== 'object' || Array.isArray(service)) throw Error('service must be an object');
  const { id = 'service', autostart = false, legacyComputer, sourceFiles, ...execution } = service;
  if (!/^[a-z][a-z0-9-]{0,47}$/.test(id)) throw Error('invalid service id');
  if (typeof autostart !== 'boolean') throw Error('service.autostart must be boolean');
  if (sourceFiles !== undefined && (!Array.isArray(sourceFiles) || !sourceFiles.length || sourceFiles.length > 100
      || new Set(sourceFiles).size !== sourceFiles.length || sourceFiles.some(s => typeof s !== 'string' || s.length > 512
        || s.split('/').some(p => !/^[A-Za-z0-9_][A-Za-z0-9._-]*$/.test(p) || p === '..'))))
    throw Error('invalid container sourceFiles');
  if (Object.keys(execution).some(k => !['image', 'command', 'network', 'http', 'user'].includes(k))) throw Error('unsupported service option');
  if (execution.user !== undefined && (typeof execution.user !== 'string' || !/^[1-9]\d{0,4}:[1-9]\d{0,4}$/.test(execution.user)
    || execution.user.split(':').some(id=>Number(id)>65535))) throw Error('service.user requires a non-root numeric uid:gid');
  if (!/^[a-zA-Z0-9][a-zA-Z0-9._/:-]*@sha256:[a-fA-F0-9]{64}$/.test(execution.image || '')) throw Error('service.image must be digest-pinned');
  if (!Array.isArray(execution.command) || !execution.command.length || execution.command.length > 64
      || execution.command.some(s => typeof s !== 'string' || s.includes('\0') || s.length > 8192) || !execution.command[0]) throw Error('service.command requires an exact argv array');
  execution.network ??= 'none';
  if (!['none', 'public'].includes(execution.network)) throw Error('unsupported service network');
  if (execution.http != null) {
    const { port, healthPath } = execution.http;
    if (Object.keys(execution.http).some(k => !['port', 'healthPath'].includes(k)) || !Number.isInteger(port) || port < 1 || port > 65535
        || typeof healthPath !== 'string' || !healthPath.startsWith('/') || healthPath.startsWith('//')
        || healthPath.length > 512 || /[\s\x00-\x1f\x7f#\\]/.test(healthPath)) throw Error('invalid service HTTP readiness declaration');
  }
  // Compatibility is private routing, never a new Agent interface or authority.
  if (legacyComputer !== undefined) {
    const segment = s => typeof s === 'string' && /^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$/.test(s) && s !== '..';
    const path = s => typeof s === 'string' && s.startsWith('/') && !s.startsWith('//') && !/[\s\x00-\x1f\x7f#\\]/.test(s) && !s.split('/').includes('..') && s.length <= 512;
    if (!legacyComputer || Object.keys(legacyComputer).some(k => !['directory','include','services'].includes(k))
        || !segment(legacyComputer.directory) || !Array.isArray(legacyComputer.include) || !legacyComputer.include.length
        || legacyComputer.include.length > 16 || !legacyComputer.include.every(segment)
        || new Set(legacyComputer.include).size !== legacyComputer.include.length
        || !Array.isArray(legacyComputer.services) || !legacyComputer.services.length || legacyComputer.services.length > 16)
      throw Error('invalid legacy Computer migration');
    const ids = new Set();
    for (const endpoint of legacyComputer.services) {
      if (!endpoint || Object.keys(endpoint).some(k => !['serviceId','port','protocol','path','bearerTokenFile'].includes(k))
          || !segment(endpoint.serviceId) || ids.has(endpoint.serviceId) || !['http','mcp'].includes(endpoint.protocol)
          || !Number.isInteger(endpoint.port) || endpoint.port < 1 || endpoint.port > 65535 || !path(endpoint.path)
          || (endpoint.bearerTokenFile !== undefined && (!path(endpoint.bearerTokenFile) || !endpoint.bearerTokenFile.startsWith('/data/'))))
        throw Error('invalid legacy Computer endpoint');
      ids.add(endpoint.serviceId);
    }
    if (!execution.http) throw Error('legacy Computer endpoints require HTTP readiness');
  }
  if (spec.features?.some(f => /^abrum\.host\.(container|compute)\//.test(f.contract))) throw Error('one compute service per installation is supported');
  if (spec.executionLevel && spec.executionLevel !== 'effect-declaration') throw Error('container service requires effect-declaration');
  const operations = { status: 'serviceStatus', start: 'startService', stop: 'stopService', ...(execution.http ? { openService: 'openService' } : {}) };
  const functions = Object.entries(operations).map(([operation, id]) => ({
    id, runtime: 'container', description: `${operation} the installed app service`,
    requiredRights: operation === 'status' ? ['read'] : ['read', 'write'],
    input: { type: 'object', properties: operation === 'openService' ? { serviceId: { type: 'string', const: service.id ?? 'service' } } : {},
      required: operation === 'openService' ? ['serviceId'] : [], additionalProperties: false },
  }));
  if (functions.some(f => spec.functions?.some(other => (other.id ?? other.name) === f.id) || spec.actions?.[f.id])) throw Error('service function name collision');
  return {
    ...spec, executionLevel: 'effect-declaration',
    features: [...(spec.features ?? []), { id, contract: 'abrum.host.container/v1', placement: 'station', host: 'room-authority', operations, service: execution, autostart, ...(legacyComputer ? {legacyComputer} : {}), ...(sourceFiles ? {sourceFiles} : {}) }],
    functions: [...(spec.functions ?? []), ...functions],
    capabilityOffers: [...(spec.capabilityOffers ?? []), {
      id: `${spec.id}.service`, title: `Manage ${spec.title}`, functions: Object.values(operations),
      modes: ['on_behalf_of_caller'], defaultMode: 'on_behalf_of_caller', risk: 'medium',
      resultPolicies: ['agent_room'], defaultResultPolicy: 'agent_room',
    }],
  };
}
