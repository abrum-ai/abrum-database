import { copyFile, mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { createRequire } from "node:module";
import { fileURLToPath, pathToFileURL } from "node:url";
import ts from "typescript";

import { assertAppPortable } from "./portability.js";
import { validateResourceFeatures } from "./resource.js";
import { validateMcpFeatures } from "./mcp.js";

const PACKAGE_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const APP_RUNTIME_IMPORT = pathToFileURL(path.join(PACKAGE_ROOT, "src", "index.js")).href;

export async function assertRelativeViteBase(appDir) {
  const root = path.resolve(appDir);
  const entries = await readdir(root).catch(() => []);
  const resolvedConfigName = [
    "vite.config.ts",
    "vite.config.mts",
    "vite.config.js",
    "vite.config.mjs",
    "vite.config.cts",
    "vite.config.cjs",
  ].find((name) => entries.includes(name));
  if (!resolvedConfigName) return;

  const source = await readFile(path.join(root, resolvedConfigName), "utf8");
  const code = source.replace(/\/\/[^\n]*/g, "").replace(/\/\*[\s\S]*?\*\//g, "");
  const match = code.match(/\bbase\s*:\s*(["'`])([^"'`]*)\1/);
  const value = match?.[2];
  if (value === "./" || value === "." || value === "") return;

  const found = match ? `base: ${JSON.stringify(value)}` : 'no `base` set (defaults to "/")';
  throw new Error(
    `${resolvedConfigName} must set a relative base (\`base: "./"\`) — found ${found}.\n` +
      "  A station serves this app under /apps/{room}/{app}/, so an absolute base makes\n" +
      "  the built /assets/… URLs 404 and the app renders blank. Add `base: \"./\"` to defineConfig().",
  );
}

export async function buildAppDefinition(appDir, options = {}) {
  const root = path.resolve(appDir);
  await assertAppPortable(root);
  const specPath = path.join(root, "abrum.app.ts");
  const pkg = await readPackageJson(root);
  const spec = await loadSpec(specPath);
  validateSpec(spec, pkg);
  const normalized = await normalizeSpec(spec, pkg, root, options);
  const manifest = manifestFromSpec(normalized);
  const generatedDir = path.join(root, "generated");
  await mkdir(generatedDir, { recursive: true });
  await writeJson(path.join(root, "abrum.app.json"), manifest);
  await writeJson(path.join(generatedDir, "manifest.json"), manifest);
  await writeFile(path.join(generatedDir, "twins.ts"), generatedTwins(normalized, manifest), "utf8");
  const moduleContract = moduleContractFromSpec(normalized, manifest);
  await writeFile(path.join(generatedDir, "module.js"), generatedModuleJs(moduleContract), "utf8");
  await writeFile(path.join(generatedDir, "module.d.ts"), generatedModuleTypes(moduleContract), "utf8");
  const publicPackageDir = await syncWorkspacePackageContract(root, manifest.package, [
    "module.js",
    "module.d.ts",
    "twins.ts",
  ]);
  if (options.stdout) {
    options.stdout.write(`generated abrum app artifacts for ${manifest.appId}\n`);
  }
  return { spec: normalized, manifest, publicPackageDir };
}

/** Generate only the package import contract. Used as the first pass of the
 * repo-wide generator so providers exist before any consumer resolves them. */
export async function buildAppModuleDefinition(appDir, options = {}) {
  const root = path.resolve(appDir);
  await assertAppPortable(root);
  const specPath = path.join(root, "abrum.app.ts");
  const pkg = await readPackageJson(root);
  const spec = await loadSpec(specPath);
  validateSpec(spec, pkg);
  const normalized = await normalizeSpec(spec, pkg, root, { ...options, resolveImports: false });
  const manifest = manifestFromSpec(normalized);
  const generatedDir = path.join(root, "generated");
  await mkdir(generatedDir, { recursive: true });
  const moduleContract = moduleContractFromSpec(normalized, manifest);
  await writeFile(path.join(generatedDir, "module.js"), generatedModuleJs(moduleContract), "utf8");
  await writeFile(path.join(generatedDir, "module.d.ts"), generatedModuleTypes(moduleContract), "utf8");
  const publicPackageDir = await syncWorkspacePackageContract(root, manifest.package, [
    "module.js",
    "module.d.ts",
  ]);
  return { spec: normalized, manifest, moduleContract, publicPackageDir };
}

async function syncWorkspacePackageContract(appDir, packageName, files) {
  if (!packageName) return null;
  const workspace = await findWorkspaceRoot(appDir);
  if (!workspace) return null;

  for (const pattern of workspace.patterns) {
    for (const packageDir of await expandWorkspacePattern(workspace.root, pattern)) {
      if (path.resolve(packageDir) === path.resolve(appDir)) continue;
      const pkg = await readPackageJson(packageDir);
      if (pkg.name !== packageName) continue;

      const targetDir = path.join(packageDir, "generated");
      await mkdir(targetDir, { recursive: true });
      await Promise.all(files.map((file) =>
        copyFile(path.join(appDir, "generated", file), path.join(targetDir, file))
      ));
      return targetDir;
    }
  }
  return null;
}

async function findWorkspaceRoot(startDir) {
  let current = path.resolve(startDir);
  while (true) {
    const pkg = await readPackageJson(current);
    const patterns = Array.isArray(pkg.workspaces)
      ? pkg.workspaces
      : pkg.workspaces?.packages;
    if (Array.isArray(patterns)) {
      return { root: current, patterns };
    }
    const parent = path.dirname(current);
    if (parent === current) return null;
    current = parent;
  }
}

async function expandWorkspacePattern(root, pattern) {
  if (typeof pattern !== "string" || pattern.includes("**")) return [];
  let candidates = [root];
  for (const segment of pattern.split("/").filter(Boolean)) {
    const next = [];
    for (const candidate of candidates) {
      if (segment === "*") {
        const entries = await readdir(candidate, { withFileTypes: true }).catch(() => []);
        next.push(...entries.filter((entry) => entry.isDirectory()).map((entry) => path.join(candidate, entry.name)));
      } else {
        next.push(path.join(candidate, segment));
      }
    }
    candidates = next;
  }
  return candidates;
}

async function loadSpec(specPath) {
  const source = await readFile(specPath, "utf8");
  const transpiled = ts.transpileModule(source, {
    compilerOptions: {
      module: ts.ModuleKind.ESNext,
      target: ts.ScriptTarget.ES2022,
      moduleResolution: ts.ModuleResolutionKind.Bundler,
      esModuleInterop: true,
    },
    fileName: specPath,
  }).outputText.replaceAll("\"@abrum/app\"", JSON.stringify(APP_RUNTIME_IMPORT));
  const tmpPath = path.join(
    path.dirname(specPath),
    `.abrum-app-${Date.now()}.mjs`,
  );
  await writeFile(tmpPath, transpiled, "utf8");
  let mod;
  try {
    mod = await import(`${pathToFileURL(tmpPath).href}?v=${Date.now()}`);
  } catch (err) {
    // Surface the underlying syntax/import error instead of a generic message.
    const message = err instanceof Error ? err.message : String(err);
    throw new Error(`failed to load ${path.relative(process.cwd(), specPath)}: ${message}`);
  } finally {
    // Don't leave a growing pile of timestamped build artifacts behind.
    await rm(tmpPath, { force: true }).catch(() => {});
  }
  const spec = mod.default ?? mod.app;
  if (!spec || typeof spec !== "object") {
    throw new Error(`${specPath} must default-export defineApp({...})`);
  }
  return spec;
}

async function readPackageJson(appDir) {
  try {
    return JSON.parse(await readFile(path.join(appDir, "package.json"), "utf8"));
  } catch (err) {
    if (err && err.code === "ENOENT") {
      return {};
    }
    throw err;
  }
}

async function writeJson(file, value) {
  await writeFile(file, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

// Validate the spec up front so authoring mistakes fail at `abrum app build`
// with a field-level message, instead of silently producing an `undefined`
// manifest field that only blows up later at publish/install time.
function validateSpec(spec, pkg) {
  validateResourceFeatures(spec.features, spec.functions);
  validateMcpFeatures(spec.features, spec.functions);
  const errors = [];
  if (typeof spec.id !== "string" || !spec.id.trim()) {
    errors.push('`id` is required and must be a non-empty string (e.g. "abrum.tasks")');
  } else if (!/^[a-z0-9]+(?:[.-][a-z0-9]+)*$/i.test(spec.id.trim())) {
    errors.push(`\`id\` "${spec.id}" should look like "abrum.myapp" (letters, digits, dots, dashes only)`);
  }
  if (typeof spec.title !== "string" || !spec.title.trim()) {
    errors.push("`title` is required and must be a non-empty string");
  }
  if (spec.kind !== undefined && !["web", "wasm", "native"].includes(spec.kind)) {
    errors.push(`\`kind\` must be one of web | wasm | native (got ${JSON.stringify(spec.kind)})`);
  }
  const version = pkg.version ?? spec.version;
  if (version !== undefined && typeof version !== "string") {
    errors.push('`version` must be a string like "0.1.0"');
  }
  if (spec.entities !== undefined) {
    if (!isPlainObject(spec.entities)) {
      errors.push("`entities` must be an object mapping name -> abrum.entity({...})");
    } else {
      for (const [name, def] of Object.entries(spec.entities)) {
        if (!def || def.__abrumEntity !== true) {
          errors.push(`entity \`${name}\` must be defined with abrum.entity({...})`);
          continue;
        }
        // An empty `abrum.entity({})` is valid: a companion app can reference an
        // existing schema by name (.named(...)) without redeclaring its fields.
        const fields = def.fields ?? {};
        if (!isPlainObject(fields)) {
          errors.push(`entity \`${name}\` fields must be an object`);
          continue;
        }
        for (const [fieldName, fieldDef] of Object.entries(fields)) {
          const descriptor = fieldDef?.descriptor ?? fieldDef;
          if (!fieldDef || fieldDef.__abrumField !== true || !descriptor?.kind) {
            errors.push(`field \`${name}.${fieldName}\` must be an abrum field (e.g. abrum.string())`);
          }
        }
      }
    }
  }
  if (spec.functions !== undefined) {
    if (!Array.isArray(spec.functions)) {
      errors.push("`functions` must be an array");
    } else {
      spec.functions.forEach((fn, i) => {
        const handle = fn && typeof fn === "object" ? (fn.id ?? fn.name) : undefined;
        if (typeof handle !== "string" || !handle.trim()) {
          errors.push(`functions[${i}] must be an object with a non-empty string \`id\` (or \`name\`)`);
        }
        if (fn && typeof fn === "object" && fn.input !== undefined) {
          if (!isPlainObject(fn.input)) {
            errors.push(`functions[${i}].input must be a JSON Schema object`);
          } else {
            validateToolInputSchema(fn.input, `functions[${i}].input`, errors);
          }
        }
        if (fn && typeof fn === "object" && Object.hasOwn(fn, "snapshotTypes")) {
          errors.push(`functions[${i}].snapshotTypes was removed; use bounded async ctx.db queries`);
        }
      });
    }
  }
  if (spec.imports !== undefined) {
    if (!Array.isArray(spec.imports)) {
      errors.push("`imports` must be an array of package names or package/function selections");
    } else {
      spec.imports.forEach((mod, i) => {
        if (typeof mod === "string") {
          if (!isPackageNameImport(mod)) {
            errors.push(`imports[${i}] must be a bare package name like "@abrum/agent"; do not use subpaths such as "@abrum/agent/module"`);
          }
        } else if (isPlainObject(mod)) {
          const extraKeys = Object.keys(mod).filter((key) => !["package", "functions"].includes(key));
          if (!isPackageNameImport(mod.package)) {
            errors.push(`imports[${i}].package must be a bare package name like "@abrum/agent"`);
          }
          if (!Array.isArray(mod.functions) || mod.functions.length === 0
            || mod.functions.some((handle) => typeof handle !== "string" || !handle.trim())) {
            errors.push(`imports[${i}].functions must be a non-empty array of provider function names`);
          } else if (new Set(mod.functions.map((handle) => handle.trim())).size !== mod.functions.length) {
            errors.push(`imports[${i}].functions must not contain duplicates`);
          }
          if (extraKeys.length > 0) {
            errors.push(`imports[${i}] may contain only \`package\` and \`functions\`; provider metadata comes from the generated module`);
          }
        } else {
          errors.push(`imports[${i}] must be a package name or a { package, functions } selection`);
        }
      });
    }
  }
  if (spec.surfaces !== undefined) {
    if (!Array.isArray(spec.surfaces)) {
      errors.push("`surfaces` must be an array");
    } else {
      const surfaceIds = new Set();
      spec.surfaces.forEach((surface, i) => {
        if (!surface || typeof surface !== "object" || typeof surface.kind !== "string" || !surface.kind.trim()) {
          errors.push(`surfaces[${i}] must be an object with a string \`kind\``);
          return;
        }
        if (surface.id !== undefined) {
          if (typeof surface.id !== "string" || !surface.id.trim()) {
            errors.push(`surfaces[${i}].id must be a non-empty string`);
          } else if (surfaceIds.has(surface.id)) {
            errors.push(`surfaces[${i}].id duplicates \`${surface.id}\``);
          } else {
            surfaceIds.add(surface.id);
          }
        }
        if (surface.entrypoint !== undefined && (typeof surface.entrypoint !== "string" || !surface.entrypoint.trim())) {
          errors.push(`surfaces[${i}].entrypoint must be a non-empty string`);
        }
        if (surface.placements !== undefined) {
          if (!surface.id || typeof surface.id !== "string") {
            errors.push(`surfaces[${i}] with placements must declare a stable \`id\``);
          }
          if (!Array.isArray(surface.placements) || surface.placements.length === 0
            || surface.placements.some((placement) => !["app", "inline", "modal", "window"].includes(placement))) {
            errors.push(`surfaces[${i}].placements must contain only app, inline, modal, or window`);
          }
        }
        if (surface.input !== undefined) {
          if (!isPlainObject(surface.input)) {
            errors.push(`surfaces[${i}].input must be a JSON Schema object`);
          } else {
            validateSurfaceInputSchema(surface.input, `surfaces[${i}].input`, errors);
          }
        }
        if (surface.defaultSize !== undefined) {
          const size = surface.defaultSize;
          if (!isPlainObject(size)
            || [size.width, size.height].some((value) => value !== undefined && (!Number.isFinite(value) || value <= 0))) {
            errors.push(`surfaces[${i}].defaultSize width/height must be positive numbers`);
          }
        }
      });
    }
  }
  if (spec.requiredSecrets !== undefined) {
    errors.push('`requiredSecrets` is generated; declare `const credential = abrum.secret({...})` and attach it to consuming functions with `secrets: [credential]`');
  }
  if (spec.executionLevel !== undefined
    && (typeof spec.executionLevel !== "string" || !spec.executionLevel.trim())) {
    errors.push('`executionLevel` must be a non-empty string (e.g. "effect-declaration")');
  }
  if (spec.icon !== undefined && (typeof spec.icon !== "string" || !spec.icon.trim())) {
    errors.push('`icon` must be a non-empty host icon token or image URL/path');
  }
  if (spec.backend !== undefined && spec.backend !== null) {
    if (!isPlainObject(spec.backend)) {
      errors.push('`backend` must be an object like { kind: "js" } or { kind: "wasm" }');
    } else {
      if (!['js', 'wasm'].includes(spec.backend.kind)) {
        errors.push(`\`backend.kind\` must be js | wasm (got ${JSON.stringify(spec.backend.kind)})`);
      }
      if (typeof spec.backend.entrypoint !== "string" || !spec.backend.entrypoint.trim()) {
        errors.push('`backend.entrypoint` is required and must be a non-empty string');
      }
    }
  }
  if (spec.backends !== undefined && spec.backends !== null) {
    if (!isPlainObject(spec.backends) || Object.keys(spec.backends).length === 0) {
      errors.push('`backends` must be a non-empty object like { js: { entrypoint }, wasm: { entrypoint } }');
    } else {
      for (const [kind, backend] of Object.entries(spec.backends)) {
        if (!['js', 'wasm'].includes(kind)) {
          errors.push(`\`backends.${kind}\` is not supported; use js | wasm`);
          continue;
        }
        if (!isPlainObject(backend)) {
          errors.push(`\`backends.${kind}\` must be an object with an \`entrypoint\``);
        } else if (typeof backend.entrypoint !== "string" || !backend.entrypoint.trim()) {
          errors.push(`\`backends.${kind}.entrypoint\` is required and must be a non-empty string`);
        }
      }
    }
  }
  const backendDeclarations = [spec.backend, spec.backends, spec.runtime]
    .filter((value) => value !== undefined && value !== null);
  if (backendDeclarations.length > 1) {
    errors.push('declare exactly one of `backend`, `backends`, or legacy `runtime`');
  }
  if (isPlainObject(spec.backends) && Array.isArray(spec.functions)) {
    spec.functions.forEach((fn, i) => {
      if (!fn || typeof fn !== "object") return;
      if (typeof fn.backend !== "string" || !fn.backend.trim()) {
        errors.push(`functions[${i}] must select a declared \`backend\` when the app has multiple backends`);
      } else if (!Object.hasOwn(spec.backends, fn.backend)) {
        errors.push(`functions[${i}].backend references undeclared backend ${JSON.stringify(fn.backend)}`);
      }
      if (fn.runtime !== undefined) {
        errors.push(`functions[${i}] must use public \`backend\`, not internal \`runtime\`, with \`backends\``);
      }
    });
  }
  if (isPlainObject(spec.backend) && Array.isArray(spec.functions)) {
    spec.functions.forEach((fn, i) => {
      if (!fn || typeof fn !== "object") return;
      const installedServiceOperation = fn.runtime === 'container' && spec.features?.some(feature =>
        feature.contract === 'abrum.host.container/v1' && Object.values(feature.operations ?? {}).includes(fn.id ?? fn.name));
      if (fn.backend !== undefined || (fn.runtime !== undefined && !installedServiceOperation)) {
        errors.push(`functions[${i}] must not repeat a runtime when the app has one \`backend\`; codegen infers it`);
      }
    });
  }
  if (Array.isArray(spec.functions)) {
    spec.functions.forEach((fn, functionIndex) => {
      if (!fn || typeof fn !== "object" || fn.secrets === undefined) return;
      if (!Array.isArray(fn.secrets)) {
        errors.push(`functions[${functionIndex}].secrets must be an array of abrum.secret({...}) references`);
        return;
      }
      fn.secrets.forEach((secret, secretIndex) => {
        if (!secret || secret.__abrumSecret !== true
          || typeof secret.id !== "string" || !secret.id.trim()
          || typeof secret.kind !== "string" || !secret.kind.trim()
          || typeof secret.fillAs !== "string" || !secret.fillAs.trim()) {
          errors.push(`functions[${functionIndex}].secrets[${secretIndex}] must be created with abrum.secret({...}) and have non-empty \`id\`, \`kind\`, and \`fillAs\``);
        }
      });
    });
  }
  if (spec.build !== undefined && !isPlainObject(spec.build)) {
    errors.push("`build` must be an object like { command, dist, entrypoint }");
  }
  if (spec.install !== undefined && !isPlainObject(spec.install)) {
    errors.push("`install` must be an object like { grant, grantedRights }");
  }
  if (spec.computer !== undefined) {
    if (!isPlainObject(spec.computer) || !Array.isArray(spec.computer.services)
      || spec.computer.services.length === 0) {
      errors.push("`computer` must be an object with a non-empty `services` array");
    } else {
      if (!Array.isArray(spec.companions) || !spec.companions.includes("abrum.computer")) {
        errors.push('`computer.services` requires `companions: ["abrum.computer"]`');
      }
      if (spec.computer.services.length > 16) {
        errors.push("`computer.services` may declare at most 16 services");
      }
      const serviceIds = new Set();
      spec.computer.services.forEach((service, index) => {
        const prefix = `computer.services[${index}]`;
        if (!isPlainObject(service)) {
          errors.push(`${prefix} must be an object`);
          return;
        }
        const id = typeof service.serviceId === "string" ? service.serviceId.trim() : "";
        if (!/^[a-z0-9][a-z0-9._-]{0,63}$/i.test(id)) {
          errors.push(`${prefix}.serviceId must be a valid non-empty service id`);
        } else if (serviceIds.has(id)) {
          errors.push(`${prefix}.serviceId duplicates \`${id}\``);
        } else {
          serviceIds.add(id);
        }
        if (typeof service.label !== "string" || !service.label.trim()) {
          errors.push(`${prefix}.label must be a non-empty string`);
        }
        if (!['http', 'mcp'].includes(service.protocol)) {
          errors.push(`${prefix}.protocol must be http or mcp`);
        }
        if (!Number.isInteger(service.port) || service.port < 1 || service.port > 65_535) {
          errors.push(`${prefix}.port must be an integer from 1 to 65535`);
        }
        if (service.path !== undefined
          && (typeof service.path !== "string" || !service.path.startsWith("/") || service.path.includes(".."))) {
          errors.push(`${prefix}.path must be an absolute service path without ..`);
        }
        if (typeof service.startupScript !== "string" || !service.startupScript.trim()
          || service.startupScript.trim().length > 32_000) {
          errors.push(`${prefix}.startupScript must be a non-empty string of at most 32000 characters`);
        }
        if (service.bearerTokenFile !== undefined) {
          const tokenFile = typeof service.bearerTokenFile === "string"
            ? service.bearerTokenFile.trim()
            : "";
          if (!tokenFile.startsWith("/workspace/work/") || tokenFile.length > 512
            || tokenFile.includes("..") || /[\u0000-\u001f\u007f]/.test(tokenFile)) {
            errors.push(`${prefix}.bearerTokenFile must stay below /workspace/work/`);
          }
        }
      });
    }
  }
  if (spec.sidebar !== undefined) {
    if (!isPlainObject(spec.sidebar)) {
      errors.push("`sidebar` must be an object");
    } else {
      const createRoom = spec.sidebar.createRoom;
      if (createRoom !== undefined && (!isPlainObject(createRoom)
        || typeof createRoom.label !== "string" || !createRoom.label.trim()
        || (createRoom.icon !== undefined && typeof createRoom.icon !== "string")
        || (createRoom.actionId !== undefined && (typeof createRoom.actionId !== "string" || !createRoom.actionId.trim()))
        || (createRoom.setupActionId !== undefined && (typeof createRoom.setupActionId !== "string" || !createRoom.setupActionId.trim()))
        || (createRoom.setupFailureMessage !== undefined
          && (typeof createRoom.setupFailureMessage !== "string" || !createRoom.setupFailureMessage.trim()))
        || (createRoom.hideFromSidebar !== undefined && typeof createRoom.hideFromSidebar !== "boolean")
        || (createRoom.activationContentType !== undefined
          && (typeof createRoom.activationContentType !== "string" || !createRoom.activationContentType.trim()))
        || (createRoom.existingComputerMcpServiceId !== undefined
          && (typeof createRoom.existingComputerMcpServiceId !== "string" || !createRoom.existingComputerMcpServiceId.trim()))
        || (createRoom.dialog !== undefined && (!isPlainObject(createRoom.dialog)
          || ["title", "description", "nameLabel", "namePlaceholder", "submitLabel", "initialName"]
            .some((field) => createRoom.dialog[field] !== undefined && typeof createRoom.dialog[field] !== "string"))))) {
        errors.push("`sidebar.createRoom` must have a non-empty string `label`, optional string `icon`/`actionId`/`setupActionId`/`setupFailureMessage`/`activationContentType`/`existingComputerMcpServiceId`, optional boolean `hideFromSidebar`, and an optional string-valued `dialog`");
      } else if (createRoom?.actionId !== undefined && createRoom.dialog !== undefined) {
        errors.push("`sidebar.createRoom` must choose either `actionId` or `dialog`, not both");
      }
      const contextLabel = spec.sidebar.contextLabel;
      if (contextLabel !== undefined) {
        const source = contextLabel.source;
        const fallbackOk = contextLabel.fallback === undefined
          || contextLabel.fallback === "roomName"
          || contextLabel.fallback === "appTitle";
        const sourceOk = source === undefined || (isPlainObject(source)
          && typeof source.contentType === "string" && source.contentType.trim()
          && typeof source.field === "string" && source.field.trim()
          && (source.iconField === undefined || (typeof source.iconField === "string" && source.iconField.trim()))
          && (source.orderBy === undefined || (typeof source.orderBy === "string" && source.orderBy.trim())));
        if (!isPlainObject(contextLabel) || !fallbackOk || !sourceOk) {
          errors.push("`sidebar.contextLabel` must have optional fallback `roomName` or `appTitle` and an optional source `{contentType, field, iconField?, orderBy?}`");
        }
      }
      const actions = spec.sidebar.roomActions;
      if (actions !== undefined) {
        if (!Array.isArray(actions)) {
          errors.push("`sidebar.roomActions` must be an array");
        } else {
          const ids = new Set();
          actions.forEach((action, i) => {
            if (!isPlainObject(action)
              || typeof action.id !== "string" || !action.id.trim()
              || typeof action.label !== "string" || !action.label.trim()
              || (action.icon !== undefined && typeof action.icon !== "string")) {
              errors.push(`sidebar.roomActions[${i}] must have non-empty string \`id\` and \`label\` values and an optional string \`icon\``);
              return;
            }
            if (ids.has(action.id.trim())) errors.push(`sidebar.roomActions[${i}].id duplicates \`${action.id.trim()}\``);
            if (action.navigationOnly !== undefined && typeof action.navigationOnly !== "boolean") {
              errors.push(`sidebar.roomActions[${i}].navigationOnly must be a boolean`);
            }
            ids.add(action.id.trim());
          });
        }
      }
    }
  }
  if (errors.length > 0) {
    throw new Error(`invalid abrum.app.ts:\n  - ${errors.join("\n  - ")}`);
  }
}

function isPlainObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function validateToolInputSchema(schema, pathLabel, errors) {
  if (schema.type === "array" && schema.items === undefined) {
    errors.push(`${pathLabel}.items is required when type is array`);
  }
  if (schema.properties !== undefined && isPlainObject(schema.properties)) {
    for (const [key, child] of Object.entries(schema.properties)) {
      if (isPlainObject(child)) {
        validateToolInputSchema(child, `${pathLabel}.properties.${key}`, errors);
      }
    }
  }
  if (schema.items !== undefined) {
    if (!isPlainObject(schema.items)) {
      errors.push(`${pathLabel}.items must be a schema object`);
    } else {
      validateToolInputSchema(schema.items, `${pathLabel}.items`, errors);
    }
  }
}

const APP_SURFACE_SCHEMA_KEYS = new Set([
  "$id", "$schema", "title", "description", "default", "examples", "deprecated", "readOnly", "writeOnly",
  "type", "properties", "required", "additionalProperties", "items", "enum", "const",
]);
const APP_SURFACE_SCHEMA_TYPES = new Set(["object", "array", "string", "number", "integer", "boolean", "null"]);

function validateSurfaceInputSchema(schema, pathLabel, errors) {
  for (const key of Object.keys(schema)) {
    if (!APP_SURFACE_SCHEMA_KEYS.has(key)) {
      errors.push(`${pathLabel} uses unsupported schema keyword "${key}"`);
    }
  }
  if (schema.type !== undefined && !APP_SURFACE_SCHEMA_TYPES.has(schema.type)) {
    errors.push(`${pathLabel}.type must be one supported JSON scalar/container type`);
  }
  if (schema.required !== undefined
    && (!Array.isArray(schema.required) || schema.required.some((key) => typeof key !== "string"))) {
    errors.push(`${pathLabel}.required must be an array of strings`);
  }
  if (schema.additionalProperties !== undefined && typeof schema.additionalProperties !== "boolean") {
    errors.push(`${pathLabel}.additionalProperties must be boolean`);
  }
  if (schema.properties !== undefined) {
    if (!isPlainObject(schema.properties)) {
      errors.push(`${pathLabel}.properties must be an object`);
    } else {
      for (const [key, child] of Object.entries(schema.properties)) {
        if (!isPlainObject(child)) errors.push(`${pathLabel}.properties.${key} must be a schema object`);
        else validateSurfaceInputSchema(child, `${pathLabel}.properties.${key}`, errors);
      }
    }
  }
  if (schema.items !== undefined) {
    if (!isPlainObject(schema.items)) errors.push(`${pathLabel}.items must be a schema object`);
    else validateSurfaceInputSchema(schema.items, `${pathLabel}.items`, errors);
  }
}

async function normalizeSpec(spec, pkg, appDir, options = {}) {
  const id = stringValue(spec.id, "id");
  const entities = spec.entities ?? {};
  const imports = options.resolveImports === false
    ? []
    : await normalizeImports(spec.imports ?? [], appDir);
  const runtime = spec.backend == null ? spec.runtime : runtimeFromBackend(spec.backend);
  const backends = spec.backends == null ? undefined : Object.fromEntries(
    Object.entries(spec.backends).map(([kind, backend]) => [
      kind,
      runtimeFromBackend({ kind, ...backend }),
    ]),
  );
  // KARTE 649: DER FINGERABDRUCK DES BACKEND-CODES GEHOERT INS MANIFEST.
  //
  // Ohne ihn kommt eine reine Inhaltsaenderung am Backend NIE auf einer Station an:
  // default_app_content_changed (crates/abrum-station/src/station/rooms.rs) vergleicht
  // 20 Manifest-Schluessel — title, appVersion, functions, runtime, artifact und
  // weitere — und KEINER davon kannte den Inhalt. `runtime` nannte nur Engine und
  // Einstiegspunkt. Die Station stellte also fest "nichts hat sich geaendert" und
  // installierte nicht neu; der Deploy lief mit Exit 0 durch und bewirkte nichts.
  // Das ist die schlimmste Sorte Fehler: es scheitert nichts, und wer nicht misst,
  // glaubt, er habe ausgerollt. (Gemessen 2026-08-02/03: die App-Version musste
  // dreimal von Hand angehoben werden, 0.4.2 -> 0.4.5, nur damit etwas ankommt.)
  //
  // Der Fingerabdruck sitzt bewusst INNERHALB von `runtime`: dieser Schluessel steht
  // bereits auf der Vergleichsliste des Kerns, also greift die Pruefung ohne jede
  // Rust-Aenderung. Ein Digest, kein Zeitstempel — sonst meldete jeder Lauf eine
  // Aenderung und die Station installierte bei jedem Start neu.
  await mitBackendDigest(runtime, appDir, options);
  if (backends) for (const b of Object.values(backends)) await mitBackendDigest(b, appDir, options);

  const { functions, requiredSecrets } = normalizeFunctions(spec.functions ?? []);
  const capabilityOffers = normalizeCapabilityOffers(spec.capabilityOffers ?? [], functions);
  validateCapabilityCoverage(spec.capabilityCoverage, capabilityOffers, functions);
  const schemaEntries = [
    ...Object.entries(entities).map(([entity, def]) => ({
      entity,
      name: schemaNameFor(id, entity, def),
      contentType: def.contentType ?? def.options?.contentType ?? entity,
      schema: entityJsonSchema(id, entity, def),
    })),
    ...(spec.schemas ?? []),
  ];
  return {
    ...spec,
    id,
    package: spec.package ?? pkg.name,
    version: pkg.version ?? spec.version ?? "0.1.0",
    kind: spec.kind ?? "web",
    entities,
    imports,
    runtime,
    backends,
    functions,
    capabilityOffers,
    requiredSecrets,
    schemaEntries: dedupeSchemas(schemaEntries),
  };
}

/** Haengt den sha256 des Einstiegspunkts an die Laufzeit-Beschreibung (Karte 649).
 *  Fehlt die Datei, wird NICHTS gesetzt: ein erfundener Digest waere schlimmer als
 *  keiner — er behauptete eine Aenderung, die niemand nachlesen kann. */
async function mitBackendDigest(laufzeit, appDir, options) {
  if (!laufzeit || typeof laufzeit.entrypoint !== "string" || !laufzeit.entrypoint) return;
  // A source contract cannot depend on a compiler output from the current host.
  // Build generation (the default) still binds the actual bytes for deployment.
  if (options.sourceContract && laufzeit.kind === "wasm") {
    delete laufzeit.backendDigest;
    return;
  }
  try {
    const inhalt = await readFile(path.join(appDir, laufzeit.entrypoint));
    laufzeit.backendDigest = createHash("sha256").update(inhalt).digest("hex").slice(0, 32);
  } catch {
    // Kein Einstiegspunkt auf der Platte (z. B. nur deklariert): still lassen.
  }
}

function validateCapabilityCoverage(coverage, offers, functions) {
  if (coverage === undefined) return;
  if (coverage !== "complete") {
    throw new Error('invalid abrum.app.ts:\n  - capabilityCoverage must be "complete" when declared');
  }
  const covered = new Set(offers.flatMap((offer) => offer.functions));
  const missing = functions
    .map(functionHandle)
    .filter(Boolean)
    .filter((handle) => !covered.has(handle));
  if (missing.length) {
    throw new Error(
      `invalid abrum.app.ts:\n  - capabilityCoverage "complete" requires every function in a capability offer; missing: ${missing.join(", ")}`,
    );
  }
}

function normalizeCapabilityOffers(offers, functions) {
  if (!Array.isArray(offers)) {
    throw new Error("invalid abrum.app.ts:\n  - capabilityOffers must be an array");
  }
  const functionHandles = new Set(functions.map(functionHandle).filter(Boolean));
  const ids = new Set();
  return offers.map((offer, index) => {
    if (!isPlainObject(offer)) {
      throw new Error(`invalid abrum.app.ts:\n  - capabilityOffers[${index}] must be an object`);
    }
    const id = stringValue(offer.id, `capabilityOffers[${index}].id`);
    if (ids.has(id)) {
      throw new Error(`invalid abrum.app.ts:\n  - duplicate capability offer ${JSON.stringify(id)}`);
    }
    ids.add(id);
    stringValue(offer.title, `capabilityOffers[${index}].title`);
    if (!Array.isArray(offer.functions) || offer.functions.length === 0) {
      throw new Error(`invalid abrum.app.ts:\n  - capabilityOffers[${index}].functions must be a non-empty array`);
    }
    const unknown = offer.functions.filter(
      (handle) => typeof handle !== "string" || !functionHandles.has(handle),
    );
    if (unknown.length) {
      throw new Error(
        `invalid abrum.app.ts:\n  - capability offer ${JSON.stringify(id)} references unknown functions: ${unknown.join(", ")}`,
      );
    }
    const modes = offer.modes ?? ["on_behalf_of_caller"];
    if (!Array.isArray(modes) || modes.length === 0 || modes.some((mode) => typeof mode !== "string")) {
      throw new Error(`invalid abrum.app.ts:\n  - capabilityOffers[${index}].modes must be a non-empty array of strings`);
    }
    if (offer.defaultMode !== undefined && !modes.includes(offer.defaultMode)) {
      throw new Error(`invalid abrum.app.ts:\n  - capability offer ${JSON.stringify(id)} defaultMode must be listed in modes`);
    }
    // Today agent tool outputs are durable in the consumer Agent Room. A
    // private-to-invoker overlay is a separate future projection; never claim
    // that policy implicitly before the runtime can enforce it.
    const resultPolicies = offer.resultPolicies ?? ["agent_room"];
    if (!Array.isArray(resultPolicies) || resultPolicies.length === 0
      || resultPolicies.some((policy) => typeof policy !== "string")) {
      throw new Error(`invalid abrum.app.ts:\n  - capabilityOffers[${index}].resultPolicies must be a non-empty array of strings`);
    }
    if (offer.defaultResultPolicy !== undefined
      && !resultPolicies.includes(offer.defaultResultPolicy)) {
      throw new Error(`invalid abrum.app.ts:\n  - capability offer ${JSON.stringify(id)} defaultResultPolicy must be listed in resultPolicies`);
    }
    return stripUndefined({
      ...offer,
      id,
      functions: [...new Set(offer.functions)],
      modes: [...new Set(modes)],
      defaultMode: offer.defaultMode ?? modes[0],
      resultPolicies: [...new Set(resultPolicies)],
      defaultResultPolicy: offer.defaultResultPolicy ?? resultPolicies[0],
    });
  });
}

function normalizeFunctions(functions) {
  const secretsById = new Map();
  const normalizedFunctions = functions.map((fn) => {
    if (!isPlainObject(fn)) return fn;
    const handle = functionHandle(fn);
    const { backend, secrets = [], ...definition } = fn;
    for (const secret of secrets) {
      const normalizedSecret = stripUndefined(Object.fromEntries(
        Object.entries(secret).filter(([key]) => key !== "__abrumSecret" && key !== "functions"),
      ));
      const current = secretsById.get(normalizedSecret.id);
      if (current && JSON.stringify(current.definition) !== JSON.stringify(normalizedSecret)) {
        throw new Error(`invalid abrum.app.ts:\n  - secret ${JSON.stringify(normalizedSecret.id)} is declared with conflicting options`);
      }
      const entry = current ?? { definition: normalizedSecret, functions: [] };
      if (handle && !entry.functions.includes(handle)) entry.functions.push(handle);
      secretsById.set(normalizedSecret.id, entry);
    }
    return backend === undefined
      ? definition
      : { ...definition, runtime: runtimeKind(backend) };
  });
  const requiredSecrets = [...secretsById.values()].map(({ definition, functions: consumers }) => ({
    ...definition,
    functions: consumers,
  }));
  return { functions: normalizedFunctions, requiredSecrets };
}

function runtimeFromBackend(backend) {
  const { kind, ...options } = backend;
  return {
    ...options,
    kind: kind === "js" ? "station-js" : "wasm",
  };
}

function runtimeKind(kind) {
  return kind === "js" ? "station-js" : "station-wasm";
}

function manifestFromSpec(spec) {
  const install = spec.sidebar || spec.computer
    ? {
        ...(spec.install ?? {}),
        config: {
          ...(isPlainObject(spec.install?.config) ? spec.install.config : {}),
          ...(spec.sidebar ? { sidebar: spec.sidebar } : {}),
          ...(spec.computer ? { computer: spec.computer } : {}),
        },
      }
    : spec.install;
  return stripUndefined({
    appId: spec.id,
    package: spec.package,
    title: spec.title,
    icon: spec.icon,
    description: spec.description,
    kind: spec.kind,
    appVersion: spec.version,
    // Security gate metadata (konzept BR-1/3/4, station dispatch): station-side runtimes
    // (station-wasm/station-js effect paths) are only dispatched when the manifest declares
    // an executionLevel — undeclared defaults to schema-only and the station refuses. The
    // field must flow through here or an app CANNOT declare it at all (the 2026-07-07
    // mail-fetch finding: syncInbox blocked for every install).
    executionLevel: spec.executionLevel,
    build: spec.build,
    install,
    imports: spec.imports.length ? manifestImports(spec.imports) : undefined,
    companions: spec.companions ?? undefined,
    schemas: spec.schemaEntries,
    features: spec.features ?? [],
    functions: spec.functions ?? [],
    capabilityOffers: spec.capabilityOffers.length ? spec.capabilityOffers : undefined,
    requiredSecrets: spec.requiredSecrets.length ? spec.requiredSecrets : undefined,
    surfaces: spec.surfaces ?? [],
    background: spec.background ?? null,
    runtime: spec.runtime ?? null,
    backends: spec.backends,
    network: spec.network ?? undefined,
  });
}

function manifestImports(imports) {
  return imports.map((imported) => ({
    ...imported,
    // The consumer manifest is an authorization allowlist, not another copy of
    // the provider contract. Full schemas remain in the provider module and are
    // used only while generating the consumer's typed binding.
    functions: Array.isArray(imported.functions)
      ? imported.functions.map((fn) => {
          const handle = functionHandle(fn);
          return fn?.id ? { id: handle } : { name: handle };
        }).filter((fn) => fn.id || fn.name)
      : undefined,
    // Provider-owned widget declarations stay generated. Hosts use this import
    // allowlist to authorize cross-app modal/window placement.
    surfaces: Array.isArray(imported.surfaces) ? imported.surfaces : undefined,
  }));
}

function moduleContractFromSpec(spec, manifest) {
  return stripUndefined({
    __abrumModule: true,
    appId: manifest.appId,
    package: manifest.package,
    version: compatibleVersion(manifest.appVersion),
    capabilities: Array.isArray(spec.capabilities) && spec.capabilities.length
      ? spec.capabilities
      : undefined,
    required: true,
    schemas: manifest.schemas,
    functions: manifest.functions,
    capabilityOffers: manifest.capabilityOffers,
    surfaces: manifest.surfaces,
  });
}

function compatibleVersion(version) {
  return typeof version === "string" && /^\d+\.\d+\.\d+/.test(version)
    ? `^${version}`
    : version;
}

function generatedModuleJs(contract) {
  return [
    `export const abrumModule = ${JSON.stringify(contract, null, 2)};`,
    "export default abrumModule;",
    "",
  ].join("\n");
}

function generatedModuleTypes(contract) {
  return [
    "export declare const abrumModule: {",
    `  readonly appId: ${JSON.stringify(contract.appId)};`,
    ...(contract.package === undefined ? [] : [`  readonly package: ${JSON.stringify(contract.package)};`]),
    ...(contract.version === undefined ? [] : [`  readonly version: ${JSON.stringify(contract.version)};`]),
    "  readonly __abrumModule: true;",
    "  readonly required: true;",
    "  readonly capabilities?: readonly string[];",
    "  readonly schemas: ReadonlyArray<{ readonly entity: string; readonly name: string; readonly contentType?: string; readonly schema?: unknown }>;",
    "  readonly functions: ReadonlyArray<{ readonly id?: string; readonly name?: string; readonly input?: unknown; readonly output?: unknown; readonly [key: string]: unknown }>;",
    "  readonly capabilityOffers?: ReadonlyArray<{ readonly id: string; readonly title: string; readonly functions: readonly string[]; readonly modes?: readonly string[]; readonly defaultMode?: string; readonly risk?: string; readonly resultPolicies?: readonly string[]; readonly defaultResultPolicy?: string; readonly [key: string]: unknown }>;",
    "  readonly surfaces: ReadonlyArray<{ readonly id?: string; readonly kind: string; readonly label?: string; readonly entrypoint?: string; readonly placements?: readonly string[]; readonly input?: unknown; readonly [key: string]: unknown }>;",
    "};",
    "export default abrumModule;",
    "",
  ].join("\n");
}

function generatedTwins(spec, manifest) {
  const appVar = `${camelIdentifier(spec.id.replace(/^abrum\./, ""))}App`;
  const installVar = `${camelIdentifier(spec.id.replace(/^abrum\./, ""))}InstallManifest`;
  const constants = [
    `export const ${constantPrefix(spec.id)}_APP_ID = ${JSON.stringify(spec.id)};`,
    `export const ${constantPrefix(spec.id)}_APP_VERSION = ${JSON.stringify(spec.version)};`,
    ...spec.schemaEntries.map((schema) => (
      `export const ${schemaConst(schema.entity)} = ${JSON.stringify(schema.name)};`
    )),
  ].join("\n");
  const entityLines = Object.entries(spec.entities).map(([name, def]) => {
    return `  ${safeKey(name)}: ${entityExpression(def, schemaNameFor(spec.id, name, def))},`;
  }).join("\n");
  const entityRecordTypes = Object.keys(spec.entities).map((name) => {
    const typeName = `${pascalIdentifier(name) || "Entity"}Record`;
    return `export type ${typeName} = AbrumEntityRecord<(typeof ${appVar}.entities)[${JSON.stringify(name)}]>;`;
  }).join("\n");

  // Registered functions become typed UI bindings (see useAbrumActions). The
  // handle is the function's `id` (or `name`); it is what run_app_function
  // matches on. Each function carries its input type so callers get checked
  // arguments — the same schema the manifest ships to the station.
  const functionDefs = (Array.isArray(spec.functions) ? spec.functions : [])
    .map((fn) => {
      const handle = functionHandle(fn);
      return handle ? { handle, runtime: fn.runtime, input: fn.input, output: fn.output } : null;
    })
    .filter(Boolean);
  const surfaceDefs = typedSurfaceDefs(manifest.surfaces);
  const functionInterfaces = functionDefs
    .flatMap((fn) => [functionInputInterface(fn), functionOutputDeclaration(fn)])
    .filter(Boolean)
    .join("\n\n");
  const surfaceInterfaces = surfaceDefs.map(surfaceInputInterface).filter(Boolean).join("\n\n");
  const appOptionLines = [
    ...(functionDefs.length > 0 ? [
        "  functions: {",
        ...functionDefs.map((fn) => `    ${safeKey(fn.handle)}: ${functionDescriptorExpr(fn)},`),
        "  },",
      ] : []),
    ...(surfaceDefs.length > 0 ? [
        "  surfaces: {",
        ...surfaceDefs.map((surface) => `    ${safeKey(surface.key)}: ${surfaceDescriptorExpr(surface)},`),
        "  },",
      ] : []),
  ];
  const importedApps = spec.imports.map((imported) => {
    const importName = `${camelIdentifier(imported.appId.replace(/^abrum\./, ""))}Import`;
    const typePrefix = pascalIdentifier(imported.appId.replace(/^abrum\./, ""));
    const defs = (Array.isArray(imported.functions) ? imported.functions : [])
      .map((fn) => {
        const handle = functionHandle(fn);
        return handle ? { handle, runtime: fn.runtime, input: fn.input, output: fn.output, typePrefix } : null;
      })
      .filter(Boolean);
    const surfaces = typedSurfaceDefs(imported.surfaces, typePrefix);
    const interfaces = defs
      .flatMap((fn) => [functionInputInterface(fn), functionOutputDeclaration(fn)])
      .concat(surfaces.map(surfaceInputInterface))
      .filter(Boolean)
      .join("\n\n");
    const optionLines = [
      ...(defs.length > 0 ? [
        "  functions: {",
        ...defs.map((fn) => `    ${safeKey(fn.handle)}: ${functionDescriptorExpr(fn)},`),
        "  },",
      ] : []),
      ...(surfaces.length > 0 ? [
        "  surfaces: {",
        ...surfaces.map((surface) => `    ${safeKey(surface.key)}: ${surfaceDescriptorExpr(surface)},`),
        "  },",
      ] : []),
    ];
    const options = optionLines.length > 0
      ? [
          ", {",
          ...optionLines,
          "}",
        ].join("\n")
      : "";
    return {
      interfaces,
      source: `export const ${importName} = abrum.app(${JSON.stringify(imported.appId)}, {}${options});`,
      hasFunctions: defs.length > 0,
      hasSurfaces: surfaces.length > 0,
      needsJsonValue: defs.some((fn) => functionOutputTypeName(fn) && !functionInputTypeName(fn))
        || surfaces.some((surface) => !surfaceInputTypeName(surface)),
    };
  });
  const importedFunctionInterfaces = importedApps.map((entry) => entry.interfaces).filter(Boolean).join("\n\n");
  const importedAppSources = importedApps.map((entry) => entry.source).join("\n\n");

  const manifestForInstall = {
    appId: manifest.appId,
    title: manifest.title,
    icon: manifest.icon,
    description: manifest.description,
    kind: manifest.kind,
    appVersion: spec.version,
    executionLevel: manifest.executionLevel,
    schemas: manifest.schemas,
    imports: manifest.imports,
    requiredSecrets: manifest.requiredSecrets,
    features: manifest.features,
    functions: manifest.functions,
    surfaces: manifest.surfaces,
    background: manifest.background,
    runtime: manifest.runtime,
    backends: manifest.backends,
    network: manifest.network,
    grantedRights: manifest.install?.grantedRights,
  };

  const runtimeImports = ["abrum", "type AbrumInstallAppOptions"];
  if (entityRecordTypes) {
    runtimeImports.splice(1, 0, "type AbrumEntityRecord");
  }
  if (functionDefs.length > 0 || importedApps.some((entry) => entry.hasFunctions)) {
    runtimeImports.splice(1, 0, "type AbrumAppFunctionDef");
  }
  if (surfaceDefs.length > 0 || importedApps.some((entry) => entry.hasSurfaces)) {
    runtimeImports.splice(1, 0, "type AbrumAppSurfaceDef");
  }
  if (
    functionDefs.some((fn) => functionOutputTypeName(fn) && !functionInputTypeName(fn))
    || surfaceDefs.some((surface) => !surfaceInputTypeName(surface))
    || importedApps.some((entry) => entry.needsJsonValue)
  ) {
    runtimeImports.splice(runtimeImports.length - 1, 0, "type JsonValue");
  }

  return [
    `import { ${runtimeImports.join(", ")} } from "@abrum/web-runtime";`,
    "",
    constants,
    "",
    ...(functionInterfaces ? [functionInterfaces, ""] : []),
    ...(surfaceInterfaces ? [surfaceInterfaces, ""] : []),
    ...(importedFunctionInterfaces ? [importedFunctionInterfaces, ""] : []),
    `export const ${appVar} = abrum.app(${JSON.stringify(spec.id)}, {`,
    entityLines,
    ...(appOptionLines.length > 0
      ? ["}, {", ...appOptionLines, "});"]
      : ["});"]),
    `export const app = ${appVar};`,
    "",
    ...(entityRecordTypes ? [entityRecordTypes, ""] : []),
    ...(importedAppSources ? [importedAppSources, ""] : []),
    `export const ${installVar}: AbrumInstallAppOptions = ${JSON.stringify(stripUndefined(manifestForInstall), null, 2)};`,
    `export const install = ${installVar};`,
    "",
  ].join("\n");
}

function functionHandle(fn) {
  if (!fn || typeof fn !== "object") return null;
  const handle = typeof fn.id === "string" && fn.id.trim()
    ? fn.id.trim()
    : typeof fn.name === "string" && fn.name.trim()
      ? fn.name.trim()
      : null;
  return handle;
}

function functionInputTypeName(fn) {
  const schema = fn.input;
  if (!isPlainObject(schema) || schema.type !== "object" || !isPlainObject(schema.properties)) {
    return null;
  }
  return `${fn.typePrefix ?? ""}${pascalIdentifier(fn.handle)}Input`;
}

function functionOutputTypeName(fn) {
  return isPlainObject(fn.output)
    ? `${fn.typePrefix ?? ""}${pascalIdentifier(fn.handle)}Output`
    : null;
}

function functionInputInterface(fn) {
  const typeName = functionInputTypeName(fn);
  if (!typeName) return null;
  const schema = fn.input;
  const required = new Set(Array.isArray(schema.required) ? schema.required : []);
  const lines = Object.entries(schema.properties).map(([prop, propSchema]) => {
    const optional = required.has(prop) ? "" : "?";
    return `  ${safeKey(prop)}${optional}: ${tsTypeForSchema(propSchema)};`;
  });
  return `export interface ${typeName} {\n${lines.join("\n")}\n}`;
}

function functionOutputDeclaration(fn) {
  const typeName = functionOutputTypeName(fn);
  return typeName ? `export type ${typeName} = ${tsTypeForSchema(fn.output)};` : null;
}

function functionDescriptorExpr(fn) {
  const descriptor = { name: fn.handle };
  if (typeof fn.runtime === "string" && fn.runtime.trim()) {
    descriptor.runtime = fn.runtime.trim();
  }
  const literal = JSON.stringify(descriptor);
  const inputType = functionInputTypeName(fn);
  const outputType = functionOutputTypeName(fn);
  if (outputType) {
    return `${literal} as AbrumAppFunctionDef<${inputType ?? "JsonValue"}, ${outputType}>`;
  }
  return inputType ? `${literal} as AbrumAppFunctionDef<${inputType}>` : `${literal} as AbrumAppFunctionDef`;
}

function typedSurfaceDefs(surfaces, typePrefix = "") {
  return (Array.isArray(surfaces) ? surfaces : [])
    .filter((surface) => surface && typeof surface.id === "string" && surface.id.trim())
    .map((surface) => ({
      id: surface.id.trim(),
      key: camelIdentifier(surface.id.trim()),
      input: surface.input,
      typePrefix,
    }));
}

function surfaceInputTypeName(surface) {
  const schema = surface.input;
  if (!isPlainObject(schema) || schema.type !== "object" || !isPlainObject(schema.properties)) {
    return null;
  }
  return `${surface.typePrefix ?? ""}${pascalIdentifier(surface.id)}SurfaceInput`;
}

function surfaceInputInterface(surface) {
  const typeName = surfaceInputTypeName(surface);
  if (!typeName) return null;
  const required = new Set(Array.isArray(surface.input.required) ? surface.input.required : []);
  const lines = Object.entries(surface.input.properties).map(([prop, propSchema]) => {
    const optional = required.has(prop) ? "" : "?";
    return `  ${safeKey(prop)}${optional}: ${tsTypeForSchema(propSchema)};`;
  });
  return `export interface ${typeName} {\n${lines.join("\n")}\n}`;
}

function surfaceDescriptorExpr(surface) {
  const typeName = surfaceInputTypeName(surface);
  const input = typeName ?? "JsonValue";
  return `${JSON.stringify({ name: surface.id })} as AbrumAppSurfaceDef<${input}>`;
}

function tsTypeForSchema(schema) {
  if (!isPlainObject(schema)) return "unknown";
  if (Array.isArray(schema.type)) {
    return schema.type
      .map((type) => tsTypeForSchema({ ...schema, type }))
      .join(" | ");
  }
  switch (schema.type) {
    case "string":
      return Array.isArray(schema.enum) && schema.enum.length > 0
        && schema.enum.every((value) => typeof value === "string")
        ? schema.enum.map((value) => JSON.stringify(value)).join(" | ")
        : "string";
    case "integer":
    case "number":
      return "number";
    case "boolean":
      return "boolean";
    case "null":
      return "null";
    case "array":
      return `Array<${tsTypeForSchema(schema.items)}>`;
    case "object":
      return isPlainObject(schema.properties) && Object.keys(schema.properties).length > 0
        ? `{ ${Object.entries(schema.properties)
            .map(([prop, propSchema]) => {
              const required = Array.isArray(schema.required) && schema.required.includes(prop);
              return `${safeKey(prop)}${required ? "" : "?"}: ${tsTypeForSchema(propSchema)}`;
            })
            .join("; ")} }`
        : "Record<string, unknown>";
    default:
      return "unknown";
  }
}

function pascalIdentifier(value) {
  return value
    .split(/[^a-z0-9]+/i)
    .filter(Boolean)
    .map((part) => `${part.charAt(0).toUpperCase()}${part.slice(1)}`)
    .join("");
}

function entityExpression(def, schemaName) {
  const fields = Object.entries(def.fields ?? {}).map(([name, field]) => {
    return `    ${safeKey(name)}: ${fieldExpression(field)},`;
  }).join("\n");
  let expr = `abrum.entity({\n${fields}\n  })`;
  expr += `.named(${JSON.stringify(schemaName)})`;
  if (def.contentType || def.options?.contentType) {
    expr += `.type(${JSON.stringify(def.contentType ?? def.options.contentType)})`;
  }
  expr += ".roomScoped()";
  return expr;
}

function fieldExpression(field) {
  const descriptor = field.descriptor ?? field;
  let expr = `abrum.${descriptor.kind}()`;
  if (descriptor.required === false) {
    expr += ".optional()";
  }
  if (descriptor.unique) {
    expr += ".unique()";
  } else if (descriptor.indexed) {
    expr += ".index()";
  }
  return expr;
}

function schemaNameFor(appId, entity, def) {
  return def.schema ?? def.options?.schemaName ?? `${appId}.${entity}.v1`;
}

function entityJsonSchema(appId, entity, def) {
  const contentType = def.contentType ?? def.options?.contentType ?? entity;
  const properties = { type: { const: contentType } };
  const required = ["type"];
  const indexed = [];
  const unique = [];
  for (const [fieldName, field] of Object.entries(def.fields ?? {})) {
    const descriptor = field.descriptor ?? field;
    const metadata = {
      "x-abrum-indexed": descriptor.indexed === true,
      "x-abrum-unique": descriptor.unique === true,
    };
    switch (descriptor.kind) {
      case "string":
        properties[fieldName] = { type: "string", ...metadata };
        break;
      case "number":
        properties[fieldName] = { type: "integer", ...metadata };
        break;
      case "boolean":
        properties[fieldName] = { type: "boolean", ...metadata };
        break;
      case "date":
        properties[fieldName] = {
          anyOf: [{ type: "integer" }, { type: "string", format: "date-time" }],
          ...metadata,
        };
        break;
      case "json":
      case "any":
        properties[fieldName] = metadata;
        break;
      default:
        throw new Error(`unsupported entity field kind ${JSON.stringify(descriptor.kind)}`);
    }
    if (descriptor.required !== false) required.push(fieldName);
    if (descriptor.indexed === true) indexed.push(fieldName);
    if (descriptor.unique === true) unique.push(fieldName);
  }
  return {
    type: "object",
    required,
    properties,
    additionalProperties: true,
    "x-abrum": {
      app: appId,
      entity,
      schemaName: schemaNameFor(appId, entity, def),
      scope: def.scope ?? def.options?.scope ?? "room",
      indexed,
      unique,
    },
  };
}

function dedupeSchemas(schemas) {
  const seen = new Set();
  const out = [];
  for (const schema of schemas) {
    if (!schema?.entity || !schema?.name) continue;
    const key = `${schema.entity}\0${schema.name}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ ...schema });
  }
  return out;
}

async function normalizeImports(imports, appDir) {
  if (!Array.isArray(imports)) return [];
  const resolved = [];
  for (const entry of imports) {
    const packageName = typeof entry === "string" ? entry : entry.package;
    const selectedHandles = typeof entry === "string"
      ? null
      : new Set(entry.functions.map((handle) => handle.trim()));
    const mod = await loadPackageModuleImport(packageName, appDir);
    if (!mod || typeof mod !== "object" || typeof mod.appId !== "string" || !mod.appId.trim()) continue;
    const providerFunctions = Array.isArray(mod.functions) ? mod.functions : [];
    if (selectedHandles) {
      const availableHandles = new Set(providerFunctions.map(functionHandle).filter(Boolean));
      const unknown = [...selectedHandles].filter((handle) => !availableHandles.has(handle));
      if (unknown.length > 0) {
        throw new Error(`app import ${JSON.stringify(packageName)} selects unknown function(s): ${unknown.join(", ")}`);
      }
    }
    resolved.push(stripUndefined({
      appId: mod.appId.trim(),
      package: typeof mod.package === "string" && mod.package.trim() ? mod.package.trim() : undefined,
      version: typeof mod.version === "string" && mod.version.trim() ? mod.version.trim() : undefined,
      capabilities: Array.isArray(mod.capabilities) ? mod.capabilities.filter((value) => typeof value === "string" && value.trim()) : undefined,
      functions: providerFunctions.filter((fn) => selectedHandles === null || selectedHandles.has(functionHandle(fn))),
      surfaces: Array.isArray(mod.surfaces) ? mod.surfaces : undefined,
      required: mod.required === undefined ? undefined : mod.required === true,
    }));
  }
  return resolved;
}

async function loadPackageModuleImport(packageName, appDir) {
  const pkg = packageName.trim();
  if (!isPackageNameImport(pkg)) {
    throw new Error(`app import must be a bare package name like "@abrum/agent"; got ${JSON.stringify(packageName)}`);
  }
  const specifier = `${pkg}/module`;
  const requireFromApp = createRequire(path.join(appDir, "package.json"));
  let resolvedPath;
  try {
    resolvedPath = requireFromApp.resolve(specifier);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    throw new Error(`failed to resolve app import ${JSON.stringify(pkg)} via ${specifier}: ${message}`);
  }
  const mod = await import(`${pathToFileURL(resolvedPath).href}?v=${Date.now()}`);
  const contract = pickModuleExport(mod, pkg);
  if (!contract) {
    throw new Error(`app import ${JSON.stringify(pkg)} must export an abrum module from ${specifier}`);
  }
  return contract;
}

function pickModuleExport(mod, packageName) {
  const packageLeaf = packageName.split("/").pop()?.replace(/^abrum-/, "") ?? "";
  const camelLeaf = camelIdentifier(packageLeaf);
  const candidates = [
    mod.default,
    mod.abrumModule,
    mod.module,
    camelLeaf ? mod[`${camelLeaf}Module`] : undefined,
    ...Object.values(mod),
  ];
  return candidates.find((value) => value && typeof value === "object" && value.__abrumModule === true) ?? null;
}

function isPackageNameImport(value) {
  const name = typeof value === "string" ? value.trim() : "";
  return /^(?:@[a-z0-9._-]+\/)?[a-z0-9._-]+$/i.test(name);
}

function stripUndefined(value) {
  if (Array.isArray(value)) {
    return value.map(stripUndefined);
  }
  if (!value || typeof value !== "object") {
    return value;
  }
  return Object.fromEntries(
    Object.entries(value)
      .filter(([, v]) => v !== undefined)
      .map(([k, v]) => [k, stripUndefined(v)]),
  );
}

function constantPrefix(appId) {
  return appId.replace(/^abrum\./, "").replace(/[^a-z0-9]+/gi, "_").replace(/^_+|_+$/g, "").toUpperCase();
}

function schemaConst(entity) {
  return `${entity.replace(/([a-z0-9])([A-Z])/g, "$1_$2").replace(/[^a-z0-9]+/gi, "_").toUpperCase()}_SCHEMA_NAME`;
}

function camelIdentifier(value) {
  const parts = value.split(/[^a-z0-9]+/i).filter(Boolean);
  const [first = "app", ...rest] = parts;
  return `${first.charAt(0).toLowerCase()}${first.slice(1)}${rest.map((p) => `${p.charAt(0).toUpperCase()}${p.slice(1)}`).join("")}`;
}

function safeKey(key) {
  return /^[A-Za-z_$][A-Za-z0-9_$]*$/.test(key) ? key : JSON.stringify(key);
}

function stringValue(value, label) {
  if (typeof value !== "string" || !value.trim()) {
    throw new Error(`abrum.app.ts ${label} must be a non-empty string`);
  }
  return value.trim();
}
