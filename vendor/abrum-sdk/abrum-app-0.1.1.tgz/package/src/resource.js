// Spec 36: an address, never a grant. Domain context stays owned by the app.
export const resourceRefSchema = Object.freeze({
  type: "object",
  additionalProperties: false,
  properties: {
    contract: { type: "string", const: "abrum.resource/v1" },
    roomId: { type: "string", minLength: 1 },
    appId: { type: "string", minLength: 1 },
    entityType: { type: "string", minLength: 1 },
    lineageCid: { type: "string", minLength: 1 },
    versionCid: { type: "string", minLength: 1 },
  },
  required: ["contract", "roomId", "appId", "entityType", "lineageCid", "versionCid"],
});

/** Build-time gate: only advertise native resource verbs that actually exist. */
export function validateResourceFeatures(features = [], functions = []) {
  for (const feature of features) {
    if (feature?.id !== "abrum.app.resources/v1") continue;
    if (!Array.isArray(feature.resources) || !feature.resources.length) throw new Error("resources/v1 requires resources");
    const names = new Set(functions.map((fn) => fn.id ?? fn.name));
    const entities = new Set();
    for (const resource of feature.resources) {
      if (!resource.entityType || entities.has(resource.entityType)) throw new Error("resource entityType must be unique");
      entities.add(resource.entityType);
      if (!resource.readFunction) throw new Error("resource requires a readFunction, not just a preview");
      const verbs = [resource.readFunction, resource.presentFunction,
        ...(resource.prepareFunctions ?? []), ...(resource.writeFunctions ?? [])].filter(Boolean);
      for (const verb of verbs) if (!names.has(verb)) throw new Error(`resource verb ${verb} does not exist`);
      if (resource.resultFunctions?.length) {
        if (resource.openAction !== "select-twin" || !resource.resultLabel?.trim()) {
          throw new Error("resource results require select-twin and a resultLabel");
        }
        for (const verb of resource.resultFunctions) {
          if (!names.has(verb) || !resource.writeFunctions?.includes(verb)) {
            throw new Error(`resource result function ${verb} must be a declared writeFunction`);
          }
        }
      }
    }
  }
}
