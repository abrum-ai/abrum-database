import { readFileSync } from "node:fs";
import {
  actorHttpSignaturePayload as actorHttpSignaturePayloadRust,
  conveySecret as conveySecretRust,
  identityX25519 as identityX25519Rust,
  initSync,
  sealPortableSecret as sealPortableSecretRust,
} from "./pkg/abrum_wasm.js";

initSync({
  module: readFileSync(new URL("./pkg/abrum_wasm_bg.wasm", import.meta.url)),
});

/** Node entrypoint for protocol semantics owned by abrum-core through WASM. */
export function actorHttpSignaturePayload(
  method,
  routeScope,
  actorDid,
  timestampMs,
  nonce,
  bodyText,
) {
  return actorHttpSignaturePayloadRust(
    method,
    routeScope,
    actorDid,
    BigInt(timestampMs),
    nonce,
    bodyText,
  );
}

export function identityX25519(seedHex) {
  return JSON.parse(identityX25519Rust(seedHex));
}

export function conveySecret(recipientPublic, context, value) {
  return JSON.parse(conveySecretRust(recipientPublic, context, value));
}

export function sealPortableSecret(recipientPublics, context, value) {
  return JSON.parse(sealPortableSecretRust(
    JSON.stringify(recipientPublics.map((publicKey) => Array.from(publicKey))),
    context,
    value,
  ));
}
