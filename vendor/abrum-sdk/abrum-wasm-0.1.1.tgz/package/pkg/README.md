# abrum-wasm

WASM ABI for the browser/runtime boundary.

This crate wraps `abrum-core`; it does not reimplement protocol rules. The ABI
uses JSON strings for signed twins and identities so the boundary stays small
and stable across JS bundlers.

Build with:

```sh
wasm-pack build crates/abrum-wasm --target web --out-dir ../../packages/abrum-wasm/pkg
```

The generated module is consumed by `createAbrumWasmProtocolCore` in
`@abrum/web-runtime`.
