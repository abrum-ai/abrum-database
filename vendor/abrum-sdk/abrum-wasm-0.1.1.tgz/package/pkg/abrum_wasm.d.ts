/* tslint:disable */
/* eslint-disable */
/**
 * The `ReadableStreamType` enum.
 *
 * *This API requires the following crate features to be activated: `ReadableStreamType`*
 */

type ReadableStreamType = "bytes";

export class IntoUnderlyingByteSource {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableByteStreamController): Promise<any>;
    start(controller: ReadableByteStreamController): void;
    readonly autoAllocateChunkSize: number;
    readonly type: ReadableStreamType;
}

export class IntoUnderlyingSink {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    abort(reason: any): Promise<any>;
    close(): Promise<any>;
    write(chunk: any): Promise<any>;
}

export class IntoUnderlyingSource {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableStreamDefaultController): Promise<any>;
}

export function actorHttpSignaturePayload(method: string, route_scope: string, actor_did: string, timestamp_ms: bigint, nonce: string, body_text: string): string;

export function canonicalBytes(block_json: string): Uint8Array;

export function computeCid(bytes: Uint8Array): string;

export function computePayloadCid(bytes: Uint8Array): string;

export function computeStorageCid(bytes: Uint8Array): string;

export function conveySecret(recipient_public: Uint8Array, context: Uint8Array, value: Uint8Array): string;

/**
 * Browser crypto is the same Rust implementation used by every Station. The
 * bindings accept bytes so plaintext and key material never need a stringly
 * transport or a Station round-trip.
 */
export function deriveKey(ikm: Uint8Array, info: Uint8Array): Uint8Array;

export function deviceKeyTwin(seed_hex: string, identity_root_cid: string, label: string | null | undefined, created_at_ms: bigint): string;

export function identityFromRecoveryPhrase(phrase: string): string;

export function identityFromSeedHex(seed_hex: string): string;

export function identityRootDid(identity_root_cid: string): string;

export function identityRootTwin(seed_hex: string, root_kind: string, label: string | null | undefined, created_at_ms: bigint): string;

export function identityX25519(seed_hex: string): string;

export function objectTwin(seed_hex: string, schema_cid: string, content_json: string, previous_version?: string | null): string;

export function openValue(key: Uint8Array, envelope_json: string, aad: Uint8Array): Uint8Array;

export function payloadCidForValue(value_json: string): string;

export function relationTwin(seed_hex: string, source: string, target: string, relation_type: string, inherits_access: boolean, extra_json?: string | null): string;

/**
 * Send a bounded first-party web-session or read-only query request directly
 * to a signed Station binding. The browser keeps no Room key and no Vault
 * copy; iroh supplies only the live encrypted transport to an online Station.
 */
export function requestIdentityStation(endpoint_ticket: string, request_json: string): Promise<string>;

export function schemaTwin(seed_hex: string, name: string, schema_class: string, json_schema_json: string): string;

export function sealPortableSecret(recipient_publics_json: string, context: Uint8Array, value: Uint8Array): string;

export function sealValue(key: Uint8Array, plaintext: Uint8Array, aad: Uint8Array): string;

export function signBlock(seed_hex: string, block_json: string): string;

export function signUtf8(seed_hex: string, payload: string): string;

export function storageCidForClearBlock(block_json: string): string;

export function unwrapKey(recipient_secret: Uint8Array, wrapped_json: string): Uint8Array;

export function userPrincipalTwin(seed_hex: string, display_name: string, created_at_ms: bigint): string;

export function verifyTwin(twin_json: string): void;

export function wrapKey(recipient_public: Uint8Array, cek: Uint8Array): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly actorHttpSignaturePayload: (a: number, b: number, c: number, d: number, e: number, f: number, g: bigint, h: number, i: number, j: number, k: number) => [number, number];
    readonly canonicalBytes: (a: number, b: number) => [number, number, number, number];
    readonly computeCid: (a: number, b: number) => [number, number];
    readonly computePayloadCid: (a: number, b: number) => [number, number];
    readonly computeStorageCid: (a: number, b: number) => [number, number];
    readonly conveySecret: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly deriveKey: (a: number, b: number, c: number, d: number) => [number, number];
    readonly deviceKeyTwin: (a: number, b: number, c: number, d: number, e: number, f: number, g: bigint) => [number, number, number, number];
    readonly identityFromRecoveryPhrase: (a: number, b: number) => [number, number, number, number];
    readonly identityFromSeedHex: (a: number, b: number) => [number, number, number, number];
    readonly identityRootDid: (a: number, b: number) => [number, number];
    readonly identityRootTwin: (a: number, b: number, c: number, d: number, e: number, f: number, g: bigint) => [number, number, number, number];
    readonly identityX25519: (a: number, b: number) => [number, number, number, number];
    readonly objectTwin: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number, number];
    readonly openValue: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly payloadCidForValue: (a: number, b: number) => [number, number, number, number];
    readonly relationTwin: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number) => [number, number, number, number];
    readonly requestIdentityStation: (a: number, b: number, c: number, d: number) => any;
    readonly schemaTwin: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number, number];
    readonly sealPortableSecret: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly sealValue: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly signBlock: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly signUtf8: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly storageCidForClearBlock: (a: number, b: number) => [number, number, number, number];
    readonly unwrapKey: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly userPrincipalTwin: (a: number, b: number, c: number, d: number, e: bigint) => [number, number, number, number];
    readonly verifyTwin: (a: number, b: number) => [number, number];
    readonly wrapKey: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly __wbg_intounderlyingbytesource_free: (a: number, b: number) => void;
    readonly intounderlyingbytesource_autoAllocateChunkSize: (a: number) => number;
    readonly intounderlyingbytesource_cancel: (a: number) => void;
    readonly intounderlyingbytesource_pull: (a: number, b: any) => any;
    readonly intounderlyingbytesource_start: (a: number, b: any) => void;
    readonly intounderlyingbytesource_type: (a: number) => number;
    readonly __wbg_intounderlyingsink_free: (a: number, b: number) => void;
    readonly intounderlyingsink_abort: (a: number, b: any) => any;
    readonly intounderlyingsink_close: (a: number) => any;
    readonly intounderlyingsink_write: (a: number, b: any) => any;
    readonly __wbg_intounderlyingsource_free: (a: number, b: number) => void;
    readonly intounderlyingsource_cancel: (a: number) => void;
    readonly intounderlyingsource_pull: (a: number, b: any) => any;
    readonly ring_core_0_17_14__bn_mul_mont: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h461b8ec48fad58b7: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h455a2a48cb5b034d: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h8c0363a1344cb13c: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__ha16215d9c57fd668: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__hbdcf83c41c4ec436: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__ha051829d3ae4f450: (a: number, b: number) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h060331c029c7a9c7: (a: number, b: number) => void;
    readonly wasm_bindgen__convert__closures_____invoke__hd52975a751450995: (a: number, b: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
