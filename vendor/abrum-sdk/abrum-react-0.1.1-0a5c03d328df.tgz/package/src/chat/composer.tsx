import { chatText } from "./chat-text";
import * as React from "react";
import { AuiIf, ComposerPrimitive, useAui } from "@assistant-ui/react";
import { LoaderCircle } from "lucide-react";
import { ArrowUp, Stop } from "../brand-icons";
import { cn } from "../ui/cn";
import { ChatAttachmentIcon, ComposerAttachmentCard } from "./attachments";
import { cancelPersistedAgentRun } from "./composer-cancel";
import { ChatQueueItem } from "./queue-item";

/*
 * ChatComposer — the shared message input. Built on assistant-ui's
 * ComposerPrimitive so submit/clear/disabled wire straight into whatever
 * runtime the host mounts. `actions` injects extra controls (e.g. connected
 * apps) into the right action group; `controls` creates a quiet bottom toolbar
 * for runtime controls; `attachments` renders a row above the textarea.
 */

export interface ChatComposerProps {
  /** Prevent an editable stopped prompt from following navigation to another chat. */
  editScope?: string;
  /** Host-owned named affordances, shared by co-presence and acceptance. */
  affordanceScope?: string;
  placeholder?: string;
  /** Await the host stop request; the host reports failures in its run notice. */
  onStop?: () => Promise<void>;
  disabled?: boolean;
  /** Extra controls rendered in the right action group, before attachment and Send. */
  actions?: React.ReactNode;
  /** Controls rendered in a bottom toolbar, opposite actions and Send. */
  controls?: React.ReactNode;
  /** Optional attachment row rendered above the input. */
  attachments?: React.ReactNode;
  /** Enable the shared file picker, paste and drop attachment lifecycle. */
  allowAttachments?: boolean;
  /** Visual treatment for the attachment control. Use plain-black for an unframed black icon. */
  attachmentVariant?: "default" | "plain-black";
  /** Visual treatment for Send. Use black for a fixed high-contrast action. */
  sendVariant?: "primary" | "neutral" | "black";
  /** Vertical density. Compact keeps narrow sidebar composers visually centered. */
  density?: "default" | "compact";
  className?: string;
  /** Optional host-specific typography/layout for the editable message field. */
  inputClassName?: string;
  /** Hide the composer entirely (e.g. while voice mode is open). */
  hidden?: boolean;
}

function useComposerInputWidth() {
  const inputRef = React.useRef<HTMLTextAreaElement>(null);
  const [, setObservedWidth] = React.useState<number | null>(null);

  React.useLayoutEffect(() => {
    const input = inputRef.current;
    if (!input || typeof ResizeObserver === "undefined") return undefined;

    let observedWidth = input.getBoundingClientRect().width;
    const observer = new ResizeObserver(([entry]) => {
      const nextWidth = entry?.contentRect.width ?? input.getBoundingClientRect().width;
      if (nextWidth === observedWidth) return;
      observedWidth = nextWidth;

      // ComposerPrimitive.Input uses react-textarea-autosize, which measures on
      // render but does not observe element-width changes. A collapsed sidebar
      // can therefore leave its initial six-row measurement in place until the
      // first keystroke. Re-render at the new width so its layout effect can
      // immediately calculate the correct row count without remounting/focus loss.
      setObservedWidth(nextWidth);
    });
    observer.observe(input);
    return () => observer.disconnect();
  }, []);

  return inputRef;
}

function StopPersistedRunButton({
  affordanceScope,
  sendVariant,
  onStop,
  onStopped,
}: {
  affordanceScope?: string;
  sendVariant: "primary" | "neutral" | "black";
  onStop?: () => Promise<void>;
  onStopped?: (text: string) => void;
}) {
  const aui = useAui();
  const [stopping, setStopping] = React.useState(false);

  const stopPending = React.useRef(false);
  const stop = React.useCallback(async () => {
    if (stopPending.current) return;
    stopPending.current = true;
    setStopping(true);
    try {
      const lastUser = [...aui.thread().getState().messages].reverse().find(message => message.role === 'user');
      const previousText = lastUser?.content.filter(part => part.type === 'text').map(part => part.type === 'text' ? part.text : '').join('\n') || '';
      await cancelPersistedAgentRun({
        getText: () => aui.composer().getState().text,
        cancel: onStop ?? (() => aui.composer().cancel()),
        setText: (text) => aui.composer().setText(text),
      });
      onStopped?.(previousText);
    } catch {
      // The host displays the request error. Allow another stop attempt.
    } finally {
      stopPending.current = false;
      setStopping(false);
    }
  }, [aui, onStop, onStopped]);

  return (
    <button
      type="button"
      data-slot="chat-composer-stop"
      data-abrum-verb={affordanceScope ? `${affordanceScope}.stop` : undefined}
      aria-label={stopping ? chatText("Stopping", "Wird gestoppt", "Arrêt en cours") : chatText("Stop", "Stoppen", "Arrêter")}
      title={stopping ? chatText("Stopping…", "Wird gestoppt…", "Arrêt en cours…") : chatText("Stop", "Stoppen", "Arrêter")}
      disabled={stopping}
      onClick={stop}
      className={cn(
        "inline-flex size-8 shrink-0 items-center justify-center rounded-full transition hover:opacity-80 disabled:cursor-wait disabled:opacity-70",
        sendVariant === "black"
          ? "bg-black"
          : sendVariant === "neutral"
            ? "bg-surface-muted"
            : "bg-primary",
      )}
    >
      {stopping ? (
        <LoaderCircle
          className={cn(
            "size-4 animate-spin motion-reduce:animate-none",
            sendVariant === "neutral" ? "text-fg" : "text-white",
          )}
          aria-hidden="true"
        />
      ) : (
        <Stop
          className={cn(
            "size-4",
            sendVariant === "neutral" ? "text-fg" : "text-white",
          )}
          aria-hidden="true"
        />
      )}
    </button>
  );
}

export function ChatComposer({
  editScope,
  affordanceScope,
  placeholder = "Message your assistant",
  onStop,
  disabled = false,
  actions,
  controls,
  attachments,
  allowAttachments = false,
  attachmentVariant = "default",
  sendVariant = "primary",
  density = "default",
  className,
  inputClassName,
  hidden,
}: ChatComposerProps) {
  const inputRef = useComposerInputWidth();
  const aui = useAui();
  const [stoppedDraft, setStoppedDraft] = React.useState<{scope?:string;text:string}>({text:''});
  const stoppedPrompt = stoppedDraft.scope === editScope ? stoppedDraft.text : '';
  const setStoppedPrompt = (text: string) => setStoppedDraft({scope:editScope,text});
  const editStoppedPrompt = () => {
    if (!stoppedPrompt || aui.thread().getState().isRunning || aui.composer().getState().text.trim()) return;
    aui.composer().setText(stoppedPrompt);
    setStoppedPrompt('');
    inputRef.current?.focus();
  };

  return (
    <ComposerPrimitive.AttachmentDropzone
      asChild
      disabled={disabled || !allowAttachments}
    >
      <ComposerPrimitive.Root
        data-slot="chat-composer"
        className={cn(
          "abrum-backdrop-blur flex flex-col rounded-2xl border border-border bg-field shadow-sm",
          allowAttachments && "data-[dragging=true]:border-dashed data-[dragging=true]:border-accent data-[dragging=true]:bg-accent-soft",
          density === "compact" ? "gap-1.5 p-2" : "gap-2 p-2",
          hidden && "hidden",
          className,
        )}
        aria-disabled={disabled || undefined}
      >
      {allowAttachments ? (
        <div className="flex flex-wrap gap-1 px-1">
          <ComposerPrimitive.Attachments>
            {({ attachment }) => <ComposerAttachmentCard attachment={attachment} />}
          </ComposerPrimitive.Attachments>
        </div>
      ) : null}
      {attachments ? <div className="px-1">{attachments}</div> : null}
      <ComposerPrimitive.Queue>
        {({ queueItem }) => (
          <ChatQueueItem queueItem={queueItem} />
        )}
      </ComposerPrimitive.Queue>
      <div className={cn("flex gap-1.5", controls ? "flex-col" : "items-center")}>
        <ComposerPrimitive.Input
          data-abrum-verb={affordanceScope ? `${affordanceScope}.compose` : undefined}
          ref={inputRef}
          rows={1}
          maxRows={6}
          autoFocus
          placeholder={placeholder}
          disabled={disabled}
          onKeyDown={event => { if (event.key === 'ArrowUp' && !event.currentTarget.value && stoppedPrompt && !aui.thread().getState().isRunning) { event.preventDefault(); editStoppedPrompt(); } }}
          className={cn(
            "max-h-40 resize-none bg-transparent px-1.5 text-body!! text-fg outline-none",
            controls ? "w-full flex-none" : "min-w-0 flex-1",
            density === "compact"
              ? "h-7! min-h-7! py-1!"
              : "h-8! min-h-8 py-1.5",
            "placeholder:text-fg-subtle disabled:opacity-50",
            inputClassName,
          )}
        />
        <div className={cn("flex items-center gap-1.5", controls && "min-h-8 justify-between")}>
          {controls ? <div className="min-w-0 flex-1">{controls}</div> : null}
          {actions}
          {allowAttachments ? (
            <ComposerPrimitive.AddAttachment
              multiple
              aria-label={chatText("Add attachment", "Anhang hinzufügen", "Ajouter une pièce jointe")}
              title={chatText("Add attachment", "Anhang hinzufügen", "Ajouter une pièce jointe")}
              className={cn(
                "inline-flex size-8 shrink-0 items-center justify-center rounded-full bg-transparent",
                attachmentVariant === "plain-black"
                  ? "text-black hover:bg-transparent hover:text-black active:bg-transparent"
                  : "text-fg-muted hover:bg-surface-muted hover:text-fg",
              )}
            >
              <ChatAttachmentIcon className="size-4" />
            </ComposerPrimitive.AddAttachment>
          ) : null}
          <AuiIf condition={(state) => state.thread.isRunning}>
            <StopPersistedRunButton affordanceScope={affordanceScope} sendVariant={sendVariant} onStop={onStop} onStopped={setStoppedPrompt} />
          </AuiIf>
          <ComposerPrimitive.Send
            data-slot="chat-composer-send"
            data-abrum-verb={affordanceScope ? `${affordanceScope}.send` : undefined}
            aria-label={chatText("Send", "Senden", "Envoyer")}
            disabled={disabled}
            className={cn(
              "inline-flex size-8 shrink-0 items-center justify-center rounded-full transition-[background-color,color,transform] duration-150 active:scale-90 motion-reduce:active:scale-100",
              sendVariant === "black"
                ? "bg-black text-white hover:bg-zinc-800"
                : sendVariant === "neutral"
                  ? "bg-surface-muted text-fg hover:bg-surface-hover"
                  : "bg-primary text-primary-fg hover:bg-primary-hover",
              "disabled:cursor-not-allowed",
              "disabled:opacity-40",
            )}
          >
            <ArrowUp className="size-4" strokeWidth={2} />
          </ComposerPrimitive.Send>
        </div>
      </div>
      </ComposerPrimitive.Root>
    </ComposerPrimitive.AttachmentDropzone>
  );
}
