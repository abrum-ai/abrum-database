import * as React from "react";
import {
  useMessage,
  useThread,
  useThreadRuntime,
  type ToolCallMessagePartProps,
} from "@assistant-ui/react";
import { CircleHelp, X } from "lucide-react";
import { ArrowUp, ChevronDown } from "../brand-icons";
import { MarkdownText } from "./markdown";
import { chatText } from "./chat-text";
import { ToolCallPart } from "./parts";
import {
  humanInputRequestFromResult,
  humanInputFallbackState,
  pendingHumanInputRequest,
  humanQuestionTopicKey,
  answerToHumanQuestion,
  humanQuestionPresentationKey,
  humanQuestionIsClosed,
  type HumanInputRequest,
} from "./human-question-data";

export {
  humanInputRequestFromResult,
  pendingHumanInputRequest,
  ABRUM_REQUEST_USER_INPUT_TOOL,
  humanInputResponseFromMessage,
  type HumanInputResponseRef,
  type HumanInputRequest,
} from "./human-question-data";

export const HumanQuestionScopeContext = React.createContext<string | null | undefined>(undefined);
export const HumanQuestionReadOnlyContext = React.createContext(false);
export type HumanQuestionSubmit = (request: HumanInputRequest, answer: string) => Promise<boolean>;
export const HumanQuestionSubmitContext = React.createContext<HumanQuestionSubmit | undefined>(undefined);
export type HumanQuestionDismiss = (request: HumanInputRequest) => Promise<boolean>;
export const HumanQuestionDismissContext = React.createContext<HumanQuestionDismiss | undefined>(undefined);

function HumanQuestionCard({ request, presentationKey }: { request: HumanInputRequest; presentationKey: string }) {
  const runtime = useThreadRuntime();
  const running = useThread((state) => state.isRunning);
  const [answer, setAnswer] = React.useState("");
  const [submitted, setSubmitted] = React.useState(false);
  const [accepted, setAccepted] = React.useState(false);
  const [submitError, setSubmitError] = React.useState(false);
  const submitting = React.useRef(false);
  const submitAnswer = React.useContext(HumanQuestionSubmitContext);
  const dismissQuestion = React.useContext(HumanQuestionDismissContext);
  const [closing, setClosing] = React.useState(false);
  const [closeError, setCloseError] = React.useState(false);
  const closePending = React.useRef(false);
  const close = async () => {
    if (!dismissQuestion || !(request.responseRef || request.dismissRef) || closePending.current || submitting.current) return;
    closePending.current = true;
    setClosing(true);
    setCloseError(false);
    try {
      if (!await dismissQuestion(request)) throw Error("Close was not accepted");
      setAccepted(true);
    } catch { setCloseError(true); }
    finally { closePending.current = false; setClosing(false); }
  };
  const closeButton = dismissQuestion && (request.responseRef || request.dismissRef) ? (
    <button type="button" data-abrum-verb="chat.question.dismiss" disabled={closing || submitted}
      aria-label={chatText("Close question – no longer relevant", "Rückfrage schließen – nicht mehr relevant", "Fermer la question – plus pertinente")}
      title={chatText("No longer relevant: end this question and its continuation", "Nicht mehr relevant: Rückfrage und zugehörige Fortsetzung beenden", "Plus pertinente : terminer cette question et sa suite")}
      onClick={() => void close()}
      className="flex size-7 shrink-0 items-center justify-center rounded-md text-fg-muted hover:bg-surface-muted disabled:opacity-50">
      <X className="size-3.5" aria-hidden="true" />
    </button>
  ) : null;
  const storageKey = `abrum:question-collapsed:${presentationKey}`;
  const [collapsed, setCollapsed] = React.useState(() => {
    try { return sessionStorage.getItem(storageKey) === "1"; } catch { return false; }
  });
  const setPresentationCollapsed = (value: boolean) => {
    setCollapsed(value);
    try {
      if (value) sessionStorage.setItem(storageKey, "1");
      else sessionStorage.removeItem(storageKey);
    } catch { /* Session storage is optional; in-memory presentation still works. */ }
  };

  const submit = React.useCallback(
    async (value: string) => {
      const trimmed = value.trim();
      if (!trimmed || running || submitting.current || closePending.current) return;
      submitting.current = true;
      setSubmitted(true);
      setSubmitError(false);
      try {
        if (submitAnswer) {
          if (!await submitAnswer(request, trimmed)) throw Error('Answer not accepted');
          setAccepted(true);
        } else {
          // Ordinary app runtimes remove this card when the answer appears in
          // their transcript; append itself is void, not a send receipt.
          runtime.append({ role: "user", content: [{ type: "text", text: trimmed }],
            metadata: { custom: { ...(request.responseRef ? { humanInputResponse: request.responseRef } : {}) } } });
        }
      } catch {
        submitting.current = false;
        setSubmitted(false);
        setSubmitError(true);
      }
    },
    [running, runtime, request, submitAnswer],
  );

  if (accepted) return null;
  if (collapsed) return (
    <div className="motion-safe:animate-chat-rise mx-auto flex max-w-full flex-col items-center gap-1">
    <div className="flex max-w-full items-center gap-0.5 rounded-full bg-bg py-0.5 pl-1 pr-0.5 shadow-[0_0_0_1px_color-mix(in_srgb,var(--color-accent)_35%,transparent),0_2px_8px_color-mix(in_srgb,var(--color-accent)_12%,transparent)]">
    <button type="button" data-slot="human-question-collapsed" data-abrum-verb="chat.question.expand"
      aria-expanded={false} onClick={() => setPresentationCollapsed(false)}
      className="flex min-h-8 min-w-0 max-w-full items-center gap-2 rounded-full border-0 bg-transparent px-2.5 py-1 text-ui font-medium text-accent shadow-none hover:bg-transparent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
      <span className="size-1.5 shrink-0 rounded-full bg-accent" aria-hidden="true" />
      <span className="shrink-0">{chatText("Open question", "Offene Rückfrage", "Question ouverte")}</span>
      <span className="min-w-0 truncate font-normal text-fg-muted">{request.question}</span>
    </button>
    {closeButton}
    </div>
    {closeError && <p role="alert" className="text-meta text-danger">{chatText("Closing was not confirmed. Please try again.", "Schließen nicht bestätigt. Bitte erneut versuchen.", "Fermeture non confirmée. Veuillez réessayer.")}</p>}
    </div>
  );
  return (
    // This card can float over transcript text. Use the opaque canvas token,
    // not the host's potentially translucent surface material.
    <section
      data-slot="human-question-card"
      className="motion-safe:animate-chat-rise mx-auto min-h-0 w-full max-w-3xl shrink overflow-y-auto overscroll-contain break-words rounded-xl bg-bg p-3 text-fg shadow-[0_0_0_1px_color-mix(in_srgb,var(--color-accent)_35%,transparent),0_6px_20px_color-mix(in_srgb,var(--color-accent)_12%,transparent)]"
      aria-labelledby={`human-question-${request.inputRequestId}`}
      onKeyDown={(event) => {
        if (event.key === "Escape") {
          event.stopPropagation();
          setPresentationCollapsed(true);
          return;
        }
        // 1–9 pick the matching choice, except while typing a free answer.
        const target = event.target as HTMLElement;
        if (submitted || /^(TEXTAREA|INPUT)$/.test(target.tagName) || event.metaKey || event.ctrlKey || event.altKey) return;
        const choice = /^[1-9]$/.test(event.key) ? request.choices[Number(event.key) - 1] : undefined;
        if (choice) {
          event.preventDefault();
          void submit(choice);
        }
      }}
    >
      <div className="flex items-start gap-2">
        <div className="min-w-0 flex-1">
          <p className="m-0 mb-1 flex items-center gap-1.5 text-meta font-medium text-accent">
            <CircleHelp className="size-3.5" aria-hidden="true" />
            {chatText("SINA needs your input", "SINA fragt nach", "SINA a besoin de vous")}
          </p>
          <h3 id={`human-question-${request.inputRequestId}`} className="m-0 text-body font-medium text-fg">
            {request.question}
          </h3>
          <p className="mt-1 text-meta text-fg-muted">{request.reason}</p>
          {request.requiredFields.length ? (
            <p className="mt-1 text-meta text-fg-subtle">
              {chatText("Needed", "Benötigt", "Requis")}: {request.requiredFields.join(" · ")}
            </p>
          ) : null}
        </div>
        <button type="button" data-abrum-verb="chat.question.collapse"
          aria-label={chatText("Collapse question", "Rückfrage einklappen", "Réduire la question")}
          title={chatText("Collapse – stays unanswered", "Rückfrage einklappen – bleibt unbeantwortet", "Réduire – reste sans réponse")}
          aria-expanded={true} onClick={() => setPresentationCollapsed(true)}
          className="flex size-7 shrink-0 items-center justify-center rounded-md text-fg-muted hover:bg-surface-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          <ChevronDown className="size-3.5" aria-hidden="true" />
        </button>
        {closeButton}
      </div>

      {closeError && <p role="alert" className="mt-2 text-ui text-danger">{chatText("Closing was not confirmed. Please try again.", "Schließen nicht bestätigt. Bitte erneut versuchen.", "Fermeture non confirmée. Veuillez réessayer.")}</p>}

      {submitted ? (
        <div className="mt-3 flex items-center gap-2 rounded-lg bg-surface-muted px-3 py-2 text-ui text-fg-muted" role="status">
          {chatText("Sending answer…", "Antwort wird übermittelt…", "Envoi de la réponse…")}
        </div>
      ) : (
        <>
          {request.choices.length ? (
            <div className="mt-3 grid gap-1.5" role="group" aria-label={chatText("Answer choices", "Antwortoptionen", "Choix de réponse")}>
              {request.choices.map((choice, index) => (
                <button
                  key={choice}
                  type="button"
                  disabled={running}
                  onClick={() => submit(choice)}
                  className="flex min-h-9 cursor-pointer items-center gap-2 rounded-lg border border-border bg-field px-3 py-1.5 text-left text-ui text-fg transition-[background-color,border-color,transform] duration-150 hover:border-accent/40 hover:bg-accent-soft active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:pointer-events-none disabled:opacity-50 motion-reduce:active:scale-100"
                >
                  <span className="min-w-0 flex-1">{choice}</span>
                  {index < 9 ? <kbd className="shrink-0 font-sans text-meta text-fg-subtle">{index + 1}</kbd> : null}
                </button>
              ))}
            </div>
          ) : null}

          {request.allowFreeform ? (
            <form
              className="mt-3 flex items-end gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                submit(answer);
              }}
            >
              <label className="min-w-0 flex-1">
                <span className="sr-only">{chatText("Your answer", "Deine Antwort", "Votre réponse")}</span>
                <textarea
                  rows={1}
                  value={answer}
                  onChange={(event) => setAnswer(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
                      event.preventDefault();
                      submit(answer);
                    }
                  }}
                  placeholder={request.choices.length
                    ? chatText("Or type another answer…", "Oder eine andere Antwort schreiben…", "Ou écrivez une autre réponse…")
                    : chatText("Type your answer…", "Deine Antwort…", "Votre réponse…")}
                  className="min-h-9 w-full resize-none rounded-lg border border-border bg-field px-3 py-2 text-body text-fg outline-none placeholder:text-fg-subtle focus-visible:ring-2 focus-visible:ring-ring"
                />
              </label>
              <button
                type="submit"
                disabled={running || !answer.trim()}
                className="inline-flex size-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-fg transition hover:bg-primary-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-40"
                aria-label={chatText("Send answer", "Antwort senden", "Envoyer la réponse")}
              >
                <ArrowUp className="size-4" aria-hidden="true" />
              </button>
            </form>
          ) : null}
        </>
      )}
      {submitError && <p role="alert" className="mt-2 text-ui text-danger">{chatText("The answer was not accepted. Please try again.", "Antwort wurde nicht angenommen. Bitte erneut versuchen.", "La réponse n’a pas été acceptée. Veuillez réessayer.")}</p>}
    </section>
  );
}

export function PendingHumanQuestion() {
  const messages = useThread((state) => state.messages);
  const readOnly = React.useContext(HumanQuestionReadOnlyContext);
  const topicKey = React.useContext(HumanQuestionScopeContext);
  const request = React.useMemo(() => pendingHumanInputRequest(messages, topicKey), [messages, topicKey]);
  const presentationKey = request ? humanQuestionPresentationKey(request, topicKey) : "";
  return request && !readOnly ? <HumanQuestionCard key={presentationKey} presentationKey={presentationKey} request={request} /> : null;
}

export function HumanQuestionToolPart(props: ToolCallMessagePartProps) {
  const readOnly = React.useContext(HumanQuestionReadOnlyContext);
  const messageId = useMessage((message) => message.id);
  const messages = useThread((state) => state.messages);
  const topicKey = React.useContext(HumanQuestionScopeContext);
  const runtime = useThreadRuntime();
  const running = useThread((state) => state.isRunning);
  const submitAnswer = React.useContext(HumanQuestionSubmitContext);

  const [submitting, setSubmitting] = React.useState(false);
  const [submitError, setSubmitError] = React.useState(false);
  const submittingRef = React.useRef(false);

  const request = humanInputRequestFromResult(props.result);
  // These hooks must run for every render. A tool part can first render while
  // its request is unavailable and receive the request result later; placing
  // hooks below the early return makes React see a different hook order and
  // crashes the whole renderer.
  const messageParts = useMessage((message) => message.content);
  const submit = React.useCallback(
    async (value: string) => {
      const currentRequest = request;
      const trimmed = value.trim();
      if (!currentRequest || !trimmed || running || submittingRef.current) return;
      submittingRef.current = true;
      setSubmitting(true);
      setSubmitError(false);
      try {
        if (submitAnswer) {
          if (!await submitAnswer(currentRequest, trimmed)) throw Error('Answer not accepted');
        } else {
          runtime.append({
            role: "user",
            content: [{ type: "text", text: trimmed }],
            metadata: { custom: { ...(currentRequest.responseRef ? { humanInputResponse: currentRequest.responseRef } : {}) } },
          });
        }
      } catch {
        submittingRef.current = false;
        setSubmitting(false);
        setSubmitError(true);
      }
    },
    [running, runtime, request, submitAnswer],
  );

  if (!request) {
    const state = humanInputFallbackState(
      props.result,
      (props as { status?: { type?: string } }).status?.type,
      (props as { isError?: boolean }).isError,
    );
    const displayName = state === "failed"
      ? chatText("Question could not be shown", "Rückfrage konnte nicht angezeigt werden", "Impossible d’afficher la question")
      : state === "unavailable"
        ? chatText("Question no longer available", "Rückfrage nicht mehr verfügbar", "Question plus disponible")
        : chatText("Waiting for your input", "Wartet auf deine Antwort", "En attente de votre réponse");
    return <ToolCallPart {...props} displayName={displayName} />;
  }

  const messageIndex = messages.findIndex((message) => message.id === messageId);
  const answer = answerToHumanQuestion(messages, messageIndex);
  if (messageIndex >= 0 && humanQuestionIsClosed(messages[messageIndex])) return null;
  const outsideTopic = topicKey !== undefined && messageIndex >= 0
    && humanQuestionTopicKey(messages[messageIndex]) !== (topicKey ?? "");

  if (outsideTopic) {
    return (
      <div data-slot="human-question-pending" className="my-1 flex items-center gap-2 text-ui text-fg-muted" role="status">
        <CircleHelp className="size-3.5" aria-hidden="true" />
        {`${request.question} — ${chatText("Open this topic to answer.", "Öffne dieses Thema, um zu antworten.", "Ouvrez ce sujet pour répondre.")}`}
      </div>
    );
  }

  const textAlreadyHasQuestion = messageParts.some(
    (part) => part.type === "text" && part.text.trim().includes(request.question.trim()),
  );

  const questionText = textAlreadyHasQuestion ? null : (
    <div data-slot="human-question-text">
      <MarkdownText>{request.question}</MarkdownText>
    </div>
  );
  if (!answer) {
    // A text question is ordinary assistant prose. The person answers in the
    // chat composer; a second form, reason line or confirmation row is not.
    if (request.choices.length === 0) return questionText;
    return (
      <div data-slot="human-question-card" className="my-1 flex flex-col gap-2 text-fg">
        {questionText}
        <span className="inline-flex flex-wrap items-center gap-1.5" role="group" aria-label={chatText("Answer choices", "Antwortoptionen", "Choix de réponse")}>
          {request.choices.map((choice) => (
            <button
              key={choice}
              type="button"
              data-abrum-verb="chat.question.answer"
              disabled={running || submitting || readOnly}
              onClick={() => void submit(choice)}
              className="inline-flex min-h-8 cursor-pointer items-center rounded-lg border border-border bg-field px-3 py-1 text-ui font-medium text-fg shadow-[0_1px_2px_rgb(0_0_0/0.04)] transition-[background-color,border-color,color,transform] duration-150 hover:border-accent/40 hover:bg-accent-soft hover:text-accent active:scale-[0.97] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:cursor-default disabled:opacity-50 disabled:hover:border-border disabled:hover:bg-field disabled:hover:text-fg motion-reduce:active:scale-100"
            >
              {choice}
            </button>
          ))}
        </span>
        {submitting ? <span className="text-meta text-fg-muted">{chatText("Sending answer…", "Antwort wird übermittelt…", "Envoi de la réponse…")}</span> : null}
        {submitError ? (
          <span role="alert" className="text-meta text-danger">{chatText("The answer was not accepted. Please try again.", "Antwort wurde nicht angenommen. Bitte erneut versuchen.", "La réponse n’a pas été acceptée. Veuillez réessayer.")}</span>
        ) : null}
      </div>
    );
  }
  // The answer is already the following user bubble. Do not repeat it here.
  return request.choices.length === 0 ? questionText : (
    <div data-slot="human-question-answered">{questionText}</div>
  );
}
