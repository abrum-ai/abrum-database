/*
 * Chat UI copy follows the host's document language. The desktop keeps
 * <html lang> in sync with its locale setting; standalone apps fall back to the
 * browser language. Components call chatText at render time, so a language
 * switch re-renders with the new copy.
 */
export type ChatLocale = "en" | "de" | "fr";

export function chatLocale(explicit?: string): ChatLocale {
  // Outside a browser document (server render, tests) the copy stays English
  // instead of following the machine locale.
  const raw = explicit
    || (typeof document !== "undefined"
      ? document.documentElement.lang || (typeof navigator !== "undefined" ? navigator.language : "")
      : "")
    || "en";
  return raw.startsWith("de") ? "de" : raw.startsWith("fr") ? "fr" : "en";
}

export function chatText(en: string, de: string, fr: string = en, explicit?: string): string {
  const locale = chatLocale(explicit);
  return locale === "de" ? de : locale === "fr" ? fr : en;
}

/** Transport errors reach the transcript as `⚠️ <provider text>`. */
export const CHAT_ERROR_PREFIX = "⚠️";

export function isChatErrorText(text: string): boolean {
  return text.trimStart().startsWith(CHAT_ERROR_PREFIX);
}

/**
 * The person-facing reason of an error text: without the warning glyph, the
 * provider transport prefix ("OpenAI-compatible API:") and bracketed internal
 * codes ("[provider_stream/rate_limited]"). The raw text stays in the message
 * (copy, support report); only its presentation changes.
 */
export function chatErrorReason(text: string): string {
  return text
    .trimStart()
    .replace(/^⚠️\s*/u, "")
    .replace(/^[\w .-]+ API:\s*/u, "")
    .replace(/\[[a-z0-9_]+(?:\/[a-z0-9_]+)+\]\s*/giu, "")
    .trim();
}
