/** A durable launch/schedule receipt links to a conversation; it grants no access. */
export const CHAT_REFERENCE_PART = "abrum.chat-reference";
export interface ChatReference {
  roomID: string;
  threadLineageCid: string;
  runId: string;
  title?: string;
  resultReturn?: true;
}

export function chatReferenceFromReceipt(input: unknown, depth = 0): ChatReference | null {
  if (depth > 4) return null;
  if (typeof input === "string") {
    try { return chatReferenceFromReceipt(JSON.parse(input), depth + 1); } catch { return null; }
  }
  if (!input || typeof input !== "object" || Array.isArray(input)) return null;
  const value = input as Record<string, unknown>;
  if (value.error || value.success === false || value.failed === true) return null;
  if (value.kind === "parent_return") {
    const receipt = value.receipt as Record<string, unknown> | undefined;
    if (receipt?.kind !== "sina_task_result" || value.sourceRoomId !== receipt.roomId
      || value.sourceRunId !== receipt.runId || typeof receipt.threadLineageCid !== "string"
      || !receipt.threadLineageCid.startsWith("sina-task:")
      || !["completed", "failed", "cancelled"].includes(String(receipt.taskStatus))) return null;
    if (typeof receipt.roomId !== "string" || !receipt.roomId || receipt.roomId.length > 512
      || typeof receipt.runId !== "string" || !receipt.runId || receipt.runId.length > 512
      || receipt.threadLineageCid.length > 512) return null;
    return {roomID:receipt.roomId, threadLineageCid:receipt.threadLineageCid, runId:receipt.runId,
      ...(typeof value.title === "string" && value.title ? {title:value.title.slice(0,120)} : {}),
      resultReturn:true};
  }
  const scheduled = value.kind === "chat_trigger_saved" && value.saved === true;
  if (scheduled || value.kind === "sina_task_assignment" || value.kind === "sina_task_continuation") {
    const ref = (scheduled ? value.trigger : value) as Record<string, unknown> | undefined;
    if (!ref || ![ref.roomId, ref.threadLineageCid].every(v => typeof v === "string" && v.length > 0 && v.length <= 512)) return null;
    const runId = scheduled ? ref.sourceRunId : ref.runId;
    if (typeof runId !== "string" || !runId || runId.length > 512) return null;
    return { roomID: ref.roomId as string, threadLineageCid: ref.threadLineageCid as string, runId,
      ...(typeof ref.title === "string" ? {title: ref.title.slice(0, 120)} : {}) };
  }
  return chatReferenceFromReceipt(value.data, depth + 1);
}

/** Batch delegation preserves every successfully admitted task, including when
 * another part failed admission. A partial receipt is not blanket success. */
export function chatReferencesFromReceipt(input: unknown, depth = 0): ChatReference[] {
  if (depth > 4) return [];
  if (typeof input === "string") {
    try { return chatReferencesFromReceipt(JSON.parse(input), depth + 1); } catch { return []; }
  }
  if (!input || typeof input !== "object" || Array.isArray(input)) return [];
  const value = input as Record<string, unknown>;
  if (value.isError || value.error || value.success === false || value.failed === true) return [];
  if (value.kind === "sina_task_assignments" && Array.isArray(value.assignments)) {
    return value.assignments.slice(0, 16).flatMap(item => chatReferencesFromReceipt(item, depth + 1));
  }
  const single = chatReferenceFromReceipt(value, depth);
  return single ? [single] : chatReferencesFromReceipt(value.data, depth + 1);
}

/** Link a signed task-result read back to its task chat. A return may become
 * a new wake Run or be injected into an already running SINA turn. In the
 * first case the wake ID also pins the exact child; in both cases this only
 * accepts an actual completed getAgentRunMessages tool receipt. */
export function chatReferenceFromParentReturnRead(input: unknown, wakeRunId: string | undefined): ChatReference | null {
  let value: unknown = input;
  if (typeof value === "string") {
    try { value = JSON.parse(value); } catch { return null; }
  }
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const read = value as Record<string, unknown>;
  if (read.isError === true || read.error || read.function !== "getAgentRunMessages") return null;
  const data = read.data as Record<string, unknown> | undefined;
  const run = data?.currentRun as Record<string, unknown> | undefined;
  if (!run || typeof run.runId !== "string" || !run.runId || run.runId.length > 512
    || (wakeRunId?.startsWith("wake-") && run.runId !== wakeRunId.slice(5)) || run.finished !== true
    || typeof run.roomId !== "string" || !run.roomId || run.roomId.length > 512
    || typeof data?.threadLineageCid !== "string" || !data.threadLineageCid.startsWith("sina-task:")
    || data.threadLineageCid.length > 512) return null;
  return {roomID: run.roomId, threadLineageCid: data.threadLineageCid, runId: run.runId,
    ...(typeof run.title === "string" && run.title ? {title: run.title.slice(0, 120)} : {}),
    resultReturn:true};
}
