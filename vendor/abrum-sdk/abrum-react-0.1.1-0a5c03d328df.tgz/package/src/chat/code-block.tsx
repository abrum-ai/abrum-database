// Adapted for abrum from https://beui.dev/components/agents/code-block
import { chatText } from "./chat-text";
import {
  type ReactNode,
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { Check, FileCode2, LoaderCircle } from "lucide-react";
import { Copy } from "../brand-icons";
import { cn } from "../ui/cn";
import {
  AgentCodeLine,
  useAgentCodeTokens,
} from "./agent-code";
import type { AgentCodeLanguage } from "./code-language";
import "./code-block.css";

export type CodeBlockStatus = "streaming" | "complete";

export interface CodeBlockProps {
  code: string;
  language?: AgentCodeLanguage;
  filename?: ReactNode;
  status?: CodeBlockStatus;
  showLineNumbers?: boolean;
  highlightLines?: number[];
  maxHeight?: number;
  wrap?: boolean;
  copyable?: boolean;
  onCopy?: () => void | Promise<void>;
  className?: string;
}

export function CodeBlock({
  code,
  language = "text",
  filename,
  status = "complete",
  showLineNumbers = true,
  highlightLines = [],
  maxHeight = 280,
  wrap = false,
  copyable = true,
  onCopy,
  className,
}: CodeBlockProps) {
  const viewportRef = useRef<HTMLDivElement>(null);
  const copyTimer = useRef<number | undefined>(undefined);
  const [copied, setCopied] = useState(false);
  const streaming = status === "streaming";
  const tokens = useAgentCodeTokens(code, language);
  const highlighted = useMemo(() => new Set(highlightLines), [highlightLines]);
  let offset = 0;
  const lines = code.split("\n").map((content) => {
    const line = { content, offset };
    offset += content.length + 1;
    return line;
  });

  useEffect(
    () => () => {
      if (copyTimer.current) window.clearTimeout(copyTimer.current);
    },
    [],
  );

  useLayoutEffect(() => {
    const viewport = viewportRef.current;
    if (!viewport || !streaming) return;

    const frame = requestAnimationFrame(() => {
      if (viewport.scrollHeight <= viewport.clientHeight) return;
      viewport.scrollTo({
        top: viewport.scrollHeight,
        behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches
          ? "auto"
          : "smooth",
      });
    });
    return () => cancelAnimationFrame(frame);
  });

  const handleCopy = useCallback(async () => {
    try {
      if (onCopy) await onCopy();
      else {
        if (!navigator.clipboard?.writeText) return;
        await navigator.clipboard.writeText(code);
      }

      setCopied(true);
      if (copyTimer.current) window.clearTimeout(copyTimer.current);
      copyTimer.current = window.setTimeout(() => setCopied(false), 1600);
    } catch {
      // Clipboard writes can be denied when the window is not focused. Keep
      // the control quiet and truthful instead of surfacing an unhandled
      // rejection or showing the success state.
      setCopied(false);
    }
  }, [code, onCopy]);

  return (
    <div
      data-slot="chat-code-block"
      data-state={status}
      aria-busy={streaming}
      className={cn(
        "my-2 w-full min-w-0 overflow-hidden rounded-2xl bg-surface-muted text-body",
        className,
      )}
    >
      <div className="flex h-10 items-center gap-2.5 px-3">
        <FileCode2 aria-hidden="true" className="size-3.5 shrink-0 text-fg-muted" />
        {filename ? (
          <span className="min-w-0 truncate font-mono text-ui text-fg">
            {filename}
          </span>
        ) : null}
        <span className="text-micro font-medium uppercase tracking-label text-fg-muted">
          {language}
        </span>
        {/* Only while the block is still arriving. A finished block needs no
            badge saying so — it is simply there, and the label competed with
            the filename for the eye. */}
        {streaming ? (
          <span className="ml-auto inline-flex shrink-0 items-center gap-1 text-micro font-medium text-accent">
            <LoaderCircle
              aria-hidden="true"
              className="size-3 animate-spin motion-reduce:animate-none"
            />
            Writing
          </span>
        ) : null}
        {copyable || onCopy ? (
          <button
            type="button"
            aria-label={copied ? chatText("Copied", "Kopiert", "Copié") : chatText("Copy code", "Code kopieren", "Copier le code")}
            title={copied ? chatText("Copied", "Kopiert", "Copié") : chatText("Copy code", "Code kopieren", "Copier le code")}
            onClick={handleCopy}
            className={cn(
              // No pill behind the glyph: the header is already a surface of
              // its own, and a filled circle on top of it reads as a separate
              // control rather than as an affordance of this block.
              "grid size-7 shrink-0 place-items-center rounded-md text-fg-muted outline-none",
              "transition-[color,transform] hover:text-fg focus-visible:ring-2 focus-visible:ring-border-focus",
              "active:scale-90 motion-reduce:transform-none",
              streaming ? "" : "ml-auto",
            )}
          >
            {copied ? (
              <Check aria-hidden="true" className="size-3.5" />
            ) : (
              <Copy aria-hidden="true" className="size-3.5" />
            )}
          </button>
        ) : null}
      </div>

      <div
        ref={viewportRef}
        role={streaming ? "log" : undefined}
        aria-live={streaming ? "polite" : undefined}
        className="overflow-auto border-t border-border py-2"
        style={{ maxHeight }}
      >
        <pre className="m-0 min-w-max font-mono text-code text-fg">
          <code>
            {lines.map((line, index) => {
              const lineNumber = index + 1;
              return (
                <span
                  key={line.offset}
                  className={cn(
                    "grid min-h-[var(--abrum-leading-code)]",
                    showLineNumbers
                      ? "grid-cols-[2.75rem_minmax(0,1fr)]"
                      : "grid-cols-1",
                    highlighted.has(lineNumber) && "bg-accent-soft",
                  )}
                >
                  {showLineNumbers ? (
                    <span className="select-none pr-3 text-right tabular-nums text-fg-subtle">
                      {lineNumber}
                    </span>
                  ) : null}
                  <AgentCodeLine
                    code={line.content}
                    tokens={tokens?.[index]}
                    className={cn(
                      "pr-4",
                      showLineNumbers ? "pl-1" : "pl-4",
                      wrap ? "whitespace-pre-wrap break-words" : "whitespace-pre",
                    )}
                  />
                </span>
              );
            })}
          </code>
        </pre>
      </div>
    </div>
  );
}
