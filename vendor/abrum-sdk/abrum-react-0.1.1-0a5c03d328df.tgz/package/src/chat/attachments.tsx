import { chatText } from "./chat-text";
import * as React from "react";
import { AttachmentPrimitive, type Attachment as AssistantAttachment, type AttachmentAdapter, type DataMessagePartComponent } from "@assistant-ui/react";
import { Download, File, X } from "lucide-react";
import { Paperclip } from "../brand-icons";
import {
  AttachmentAction,
  Attachment,
  AttachmentActions,
  AttachmentContent,
  AttachmentDescription,
  AttachmentMedia,
  AttachmentTitle,
  AttachmentTrigger,
} from "../ui/attachment";
import {
  CHAT_ATTACHMENT_MAX_FILE_BYTES,
  ABRUM_CHAT_ATTACHMENT_DATA_PART,
  isChatAttachmentRef,
  type ChatAttachmentRef,
  type ChatAttachmentUploader,
} from "./attachment-contract";

export {
  CHAT_ATTACHMENT_MAX_FILE_BYTES,
  ABRUM_CHAT_ATTACHMENT_DATA_PART,
  chatAttachmentRefsFromMessage,
  isChatAttachmentRef,
  type ChatAttachmentRef,
  type ChatAttachmentUploader,
} from "./attachment-contract";

function attachmentId(file: File): string {
  return `${file.name}-${file.size}-${file.lastModified}-${Math.random().toString(36).slice(2, 10)}`;
}

function attachmentType(file: File): "image" | "document" | "file" {
  if (file.type.startsWith("image/")) return "image";
  if (file.type.startsWith("text/") || /\.(?:md|txt|csv|tsv|json|xml|ya?ml|pdf)$/i.test(file.name)) return "document";
  return "file";
}

/**
 * Adapter for assistant-ui's native composer attachment lifecycle. It uploads
 * exactly when the message is submitted, so queued messages retain their own
 * files instead of sharing mutable component state with the next draft.
 */
export function createChatAttachmentAdapter(upload: ChatAttachmentUploader): AttachmentAdapter {
  return {
    accept: "*",
    async add({ file }) {
      if (file.size > CHAT_ATTACHMENT_MAX_FILE_BYTES) {
        throw new Error(`Files must be 25 MB or smaller (${file.name} is too large).`);
      }
      return {
        id: attachmentId(file),
        type: attachmentType(file),
        name: file.name || "attachment",
        contentType: file.type || "application/octet-stream",
        file,
        status: { type: "requires-action", reason: "composer-send" },
      };
    },
    async send(attachment) {
      const reference = await upload(attachment.file);
      return {
        ...attachment,
        status: { type: "complete" },
        content: [{ type: "data", name: ABRUM_CHAT_ATTACHMENT_DATA_PART, data: reference }],
      };
    },
    async remove() {
      // Upload only happens on submit, so removing a draft has no durable side effect.
    },
  };
}

function formatBytes(size: number): string {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${Math.round(size / 1024)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

/** Composer-side card. The AttachmentPrimitive binding supplies name/removal. */
export function ComposerAttachmentCard({ attachment }: { attachment: AssistantAttachment }) {
  const isImage = attachment.type === "image" && Boolean(attachment.file);
  const [previewUrl, setPreviewUrl] = React.useState<string>();

  React.useEffect(() => {
    if (!isImage || !attachment.file) {
      setPreviewUrl(undefined);
      return;
    }
    const url = URL.createObjectURL(attachment.file);
    setPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [attachment.file, isImage]);

  return (
    <Attachment size="xs" className="max-w-full bg-surface-muted text-body">
      <AttachmentMedia variant={previewUrl ? "image" : "icon"}>
        {previewUrl ? <img src={previewUrl} alt="" /> : <File className="size-3.5" />}
      </AttachmentMedia>
      <AttachmentContent><AttachmentTitle><AttachmentPrimitive.Name /></AttachmentTitle></AttachmentContent>
      <AttachmentActions>
        <AttachmentPrimitive.Remove
          className="inline-flex size-5 items-center justify-center rounded hover:bg-surface-hover"
          aria-label={chatText("Remove attachment", "Anhang entfernen", "Retirer la pièce jointe")}
          title={chatText("Remove attachment", "Anhang entfernen", "Retirer la pièce jointe")}
        >
          <X className="size-3" />
        </AttachmentPrimitive.Remove>
      </AttachmentActions>
    </Attachment>
  );
}

export type ChatAttachmentOpen = (attachment: ChatAttachmentRef) => void | Promise<void>;
export type ChatAttachmentUrl = (attachment: ChatAttachmentRef) => string | undefined | Promise<string | undefined>;

const attachmentIconAction = "inline-flex size-8 shrink-0 appearance-none items-center justify-center rounded-md border-0 bg-transparent p-0 text-fg-muted shadow-none outline-none transition-colors hover:bg-transparent hover:text-fg focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-40";

/** Create a transcript renderer with host-owned blob opening and preview behavior. */
export function createChatAttachmentPart(
  onOpen?: ChatAttachmentOpen,
  attachmentUrl?: ChatAttachmentUrl,
): DataMessagePartComponent<ChatAttachmentRef> {
  return function ChatAttachmentPart({ data }) {
    const [downloadState, setDownloadState] = React.useState<"done" | "processing" | "error">("done");
    const [previewFailed, setPreviewFailed] = React.useState(false);
    const [asyncPreview, setAsyncPreview] = React.useState<{ request: Promise<string | undefined>; url?: string }>();
    const preview = React.useRef<HTMLDialogElement>(null);
    const attachment = isChatAttachmentRef(data) ? data : null;
    const attachmentKey = attachment
      ? `${attachment.blobHash}\u0000${attachment.name}\u0000${attachment.mime}\u0000${attachment.size}`
      : "";
    const resolvedUrl = React.useMemo(() => {
      if (!attachment || !attachmentUrl) return undefined;
      try { return attachmentUrl(attachment); } catch { return undefined; }
    }, [attachmentUrl, attachmentKey]);
    React.useEffect(() => {
      if (!resolvedUrl || typeof resolvedUrl === "string") return;
      let active = true;
      resolvedUrl.then((url) => { if (active) setAsyncPreview({ request: resolvedUrl, url }); })
        .catch(() => { if (active) setAsyncPreview({ request: resolvedUrl }); });
      return () => { active = false; };
    }, [resolvedUrl]);
    const download = React.useCallback(async () => {
      if (!onOpen || !attachment || downloadState === "processing") return;
      setDownloadState("processing");
      try {
        await onOpen(attachment);
        setDownloadState("done");
      } catch {
        setDownloadState("error");
      }
    }, [attachment, downloadState, onOpen]);
    if (!attachment) return null;
    const url = typeof resolvedUrl === "string" ? resolvedUrl
      : resolvedUrl && asyncPreview?.request === resolvedUrl ? asyncPreview?.url : undefined;
    const isImage = attachment.mime.startsWith("image/") && Boolean(url);
    const downloadLabel = `${chatText("Download", "Herunterladen", "Télécharger")} ${attachment.name}`;
    // Trusted Station attachment URLs, not model-generated remote image links.
    // The same part is used by the Agent app and the desktop SINA chat.
    if (isImage) {
      return <figure className="mx-0 my-2 w-fit max-w-[min(100%,24rem)] overflow-hidden rounded-xl border border-border bg-surface-muted">
        <button type="button" className="block max-w-full cursor-zoom-in appearance-none overflow-hidden border-0 bg-transparent p-0 outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring" aria-label={`${chatText("Enlarge", "Vergrößern", "Agrandir")} ${attachment.name}`}
          onClick={() => preview.current?.showModal()}>
          <img src={url} alt={attachment.name} loading="lazy" decoding="async"
            onLoad={() => setPreviewFailed(false)} onError={() => setPreviewFailed(true)}
            className="block h-auto max-h-80 w-auto max-w-full object-contain" />
        </button>
        {previewFailed ? <p role="status" className="px-3 py-2 text-ui">{chatText("Image preview unavailable. You can still save the file.", "Bildvorschau nicht verfügbar. Du kannst die Datei trotzdem speichern.", "Aperçu indisponible. Vous pouvez tout de même enregistrer le fichier.")}</p> : null}
        <figcaption className="box-border flex w-0 min-w-full items-center justify-between gap-2 px-3 py-2 text-ui">
          <span className="min-w-0 flex-1 [overflow-wrap:anywhere]">{attachment.name}</span>
          {onOpen ? <button type="button" className={attachmentIconAction} aria-label={downloadLabel} title={downloadLabel}
            disabled={downloadState === "processing"} onClick={() => void download()}><Download className="size-4" /></button>
            : <a className={attachmentIconAction} href={url} download={attachment.name} aria-label={downloadLabel} title={downloadLabel}><Download className="size-4" /></a>}
          {downloadState === "error" ? <span role="status" className="text-danger">{chatText("Download failed — retry", "Download fehlgeschlagen – erneut versuchen", "Échec du téléchargement — réessayer")}</span> : null}
        </figcaption>
        <dialog ref={preview} tabIndex={-1} autoFocus aria-label={attachment.name}
          className="abrum-backdrop-blur-backdrop--16 fixed inset-0 m-auto w-fit max-h-[90dvh] max-w-[90vw] overflow-hidden rounded-xl border border-border bg-surface p-0 text-foreground outline-none backdrop:bg-black/35">
          <form method="dialog" className="box-border flex w-0 min-w-full items-center justify-between gap-3 px-3 py-2 text-ui">
            <span className="min-w-0 flex-1 truncate">{attachment.name}</span>
            <button type="submit" className={attachmentIconAction} aria-label={chatText("Close image preview", "Bildvorschau schließen", "Fermer l’aperçu")}><X className="size-5" /></button>
          </form>
          <img src={url} alt={attachment.name} decoding="async" className="block h-auto max-h-[calc(90dvh-3rem-2px)] w-auto max-w-full object-contain" />
        </dialog>
      </figure>;
    }
    return (
      <Attachment
        size="xs"
        state={downloadState}
        className="my-1 max-w-sm cursor-pointer bg-surface-muted transition-colors hover:bg-surface-hover"
      >
        {url ? (
          <AttachmentTrigger asChild>
            <a
              href={url}
              download={attachment.name}
              aria-label={downloadLabel}
              title={downloadLabel}
            />
          </AttachmentTrigger>
        ) : onOpen ? (
          <AttachmentTrigger
            type="button"
            aria-label={downloadLabel}
            title={downloadLabel}
            disabled={downloadState === "processing"}
            onClick={() => void download()}
          />
        ) : null}
        <AttachmentMedia className="pointer-events-none" variant={isImage ? "image" : "icon"}>
          {isImage ? <img src={url} alt="" /> : <File className="size-3.5" />}
        </AttachmentMedia>
        <AttachmentContent className="pointer-events-none">
          <AttachmentTitle>{attachment.name}</AttachmentTitle>
          <AttachmentDescription>
            {downloadState === "error"
              ? chatText("Download failed - click to retry", "Download fehlgeschlagen – zum Wiederholen klicken", "Échec du téléchargement - cliquez pour réessayer")
              : `${attachment.mime || "file"} - ${formatBytes(attachment.size)}`}
          </AttachmentDescription>
        </AttachmentContent>
        {onOpen ? (
          <AttachmentActions>
            <AttachmentAction
              type="button"
              className={attachmentIconAction}
              aria-label={downloadLabel}
              title={downloadLabel}
              disabled={downloadState === "processing"}
              onClick={() => void download()}
            >
              <Download className="size-3.5" />
            </AttachmentAction>
          </AttachmentActions>
        ) : null}
      </Attachment>
    );
  };
}

/** Non-interactive fallback for hosts without blob-open authority. */
export const ChatAttachmentPart = createChatAttachmentPart();

export const ChatAttachmentIcon = Paperclip;
