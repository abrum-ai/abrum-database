export interface PersistedRunComposerControl {
  getText: () => string;
  cancel: () => void | Promise<void>;
  setText: (text: string) => void;
}

/**
 * assistant-ui restores the preceding user message when it cancels an empty
 * optimistic assistant head. ABRUM has already persisted that user turn, so
 * restoring it as a draft invites an accidental duplicate send. Preserve the
 * current unsent draft across that synchronous rollback, including an empty
 * input. Restore before awaiting the host so later edits are never overwritten.
 */
export async function cancelPersistedAgentRun(
  composer: PersistedRunComposerControl,
): Promise<void> {
  const draft = composer.getText();
  let pending: void | Promise<void>;
  try {
    pending = composer.cancel();
  } finally {
    composer.setText(draft);
  }
  await pending;
}
