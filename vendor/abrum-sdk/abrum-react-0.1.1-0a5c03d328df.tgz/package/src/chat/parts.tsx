import { createContext, useContext, type ComponentType, type ReactNode } from "react";
import type { DataMessagePartProps, ToolCallMessagePartProps } from "@assistant-ui/react";
import { Check, ExternalLink, Globe2, ListRestart, Loader2, MessageSquare, SquareTerminal, TriangleAlert, Wrench } from "lucide-react";
import { BrainCircuit, ChevronRight } from "../brand-icons";
import { cn } from "../ui/cn";
import { Marker, MarkerContent, MarkerIcon } from "../ui/marker";
import { Shimmer } from "../ui/shimmer";
import { MarkdownText, openExternalUrl } from "./markdown";
import type { AgentActivityData, AgentSourceReference, SourceSummaryData, ToolActivityData, ToolActivityItem } from "./agent-message";
import { toolCommand } from "./tool-command";
import { chatErrorReason, chatText, isChatErrorText } from "./chat-text";
import { CustomerToolResults } from "./customer-tool-results";

/*
 * Message-part renderers shared by every abrum chat surface. These plug straight
 * into assistant-ui's <MessagePrimitive.Parts components={...}> slot, so the
 * desktop sidebar and the web agent render text, reasoning and tool calls
 * identically. Prop shapes are kept loose on purpose — assistant-ui passes parts
 * structurally and the existing renderer compiled against exactly these.
 */

/** Streamed/running "thinking" status, shimmering until the first token. */
export function ThinkingIndicator({ label = chatText("Thinking…", "Denkt nach…", "Réflexion…") }: { label?: string }) {
  return (
    <Shimmer data-slot="thinking-indicator" className="text-sm motion-safe:animate-chat-fade" role="status" aria-label={label}>
      {label}
    </Shimmer>
  );
}

export function UserText({ text }: { text: string }) {
  return <span className="whitespace-pre-wrap [overflow-wrap:anywhere]">{text || "…"}</span>;
}

export function AssistantText({ text, status }: { text: string; status?: { type: string } }) {
  if (!text) {
    if (status?.type === "running") return <ThinkingIndicator />;
    return <span className="text-sm text-fg-subtle">{chatText("No answer — please try again.", "Keine Antwort – bitte erneut versuchen.", "Aucune réponse — veuillez réessayer.")}</span>;
  }
  if (isChatErrorText(text)) return <AssistantErrorText text={text} />;
  // The answer fades in where "Thinking…" was, instead of swapping hard.
  return <div className="motion-safe:animate-chat-fade"><MarkdownText>{text}</MarkdownText></div>;
}

/** Host actions for a failed message (retry, report). The failure card renders
 * them inside itself so the message and its way out read as one unit. */
export const ChatFailureActionsContext = createContext<ReactNode>(null);

export function ChatFailureActions({ children }: { children: ReactNode }) {
  if (!children) return null;
  return <div data-slot="failure-actions" className="mt-2.5">{children}</div>;
}

/** A reported failure reads as one card: what happened, in plain words. The
 * raw provider text (codes included) stays in the message for copy and support
 * reports. Host actions (retry, report) sit inside the card. */
export function AssistantErrorText({ text }: { text: string }) {
  const reason = chatErrorReason(text);
  const actions = useContext(ChatFailureActionsContext);
  return (
    <div data-slot="assistant-error" role="status" className="motion-safe:animate-chat-rise my-1 flex items-start gap-2.5 rounded-lg bg-amber-500/10 px-3 py-2.5 text-ui text-fg-muted">
      <TriangleAlert className="mt-0.5 size-4 shrink-0 text-amber-600 dark:text-amber-400" aria-hidden="true" />
      <div className="min-w-0 flex-1">
        <p className="m-0 text-body text-fg">{chatText("That didn’t work", "Das hat nicht geklappt", "Cela n’a pas fonctionné")}</p>
        {reason ? <p className="m-0 mt-0.5 text-body [overflow-wrap:anywhere]">{reason}</p> : null}
        <ChatFailureActions>{actions}</ChatFailureActions>
      </div>
    </div>
  );
}

const REASONING_MARKDOWN_CLASS_NAME =
  "text-sm [&_a[data-slot=chat-link]]:text-sm [&_h1]:text-sm [&_h2]:text-sm [&_h3]:text-sm";

export function ReasoningPart({ text }: { text: string }) {
  if (!text.trim()) return null;
  return (
    <ChatInlineDisclosure
      dataSlot="reasoning"
      label={chatText("Thoughts", "Gedanken", "Réflexion")}
      summaryClassName="text-sm text-fg-subtle hover:text-fg-muted"
      contentClassName="ml-1.5 border-l-2 border-border pl-2 text-sm text-fg-muted [overflow-wrap:anywhere]"
    >
      <MarkdownText className={REASONING_MARKDOWN_CLASS_NAME}>{text}</MarkdownText>
    </ChatInlineDisclosure>
  );
}

/** A quiet, transcript-level lifecycle row for agent work that is neither
 * assistant prose nor a user-invoked tool. The same renderer is installed by
 * ChatThread for every abrum chat surface. */
export function AgentActivityPart({ data }: DataMessagePartProps<AgentActivityData>) {
  if (!data || data.kind !== "context_compaction") return null;
  const running = data.status === "running";
  const failed = data.status === "failed";
  const label = failed
    ? chatText("Conversation summary incomplete", "Zusammenfassung unvollständig", "Résumé incomplet")
    : running
      ? chatText("Summarizing earlier messages…", "Frühere Nachrichten werden zusammengefasst…", "Résumé des messages précédents…")
      : chatText("Earlier messages summarized", "Frühere Nachrichten zusammengefasst", "Messages précédents résumés");
  return (
    <div
      data-slot="agent-activity"
      className={cn("my-2 flex w-full items-center gap-2 text-meta text-fg-subtle", failed && "text-danger")}
      role="status"
      aria-label={label}
    >
      <span className="h-px min-w-4 flex-1 bg-border" aria-hidden="true" />
      <span className="flex shrink-0 items-center gap-1.5" title={label}>
        {running ? (
          <Loader2 className="size-3.5 animate-spin motion-reduce:animate-none" aria-hidden="true" />
        ) : (
          <ListRestart className="size-3.5" aria-hidden="true" />
        )}
        <span>{label}</span>
      </span>
      <span className="h-px min-w-4 flex-1 bg-border" aria-hidden="true" />
    </div>
  );
}

function sourceHostname(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

function isExcludedSourceUrl(url: string): boolean {
  try {
    const hostname = new URL(url).hostname.toLowerCase().replace(/^www\./, "");
    return hostname === "json-schema.org" || hostname.endsWith(".json-schema.org");
  } catch {
    return false;
  }
}

interface ChatInlineDisclosureProps {
  dataSlot: string;
  label: ReactNode;
  leading?: ReactNode;
  detail?: ReactNode;
  ariaLabel?: string;
  role?: "status";
  className?: string;
  summaryClassName?: string;
  leadingClassName?: string;
  contentClassName?: string;
  children: ReactNode;
}

/** The single disclosure treatment for compact, expandable transcript rows.
 * Keeping the trigger here prevents Sources and tool activity from drifting
 * between the full Agent app and the desktop sidebar. */
export function ChatInlineDisclosure({
  dataSlot,
  label,
  leading,
  detail,
  ariaLabel,
  role,
  className,
  summaryClassName,
  leadingClassName,
  contentClassName,
  children,
}: ChatInlineDisclosureProps) {
  return (
    <details data-slot={dataSlot} className={cn("group/disclosure my-1 w-full", className)}>
      <summary
        className={cn(
          "group/summary flex w-full max-w-full cursor-pointer list-none items-center gap-1.5 rounded-md px-1.5 py-1 text-ui text-fg-muted marker:hidden transition-colors hover:bg-surface-muted hover:text-fg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
          summaryClassName,
        )}
        aria-label={ariaLabel}
        role={role}
      >
        {leading ? (
          <span className={cn("flex size-4 shrink-0 items-center justify-center", leadingClassName)}>{leading}</span>
        ) : null}
        <span className="min-w-0 truncate">{label}</span>
        {detail ? <span className="min-w-0 truncate text-meta text-fg-subtle">{detail}</span> : null}
        <ChevronRight className="ml-auto size-3 shrink-0 text-fg-subtle opacity-0 transition-[transform,opacity] duration-200 group-hover/summary:opacity-100 group-focus-visible/summary:opacity-100 group-open/disclosure:rotate-90 motion-reduce:transition-none" aria-hidden="true" />
      </summary>
      <div className={cn("mt-1", contentClassName)}>{children}</div>
    </details>
  );
}

export function SourceSummaryPart({ data }: DataMessagePartProps<SourceSummaryData>) {
  const sourceList: AgentSourceReference[] = data?.kind === "source_summary" ? data.sources : [];
  const sources = sourceList.filter((source: AgentSourceReference) => !isExcludedSourceUrl(source.url));
  if (sources.length === 0) return null;
  const label = sources.length === 1
    ? chatText("1 source", "1 Quelle", "1 source")
    : chatText(`${sources.length} sources`, `${sources.length} Quellen`, `${sources.length} sources`);
  return (
    <ChatInlineDisclosure
      dataSlot="source-summary"
      label={label}
      leading={<Globe2 className="size-3.5" aria-hidden="true" />}
      contentClassName="pl-1.5"
    >
      <ul className="m-0 grid list-none gap-1 p-0" aria-label={chatText("Sources used in this answer", "Quellen dieser Antwort", "Sources de cette réponse")}>
        {sources.map((source: AgentSourceReference) => {
          const hostname = sourceHostname(source.url);
          const title = source.title?.trim() || hostname;
          const showHostname = title.toLocaleLowerCase() !== hostname.toLocaleLowerCase();
          return (
            <li key={source.url}>
              <a
                href={source.url}
                title={source.url}
                onClick={(event) => {
                  event.preventDefault();
                  event.stopPropagation();
                  openExternalUrl(source.url);
                }}
                className="flex min-w-0 items-center gap-2 rounded-lg border border-border bg-surface px-2.5 py-1.5 text-ui no-underline! transition-colors hover:bg-surface-muted hover:no-underline! focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <span className="flex min-w-0 flex-1 items-baseline gap-1.5">
                  <span className="min-w-0 truncate text-fg">{title}</span>
                  {showHostname ? <span className="min-w-0 truncate text-meta text-fg-subtle">{hostname}</span> : null}
                </span>
                <ExternalLink className="size-3.5 shrink-0 text-fg-subtle" aria-hidden="true" />
              </a>
            </li>
          );
        })}
      </ul>
    </ChatInlineDisclosure>
  );
}

/** Has the tool produced a usable result string for the expandable body? */
function resultText(result: unknown): string | null {
  if (result == null) return null;
  if (typeof result === "string") return result === "done" ? null : result;
  try {
    return JSON.stringify(result, null, 2);
  } catch {
    return String(result);
  }
}

function argsText(props: ToolCallMessagePartProps): string | null {
  const raw = (props as { argsText?: string }).argsText;
  if (raw && raw.trim() && raw.trim() !== "{}") return raw;
  const args = (props as { args?: unknown }).args;
  if (args && typeof args === "object" && Object.keys(args as object).length > 0) {
    try {
      return JSON.stringify(args, null, 2);
    } catch {
      return null;
    }
  }
  return null;
}

/**
 * Tool call — a compact status marker (spinner while running, check when done,
 * alert on failure) that expands to show args/result when present. Renders as a
 * native <details> for keyboard a11y, or a plain row when there's nothing to
 * expand.
 */
export function ToolCallPart(props: ToolCallMessagePartProps & { displayName?: string }) {
  const { toolName } = props;
  const visibleName = props.displayName || toolName;
  const status = (props as { status?: { type?: string } }).status;
  const result = (props as { result?: unknown }).result;
  const failed = status?.type === "incomplete" || (props as { isError?: boolean }).isError === true;
  const running = !failed && result === undefined && status?.type !== "complete";

  const body = resultText(result);
  const args = argsText(props);
  const expandable = Boolean(body || args);
  const command = toolCommand(toolName, (props as { args?: unknown }).args);

  const head = (
    <Marker
      variant="default"
      className="gap-1.5 py-0.5"
      title={command ?? (props.displayName ? toolName : undefined)}
    >
      <MarkerIcon className="text-fg-muted">
        {command ? (
          <SquareTerminal />
        ) : failed ? (
          <TriangleAlert />
        ) : running ? (
          <Loader2 className="animate-spin" />
        ) : (
          <Check />
        )}
      </MarkerIcon>
      {running ? (
        <Shimmer className={command ? "font-mono text-code" : "text-ui"}>{command ?? visibleName}</Shimmer>
      ) : (
        <MarkerContent className={command ? "font-mono text-code" : props.displayName ? undefined : "font-mono"}>
          {command ?? visibleName}
        </MarkerContent>
      )}
      {command ? null : <Wrench className="size-3 text-fg-subtle" aria-hidden />}
    </Marker>
  );

  if (!expandable) {
    return <div data-slot="tool-call" className="my-0.5">{head}</div>;
  }

  return (
    <details data-slot="tool-call" className="group/tool my-0.5 w-full">
      <summary className="flex cursor-pointer list-none items-center gap-1 marker:hidden">
        <ChevronRight className="size-3 shrink-0 text-fg-subtle transition-transform group-open/tool:rotate-90" />
        {head}
      </summary>
      <div className="mt-1 flex flex-col gap-1 border-l-2 border-border pl-3 text-xs">
        {args ? (
          <pre className="overflow-x-auto rounded bg-surface-muted p-1.5 text-meta leading-snug text-fg-muted">{args}</pre>
        ) : null}
        {body ? (
          <pre className="overflow-x-auto rounded bg-surface-muted p-1.5 text-meta leading-snug text-fg">{body}</pre>
        ) : null}
      </div>
    </details>
  );
}

function ToolActivityStatus({ status }: { status: ToolActivityData["status"] }) {
  if (status === "running") {
    return <Loader2 className="size-3.5 animate-spin motion-reduce:animate-none" aria-hidden="true" />;
  }
  if (status === "failed" || status === "partial") {
    return <TriangleAlert className="size-3.5" aria-hidden="true" />;
  }
  return <Check className="size-3.5" aria-hidden="true" />;
}

export interface ToolPresenterProps {
  tool: ToolActivityItem;
  displayName: string;
  activityStatus: ToolActivityData["status"];
}

export type ToolPresenterComponent = ComponentType<ToolPresenterProps>;

function DefaultToolActivityItem({
  tool,
  displayName,
  activityStatus,
}: ToolPresenterProps) {
  return (
    <ToolCallPart
      {...({
        toolCallId: tool.toolCallId,
        toolName: tool.toolName,
        args: tool.args,
        result: tool.result,
        isError: tool.isError,
        status: tool.isError
          ? { type: "incomplete", reason: "error" }
          : tool.result === undefined && activityStatus === "running"
            ? { type: "running" }
            : { type: "complete", reason: "unknown" },
      } as ToolCallMessagePartProps)}
      displayName={displayName}
    />
  );
}

function singleLine(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

function activityToolLabel(tool: ToolActivityItem, formatToolName: (toolName: string) => string): string {
  const command = toolCommand(tool.toolName, tool.args);
  if (command) return singleLine(command);
  return formatToolName(tool.toolName);
}

/** One compact Agent-work row. The newest reasoning/tool step is visible at
 * rest; expanding reveals the complete chronological activity in a bounded
 * scrollbox. */
export function ToolActivityPart({
  data,
  formatToolName = (name) => name,
  presenters,
  customerProgressOnly = false,
}: DataMessagePartProps<ToolActivityData> & {
  formatToolName?: (toolName: string) => string;
  presenters?: Record<string, ToolPresenterComponent | undefined>;
  /** Preserve interactive app results, not a second technical status feed. */
  customerProgressOnly?: boolean;
}) {
  const activity = data as ToolActivityData | undefined;
  if (!activity || activity.kind !== "tool_activity") return null;
  if (customerProgressOnly) return <CustomerToolResults activity={activity} presenters={presenters} formatToolName={formatToolName} />;
  const steps = activity.steps?.length
    ? activity.steps
    : activity.tools.map((tool) => ({ kind: "tool" as const, tool }));
  if (steps.length === 0) return null;
  const running = activity.status === "running";
  const failedCount = activity.tools.filter((tool) => tool.isError).length;
  // Keep punctuation-only keepalives in history without turning the summary
  // into the isolated dots older native runs emitted between model rounds.
  const latest = steps.findLast((step) => step.kind === "tool" || /[\p{L}\p{N}]/u.test(step.text)) ?? steps.at(-1)!;
  const latestCommand = latest.kind === "tool"
    ? toolCommand(latest.tool.toolName, latest.tool.args)
    : null;
  const latestLabel = latest.kind !== "tool"
    ? singleLine(latest.text)
    : activityToolLabel(latest.tool, formatToolName);
  // While running, the newest step is the status. Afterwards the row is a
  // quiet record of the work: "4 steps", with the steps one click away.
  const toolCount = activity.tools.length;
  const doneLabel = toolCount === 1
    ? chatText("1 step", "1 Schritt", "1 étape")
    : chatText(`${toolCount} steps`, `${toolCount} Schritte`, `${toolCount} étapes`);
  const label = running || toolCount === 0 ? latestLabel : doneLabel;
  const statusLabel = activity.status === "failed"
    ? chatText("failed", "fehlgeschlagen", "échec")
    : activity.status === "partial"
      ? chatText(`completed with ${failedCount} failed calls`, `abgeschlossen, ${failedCount} Schritte mit Problem`, `terminé avec ${failedCount} échecs`)
      : running
        ? chatText("running", "läuft", "en cours")
        : chatText("completed", "abgeschlossen", "terminé");

  return (
    <ChatInlineDisclosure
      dataSlot="tool-activity"
      label={running ? <Shimmer>{label}</Shimmer> : label}
      leading={latestCommand
        ? <SquareTerminal className="size-3.5" aria-hidden="true" />
        : <ToolActivityStatus status={activity.status} />}
      ariaLabel={`${label}, ${statusLabel}`}
      role="status"
      detail={running || toolCount === 0 ? undefined : latestLabel}
      className={cn("rounded-lg bg-surface/60 shadow-[0_0_0_0.5px_var(--color-border)]", running && "motion-safe:animate-chat-fade")}
      leadingClassName="text-fg-muted"
      summaryClassName={cn("w-full text-fg-muted", "px-2.5 py-1.5", latest.kind === "reasoning" && "text-sm")}
      contentClassName="mx-2.5 mb-2"
    >
      <div
        className="max-h-64 overflow-y-auto overscroll-contain rounded-sm border-l border-border pl-3 pr-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        role="region"
        aria-label={chatText("Agent activity history", "Verlauf der Arbeitsschritte", "Historique des étapes")}
        tabIndex={0}
      >
        {steps.map((step, index) => {
          if (step.kind !== "tool") {
            return (
              <div
                key={`${step.kind}-${index}`}
                data-slot={step.kind === "reasoning" ? "activity-thinking" : "activity-commentary"}
                className="my-0.5 flex min-w-0 items-start gap-1.5 py-0.5 text-sm text-fg-muted"
              >
                {step.kind === "reasoning"
                  ? <BrainCircuit className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
                  : <MessageSquare className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />}
                <MarkdownText
                  className={cn("min-w-0 flex-1", REASONING_MARKDOWN_CLASS_NAME)}
                >
                  {step.text}
                </MarkdownText>
              </div>
            );
          }
          const tool = step.tool;
          const Presenter = presenters?.[tool.toolName];
          return Presenter ? (
            <div key={tool.toolCallId} data-slot="tool-presenter">
              <Presenter
                tool={tool}
                displayName={formatToolName(tool.toolName)}
                activityStatus={activity.status}
              />
            </div>
          ) : (
            <DefaultToolActivityItem
              key={tool.toolCallId}
              tool={tool}
              displayName={formatToolName(tool.toolName)}
              activityStatus={activity.status}
            />
          );
        })}
      </div>
    </ChatInlineDisclosure>
  );
}
