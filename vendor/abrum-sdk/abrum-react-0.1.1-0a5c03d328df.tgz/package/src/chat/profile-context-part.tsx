import { useState } from 'react';
import type { DataMessagePartProps } from '@assistant-ui/react';
import { ChatInlineDisclosure } from './parts';
import type { ProfileContext } from './profile-context.mjs';

export function ProfileContextPart({ data, locale = 'en' }: DataMessagePartProps<ProfileContext> & {locale?: string}) {
  const [copied, setCopied] = useState(false);
  const [copyFailed, setCopyFailed] = useState(false);
  if (!data?.plan) return null;
  const de = locale.startsWith('de'), fr = locale.startsWith('fr');
  const l = (en: string, german: string, french: string) => de ? german : fr ? french : en;
  const labels: Record<string,string> = {use:l('Use','Nutzung','Utilisation'),role:l('Role','Rolle','Rôle'),priorities:l('Priorities','Schwerpunkte','Priorités'),sources:l('Declared sources','Angegebene Quellen','Sources indiquées'),website:'Website'};
  return <ChatInlineDisclosure dataSlot="profile-context" label={l('Profile context used','Verwendeter Profilkontext','Contexte de profil utilisé')}>
    <div className="space-y-2 text-ui text-fg-muted">
      <p>{l('From your saved onboarding profile. Sources are declarations; suggestions are not active automations.','Aus deinem gespeicherten Onboarding-Profil. Quellen sind Angaben; Vorschläge sind keine aktiven Automationen.','Issu de votre profil enregistré. Les sources sont déclaratives ; les suggestions ne sont pas des automatisations actives.')}</p>
      <dl>{Object.entries(data.plan.answers || {}).filter(([key,value]) => labels[key] && Array.isArray(value)).map(([key,value]) => <div key={key}><dt className="text-fg">{labels[key]}</dt><dd className="whitespace-pre-wrap [overflow-wrap:anywhere]">{(value as string[]).filter(v=>typeof v==='string').join(', ')}</dd></div>)}</dl>
      <p>{l('Profile version','Profilversion','Version du profil')}: {data.plan.version}{data.legacy ? l(' · Historical context',' · Historischer Kontext',' · Contexte historique') : ''}</p>
      <ChatInlineDisclosure dataSlot="profile-context-technical" label={l('Technical details','Technische Details','Détails techniques')}>
        <button type="button" className="text-ui underline" onClick={async () => { try { await navigator.clipboard.writeText(JSON.stringify(data,null,2)); setCopied(true); setCopyFailed(false); } catch { setCopyFailed(true); } }}>{copied ? l('Copied','Kopiert','Copié') : l('Copy context','Kontext kopieren','Copier le contexte')}</button>
        {copyFailed && <p role="alert">{l('Could not copy. You can select the text below.','Kopieren fehlgeschlagen. Du kannst den Text unten markieren.','Copie impossible. Vous pouvez sélectionner le texte ci-dessous.')}</p>}
        <pre className="max-h-80 overflow-auto whitespace-pre-wrap text-meta [overflow-wrap:anywhere]">{JSON.stringify(data,null,2)}</pre>
      </ChatInlineDisclosure>
    </div>
  </ChatInlineDisclosure>;
}
