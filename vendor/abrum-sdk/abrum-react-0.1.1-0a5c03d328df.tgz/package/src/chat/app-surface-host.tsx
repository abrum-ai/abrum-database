import { createContext, useContext, type ComponentType, type ReactNode } from "react";
import type { DataMessagePartProps } from "@assistant-ui/react";
import type { AbrumAppSurfaceReference } from "@abrum/web-runtime";
import type { AppResult } from "./app-result";

export type AbrumAppSurfacePartComponent = ComponentType<DataMessagePartProps<AbrumAppSurfaceReference>>;

const AbrumAppSurfacePartContext = createContext<AbrumAppSurfacePartComponent | null>(null);
type ResultPartComponent = ComponentType<DataMessagePartProps<AppResult>>;
const ResultPartContext = createContext<ResultPartComponent | null>(null);

export function AppResultPart(props: DataMessagePartProps<AppResult>) {
  const Host = useContext(ResultPartContext);
  return Host ? <Host {...props} /> : <section aria-label="Ergebnis">
    <p>{props.data.label}</p><p>{props.data.title}</p>
    <p>Öffnen ist in diesem Host nicht verfügbar.</p>
  </section>;
}

/** Lets a privileged shell supply its authority-owning app-surface renderer to
 * a chat mounted inside that shell. App code receives only the React component;
 * authenticated URLs stay inside the host implementation. */
export function AbrumAppSurfacePartProvider({
  component,
  resultComponent,
  children,
}: {
  component: AbrumAppSurfacePartComponent;
  resultComponent?: ResultPartComponent;
  children: ReactNode;
}) {
  return (
    <AbrumAppSurfacePartContext.Provider value={component}>
      <ResultPartContext.Provider value={resultComponent ?? null}>{children}</ResultPartContext.Provider>
    </AbrumAppSurfacePartContext.Provider>
  );
}

export function useAbrumAppSurfacePart(): AbrumAppSurfacePartComponent | null {
  return useContext(AbrumAppSurfacePartContext);
}
