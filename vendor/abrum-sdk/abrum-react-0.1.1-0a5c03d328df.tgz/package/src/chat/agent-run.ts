export type AgentRunState =
  | "requested"
  | "queued"
  | "running"
  | "completed"
  | "failed"
  | "cancelled"
  | string;

// Optional fields mirror generated twin records: absent OR explicit null, so
// every optional slot is `| null` (schema `.optional()` → `?: T | null`).
export interface AgentRunRequestLike {
  orderId: string;
  runId?: string | null;
  threadLineageCid?: string | null;
  status?: string | null;
  createdAtMs?: unknown;
  updatedAtMs?: unknown;
}

export interface AgentRunAttemptLike {
  runId: string;
  workOrderId?: string | null;
  attemptId?: string | null;
  threadLineageCid?: string | null;
  status?: string | null;
  failureClass?: string | null;
  createdAtMs?: unknown;
  updatedAtMs?: unknown;
}

export interface AgentRunView<
  Request extends AgentRunRequestLike = AgentRunRequestLike,
  Attempt extends AgentRunAttemptLike = AgentRunAttemptLike,
> {
  /** Stable public identity. New writers use the same value as orderId. */
  runId: string;
  threadId: string;
  state: AgentRunState;
  retryable: boolean;
  request: Request | null;
  /** Latest leased execution attempt; Station-only lease fields stay here. */
  attempt: Attempt | null;
  attemptId: string | null;
  createdAtMs: unknown;
  updatedAtMs: unknown;
}

function millis(value: unknown): number {
  if (value instanceof Date) return value.getTime();
  if (typeof value === "number") return value;
  if (typeof value !== "string" || !value) return 0;
  const numeric = Number(value);
  if (Number.isFinite(numeric)) return numeric;
  const parsed = new Date(value).getTime();
  return Number.isFinite(parsed) ? parsed : 0;
}

/**
 * Project immutable run requests and leased attempts into the single Run model
 * consumed by product UI. Legacy rows with distinct orderId/runId continue to
 * join through workOrderId; no historical Twin rewrite is required.
 */
export function projectAgentRuns<
  Request extends AgentRunRequestLike,
  Attempt extends AgentRunAttemptLike,
>(requests: readonly Request[], attempts: readonly Attempt[]): AgentRunView<Request, Attempt>[] {
  const requestById = new Map<string, Request>();
  for (const request of requests) {
    requestById.set(request.orderId, request);
    if (request.runId) requestById.set(request.runId, request);
  }

  const latestAttemptByRun = new Map<string, Attempt>();
  for (const attempt of attempts) {
    const publicRunId = attempt.workOrderId || attempt.runId;
    const current = latestAttemptByRun.get(publicRunId);
    if (!current || millis(attempt.updatedAtMs) >= millis(current.updatedAtMs)) {
      latestAttemptByRun.set(publicRunId, attempt);
    }
  }

  const publicIds = new Set<string>();
  for (const request of requests) publicIds.add(request.orderId);
  for (const attempt of attempts) publicIds.add(attempt.workOrderId || attempt.runId);

  return [...publicIds]
    .map((runId): AgentRunView<Request, Attempt> => {
      const request = requestById.get(runId) ?? null;
      const attempt = latestAttemptByRun.get(runId) ?? null;
      const state = attempt?.status || request?.status || "requested";
      const threadId =
        attempt?.threadLineageCid || request?.threadLineageCid || runId;
      return {
        runId,
        threadId,
        state,
        // Eligibility for a user-initiated retry, not an automatic retry policy.
        retryable: attempt?.failureClass === "transient" || attempt?.failureClass === "rate_limited",
        request,
        attempt,
        attemptId: attempt?.attemptId || null,
        createdAtMs: request?.createdAtMs ?? attempt?.createdAtMs ?? 0,
        updatedAtMs: attempt?.updatedAtMs ?? request?.updatedAtMs ?? 0,
      };
    })
    .sort((left, right) => millis(right.updatedAtMs) - millis(left.updatedAtMs));
}
