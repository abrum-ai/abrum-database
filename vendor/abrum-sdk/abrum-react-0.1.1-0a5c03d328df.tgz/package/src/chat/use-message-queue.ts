import * as React from "react";
import {
  createMessageQueue,
  type AppendMessage,
  type ExternalThreadQueueAdapter,
  type QueueItemState,
} from "@assistant-ui/react";
import {
  createDurableMessageQueueAdapter,
  createDurableQueueControls,
  type DurableMessageQueueHandlers,
  type ChatDeliveryMode,
} from "./durable-message-queue";
import {
  DURABLE_QUEUE_REVEAL_DELAY_MS,
  projectDurableQueueVisibility,
  sameQueueIds,
} from "./durable-queue-visibility";

export { createDurableMessageQueueAdapter } from "./durable-message-queue";

export interface UseMessageQueueOptions {
  /** Is the thread currently executing a run? */
  busy: boolean;
  /** A stable conversation id. Changing it starts with an empty queue. */
  threadKey: string;
  run: (message: AppendMessage, options: { steer: boolean }) => void;
  cancel?: () => void;
}

/**
 * React binding for assistant-ui's external message queue. Normal sends wait
 * behind the active run; steering cancels the active run before dispatching the
 * selected queued message. The adapter is shared by every abrum chat surface.
 */
export function useMessageQueue({
  busy,
  threadKey,
  run,
  cancel,
}: UseMessageQueueOptions): ExternalThreadQueueAdapter {
  const driverRef = React.useRef({ run, cancel });
  driverRef.current = { run, cancel };

  const controller = React.useMemo(
    () =>
      createMessageQueue({
        run: (message, options) => driverRef.current.run(message, options),
        cancel: () => driverRef.current.cancel?.(),
      }),
    [threadKey],
  );

  React.useSyncExternalStore(
    controller.subscribe,
    () => controller.adapter.items,
    () => controller.adapter.items,
  );

  const wasBusy = React.useRef(false);
  React.useEffect(() => {
    if (busy && !wasBusy.current) controller.notifyBusy();
    if (!busy && wasBusy.current) controller.notifyIdle();
    wasBusy.current = busy;
  }, [busy, controller]);

  React.useEffect(() => {
    wasBusy.current = false;
    if (busy) {
      controller.notifyBusy();
      wasBusy.current = true;
    }
  }, [controller]);

  return controller.adapter;
}

export interface UseDurableMessageQueueOptions extends DurableMessageQueueHandlers {
  /** Steering is the product default; queue support stays an internal opt-in. */
  mode?: ChatDeliveryMode;
  /** Pending items projected from Station-owned agent_process twins. */
  items: readonly QueueItemState[];
  /**
   * Avoid exposing the Station's immediate queued -> running claim transition
   * as a user-manageable queue item. Persisting items still appear after this
   * short grace period.
   */
  revealDelayMs?: number;
}

/**
 * Station-backed queue adapter. Unlike `useMessageQueue`, this never owns the
 * queue in React memory: every composer submit is persisted immediately and
 * `items` is only a projection of durable agent_process state. A renderer
 * reload therefore cannot lose pending messages or dispatch two turns against
 * the same thread.
 */
export function useDurableMessageQueue({
  items,
  enqueue,
  steer,
  remove,
  mode = "steer",
  revealDelayMs = DURABLE_QUEUE_REVEAL_DELAY_MS,
}: UseDurableMessageQueueOptions): ExternalThreadQueueAdapter {
  const handlersRef = React.useRef({ enqueue, steer, remove });
  handlersRef.current = { enqueue, steer, remove };
  const itemsRef = React.useRef(items);
  itemsRef.current = items;
  const [controls] = React.useState(createDurableQueueControls);
  const controlRevision = React.useSyncExternalStore(controls.subscribe, controls.getSnapshot, controls.getSnapshot);
  React.useEffect(() => controls.reconcile(items), [controls, items, controlRevision]);
  const firstSeenAtRef = React.useRef<ReadonlyMap<string, number>>(new Map());
  const [visibleIds, setVisibleIds] = React.useState<ReadonlySet<string>>(
    () => new Set(),
  );
  const itemIdsKey = JSON.stringify(items.map((item) => item.id));

  React.useEffect(() => {
    if (mode !== "queue") return;
    let timer: ReturnType<typeof setTimeout> | undefined;

    const synchronize = () => {
      const projection = projectDurableQueueVisibility(
        itemsRef.current,
        firstSeenAtRef.current,
        Date.now(),
        revealDelayMs,
      );
      firstSeenAtRef.current = projection.firstSeenAt;
      setVisibleIds((current) =>
        sameQueueIds(current, projection.visibleIds)
          ? current
          : projection.visibleIds,
      );
      if (projection.nextRevealInMs !== null) {
        timer = setTimeout(synchronize, projection.nextRevealInMs);
      }
    };

    synchronize();
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [itemIdsKey, revealDelayMs, mode]);

  const visibleItems = React.useMemo(
    () => items.filter((item) => visibleIds.has(item.id) && !controls.isHidden(item.id)),
    [items, visibleIds, controls, controlRevision],
  );

  return React.useMemo(
    () =>
      createDurableMessageQueueAdapter(visibleItems, {
        enqueue: (message, options) =>
          handlersRef.current.enqueue(message, options),
        steer: (queueItemId) => controls.run(queueItemId, () => handlersRef.current.steer(queueItemId)),
        remove: (queueItemId) => controls.run(queueItemId, () => handlersRef.current.remove(queueItemId)),
      }, mode),
    [visibleItems, controls, mode],
  );
}
