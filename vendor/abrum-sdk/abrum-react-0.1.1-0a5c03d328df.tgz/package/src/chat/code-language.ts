import type { BundledLanguage } from "shiki";

export const AGENT_HIGHLIGHT_LANGUAGES = [
  "bash",
  "css",
  "diff",
  "html",
  "javascript",
  "json",
  "jsonc",
  "markdown",
  "python",
  "rust",
  "sql",
  "tsx",
  "typescript",
  "yaml",
] as const satisfies readonly BundledLanguage[];

export const AGENT_CODE_LANGUAGES = ["text", ...AGENT_HIGHLIGHT_LANGUAGES] as const;

export type AgentCodeLanguage = (typeof AGENT_CODE_LANGUAGES)[number];
export type AgentHighlightLanguage = (typeof AGENT_HIGHLIGHT_LANGUAGES)[number];

const LANGUAGE_ALIASES: Record<string, AgentCodeLanguage> = {
  "": "text",
  cjs: "javascript",
  console: "bash",
  htm: "html",
  js: "javascript",
  jsx: "tsx",
  md: "markdown",
  mjs: "javascript",
  plaintext: "text",
  py: "python",
  rs: "rust",
  scss: "css",
  sh: "bash",
  shell: "bash",
  ts: "typescript",
  txt: "text",
  yml: "yaml",
  zsh: "bash",
};

const AGENT_CODE_LANGUAGE_SET = new Set<string>(AGENT_CODE_LANGUAGES);

export function normalizeAgentCodeLanguage(language?: string): AgentCodeLanguage {
  const normalized = language?.trim().toLowerCase() ?? "";
  if (normalized in LANGUAGE_ALIASES) return LANGUAGE_ALIASES[normalized];
  return AGENT_CODE_LANGUAGE_SET.has(normalized)
    ? (normalized as AgentCodeLanguage)
    : "text";
}
