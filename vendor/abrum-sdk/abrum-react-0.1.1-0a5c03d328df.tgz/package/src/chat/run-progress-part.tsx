import React from "react";
import type { DataMessagePartProps } from "@assistant-ui/react";
import { Clock3, ShieldCheck, TriangleAlert } from "lucide-react";
import { RUN_PROGRESS_POLICY, progressDuration, type RunProgressData } from "./run-progress";
import { customerProgress } from "./customer-progress";
import { Shimmer } from "../ui/shimmer";
import { cn } from "../ui/cn";
import { ChatFailureActions, ChatFailureActionsContext } from "./parts";

/*
 * One run-status row. Colour carries meaning, nothing else:
 *   running  quiet shimmer row, as before (working and system waits alike)
 *   approval blue tint: only when the person has to approve in Warden
 *   warning  amber tint: slow, retrying or not completed
 * Text copy and wait-state semantics come from customerProgress.
 */
export function RunProgressPart({ data, locale, failureShown = false }: DataMessagePartProps<RunProgressData> & {
  locale?: string;
  /** The message already shows its failure as an error card; do not repeat it. */
  failureShown?: boolean;
}) {
  const [now, setNow] = React.useState(Date.now);
  const de = (locale ?? (typeof navigator !== "undefined" ? navigator.language : "en")).startsWith("de");
  const state = customerProgress(data, now, de);
  const failureActions = React.useContext(ChatFailureActionsContext);
  React.useEffect(() => {
    if (!state.active) return;
    const timer = setInterval(() => setNow(Date.now()), RUN_PROGRESS_POLICY.tickMs);
    return () => clearInterval(timer);
  }, [state.active]);
  // Steering ends this execution attempt while the task continues in the next
  // turn. Its internal cancellation is not a user-facing Stop acknowledgement.
  const terminalPhase = data.events.at(-1)?.phase;
  if (!data.events.length || terminalPhase === "complete" || terminalPhase === "needs_input"
    || (terminalPhase === "cancelled" && data.events.at(-1)?.steered === true)) return null;
  if (failureShown && terminalPhase === "failed") return null;
  const needsApproval = state.stage === "approval_pending";
  const tinted = state.tone === "warning" || needsApproval;
  return <div data-slot="run-progress" data-wait-state={state.tone}
    className={cn("my-2 flex items-start gap-2.5 text-body text-fg-muted motion-safe:animate-chat-fade",
      tinted && "rounded-lg px-3 py-2.5",
      state.tone === "warning" && "bg-amber-500/10",
      needsApproval && "bg-accent-soft")}>
    {state.tone === "warning" ? <TriangleAlert className="mt-0.5 size-4 shrink-0 text-amber-600 dark:text-amber-400" aria-hidden="true" />
      : needsApproval ? <ShieldCheck className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
      : state.active ? <Clock3 className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" /> : null}
    <div className="min-w-0 flex-1">
      <div role="status" aria-atomic="true">
        {/* Keyed by label: a new status cross-fades in instead of jumping. */}
        {state.active && !tinted
          ? <Shimmer key={state.label} className="motion-safe:animate-chat-fade">{state.label}</Shimmer>
          : <span key={state.label} className={cn("motion-safe:animate-chat-fade", tinted && "text-fg")}>{state.label}</span>}
        {state.detail && <span className="mt-0.5 block text-ui">{state.detail}</span>}
        {state.guidance && <span className="mt-0.5 block text-ui">{state.guidance}</span>}
      </div>
      {terminalPhase === "failed" && <ChatFailureActions>{failureActions}</ChatFailureActions>}
    </div>
    {state.showElapsed && <span className="shrink-0 tabular-nums text-meta" aria-live="off"
      aria-label={de ? "Bisherige Dauer" : "Elapsed time"}>{progressDuration(state.elapsedMs, de)}</span>}
  </div>;
}
