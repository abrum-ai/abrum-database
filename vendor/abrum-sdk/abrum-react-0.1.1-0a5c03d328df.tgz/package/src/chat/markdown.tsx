import { isValidElement, type ComponentPropsWithoutRef, type ReactNode } from "react";
import { ExternalLink } from "lucide-react";
import { Streamdown, useIsCodeFenceIncomplete } from "streamdown";
import "streamdown/styles.css";
import { cn } from "../ui/cn";
import { normalizeAgentCodeLanguage } from "./code-language";
import { CodeBlock } from "./code-block";
import { ChatTable } from "./table";
import { isPlainMailtoLink } from "./mailto-link";

/*
 * MarkdownText — GitHub-flavored markdown that renders safely WHILE streaming
 * (Streamdown tolerates half-open fences/links). `controls={false}` drops
 * Streamdown's per-block toolbars. Shared by every abrum chat surface so the
 * desktop sidebar and the web agent render identically.
 */
export interface MarkdownTextProps {
  children: string;
  className?: string;
}

/** Open an external URL directly — no interstitial modal. On the desktop the
 * preload bridge routes it to the system browser or mail app
 * (shell.openExternal); on the web it opens a new tab. Feature-detected so the
 * same shared component works in both the Electron renderer and agent-web. */
export function openExternalUrl(href: string): void {
  const bridge = (globalThis as { abrumDesktop?: { openExternal?: (url: string) => void } }).abrumDesktop;
  if (bridge?.openExternal) {
    bridge.openExternal(href);
    return;
  }
  if (typeof window !== "undefined") {
    // A mail recipient is a protocol navigation, not a document: it must reach
    // the OS mail handler even when the popup opener would be throttled.
    if (isPlainMailtoLink(href)) {
      window.location.href = href;
      return;
    }
    window.open(href, "_blank", "noopener,noreferrer");
  }
}

/** http(s) host without `www.`, or null for relative / in-app / non-web links. */
function externalHost(href: string): string | null {
  try {
    const url = new URL(href);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return url.host.replace(/^www\./, "");
  } catch {
    return null;
  }
}

type ChatLinkProps = ComponentPropsWithoutRef<"a"> & { node?: unknown };

/** Streamdown/react-markdown `<a>` renderer. External (web) links become a
 * subtle chip (label + ↗) that opens DIRECTLY — desktop via the openExternal
 * bridge, web in a new tab — with no Streamdown link-safety modal. Relative /
 * in-app links fall through to a plain anchor. Reusable across every chat
 * surface so sources render consistently. */
export function ChatLink({ href, children, className, node: _node, ...rest }: ChatLinkProps) {
  const host = href ? externalHost(href) : null;
  if (!href || !host) {
    // A bare email address (GFM autolink) or an authored `mailto:` link opens
    // the system mail app directly instead of navigating the renderer.
    if (href && isPlainMailtoLink(href)) {
      return (
        <a
          {...rest}
          href={href}
          title={href}
          className={className}
          onClick={(event) => {
            event.preventDefault();
            event.stopPropagation();
            openExternalUrl(href);
          }}
        >
          {children}
        </a>
      );
    }
    return (
      <a href={href} className={className} {...rest}>
        {children}
      </a>
    );
  }
  return (
    <a
      {...rest}
      href={href}
      title={href}
      data-slot="chat-link"
      onClick={(event) => {
        event.preventDefault();
        event.stopPropagation();
        openExternalUrl(href);
      }}
      className={cn(
        "inline-flex max-w-full items-center gap-1 rounded-md bg-surface-muted px-1.5 py-0.5 align-baseline text-body text-accent no-underline! transition-colors hover:bg-surface-muted/70",
        className,
      )}
    >
      <ExternalLink className="size-3 shrink-0 opacity-70" aria-hidden="true" />
      <span className="truncate">{children ?? host}</span>
    </a>
  );
}

type ChatCodeProps = ComponentPropsWithoutRef<"code"> & {
  node?: unknown;
  "data-block"?: string | boolean;
};

/** Flatten the text children supplied by react-markdown without reaching into
 * the DOM, so the same renderer works during Streamdown's partial-fence pass. */
export function codeTextFromChildren(children: ReactNode): string {
  if (typeof children === "string" || typeof children === "number") {
    return String(children);
  }
  if (Array.isArray(children)) return children.map(codeTextFromChildren).join("");
  if (isValidElement<{ children?: ReactNode }>(children)) {
    return codeTextFromChildren(children.props.children);
  }
  return "";
}

export function ChatCode({
  children,
  className,
  node: _node,
  "data-block": block,
  ...rest
}: ChatCodeProps) {
  const incomplete = useIsCodeFenceIncomplete();
  if (!block) {
    return (
      <code
        className={cn(
          "rounded bg-surface-muted px-1 py-0.5 font-mono text-code",
          className,
        )}
        {...rest}
      >
        {children}
      </code>
    );
  }

  const languageLabel = className?.match(/language-([^\s]+)/)?.[1] ?? "text";
  // Markdown parsers conventionally append one newline inside fenced code.
  const code = codeTextFromChildren(children).replace(/\n$/, "");
  return (
    <CodeBlock
      code={code}
      language={normalizeAgentCodeLanguage(languageLabel)}
      status={incomplete ? "streaming" : "complete"}
    />
  );
}

const MARKDOWN_COMPONENTS = {
  a: ChatLink,
  code: ChatCode,
  table: ChatTable,
};

export function MarkdownText({ children, className }: MarkdownTextProps) {
  return (
    <Streamdown
      controls={false}
      // Sources open directly (system browser / new tab) — Streamdown's built-in
      // confirm modal is replaced by the ChatLink chip below.
      linkSafety={{ enabled: false }}
      components={MARKDOWN_COMPONENTS}
      className={cn(
        "min-w-0 text-sm leading-relaxed [&_p]:my-1.5 first:[&_p]:mt-0 last:[&_p]:mb-0",
        "[&_ul]:my-1.5 [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:my-1.5 [&_ol]:list-decimal [&_ol]:pl-5 [&_li]:my-0.5",
        // Plain links underline; ChatLink source chips style themselves.
        "[&_a:not([data-slot=chat-link])]:text-accent [&_a:not([data-slot=chat-link])]:underline [&_a:not([data-slot=chat-link])]:underline-offset-2",
        "[&_h1]:mt-3 [&_h1]:mb-1.5 [&_h1]:text-base [&_h1]:font-semibold [&_h2]:mt-3 [&_h2]:mb-1.5 [&_h2]:text-sm [&_h2]:font-semibold [&_h3]:mt-2 [&_h3]:mb-1 [&_h3]:font-semibold",
        "[&_blockquote]:border-l-2 [&_blockquote]:border-border [&_blockquote]:pl-3 [&_blockquote]:text-fg-muted",
        className,
      )}
    >
      {children}
    </Streamdown>
  );
}
