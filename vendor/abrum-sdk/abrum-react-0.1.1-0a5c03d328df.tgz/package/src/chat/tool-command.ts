function objectRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : null;
}

function appToolParts(toolName: string): { app: string; fn: string } | null {
  if (!toolName.startsWith("abrum_app__")) return null;
  const [app = "", fn = ""] = toolName.slice("abrum_app__".length).split("__");
  return app && fn ? { app, fn } : null;
}

function parsedArguments(value: unknown): Record<string, unknown> | null {
  const record = objectRecord(value);
  if (record) return record;
  if (typeof value !== "string" || !value.trim()) return null;
  try {
    return objectRecord(JSON.parse(value));
  } catch {
    return null;
  }
}

/** Return the user-visible shell command for the VM/Computer execution tools.
 * Other tool inputs deliberately stay opaque: this is presentation metadata,
 * not a generic argument inspector. */
export function toolCommand(toolName: string, input: unknown): string | null {
  const record = objectRecord(input);
  if (!record) return null;

  const appTool = appToolParts(toolName);
  let commandInput: Record<string, unknown> | null = null;
  if (toolName === "vm_exec") {
    commandInput = record;
  } else if (appTool?.app === "abrum_computer" && appTool.fn === "exec") {
    commandInput = record;
  } else if (
    appTool?.app === "abrum_computer" &&
    appTool.fn === "callMcpTool" &&
    record.toolName === "vm_exec"
  ) {
    commandInput = parsedArguments(record.arguments);
  }

  const script = commandInput?.script;
  return typeof script === "string" && script.trim() ? script.trim() : null;
}
