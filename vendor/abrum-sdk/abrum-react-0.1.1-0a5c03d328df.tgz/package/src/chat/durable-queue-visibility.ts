import type { QueueItemState } from "@assistant-ui/react";

export const DURABLE_QUEUE_REVEAL_DELAY_MS = 500;

export interface DurableQueueVisibilityProjection {
  firstSeenAt: ReadonlyMap<string, number>;
  visibleIds: ReadonlySet<string>;
  nextRevealInMs: number | null;
}

/**
 * A freshly persisted process is hidden briefly because every Station run is
 * born in `queued` before the scheduler claims it. Items that remain queued
 * cross the threshold and become normal steer/remove controls.
 */
export function projectDurableQueueVisibility(
  items: readonly QueueItemState[],
  previousFirstSeenAt: ReadonlyMap<string, number>,
  nowMs: number,
  revealDelayMs = DURABLE_QUEUE_REVEAL_DELAY_MS,
): DurableQueueVisibilityProjection {
  const firstSeenAt = new Map<string, number>();
  const visibleIds = new Set<string>();
  let nextRevealInMs: number | null = null;

  for (const item of items) {
    const firstSeen = previousFirstSeenAt.get(item.id) ?? nowMs;
    firstSeenAt.set(item.id, firstSeen);
    const remaining = Math.max(0, revealDelayMs - (nowMs - firstSeen));
    if (remaining === 0) {
      visibleIds.add(item.id);
    } else if (nextRevealInMs === null || remaining < nextRevealInMs) {
      nextRevealInMs = remaining;
    }
  }

  return { firstSeenAt, visibleIds, nextRevealInMs };
}

export function sameQueueIds(
  left: ReadonlySet<string>,
  right: ReadonlySet<string>,
): boolean {
  if (left.size !== right.size) return false;
  for (const id of left) {
    if (!right.has(id)) return false;
  }
  return true;
}
