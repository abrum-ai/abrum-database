export interface ProfileContext { contract: 'abrum.profile-context/v1'; plan: Record<string, any>; legacy?: boolean }
export const PROFILE_CONTEXT_PART: string;
export const PROFILE_CONTEXT_CONTRACT: string;
export const PROFILE_CONTEXT_SUFFIX: string;
export function profileContext(plan: unknown): ProfileContext | null;
export function separateProfileContext(text: string, context?: unknown): { text: string; context: ProfileContext | null };
export function presentProfileMessage<T extends {role: string; text?: string; profileContext?: unknown}>(message: T): T & {profileContext?: ProfileContext};
