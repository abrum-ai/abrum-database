import type { ThreadMessage } from "@assistant-ui/react";

export const ABRUM_REQUEST_USER_INPUT_TOOL = "request_user_input";

export interface HumanInputRequest {
  inputRequestId: string;
  question: string;
  reason: string;
  choices: string[];
  allowFreeform: boolean;
  requiredFields: string[];
  responseRef?: HumanInputResponseRef;
  /** Host transcript provenance for closing legacy questions only, never answering. */
  dismissRef?: HumanInputResponseRef;
}

/** Presentation-only identity; collapsing a question is never an answer or grant. */
export function humanQuestionPresentationKey(request: HumanInputRequest, topicKey?: string | null): string {
  const ref = request.responseRef;
  return JSON.stringify(ref
    ? [ref.roomId, ref.threadLineageCid, ref.runId, ref.inputRequestId]
    : [topicKey ?? "", request.inputRequestId]);
}

/** A `request_user_input` call without its signed input-required receipt is
 * not a pending question. Keep that distinction explicit so transcript UI
 * never tells the person to answer a call that cannot accept an answer. */
export type HumanInputFallbackState = "waiting" | "unavailable" | "failed";

export function humanInputFallbackState(
  result: unknown,
  statusType?: string,
  isError?: boolean,
): HumanInputFallbackState {
  if (isError || statusType === "incomplete") return "failed";
  if (result !== undefined || statusType === "complete") return "unavailable";
  return "waiting";
}

/** Correlation, not evidence of successful execution or a permission grant. */
export interface HumanInputResponseRef {
  roomId: string;
  threadLineageCid: string;
  runId: string;
  inputRequestId: string;
  /** Host-provided concise answer for a persisted continuation turn. */
  answerText?: string;
}

export function humanInputResponseRef(value: unknown): HumanInputResponseRef | undefined {
  if (!value || typeof value !== "object" || Array.isArray(value)) return undefined;
  const record = value as Record<string, unknown>;
  const keys = ["roomId", "threadLineageCid", "runId", "inputRequestId"] as const;
  if (!keys.every(key => typeof record[key] === "string" && record[key].length > 0
    && record[key].length <= 512 && record[key].trim() === record[key] && !/[\u0000-\u001f]/.test(record[key]))) return undefined;
  const response = Object.fromEntries(keys.map(key => [key, record[key]])) as unknown as HumanInputResponseRef;
  const answerText = typeof record.answerText === "string" ? record.answerText.trim() : "";
  return answerText ? { ...response, answerText } : response;
}

export function humanInputResponseFromMessage(message: { metadata?: { custom?: Record<string, unknown> } }): HumanInputResponseRef | undefined {
  return humanInputResponseRef(message.metadata?.custom?.humanInputResponse);
}

type UnknownRecord = Record<string, unknown>;

/** Server-projected lifecycle, never a local hide preference or fabricated answer. */
export function humanQuestionIsClosed(message: ThreadMessage): boolean {
  return message.metadata?.custom?.abrumRunStatus === "cancelled";
}

function asRecord(value: unknown, depth = 0): UnknownRecord | null {
  if (depth > 5 || value == null) return null;
  if (typeof value === "string") {
    try {
      return asRecord(JSON.parse(value), depth + 1);
    } catch {
      return null;
    }
  }
  if (typeof value !== "object" || Array.isArray(value)) return null;
  const record = value as UnknownRecord;
  if (record.kind === "agent_input_request" && record.status === "input_required") return record;
  for (const key of ["data", "result", "output", "structuredContent"]) {
    const nested = asRecord(record[key], depth + 1);
    if (nested) return nested;
  }
  return null;
}

function stringList(value: unknown, limit: number): string[] {
  if (!Array.isArray(value)) return [];
  const unique = new Set<string>();
  for (const entry of value) {
    if (typeof entry !== "string") continue;
    const trimmed = entry.trim();
    if (trimmed) unique.add(trimmed);
    if (unique.size >= limit) break;
  }
  return [...unique];
}

export function humanInputRequestFromResult(value: unknown): HumanInputRequest | null {
  const record = asRecord(value);
  if (!record) return null;
  const inputRequestId = typeof record.inputRequestId === "string" ? record.inputRequestId.trim() : "";
  const question = typeof record.question === "string" ? record.question.trim() : "";
  const reason = typeof record.reason === "string" ? record.reason.trim() : "";
  if (!inputRequestId || !question || !reason) return null;
  const responseRef = humanInputResponseRef(record.responseRef);
  return {
    inputRequestId,
    question,
    reason,
    choices: stringList(record.choices, 4),
    allowFreeform: record.allowFreeform !== false,
    requiredFields: stringList(record.requiredFields, 8),
    ...(responseRef?.inputRequestId === inputRequestId ? { responseRef } : {}),
  };
}

function requestFromMessage(message: ThreadMessage): HumanInputRequest | null {
  if (message.role !== "assistant") return null;
  for (const part of message.content) {
    if (part.type !== "tool-call" || part.toolName !== ABRUM_REQUEST_USER_INPUT_TOOL) continue;
    const request = humanInputRequestFromResult(part.result);
    if (request) {
      const execution = message.metadata?.custom?.abrumExecutionRef;
      const dismissRef = execution && typeof execution === "object"
        ? humanInputResponseRef({...execution, inputRequestId: request.inputRequestId}) : undefined;
      return {...request, ...(dismissRef ? {dismissRef} : {})};
    }
  }
  return null;
}

export function textFromUserMessage(message: ThreadMessage): string {
  if (message.role !== "user") return "";
  return message.content
    .filter((part): part is Extract<(typeof message.content)[number], { type: "text" }> => part.type === "text")
    .map((part) => part.text)
    .join("\n")
    .trim();
}

/** A shared SINA transcript contains independent conversations. An answer in
 * another topic must never satisfy this question. Unscoped app chats retain
 * their existing single-conversation behaviour. */
export function humanQuestionTopicKey(message: ThreadMessage): string {
  const key = message.metadata?.custom?.abrumTopicKey;
  return typeof key === "string" ? key : "";
}

export function answerToHumanQuestion(messages: readonly ThreadMessage[], index: number): string {
  if (index < 0 || !messages[index]) return "";
  const request = requestFromMessage(messages[index]);
  if (!request) return "";
  if (request.responseRef) {
    const expected = request.responseRef;
    const answer = messages.slice(index + 1).find(message => {
      const actual = humanInputResponseFromMessage(message);
      return message.role === "user" && actual && textFromUserMessage(message)
        && actual.roomId === expected.roomId && actual.threadLineageCid === expected.threadLineageCid
        && actual.runId === expected.runId && actual.inputRequestId === expected.inputRequestId;
    });
    if (answer) {
      const response = humanInputResponseFromMessage(answer);
      return response?.answerText || textFromUserMessage(answer);
    }
    // Text questions are answered in the normal composer. That turn is the
    // answer even when the host could not bind the signed receipt.
    if (request.choices.length === 0) {
      const topicKey = humanQuestionTopicKey(messages[index]);
      for (const message of messages.slice(index + 1)) {
        if (humanQuestionTopicKey(message) !== topicKey) continue;
        if (requestFromMessage(message)) return "";
        const typed = textFromUserMessage(message);
        if (typed) return typed;
      }
    }
    return "";
  }
  const topicKey = humanQuestionTopicKey(messages[index]);
  // Legacy receipts have no exact reference. Never let a response to a newer
  // question (or an explicitly addressed different question) satisfy this one.
  for (const message of messages.slice(index + 1)) {
    if (humanQuestionTopicKey(message) !== topicKey) continue;
    if (requestFromMessage(message)) return "";
    if (humanInputResponseFromMessage(message)) continue;
    const answer = textFromUserMessage(message);
    if (answer) return answer;
  }
  return "";
}

export function pendingHumanInputRequest(messages: readonly ThreadMessage[], topicKey?: string | null): HumanInputRequest | null {
  const answered = new Set<string>();
  const legacyAnswers = new Set<string>();
  const key = (ref: HumanInputResponseRef) => JSON.stringify([ref.roomId, ref.threadLineageCid, ref.runId, ref.inputRequestId]);
  for (let index = messages.length - 1; index >= 0; index -= 1) {
    const message = messages[index];
    const messageTopic = humanQuestionTopicKey(message);
    if (textFromUserMessage(message)) {
      const response = humanInputResponseFromMessage(message);
      if (response) answered.add(key(response));
      else legacyAnswers.add(messageTopic);
    }
    const request = requestFromMessage(message);
    if (!request) continue;
    if (humanQuestionIsClosed(message)) continue;
    const hasAnswer = request.responseRef
      ? answered.has(key(request.responseRef)) || (request.choices.length === 0 && legacyAnswers.has(messageTopic))
      : legacyAnswers.has(messageTopic);
    legacyAnswers.delete(messageTopic);
    // undefined: ordinary app chat. null: SINA chronology, only unscoped input.
    if (topicKey !== undefined && messageTopic !== (topicKey ?? "")) continue;
    if (!hasAnswer) return request;
  }
  return null;
}
