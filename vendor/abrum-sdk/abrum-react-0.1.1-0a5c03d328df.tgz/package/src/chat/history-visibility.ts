/** A deliberately queued continuation belongs in the composer queue until the
 * Station promotes it. Initial sends also pass through `queued`, but they are
 * not queueRequested and should remain visible as the active user turn. */
export function isAgentRunVisibleInHistory(
  runStatus: string | null | undefined,
  queueRequested: boolean | null | undefined,
): boolean {
  return runStatus !== "queued" || queueRequested !== true;
}
