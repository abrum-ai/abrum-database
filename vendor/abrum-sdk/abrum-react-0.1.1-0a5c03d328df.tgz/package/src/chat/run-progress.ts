/** ABRUM owns state and timing. Apps cannot advance a Run by emitting prose. */
export const RUN_PROGRESS_PART = "abrum.run-progress";
export const PUBLIC_PROGRESS_PART = "abrum.public-progress";
export const RUN_PROGRESS_POLICY = { staleAfterMs: 20_000, delayedAfterMs: 60_000, longRunAfterMs: 120_000, tickMs: 1_000 } as const;
export const PHASE_LABELS = {
  plan: ["Öffentlicher Arbeitsschritt erfasst", "Public task step recorded"],
  preparing: ["Kontext und Werkzeuge vorbereiten", "Preparing context and tools"],
  context_compaction: ["Bisherigen Chat zusammenfassen", "Summarizing earlier conversation"],
  brain: ["Vorwissen aus dem Brain abrufen", "Reading Brain context"],
  model: ["Auf den KI-Dienst warten", "Waiting for the AI service"],
  model_connected: ["KI-Dienst hat geantwortet", "AI service responded"],
  model_streaming: ["Antwortdaten vom KI-Dienst empfangen", "Receiving AI response data"],
  model_retry: ["KI-Dienst nicht verfügbar · neuer Versuch", "AI service unavailable · retrying"],
  tool: ["Werkzeug ausführen", "Executing tool"],
  approval_pending: ["Warden-Freigabe ausstehend", "Awaiting Warden approval"],
  approval_granted: ["Freigabe erhalten · Ausführung fortgesetzt", "Approval received · execution resumed"],
  tool_returned: ["Werkzeug hat geantwortet", "Tool response received"],
  tool_failed: ["Werkzeug meldet ein Problem", "Tool reported a problem"],
  review: ["Antwort mit dem Brain prüfen", "Reviewing answer with Brain"],
  review_model: ["Abschlussprüfung wartet auf den KI-Dienst", "Final review is waiting for the AI service"],
  complete: ["Antwort bereit", "Answer ready"],
  needs_input: ["Deine Antwort wird benötigt", "Your answer is needed"],
  failed: ["Auftrag konnte nicht abgeschlossen werden", "Task could not be completed"],
  cancelled: ["Auftrag abgebrochen", "Task cancelled"],
} as const;
export type ProgressPhase = keyof typeof PHASE_LABELS;
/** Host observations only: saved counts describe this refresh plan, not the Run
 * result or all older checkpoints. The total may grow after a batch is split. */
export interface CompactionProgress {
  version: 1;
  mode: "initial" | "incremental" | "resumed";
  state: "running" | "saved" | "complete" | "retrying";
  completedBatches: number;
  totalBatches: number;
  sourceMessages: number;
  checkpointReused: boolean;
}
export interface ProgressEvent { version: 1; phase: ProgressPhase; atMs: number; toolName?: string; publicActivity?: string; publicReport?: string; publicResult?: string; evidenceRefs?: string[]; compaction?: CompactionProgress; steered?: boolean }
export interface RunProgressData { events: ProgressEvent[]; running: boolean }
export function parseCompactionProgress(value: unknown): CompactionProgress | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const state = value as CompactionProgress;
  if (state.version !== 1 || !["initial", "incremental", "resumed"].includes(state.mode) ||
      !["running", "saved", "complete", "retrying"].includes(state.state) ||
      typeof state.checkpointReused !== "boolean" ||
      ![state.completedBatches, state.totalBatches, state.sourceMessages]
        .every(n => Number.isSafeInteger(n) && n >= 0) ||
      state.completedBatches > state.totalBatches ||
      (state.state === "complete" && state.completedBatches !== state.totalBatches)) return null;
  // Copy the allowlist: summaries, model prose, identifiers and unknown fields
  // must never become part of the customer-facing projection.
  return { version: 1, mode: state.mode, state: state.state,
    completedBatches: state.completedBatches, totalBatches: state.totalBatches,
    sourceMessages: state.sourceMessages, checkpointReused: state.checkpointReused };
}
export function parseProgress(value: unknown): ProgressEvent | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const event = value as ProgressEvent;
  if (event.version !== 1 || !Object.hasOwn(PHASE_LABELS, event.phase) ||
      !Number.isSafeInteger(event.atMs) || event.atMs < 0) return null;
  if (event.phase === "plan" && event.publicActivity !== undefined &&
      (typeof event.publicActivity !== "string" || !event.publicActivity.trim() ||
       [...event.publicActivity].length > 160 || /[\u0000-\u001f\u007f-\u009f]/u.test(event.publicActivity))) return null;
  if (event.phase === "plan" && event.publicReport !== undefined &&
      (typeof event.publicReport !== "string" || !event.publicReport.trim() || [...event.publicReport].length > 1000 ||
       /[\u0000-\u001f\u007f-\u009f]/u.test(event.publicReport) || !Array.isArray(event.evidenceRefs) || event.evidenceRefs.length > 8 ||
       event.evidenceRefs.some(ref => typeof ref !== "string" || !ref.trim() || ref.length > 512 || /[\u0000-\u001f\u007f-\u009f]/u.test(ref)))) return null;
  if (event.phase === "plan" && event.publicResult !== undefined &&
      (typeof event.publicResult !== "string" || !event.publicResult.trim() || [...event.publicResult].length > 8000 ||
       /[\u0000-\u0008\u000b-\u001f\u007f-\u009f]/u.test(event.publicResult) || !Array.isArray(event.evidenceRefs) || event.evidenceRefs.length > 8 ||
       event.evidenceRefs.some(ref => typeof ref !== "string" || !ref.trim() || ref.length > 512 || /[\u0000-\u001f\u007f-\u009f]/u.test(ref)))) return null;
  const compaction = event.phase === "context_compaction" && event.compaction !== undefined
    ? parseCompactionProgress(event.compaction) : null;
  if (event.phase === "context_compaction" && event.compaction !== undefined && !compaction) return null;
  return { version: 1, phase: event.phase, atMs: event.atMs,
    ...(event.phase === "plan" && event.publicActivity ? { publicActivity: event.publicActivity.trim() } : {}),
    ...(event.phase === "plan" && event.publicReport ? { publicReport: event.publicReport.trim(), evidenceRefs: [...event.evidenceRefs!] } : {}),
    ...(event.phase === "plan" && event.publicResult ? { publicResult: event.publicResult.trim(), evidenceRefs: [...event.evidenceRefs!] } : {}),
    ...(compaction ? { compaction } : {}),
    ...(event.phase === "cancelled" && event.steered === true ? { steered: true } : {}),
    ...(typeof event.toolName === "string" ? { toolName: event.toolName.slice(0, 256) } : {}) };
}

export function progressDuration(ms: number, de: boolean) {
  const seconds = Math.floor(Math.max(0, ms) / 1000);
  return seconds < 60 ? `${seconds} s` : `${Math.floor(seconds / 60)} ${de ? "Min" : "min"} ${seconds % 60} s`;
}

/** Evidence age is not connection health. Repeated real response observations
 * refresh freshness, but cannot hide an unusually long model round. */
export function progressReport(data: RunProgressData, now: number, de: boolean) {
  const clock = progressClock(data, now);
  const last = data.events.at(-1);
  const pick = (a: string, b: string) => de ? a : b;
  const model = !!last && ["model", "model_connected", "model_streaming", "model_retry"].includes(last.phase);
  const start = model ? data.events.findLast(e => e.phase === "model") ?? last : last;
  const phaseMs = clock.active && start ? Math.max(0, now - start.atMs) : 0;
  const slowPhase = clock.active && phaseMs >= RUN_PROGRESS_POLICY.delayedAfterMs;
  const longRun = clock.active && clock.elapsedMs >= RUN_PROGRESS_POLICY.longRunAfterMs;
  // A new phase must not erase minutes already spent. Only flag delay when
  // that long Run is also missing current evidence; length alone is not failure.
  const delayed = slowPhase || (longRun && clock.stale);
  const problem = last?.phase === "tool_failed" || last?.phase === "model_retry" || last?.phase === "failed";
  const currentLabel = last ? PHASE_LABELS[last.phase][de ? 0 : 1] : "";
  let label = currentLabel;
  let detail = "";
  if (!clock.active) {
    if (last && !isProgressTerminal(last)) label = pick("Auftrag beendet · letzter belegter Stand", "Task ended · last recorded state");
  } else if (last?.phase === "model_retry") {
    detail = pick("Ein Fehler wurde gemeldet. ABRUM wiederholt nur die KI-Anfrage, keine bereits ausgeführte Aktion.", "An error was reported. ABRUM retries only the AI request, not actions already performed.");
  } else if (last?.phase === "tool_failed") {
    detail = pick("Diese Rückmeldung enthält einen Fehler. Bereits vorhandene Ergebnisse bleiben erhalten; der Gesamtauftrag ist noch nicht abgeschlossen.", "This response contains an error. Previous results are retained; the overall task is not finished.");
  } else if (clock.stale) {
    detail = last?.phase === "model"
      ? pick("Noch keine Rückmeldung des KI-Dienstes für diesen Schritt. Ob er ausgelastet ist oder die Verbindung gestört ist, ist derzeit nicht erkennbar.", "No AI service response for this step yet. It is not currently possible to tell whether the service is busy or the connection is disrupted.")
      : model
        ? pick("Der KI-Dienst hat bereits geantwortet, danach kamen keine weiteren Antwortdaten. Die Verbindung ist dadurch nicht als aktuell intakt bestätigt.", "The AI service responded earlier, but no further response data has arrived. This does not confirm that the connection is still healthy.")
        : last?.phase === "review_model"
          ? pick("Die Brain-Abfrage ist erfolgt. Für den Abschluss fehlt noch die KI-Rückmeldung; die Prüfung ist noch nicht abgeschlossen.", "The Brain lookup has finished. Final review still needs an AI response; the review is not complete.")
          : pick("Für diesen Schritt liegt keine neuere Rückmeldung vor. Das bestätigt weder einen Fehler noch einen störungsfreien Ablauf.", "There is no newer observation for this step. This confirms neither a fault nor normal operation.");
  } else if (last?.phase === "model_streaming") {
    detail = pick("Neue Antwortdaten sind eingetroffen. Das Ergebnis ist noch nicht fertig.", "New response data has arrived. The result is not ready yet.");
  } else if (last?.phase === "model_connected") {
    detail = pick("Der KI-Dienst hat auf die Anfrage reagiert. Die vollständige Antwort steht noch aus.", "The AI service responded to the request. Its full answer is still pending.");
  }
  if (delayed && !problem) label = slowPhase
    ? model ? pick("KI-Dienst braucht ungewöhnlich lange", "AI service is taking unusually long")
      : pick("Dieser Schritt dauert ungewöhnlich lange", "This step is taking unusually long")
    : pick("Lange Laufzeit · aktuelle Rückmeldung fehlt", "Long-running task · current response missing");
  return { ...clock, label, currentLabel, detail, delayed, problem, phaseMs,
    responseCount: data.events.filter(e => e.phase === "tool_returned" || e.phase === "tool_failed").length,
    problemCount: data.events.filter(e => e.phase === "tool_failed").length,
    guidance: delayed ? pick("Du kannst weiter warten oder den Auftrag über Stopp beenden. Bereits ausgeführte Aktionen werden dadurch nicht rückgängig gemacht.", "You can keep waiting or use Stop to end the task. Actions already performed will not be undone.") : "" };
}
export function progressFromStream(text: string): ProgressEvent | null {
  try { return parseProgress(JSON.parse(text)); } catch { return null; }
}
export function isProgressTerminal(event: ProgressEvent): boolean {
  return ["complete", "needs_input", "failed", "cancelled"].includes(event.phase);
}
export function progressClock(data: RunProgressData, now: number) {
  const first = data.events[0], last = data.events.at(-1);
  if (!first || !last) return { elapsedMs: 0, waitingMs: 0, active: false, stale: false };
  const active = data.running && !isProgressTerminal(last);
  const end = active ? Math.max(now, last.atMs) : last.atMs;
  const waitingMs = active ? Math.max(0, end - last.atMs) : 0;
  return { active, elapsedMs: Math.max(0, end - first.atMs), waitingMs,
    stale: active && waitingMs >= RUN_PROGRESS_POLICY.staleAfterMs };
}
