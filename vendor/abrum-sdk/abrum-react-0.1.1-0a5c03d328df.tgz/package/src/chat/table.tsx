import type { ComponentPropsWithoutRef } from "react";
import { cn } from "../ui/cn";

type ChatTableProps = ComponentPropsWithoutRef<"table"> & { node?: unknown };

/**
 * Responsive Markdown table for narrow chat surfaces.
 *
 * The table fills the available message width while its columns fit. Once the
 * columns need more room, only this wrapper scrolls horizontally; the chat
 * viewport and the rest of the message stay fixed.
 */
export function ChatTable({ className, node: _node, ...props }: ChatTableProps) {
  return (
    <div
      data-slot="chat-table-scroll"
      className="my-3 w-full min-w-0 max-w-full overflow-x-auto overscroll-x-contain [scrollbar-width:thin]"
    >
      <table
        {...props}
        data-slot="chat-table"
        className={cn(
          "w-max min-w-full border-collapse text-left",
          "[&_thead]:border-b [&_thead]:border-border [&_thead]:bg-transparent",
          "[&_tbody]:divide-y [&_tbody]:divide-border/60 [&_tr]:border-0",
          "[&_th]:whitespace-nowrap [&_th]:border-0 [&_th]:px-0 [&_th]:py-1.5 [&_th]:pr-4 [&_th]:text-meta [&_th]:font-medium [&_th]:tracking-wide [&_th]:text-fg-muted [&_th:last-child]:pr-0",
          "[&_td]:whitespace-nowrap [&_td]:border-0 [&_td]:px-0 [&_td]:py-2 [&_td]:pr-4 [&_td]:align-top [&_td:last-child]:pr-0",
          className,
        )}
      />
    </div>
  );
}
