/*
 * @abrum/react/chat — the reusable agent-chat layer.
 *
 * View-only: built on @assistant-ui/react primitives + the shadcn AI components
 * in @abrum/react/ui. Each host app supplies its own runtime (useExternalStoreRuntime)
 * and message converter; this module owns the look (bubbles, tool calls,
 * markdown, scroll behavior) so every abrum chat surface matches.
 *
 * Requires the Tailwind token bridge: import "@abrum/react/tailwind.css".
 */

export { AgentChat, type AgentChatProps } from "./agent-chat";
export {
  ChatThread,
  type ChatThreadProps,
  type ChatThreadConfig,
} from "./thread";
export { ChatComposer, type ChatComposerProps } from "./composer";
export {
  AbrumAgentRuntimePickerProvider,
  useAbrumAgentRuntimePicker,
  type AbrumAgentRuntimePickerState,
} from "./runtime-provider";
export {
  AbrumAppSurfacePartProvider,
  AppResultPart,
  useAbrumAppSurfacePart,
  type AbrumAppSurfacePartComponent,
} from "./app-surface-host";
export { ABRUM_APP_RESULT_DATA_PART, finalizedAppResults, isAppResult, type AppResult } from "./app-result";
export { ChatQueueItem, type ChatQueueItemProps } from "./queue-item";
export {
  ChatAttachmentPart,
  createChatAttachmentAdapter,
  createChatAttachmentPart,
  type ChatAttachmentOpen,
} from "./attachments";
export {
  CHAT_ATTACHMENT_MAX_FILE_BYTES,
  ABRUM_CHAT_ATTACHMENT_DATA_PART,
  chatAttachmentDownloadUrl,
  chatAttachmentRefsFromMessage,
  isChatAttachmentRef,
  type ChatAttachmentRef,
  type ChatAttachmentUploader,
} from "./attachment-contract";
export {
  createDurableMessageQueueAdapter,
  useDurableMessageQueue,
  useMessageQueue,
  type UseDurableMessageQueueOptions,
  type UseMessageQueueOptions,
} from "./use-message-queue";
export {
  AgentProviderIcon,
  AgentRuntimePicker,
  type AgentRuntimeChoice,
  type AgentRuntimeModelChoice,
  type AgentProviderIconName,
  type AgentRuntimePickerProps,
  type AgentRuntimeSelection,
} from "./runtime-picker";
export { AgentModelInfo } from "./model-info";
export {
  DEFAULT_ENABLED_AGENT_PROVIDERS,
  FALLBACK_AGENT_RUNTIME_OPTIONS,
  IONOS_DEFAULT_BASE_URL,
  SELECTABLE_AGENT_PROVIDER_IDS,
  agentRuntimeOptionsFromCatalog,
  defaultAgentRuntimeSelection,
  filterEnabledAgentRuntimeOptions,
  normalizeAgentRuntimeSelection,
  normalizeEnabledAgentProviders,
  type SelectableAgentProviderId,
} from "./runtime-catalog";
export {
  projectAgentRuns,
  type AgentRunAttemptLike,
  type AgentRunRequestLike,
  type AgentRunState,
  type AgentRunView,
} from "./agent-run";
export {
  convertAgentMessageToThreadMessage,
  convertSandboxMessageToThreadMessage,
  appendAgentStreamDeltaToAgentMessages,
  appendAgentStreamDeltaToSandboxMessages,
  appendOptimisticSandboxUserMessage,
  appendAgentStreamDeltaToParts,
  mergeDurableAgentThreadMessages,
  mergeDurableSandboxMessages,
  createAgentRunId,
  isAgentMessageRunning,
  isAgentThreadRunning,
  getActiveAgentThreadRun,
  isAgentRunVisibleInHistory,
  isAgentRunStatusRunning,
  readableToolOutput,
  appSurfaceFromToolOutput,
  agentRunSurfaceKey,
  isAgentRunSurfaceReference,
  ABRUM_APP_SURFACE_DATA_PART,
  ABRUM_AGENT_ACTIVITY_DATA_PART,
  ABRUM_TOOL_ACTIVITY_DATA_PART,
  ABRUM_SOURCE_SUMMARY_DATA_PART,
  type AgentActivityData,
  type AgentSourceReference,
  type SourceSummaryData,
  type ToolActivityData,
  type ToolActivityItem,
  type ToolActivityStep,
  type AgentRunStatusLike,
  type AgentThreadMessageLike,
  type AgentThreadPartLike,
  type SandboxDeltaLike,
  type SandboxThreadMessageLike,
} from "./agent-message";
export {
  MarkdownText,
  type MarkdownTextProps,
  ChatCode,
  ChatLink,
  codeTextFromChildren,
  openExternalUrl,
} from "./markdown";
export { isPlainMailtoLink } from "./mailto-link";
export {
  CodeBlock,
  type CodeBlockProps,
  type CodeBlockStatus,
} from "./code-block";
export {
  AssistantText,
  UserText,
  ReasoningPart,
  ToolCallPart,
  ToolActivityPart,
  SourceSummaryPart,
  ThinkingIndicator,
  AgentActivityPart,
  type ToolPresenterComponent,
  type ToolPresenterProps,
} from "./parts";
export {
  HumanQuestionToolPart,
  PendingHumanQuestion,
  humanInputRequestFromResult,
  humanInputResponseFromMessage,
  type HumanInputResponseRef,
  pendingHumanInputRequest,
  ABRUM_REQUEST_USER_INPUT_TOOL,
  type HumanInputRequest,
} from "./human-question";
export { formatToolName, toolAppTitles } from "./tool-name";

export { CHAT_REFERENCE_PART, chatReferenceFromReceipt, type ChatReference } from "./chat-reference";
