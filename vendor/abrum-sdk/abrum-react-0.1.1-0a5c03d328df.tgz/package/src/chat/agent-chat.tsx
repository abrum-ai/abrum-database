import * as React from "react";
import { AssistantRuntimeProvider, type AssistantRuntime } from "@assistant-ui/react";
import { cn } from "../ui/cn";
import { ChatThread, type ChatThreadProps } from "./thread";
import { ChatComposer, type ChatComposerProps } from "./composer";

/*
 * AgentChat — the batteries-included chat surface: transcript + composer in a
 * column. Pass a `runtime` and it wraps the provider for you; omit it to mount
 * inside an existing <AssistantRuntimeProvider>. `notice` slots between the
 * thread and composer (e.g. a "link a provider" banner). For full control over
 * the composer (voice button, hide-during-voice), compose <ChatThread> and
 * <ChatComposer> directly instead.
 */

export interface AgentChatProps {
  runtime?: AssistantRuntime;
  thread?: ChatThreadProps;
  composer?: ChatComposerProps | null;
  notice?: React.ReactNode;
  className?: string;
}

export function AgentChat({ runtime, thread, composer, notice, className }: AgentChatProps) {
  const footer =
    notice || composer !== null ? (
      <div className="flex flex-col gap-2 px-3 pb-3">
        {notice}
        {composer === null ? null : <ChatComposer {...composer} />}
      </div>
    ) : undefined;
  const body = <ChatThread {...thread} footer={footer} className={cn(className, thread?.className)} />;
  if (runtime) return <AssistantRuntimeProvider runtime={runtime}>{body}</AssistantRuntimeProvider>;
  return body;
}
