import { createContext, useContext, type ReactNode } from "react";
import type {
  AgentRuntimeChoice,
  AgentRuntimeSelection,
} from "./runtime-picker";

export type AbrumAgentRuntimePickerState = {
  options: AgentRuntimeChoice[];
  value: AgentRuntimeSelection;
  onChange: (value: AgentRuntimeSelection) => void;
  loading: boolean;
  /** Host-owned commercial/configuration boundary for the selected transport. */
  providerMode: "managed" | "external";
};

const AbrumAgentRuntimePickerContext =
  createContext<AbrumAgentRuntimePickerState | null>(null);

/** One host-owned picker state shared by every Agent composer surface. */
export function AbrumAgentRuntimePickerProvider({
  state,
  children,
}: {
  state: AbrumAgentRuntimePickerState;
  children: ReactNode;
}) {
  return (
    <AbrumAgentRuntimePickerContext.Provider value={state}>
      {children}
    </AbrumAgentRuntimePickerContext.Provider>
  );
}

export function useAbrumAgentRuntimePicker(): AbrumAgentRuntimePickerState | null {
  return useContext(AbrumAgentRuntimePickerContext);
}
