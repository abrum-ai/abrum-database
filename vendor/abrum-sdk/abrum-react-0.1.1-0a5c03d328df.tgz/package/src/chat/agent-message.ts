import { PROFILE_CONTEXT_PART, presentProfileMessage, separateProfileContext } from "./profile-context.mjs";
import type { MessageStatus, ThreadMessageLike } from "@assistant-ui/react";
import type {
  AgentStreamDeltaEvent,
  JsonValue,
  AbrumAppSurfaceReference,
} from "@abrum/web-runtime";
import { ABRUM_CHAT_ATTACHMENT_DATA_PART, type ChatAttachmentRef } from "./attachment-contract";
import { CHAT_REFERENCE_PART, chatReferenceFromParentReturnRead, chatReferencesFromReceipt } from "./chat-reference";
import { toolCommand } from "./tool-command";
import { RUN_PROGRESS_PART, PUBLIC_PROGRESS_PART, parseProgress, progressFromStream, type ProgressEvent } from "./run-progress";
export { isAgentRunVisibleInHistory } from "./history-visibility";

export const ABRUM_APP_SURFACE_DATA_PART = "abrum.app-surface";
import { ABRUM_APP_RESULT_DATA_PART, finalizedAppResults } from "./app-result";
export const ABRUM_AGENT_ACTIVITY_DATA_PART = "abrum.agent-activity";
export const ABRUM_TOOL_ACTIVITY_DATA_PART = "abrum.tool-activity";
export const ABRUM_SOURCE_SUMMARY_DATA_PART = "abrum.source-summary";

const AGENT_RUN_APP_ID = "abrum.agent";
const AGENT_RUN_SURFACE_ID = "run-status";

/** Allocate one direct-chat Run correlation id before enqueueing. Both the
 * desktop sidebar and the hosted Agent app use this helper, so optimistic
 * streaming and durable work-order/process objects share one identity shape. */
export function createAgentRunId(
  nowMs = Date.now(),
  randomValue = Math.random(),
): string {
  return `agent-run-${nowMs}-${Math.floor(randomValue * 0x1_0000_0000)
    .toString(16)
    .padStart(8, "0")}`;
}

export interface AgentActivityData {
  kind: "context_compaction";
  status: "running" | "complete" | "failed";
}

export interface ToolActivityItem {
  toolCallId: string;
  toolName: string;
  args: Record<string, JsonValue>;
  result?: JsonValue;
  isError?: boolean;
}

export type ToolActivityStep =
  | { kind: "reasoning"; text: string }
  | { kind: "commentary"; text: string }
  | { kind: "tool"; tool: ToolActivityItem };

export interface ToolActivityData {
  kind: "tool_activity";
  status: "running" | "complete" | "partial" | "failed";
  tools: ToolActivityItem[];
  steps: ToolActivityStep[];
}

export interface AgentSourceReference {
  url: string;
  title?: string;
}

export interface SourceSummaryData {
  kind: "source_summary";
  sources: AgentSourceReference[];
}

type ThreadPart = Extract<ThreadMessageLike["content"], readonly unknown[]>[number];

export interface AgentRunStatusLike {
  runStatus?: string;
  finalized?: boolean;
}

export interface AgentThreadPartLike {
  kind: "text" | "reasoning" | "tool" | "error" | string;
  text?: string;
  toolName?: string;
  done?: boolean;
  input?: JsonValue;
  output?: JsonValue;
  failed?: boolean;
  appSurface?: AbrumAppSurfaceReference;
}

export interface AgentThreadMessageLike extends AgentRunStatusLike {
  profileContext?: import("./profile-context.mjs").ProfileContext;
  humanInputResponse?: import("./human-question-data").HumanInputResponseRef;
  id?: string;
  role: string;
  text?: string;
  runID?: string;
  queueRequested?: boolean;
  parts?: AgentThreadPartLike[];
  attachments?: ChatAttachmentRef[];
}

export interface SandboxDeltaLike {
  kind?: string;
  text?: string;
  name?: string;
  input?: JsonValue;
  output?: JsonValue;
}

export interface SandboxThreadMessageLike {
  profileContext?: import("./profile-context.mjs").ProfileContext;
  cid: string;
  seq?: number;
  sessionId?: string;
  role: "user" | "assistant" | "system" | string;
  deltas: SandboxDeltaLike[];
  finalized?: boolean;
  updatedAtMs?: number;
  attachments?: ChatAttachmentRef[];
}

export function agentRunSurfaceKey(reference: AbrumAppSurfaceReference | null | undefined): string | null {
  if (reference?.appId !== AGENT_RUN_APP_ID || reference.surfaceId !== AGENT_RUN_SURFACE_ID) return null;
  const input = reference.input;
  if (!input || typeof input !== "object" || Array.isArray(input)) return null;
  const runId = (input as Record<string, JsonValue>).runId;
  return typeof runId === "string" && runId.trim()
    ? `${reference.roomId}:${runId.trim()}`
    : null;
}

function canonicalJsonValue(value: JsonValue): string {
  if (Array.isArray(value)) {
    return `[${value.map(canonicalJsonValue).join(",")}]`;
  }
  if (value && typeof value === "object") {
    return `{${Object.entries(value)
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([key, entry]) => `${JSON.stringify(key)}:${canonicalJsonValue(entry)}`)
      .join(",")}}`;
  }
  return JSON.stringify(value);
}

/** Identity of one rendered app surface inside a single assistant response.
 * Placement and presentation metadata deliberately do not participate: the
 * same Room/app/surface/input is one semantic preview, even when repeated by
 * several tool results or streamed and then persisted. */
export function appSurfaceKey(reference: AbrumAppSurfaceReference | null | undefined): string | null {
  if (!reference) return null;
  return canonicalJsonValue([
    reference.roomId,
    reference.appId,
    reference.surfaceId,
    reference.input ?? null,
  ]);
}

export function isAgentRunSurfaceReference(
  reference: AbrumAppSurfaceReference | null | undefined,
): boolean {
  return agentRunSurfaceKey(reference) !== null;
}

export function isAgentRunStatusRunning(status: string | null | undefined): boolean {
  return status === "queued" || status === "running";
}

/** Fold a Station SSE delta into the canonical ordered Agent parts. Both the
 * desktop sidebar and hosted Agent apps use this path, so text, reasoning,
 * tools, lifecycle activities and app surfaces cannot drift while streaming. */
export function appendAgentStreamDeltaToParts(
  parts: AgentThreadPartLike[] | undefined,
  event: AgentStreamDeltaEvent,
): AgentThreadPartLike[] {
  const next = parts ? [...parts] : [];
  const kind = event.kind || "text";
  const last = next[next.length - 1];
  switch (kind) {
    case "text":
    case "reasoning": {
      if (last && last.kind === kind && last.toolName === undefined) {
        next[next.length - 1] = {
          ...last,
          text: `${last.text ?? ""}${event.text}`,
        };
      } else {
        next.push({ kind, text: event.text });
      }
      return next;
    }
    case "tool_call": {
      const command = toolCommand(event.toolName || "tool", { script: event.text });
      next.push({
        kind: "tool",
        toolName: event.toolName || "tool",
        done: false,
        ...(command ? { input: { script: command } } : {}),
      });
      return next;
    }
    case "tool_result": {
      for (let index = next.length - 1; index >= 0; index -= 1) {
        const part = next[index];
        if (
          part.kind === "tool" &&
          !part.done &&
          (!event.toolName || part.toolName === event.toolName)
        ) {
          next[index] = { ...part, done: true };
          return next;
        }
      }
      next.push({
        kind: "tool",
        toolName: event.toolName || "tool",
        done: true,
      });
      return next;
    }
    case "activity": {
      if (event.toolName === "harness_progress") {
        const progress = progressFromStream(event.text);
        if (progress) next.push({ kind: "activity", text: "harness_progress", input: progress as unknown as JsonValue });
        return next;
      }
      if (event.toolName !== "context_compaction") return next;
      const done = event.text === "completed" || event.text === "complete";
      const failed = event.text === "failed" || event.text === "error";
      for (let index = next.length - 1; index >= 0; index -= 1) {
        const part = next[index];
        if (
          part.kind === "activity" &&
          part.text === event.toolName &&
          !part.done &&
          !part.failed
        ) {
          next[index] = { ...part, done, failed };
          return next;
        }
      }
      next.push({
        kind: "activity",
        text: event.toolName,
        done,
        failed,
      });
      return next;
    }
    case "app-surface": {
      if (!event.appSurface) return next;
      const key = appSurfaceKey(event.appSurface);
      if (
        key &&
        next.some((part) => appSurfaceKey(part.appSurface) === key)
      ) {
        return next;
      }
      next.push({ kind: "app-surface", appSurface: event.appSurface });
      return next;
    }
    case "error":
      next.push({ kind: "error", text: event.text });
      return next;
    default:
      return next;
  }
}

export function appendAgentStreamDeltaToAgentMessages<
  Message extends AgentThreadMessageLike,
>(
  messages: Message[] | undefined,
  event: AgentStreamDeltaEvent,
): Message[] {
  const current = messages ?? [];
  const index = current.findIndex(
    (message) =>
      message.role === "assistant" && message.runID === event.runID,
  );
  if (index === -1) {
    // A Run started in the Agent application reaches the shared Room before
    // the desktop sidebar has an optimistic assistant bubble of its own. The
    // durable user turn still carries the same runID, which safely identifies
    // the one cached thread allowed to adopt these live-only deltas. Without
    // this bridge the sidebar recognizes the thread but drops every action and
    // remains on its empty running fallback ("Thinking…") until finalization.
    const correlatedTurnIndex = current.findIndex(
      (message) => message.runID === event.runID,
    );
    if (correlatedTurnIndex === -1) return current;
    const promoted = current.map((message) =>
      message.runID === event.runID && message.runStatus === "queued"
        ? ({ ...message, runStatus: "running" } as Message)
        : message,
    );
    const draft = {
      role: "assistant",
      text: event.kind === "text" || !event.kind ? event.text : "",
      runID: event.runID,
      runStatus: "running",
      finalized: false,
      parts: appendAgentStreamDeltaToParts(undefined, event),
    } as Message;
    return [
      ...promoted.slice(0, correlatedTurnIndex + 1),
      draft,
      ...promoted.slice(correlatedTurnIndex + 1),
    ];
  }
  return current.map((message, messageIndex) => {
    if (message.runID !== event.runID) return message;
    if (messageIndex !== index) {
      // User content is finalized at submission, before its Run starts. That
      // seals the text, not the Run status used by the queue and history.
      return message.runStatus === "queued"
        ? ({ ...message, runStatus: "running" } as Message)
        : message;
    }
    if (message.finalized === true) return message;
    const kind = event.kind || "text";
    return {
      ...message,
      runStatus: "running",
      finalized: false,
      text:
        kind === "text"
          ? `${message.text ?? ""}${event.text}`
          : message.text,
      parts: appendAgentStreamDeltaToParts(message.parts, event),
    } as Message;
  });
}

function sandboxDeltaFromAgentStream(
  event: AgentStreamDeltaEvent,
): SandboxDeltaLike | null {
  const kind = event.kind || "text";
  if (kind === "activity" && event.toolName === "harness_progress") {
    const progress = progressFromStream(event.text);
    return progress ? { kind: "activity", name: "harness_progress", input: progress as unknown as JsonValue } : null;
  }
  if (kind === "text" || kind === "reasoning" || kind === "error") {
    return { kind, text: event.text };
  }
  if (kind === "tool_call" || kind === "tool_result") {
    const command = kind === "tool_call"
      ? toolCommand(event.toolName || "tool", { script: event.text })
      : null;
    return {
      kind,
      name: event.toolName || "tool",
      ...(command ? { input: { script: command } } : {}),
      ...(kind === "tool_result" ? { output: "done" } : {}),
    };
  }
  if (kind === "activity" && event.toolName === "context_compaction") {
    const complete = event.text === "completed" || event.text === "complete";
    const failed = event.text === "failed" || event.text === "error";
    const value = {
      toolCallId: "live-context-compaction",
      status: failed ? "failed" : complete ? "completed" : "in_progress",
      _meta: { contextCompaction: true },
    } satisfies Record<string, JsonValue>;
    return complete || failed
      ? { kind: "tool_result", name: "Context compacted", output: value }
      : { kind: "tool_call", name: "Context compacting", input: value };
  }
  if (kind === "app-surface" && event.appSurface) {
    return {
      kind: "tool_result",
      name: "app-surface",
      output: {
        data: { appSurface: event.appSurface as unknown as JsonValue },
      },
    };
  }
  return null;
}

export function appendAgentStreamDeltaToSandboxMessages<
  Message extends SandboxThreadMessageLike,
>(
  messages: Message[] | undefined,
  event: AgentStreamDeltaEvent,
  nowMs = Date.now(),
  options: { createIfMissing?: boolean } = {},
): Message[] {
  const current = messages ?? [];
  const index = current.findIndex(
    (message) =>
      message.role === "assistant" && message.sessionId === event.runID,
  );
  const delta = sandboxDeltaFromAgentStream(event);
  if (!delta) return current;
  if (index === -1) {
    if (!options.createIfMissing) return current;
    return [
      ...current,
      {
        cid: `live:${event.runID}:assistant`,
        sessionId: event.runID,
        role: "assistant",
        finalized: false,
        updatedAtMs: nowMs,
        deltas: [delta],
      } as Message,
    ];
  }
  return current.map((message, messageIndex) => {
    if (messageIndex !== index || message.finalized === true) return message;
    const surfaceKey = event.kind === "app-surface" ? appSurfaceKey(event.appSurface) : null;
    if (
      surfaceKey &&
      message.deltas.some((entry) => surfaceKey === appSurfaceKey(appSurfaceFromToolOutput(entry.output)))
    ) {
      return message;
    }
    return {
      ...message,
      finalized: false,
      updatedAtMs: nowMs,
      deltas: [...message.deltas, delta],
    } as Message;
  });
}

/** Add the user's prompt to a hosted Agent transcript before Station docking
 * completes. The caller-allocated Run id lets the later durable user twin
 * replace this local projection without showing a duplicate. */
export function appendOptimisticSandboxUserMessage<
  Message extends SandboxThreadMessageLike,
>(
  messages: Message[] | undefined,
  runId: string,
  text: string,
  attachments: ChatAttachmentRef[] = [],
  nowMs = Date.now(),
): Message[] {
  const current = messages ?? [];
  if (
    current.some(
      (message) => message.role === "user" && message.sessionId === runId,
    )
  ) {
    return current;
  }
  return [
    ...current,
    {
      cid: `live:${runId}:user`,
      seq: nowMs,
      sessionId: runId,
      role: "user",
      deltas: text ? [{ kind: "text", text }] : [],
      finalized: false,
      updatedAtMs: nowMs,
      attachments,
    } as Message,
  ];
}

/** Fold a durable agent thread over the live one WITHOUT discarding what only
 * exists client-side. The Station persists an assistant turn as ONE twin when
 * the run ends, so for the whole run the streamed reasoning/tool parts — and
 * the optimistic assistant bubble itself — live only in the client cache. Every
 * durable read (SSE push, send response, refetch) must therefore merge rather
 * than replace: a raw replace drops the bubble mid-run, and with it the `runID`
 * the stream keys on, so the rest of the run streams into nothing and the turn
 * shows a bare "Thinking…" until it finishes. */
export function mergeDurableAgentThreadMessages<
  Message extends AgentThreadMessageLike,
>(
  live: Message[] | undefined,
  durable: Message[],
): Message[] {
  if (!live?.length) return durable;
  // `runStatus` belongs to the whole Run, not to one transcript row. A stream
  // delta promotes every live row to `running`, but an immediately following
  // durable read can still contain the earlier queued user twin. Never let
  // that stale projection regress a Run for which this renderer has already
  // observed execution; otherwise the user prompt jumps back into the composer
  // queue while its assistant turn is visibly working.
  const liveRunningRunIds = new Set(
    live
      .filter((message) => message.runID && message.runStatus === "running")
      .map((message) => message.runID!),
  );
  // A control acknowledgement is newer than an in-flight queued/running read.
  // Terminal Run state is monotonic, even before its assistant row is written.
  const terminalRuns = new Map(
    [...live, ...durable]
      .filter((message) => message.runID && isAgentRunStatusTerminal(message.runStatus))
      .map((message) => [message.runID!, message.runStatus!] as const),
  );
  const merged = durable.map((durableMessage) => {
    const terminalStatus = durableMessage.runID && terminalRuns.get(durableMessage.runID);
    if (terminalStatus && !isAgentRunStatusTerminal(durableMessage.runStatus)) {
      return { ...durableMessage, runStatus: terminalStatus, finalized: true } as Message;
    }
    const message =
      (durableMessage.role !== "assistant" || durableMessage.finalized !== true) &&
      durableMessage.runID &&
      durableMessage.runStatus === "queued" &&
      liveRunningRunIds.has(durableMessage.runID)
        ? ({ ...durableMessage, runStatus: "running" } as Message)
        : durableMessage;
    if (message.role !== "assistant" || message.finalized === true || !message.runID) {
      return message;
    }
    const liveMessage = live.find(
      (candidate) => candidate.role === "assistant" && candidate.runID === message.runID,
    );
    if (!liveMessage) return message;
    // Durable reads of a live run carry only what the Station has persisted so
    // far, so the streamed parts are usually further along. Keep whichever side
    // has more; the durable turn wins once it is finalized (returned above).
    const withParts =
      (liveMessage.parts?.length ?? 0) > (message.parts?.length ?? 0)
        ? ({ ...message, parts: liveMessage.parts } as Message)
        : message;
    if (!liveMessage.text || !message.text || liveMessage.text.length <= message.text.length) {
      return withParts;
    }
    if (!liveMessage.text.startsWith(message.text)) {
      return withParts;
    }
    return { ...withParts, text: liveMessage.text } as Message;
  });
  // Keep a still-running assistant turn the durable thread has not caught up to
  // yet — during a native run that is every turn, because the assistant twin is
  // written only at the end.
  const durableRunIds = new Set(
    durable.filter((message) => message.role === "assistant" && message.runID).map((message) => message.runID),
  );
  for (const candidate of live) {
    if (candidate.role !== "assistant" || !isAgentMessageRunning(candidate)) continue;
    if (candidate.runID && (durableRunIds.has(candidate.runID) || terminalRuns.has(candidate.runID))) continue;
    if (
      candidate.runID &&
      merged.some((message) => message.role === "assistant" && message.runID === candidate.runID)
    ) {
      continue;
    }
    merged.push(candidate);
  }
  return merged;
}

/** Reconcile durable sandbox_message heads with the ephemeral local overlay.
 * A finalized durable message always wins. While a run is active, a newer live
 * projection (including the optimistically rendered user prompt) stays visible
 * until Station persistence catches up. */
export function mergeDurableSandboxMessages<
  Message extends SandboxThreadMessageLike,
>(
  live: Message[] | undefined,
  durable: Message[],
): Message[] {
  if (!live?.length) return durable;
  const key = (message: SandboxThreadMessageLike) =>
    `${message.sessionId ?? ""}\0${message.role}`;
  const liveByKey = new Map(live.map((message) => [key(message), message]));
  const durableKeys = new Set(durable.map(key));
  const merged = durable.map((message) => {
    if (message.finalized === true) return message;
    const streamed = liveByKey.get(key(message));
    if (!streamed || streamed.finalized === true) return message;
    return (streamed.updatedAtMs ?? 0) > (message.updatedAtMs ?? 0)
      ? ({ ...message, ...streamed, cid: message.cid } as Message)
      : message;
  });
  for (const message of live) {
    if (
      message.finalized !== true &&
      !durableKeys.has(key(message))
    ) {
      merged.push(message);
    }
  }
  return merged.sort(
    (left, right) =>
      (left.seq ?? left.updatedAtMs ?? 0) -
      (right.seq ?? right.updatedAtMs ?? 0),
  );
}

/** A live assistant turn is running until it is explicitly finalized or reaches
 * a terminal status. This is shared by the sidebar chat and the Agent app so
 * optimistic streamed drafts do not flicker differently across surfaces. */
export function isAgentMessageRunning(message: AgentRunStatusLike): boolean {
  if (message.finalized === true || isAgentRunStatusTerminal(message.runStatus)) return false;
  return isAgentRunStatusRunning(message.runStatus) || message.finalized === false || (!message.runStatus && message.finalized !== true);
}

function isAgentRunStatusTerminal(status: string | undefined): boolean {
  return status === "completed" || status === "cancelled" || status === "failed";
}

/** Select the current foreground Run in transcript order. An older unclaimed
 * send must not hold the composer open after later Runs have finished. Waiting
 * continuations do not replace the foreground Run until execution starts.
 * Group by first appearance so retained streaming overlays cannot reorder Runs. */
export function getActiveAgentThreadRun(
  messages: readonly AgentThreadMessageLike[],
): AgentThreadMessageLike | null {
  const runs = new Map<string | AgentThreadMessageLike, AgentThreadMessageLike[]>();
  for (const message of messages) {
    if (message.role !== "user" && message.role !== "assistant") continue;
    const key = message.runID || message;
    const run = runs.get(key);
    if (run) run.push(message);
    else runs.set(key, [message]);
  }

  const newestFirst = [...runs.values()].reverse();
  const finished = (run: AgentThreadMessageLike[]) => run.some((message) =>
    isAgentRunStatusTerminal(message.runStatus) ||
    (message.role === "assistant" && message.finalized === true),
  );
  // Cancelling a later queued continuation does not stop the executing Run.
  for (const run of newestFirst) {
    if (finished(run)) continue;
    const executing = run.find((message) => message.runStatus === "running");
    if (executing) return executing;
  }
  for (const run of newestFirst) {
    if (run.every((message) => message.queueRequested === true && message.runStatus === "queued")) continue;
    if (finished(run)) return null;
    return run.find((message) => message.role === "assistant"
      ? isAgentMessageRunning(message)
      : isAgentRunStatusRunning(message.runStatus)) ?? null;
  }
  return null;
}

export function isAgentThreadRunning(
  messages: readonly AgentThreadMessageLike[],
): boolean {
  return getActiveAgentThreadRun(messages) !== null;
}

function assistantStatus(running: boolean): MessageStatus {
  return running ? { type: "running" } : { type: "complete", reason: "unknown" };
}

function asThreadRole(role: string): ThreadMessageLike["role"] {
  return role === "assistant" || role === "system" ? role : "user";
}

function ensureContent(content: ThreadPart[]): ThreadPart[] {
  return content.length ? content : [{ type: "text", text: "" } as ThreadPart];
}

function toolActivityItem(part: ThreadPart): ToolActivityItem | null {
  if (part.type !== "tool-call") return null;
  const tool = part as unknown as ToolActivityItem & { type: "tool-call" };
  return {
    toolCallId: tool.toolCallId,
    toolName: tool.toolName,
    args: tool.args,
    ...(tool.result !== undefined ? { result: tool.result } : {}),
    ...(tool.isError === true ? { isError: true } : {}),
  };
}

const INTERNAL_FINALIZE_RUN_TOOL = "finalize_run";

/** Collapse reasoning, tool calls and native progress prose into one activity.
 * Final answers, app surfaces and other lifecycle data remain hard boundaries. */
function groupToolActivities(
  content: ThreadPart[],
  messageRunning: boolean,
  commentary: ReadonlySet<ThreadPart>,
): ThreadPart[] {
  const grouped: ThreadPart[] = [];
  let steps: ToolActivityStep[] = [];

  const flush = (canStillBeRunning: boolean) => {
    if (steps.length === 0) return;
    const tools = steps.flatMap((step) => step.kind === "tool" ? [step.tool] : []);
    const failedCount = tools.filter((tool) => tool.isError).length;
    const status = tools.length > 0 && failedCount === tools.length
      ? "failed"
      : failedCount > 0
        ? "partial"
        : canStillBeRunning && (
            steps.at(-1)?.kind !== "tool" ||
            tools.some((tool) => tool.result === undefined)
          )
          ? "running"
          : "complete";
    grouped.push({
      type: "data",
      name: ABRUM_TOOL_ACTIVITY_DATA_PART,
      data: { kind: "tool_activity", status, tools, steps } satisfies ToolActivityData,
    } as ThreadPart);
    steps = [];
  };

  for (const part of content) {
    if (commentary.has(part) && part.type === "text") {
      if (part.text.trim()) steps.push({ kind: "commentary", text: part.text });
      continue;
    }
    if (part.type === "reasoning") {
      const text = (part as { text?: string }).text?.trim();
      if (text) steps.push({ kind: "reasoning", text });
      continue;
    }
    const tool = toolActivityItem(part);
    if (tool) {
      // finalize_run is the Station's signed terminal receipt, not user-facing
      // work. Its finalText is appended as the following assistant text part,
      // so rendering the receipt duplicates the answer as "Finalize run".
      // Keep the durable tool deltas intact and suppress only this projection.
      if (tool.toolName === INTERNAL_FINALIZE_RUN_TOOL) continue;
      // request_user_input is an interactive HITL boundary. Keep it as a real
      // tool part so ChatThread's registered presenter can render the durable
      // question and submit the next user turn through the normal runtime.
      if (tool.toolName === "request_user_input") {
        flush(false);
        grouped.push(part);
        continue;
      }
      steps.push({ kind: "tool", tool });
      continue;
    }
    // A later transcript part proves that this tool block has yielded control
    // back to the assistant, even if a tool_result delta was not persisted.
    flush(false);
    grouped.push(part);
  }
  // Only an unresolved trailing block in a live assistant turn may still be
  // running. Terminal turns must never retain a stale activity spinner.
  flush(messageRunning);
  return grouped;
}

const MARKDOWN_LINK = /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/gi;
const WEB_URL = /https?:\/\/[^\s<>"']+/gi;

function normalizedSourceUrl(value: string): string | null {
  const trimmed = value.trim().replace(/[),.;!?]+$/g, "");
  try {
    const url = new URL(trimmed);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    url.hash = "";
    return url.toString();
  } catch {
    return null;
  }
}

const EXCLUDED_SOURCE_HOSTNAME = "json-schema.org";

function isExcludedSourceUrl(url: string): boolean {
  try {
    const hostname = new URL(url).hostname.toLowerCase().replace(/^www\./, "");
    return hostname === EXCLUDED_SOURCE_HOSTNAME || hostname.endsWith(`.${EXCLUDED_SOURCE_HOSTNAME}`);
  } catch {
    return false;
  }
}

function addSource(
  sources: Map<string, AgentSourceReference>,
  urlValue: string,
  titleValue?: string,
): void {
  const url = normalizedSourceUrl(urlValue);
  if (!url || isExcludedSourceUrl(url)) return;
  if (sources.size >= 16) return;
  const title = titleValue?.trim();
  const existing = sources.get(url);
  if (!existing) {
    sources.set(url, title ? { url, title } : { url });
  } else if (!existing.title && title) {
    sources.set(url, { url, title });
  }
}

function collectSourcesFromText(sources: Map<string, AgentSourceReference>, text: string): void {
  MARKDOWN_LINK.lastIndex = 0;
  for (const match of text.matchAll(MARKDOWN_LINK)) addSource(sources, match[2], match[1]);
  WEB_URL.lastIndex = 0;
  for (const match of text.matchAll(WEB_URL)) addSource(sources, match[0]);
}

function collectSourcesFromValue(
  sources: Map<string, AgentSourceReference>,
  value: JsonValue | undefined,
  depth = 0,
): void {
  if (value == null || depth > 6 || sources.size >= 16) return;
  if (typeof value === "string") {
    collectSourcesFromText(sources, value);
    if ((value.startsWith("{") || value.startsWith("[")) && value.length <= 100_000) {
      try {
        collectSourcesFromValue(sources, JSON.parse(value) as JsonValue, depth + 1);
      } catch {
        // Not JSON; URLs in the string were already collected above.
      }
    }
    return;
  }
  if (Array.isArray(value)) {
    for (const entry of value) collectSourcesFromValue(sources, entry, depth + 1);
    return;
  }
  if (typeof value !== "object") return;
  const record = value as Record<string, JsonValue>;
  const url = [record.url, record.sourceUrl, record.source_url, record.href]
    .find((entry): entry is string => typeof entry === "string");
  const title = [record.title, record.name, record.label]
    .find((entry): entry is string => typeof entry === "string");
  if (url) addSource(sources, url, title);
  for (const [key, entry] of Object.entries(record)) {
    if (key === "_meta" || key === "appSurface") continue;
    collectSourcesFromValue(sources, entry, depth + 1);
  }
}

export function sourceSummaryFromContent(content: readonly ThreadPart[]): SourceSummaryData | null {
  const sources = new Map<string, AgentSourceReference>();
  for (const part of content) {
    if (part.type === "text") {
      collectSourcesFromText(sources, (part as { text: string }).text);
    } else if (part.type === "tool-call") {
      collectSourcesFromValue(sources, (part as { result?: JsonValue }).result);
    }
  }
  return sources.size ? { kind: "source_summary", sources: [...sources.values()] } : null;
}

/** Native model prose is progress until the terminal tool returns. Keep it in
 * the activity disclosure instead of accumulating apparent final answers.
 * The host also emits `complete` after the durable answer commit. Live streams
 * omit tool result bodies, so this observation must reveal the trailing answer
 * without waiting for a full snapshot refetch. Ordinary model prose, plans and
 * tool-return events cannot supply that terminal observation.
 * Older completed snapshots without a receipt retain their trailing answer;
 * explicit errors always stay visible. This never edits the signed history. */
function progressCommentary(
  content: ThreadPart[],
  running: boolean,
  errors: ReadonlySet<ThreadPart>,
  lastPhase: ProgressEvent["phase"],
): Set<ThreadPart> {
  const finalizedIndex = content.findLastIndex((part) => {
    const tool = toolActivityItem(part);
    if (!tool || tool.toolName !== INTERNAL_FINALIZE_RUN_TOOL || tool.isError) return false;
    let result = tool.result;
    if (typeof result === "string") {
      try { result = JSON.parse(result); } catch { return false; }
    }
    return result != null && typeof result === "object" && !Array.isArray(result)
      && result.kind === "agent_run_finalization" && result.status === "finalized";
  });
  let answerStart = finalizedIndex >= 0 ? finalizedIndex + 1 : content.length;
  const committedAnswer = lastPhase === "complete"
    || (!running && !["failed", "cancelled", "needs_input"].includes(lastPhase));
  if (finalizedIndex < 0 && committedAnswer) {
    answerStart = content.findLastIndex((part) => part.type === "text" && !errors.has(part));
    while (answerStart > 0 && content[answerStart - 1].type === "text" && !errors.has(content[answerStart - 1])) {
      answerStart--;
    }
  }
  return new Set(content.filter((part, index) => part.type === "text" && !errors.has(part) && index < answerStart));
}

/** Presentation may settle on the durable host event before the stored snapshot
 * catches up. Only the latest valid progress event counts: a resumed run must
 * remain live. This does not finalize or mutate the signed message. */
function presentationRunning(content: ThreadPart[], running: boolean): boolean {
  if (!running) return false;
  for (let index = content.length - 1; index >= 0; index--) {
    const part = content[index];
    if (part.type !== "data" || part.name !== RUN_PROGRESS_PART) continue;
    const event = parseProgress(part.data);
    if (event) return event.phase !== "complete";
  }
  return running;
}

function finalizeAssistantContent(content: ThreadPart[], running: boolean, errors: ReadonlySet<ThreadPart>): ThreadPart[] {
  const events: ProgressEvent[] = [];
  const deliveredResults = new Set<string>();
  const rest = content.flatMap((part): ThreadPart[] => {
    if (part.type !== "data" || part.name !== RUN_PROGRESS_PART) return [part];
    const event = parseProgress(part.data);
    if (!event || events.some((e) => e.atMs === event.atMs && e.phase === event.phase && e.toolName === event.toolName)) return [];
    events.push(event);
    const result: ThreadPart[] = [];
    if (event.publicResult && !deliveredResults.has(event.publicResult)) {
      deliveredResults.add(event.publicResult);
      // Host-validated partial answers use the ordinary Markdown/copy path.
      // They are not provider prose and must never collapse into commentary.
      result.push({ type: "text", text: event.publicResult });
    }
    if (event.publicReport) result.push({ type: "data", name: PUBLIC_PROGRESS_PART, data: event } as ThreadPart);
    return result;
  });
  // Earlier reports remain in the signed progress events, but a running chat
  // needs one current update. Showing every replacement paragraph makes an
  // ordinary long Run read like the assistant forgot its previous report.
  const latestReportIndex = rest.findLastIndex((part) =>
    part.type === "data" && part.name === PUBLIC_PROGRESS_PART);
  const visibleRest = rest.filter((part, index) =>
    part.type !== "data" || part.name !== PUBLIC_PROGRESS_PART || index === latestReportIndex);
  const commentary = events.length ? progressCommentary(content, running, errors, events.at(-1)!.phase) : new Set<ThreadPart>();
  const grouped = groupToolActivities(visibleRest, running, commentary);
  if (!running) {
    const summary = sourceSummaryFromContent(content);
    if (summary) {
      grouped.push({ type: "data", name: ABRUM_SOURCE_SUMMARY_DATA_PART, data: summary } as ThreadPart);
    }
  }
  // The compact thinking/tool status is a live footer for the assistant turn.
  // Keep its internal steps chronological, but place every activity group
  // after answer text and other message parts so streamed updates cannot jump
  // above content that arrived later.
  const activities: ThreadPart[] = [];
  const transcript = grouped.filter((part) => {
    if (part.type === "data" && part.name === ABRUM_TOOL_ACTIVITY_DATA_PART) {
      activities.push(part);
      return false;
    }
    return true;
  });
  // The live shimmer describes the whole Run, so it follows both the current
  // report and the thinking/tool history, regardless of their arrival order.
  const progress = events.length ? [{ type: "data", name: RUN_PROGRESS_PART,
    data: { events, running } } as ThreadPart] : [];
  return ensureContent([...transcript, ...activities, ...progress]);
}

function appendAttachmentParts(content: ThreadPart[], attachments: ChatAttachmentRef[] | undefined): void {
  for (const attachment of attachments ?? []) {
    if (!attachment?.blobHash || !attachment.name) continue;
    content.push({ type: "data", name: ABRUM_CHAT_ATTACHMENT_DATA_PART, data: attachment } as ThreadPart);
  }
}

function appendTextPart(content: ThreadPart[], type: "text" | "reasoning", text: string, errors: ReadonlySet<ThreadPart>): void {
  const last = content[content.length - 1];
  if (last && last.type === type && !errors.has(last)) {
    const previous = (last as { text: string }).text;
    // Streaming chunks normally carry their own whitespace and must stay byte-
    // adjacent ("hel" + "lo"). Persisted native-agent deltas, however, are one
    // complete model turn each; providers often omit the leading space on the
    // next turn ("Done!" + "Next step"). Add only the missing sentence boundary
    // so both representations render naturally, including existing stored runs.
    const separator =
      previous && text && !/\s$/.test(previous) && !/^\s/.test(text) && /[.!?…:;]$/.test(previous) ? " " : "";
    content[content.length - 1] = { ...last, text: `${previous}${separator}${text}` } as ThreadPart;
    return;
  }
  content.push({ type, text } as ThreadPart);
}

export function convertAgentMessageToThreadMessage(message: AgentThreadMessageLike, idx = 0): ThreadMessageLike {
  message = presentProfileMessage(message);
  const role = asThreadRole(message.role);
  if (role !== "assistant") {
    const content: ThreadPart[] = [{ type: "text", text: message.text ?? "" } as ThreadPart];
    if (message.profileContext) content.push({type:"data", name:PROFILE_CONTEXT_PART, data:message.profileContext} as ThreadPart);
    appendAttachmentParts(content, message.attachments);
    return {
      role,
      id: message.id ?? (message.runID ? `${message.runID}:${role}` : `local-${role}-${idx}`),
      content,
      metadata: { custom: { ...(message.humanInputResponse ? { humanInputResponse: message.humanInputResponse } : {}) } },
    } as ThreadMessageLike;
  }

  const content: ThreadPart[] = [];
  const errors = new Set<ThreadPart>();
  const appSurfaceIndex = new Map<string, number>();
  const running = isAgentMessageRunning(message);
  if (message.parts?.length) {
    let toolIdx = 0;
    for (const part of message.parts) {
      if (part.kind === "activity" && part.text === "harness_progress") {
        content.push({ type: "data", name: RUN_PROGRESS_PART, data: part.input } as ThreadPart);
      } else if (part.kind === "text") {
        content.push({ type: "text", text: part.text ?? "" } as ThreadPart);
      } else if (part.kind === "reasoning") {
        content.push({ type: "reasoning", text: part.text ?? "" } as ThreadPart);
      } else if (part.kind === "tool") {
        const result = part.done
          ? readableToolOutput(part.output) ?? part.output ?? (part.failed ? "failed" : "done")
          : undefined;
        content.push({
          type: "tool-call",
          toolCallId: `${message.runID ?? "run"}:tool:${toolIdx++}`,
          toolName: part.toolName ?? "tool",
          args: asArgsObject(part.input),
          result,
          isError: part.failed === true,
        } as ThreadPart);
        if (part.done && !part.failed) for (const chat of chatReferencesFromReceipt(part.output)) {
          content.push({ type: "data", name: CHAT_REFERENCE_PART, data: chat } as ThreadPart);
        }
        if (part.done && !part.failed) {
          const returned = chatReferenceFromParentReturnRead(part.output, message.runID);
          if (returned) content.push({ type: "data", name: CHAT_REFERENCE_PART, data: returned } as ThreadPart);
        }
        if (part.done && !part.failed) for (const result of finalizedAppResults(part.output)) {
          content.push({ type: "data", name: ABRUM_APP_RESULT_DATA_PART, data: result } as ThreadPart);
        }
      } else if (part.kind === "error") {
        const error = { type: "text", text: part.text ? `⚠️ ${part.text}` : "⚠️" } as ThreadPart;
        errors.add(error);
        content.push(error);
      } else if (part.kind === "activity" && part.text === "context_compaction") {
        content.push({
          type: "data",
          name: ABRUM_AGENT_ACTIVITY_DATA_PART,
          data: {
            kind: "context_compaction",
            status: part.failed ? "failed" : part.done ? "complete" : "running",
          } satisfies AgentActivityData,
        } as ThreadPart);
      } else if (part.kind === "app-surface" && part.appSurface) {
        // This surface represents a delegated Run, not the parent message's
        // streaming state. Keep its live projection after SINA hands off.
        const surfacePart = { type: "data", name: ABRUM_APP_SURFACE_DATA_PART, data: part.appSurface } as ThreadPart;
        const key = appSurfaceKey(part.appSurface);
        const existing = key ? appSurfaceIndex.get(key) : undefined;
        if (existing === undefined) {
          if (key) appSurfaceIndex.set(key, content.length);
          content.push(surfacePart);
        } else {
          content[existing] = surfacePart;
        }
      }
    }
  } else if (message.text) {
    content.push({ type: "text", text: message.text } as ThreadPart);
  }
  appendAttachmentParts(content, message.attachments);

  const visiblyRunning = presentationRunning(content, running);
  return {
    role: "assistant",
    id: message.id ?? (message.runID ? `${message.runID}:assistant` : `local-assistant-${idx}`),
    content: finalizeAssistantContent(content, visiblyRunning, errors),
    status: assistantStatus(visiblyRunning),
    metadata: { custom: { abrumRunStatus: message.runStatus } },
  };
}

function asArgsObject(input: JsonValue | undefined): Record<string, JsonValue> {
  if (input && typeof input === "object" && !Array.isArray(input)) {
    return input as Record<string, JsonValue>;
  }
  return input === undefined ? {} : { value: input };
}

export function convertSandboxMessageToThreadMessage(
  message: SandboxThreadMessageLike,
  options: { running?: boolean } = {},
): ThreadMessageLike {
  const role = asThreadRole(message.role);
  if (message.role === "user") {
    const split = separateProfileContext(message.deltas.filter(d=>d.kind === "text").map(d=>d.text || "").join(""), message.profileContext);
    if (split.context) return convertAgentMessageToThreadMessage({role:"user",id:message.cid,text:split.text,profileContext:split.context,attachments:message.attachments},0);
  }
  const running = Boolean(options.running && !message.finalized);
  const content: ThreadPart[] = [];
  const errors = new Set<ThreadPart>();
  const openToolIndex = new Map<string, number>();
  const activityIndex = new Map<string, number>();
  const appSurfaceIndex = new Map<string, number>();
  let toolSeq = 0;

  for (const delta of message.deltas) {
    if ((delta.kind === "activity" || delta.kind === "text") && delta.name === "harness_progress") {
      content.push({ type: "data", name: RUN_PROGRESS_PART, data: delta.input } as ThreadPart);
    } else if ((delta.kind === "text" || delta.kind === "reasoning") && typeof delta.text === "string") {
      appendTextPart(content, delta.kind, delta.text, errors);
    } else if (delta.kind === "error" && typeof delta.text === "string") {
      const error = { type: "text", text: `⚠️ ${delta.text}` } as ThreadPart;
      errors.add(error);
      content.push(error);
    } else if (delta.kind === "tool_call" && contextCompactionData(delta.input)) {
      const update = contextCompactionData(delta.input)!;
      const id = contextCompactionId(delta.input) ?? "context_compaction";
      const index = activityIndex.get(id);
      const part = {
        type: "data",
        name: ABRUM_AGENT_ACTIVITY_DATA_PART,
        data: update,
      } as ThreadPart;
      if (index === undefined) {
        activityIndex.set(id, content.length);
        content.push(part);
      } else {
        content[index] = part;
      }
    } else if (delta.kind === "tool_result" && contextCompactionData(delta.output)) {
      const update = contextCompactionData(delta.output)!;
      const id = contextCompactionId(delta.output) ?? "context_compaction";
      const index = activityIndex.get(id);
      const part = {
        type: "data",
        name: ABRUM_AGENT_ACTIVITY_DATA_PART,
        data: update,
      } as ThreadPart;
      if (index === undefined) {
        activityIndex.set(id, content.length);
        content.push(part);
      } else {
        content[index] = part;
      }
    } else if (delta.kind === "tool_call") {
      const name = delta.name || "tool";
      content.push({
        type: "tool-call",
        toolCallId: `${message.cid}:tool:${toolSeq++}`,
        toolName: name,
        args: asArgsObject(delta.input),
        isError: isFailedToolValue(delta.input),
      } as ThreadPart);
      openToolIndex.set(name, content.length - 1);
    } else if (delta.kind === "tool_result") {
      const name = delta.name || "tool";
      const result: JsonValue = readableToolOutput(delta.output) ?? delta.output ?? "done";
      const index = openToolIndex.get(name);
      if (index !== undefined) {
        content[index] = {
          ...(content[index] as object),
          result,
          isError: isFailedToolValue(delta.output),
        } as ThreadPart;
        openToolIndex.delete(name);
      } else {
        content.push({
          type: "tool-call",
          toolCallId: `${message.cid}:tool:${toolSeq++}`,
          toolName: name,
          args: {},
          result,
          isError: isFailedToolValue(delta.output),
        } as ThreadPart);
      }
      // The typed receipt validates each assignment, including partial batches.
      for (const chat of chatReferencesFromReceipt(delta.output)) {
        content.push({ type: "data", name: CHAT_REFERENCE_PART, data: chat } as ThreadPart);
      }
      const returned = chatReferenceFromParentReturnRead(delta.output, message.sessionId);
      if (returned) content.push({ type: "data", name: CHAT_REFERENCE_PART, data: returned } as ThreadPart);
      const appSurface = appSurfaceFromToolOutput(delta.output);
      for (const result of finalizedAppResults(delta.output)) {
        content.push({ type: "data", name: ABRUM_APP_RESULT_DATA_PART, data: result } as ThreadPart);
      }
      if (appSurface) {
        const surfacePart = { type: "data", name: ABRUM_APP_SURFACE_DATA_PART, data: appSurface } as ThreadPart;
        const key = appSurfaceKey(appSurface);
        const existing = key ? appSurfaceIndex.get(key) : undefined;
        if (existing === undefined) {
          if (key) appSurfaceIndex.set(key, content.length);
          content.push(surfacePart);
        } else {
          content[existing] = surfacePart;
        }
      }
    }
  }
  appendAttachmentParts(content, message.attachments);

  const visiblyRunning = presentationRunning(content, running);
  return {
    role,
    id: message.cid,
    content: role === "assistant" ? finalizeAssistantContent(content, visiblyRunning, errors) : ensureContent(content),
    ...(role === "assistant" ? { status: assistantStatus(visiblyRunning) } : {}),
  } as ThreadMessageLike;
}

function contextCompactionRecord(value: JsonValue | undefined): Record<string, JsonValue> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const record = value as Record<string, JsonValue>;
  const meta = record._meta;
  if (!meta || typeof meta !== "object" || Array.isArray(meta)) return null;
  return (meta as Record<string, JsonValue>).contextCompaction === true ? record : null;
}

function contextCompactionId(value: JsonValue | undefined): string | null {
  const record = contextCompactionRecord(value);
  return record && typeof record.toolCallId === "string" ? record.toolCallId : null;
}

function contextCompactionData(value: JsonValue | undefined): AgentActivityData | null {
  const record = contextCompactionRecord(value);
  if (!record) return null;
  const status = typeof record.status === "string" ? record.status.toLowerCase() : "";
  return {
    kind: "context_compaction",
    status: status === "failed" || status === "error"
      ? "failed"
      : status === "completed" || status === "complete"
        ? "complete"
        : "running",
  };
}

function isFailedToolValue(value: JsonValue | undefined, depth = 0): boolean {
  if (value === undefined || value === null || depth > 6) return false;
  if (Array.isArray(value)) return value.some((entry) => isFailedToolValue(entry, depth + 1));
  if (typeof value !== "object") return false;
  const object = value as Record<string, JsonValue>;
  const status = typeof object.status === "string" ? object.status.toLowerCase() : "";
  return object.isError === true || object.error != null || status === "failed" || status === "error" ||
    Object.values(object).some((entry) => isFailedToolValue(entry, depth + 1));
}

/** Find the standard `{ appSurface: ... }` result envelope emitted by an app
 * function. Tool adapters may wrap it in `data`, `result`, or a JSON string. */
export function appSurfaceFromToolOutput(value: JsonValue | undefined): AbrumAppSurfaceReference | null {
  return findAppSurface(value, 0);
}

function findAppSurface(value: JsonValue | undefined, depth: number): AbrumAppSurfaceReference | null {
  if (value === undefined || depth > 6) return null;
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (!trimmed.startsWith("{") && !trimmed.startsWith("[")) return null;
    try {
      return findAppSurface(JSON.parse(trimmed) as JsonValue, depth + 1);
    } catch {
      return null;
    }
  }
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const record = value as Record<string, JsonValue>;
  const candidate = record.appSurface;
  if (candidate && typeof candidate === "object" && !Array.isArray(candidate)) {
    const surface = candidate as Record<string, JsonValue>;
    if (
      typeof surface.roomId === "string" && surface.roomId.trim()
      && typeof surface.appId === "string" && surface.appId.trim()
      && typeof surface.surfaceId === "string" && surface.surfaceId.trim()
    ) {
      return {
        roomId: surface.roomId.trim(),
        appId: surface.appId.trim(),
        surfaceId: surface.surfaceId.trim(),
        input: surface.input,
        placement: surface.placement === "app" || surface.placement === "inline"
          || surface.placement === "modal" || surface.placement === "window"
          ? surface.placement
          : undefined,
      };
    }
  }
  for (const key of ["data", "result", "output", "structuredContent"]) {
    const found = findAppSurface(record[key], depth + 1);
    if (found) return found;
  }
  return null;
}

// Extract user-facing text from a tool output envelope, mirroring how agent
// adapters nest readable text (.text / .output / .stdout / .content[].text).
export function readableToolOutput(value: JsonValue | undefined): string | null {
  if (typeof value === "string") {
    return value.trim() ? value : null;
  }
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return null;
  }
  const record = value as Record<string, JsonValue>;
  for (const key of ["text", "output", "stdout", "stderr"]) {
    const inner = record[key];
    if (typeof inner === "string" && inner.trim()) {
      return inner;
    }
    if (inner && typeof inner === "object") {
      const nested = readableToolOutput(inner);
      if (nested) return nested;
    }
  }
  const contentValue = record.content;
  if (Array.isArray(contentValue)) {
    const parts = contentValue
      .map((entry) => (entry && typeof entry === "object" && !Array.isArray(entry) ? (entry as Record<string, JsonValue>).text : null))
      .filter((text): text is string => typeof text === "string" && Boolean(text.trim()));
    if (parts.length > 0) {
      return parts.join("\n");
    }
  }
  return null;
}
