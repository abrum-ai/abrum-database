import { PHASE_LABELS, parseCompactionProgress, progressClock, type CompactionProgress, type RunProgressData } from "./run-progress";

// Counts are observations, not percentages or an ETA. Keep even a valid but
// enormous imported count bounded without pretending it is an exact small total.
const MAX_VISIBLE_COMPACTION_COUNT = 99_999;
function compactionCounts(state: CompactionProgress, de: boolean): string {
  if (state.totalBatches === 0) return "";
  const format = (n: number) => n.toLocaleString(de ? "de-DE" : "en-US");
  const count = (n: number) => n > MAX_VISIBLE_COMPACTION_COUNT
    ? `${de ? "mehr als" : "more than"} ${format(MAX_VISIBLE_COMPACTION_COUNT)}` : format(n);
  const sections = state.checkpointReused ? (de ? "weiteren Abschnitten" : "additional sections") : (de ? "Abschnitten" : "sections");
  return de
    ? `${count(state.completedBatches)} von ${count(state.totalBatches)} ${sections} gespeichert.`
    : `${count(state.completedBatches)} of ${count(state.totalBatches)} ${sections} saved.`;
}

function compactionDetail(state: CompactionProgress, de: boolean): string {
  const pick = (a: string, b: string) => de ? a : b;
  const source = state.sourceMessages > 0 && state.sourceMessages <= MAX_VISIBLE_COMPACTION_COUNT
    ? pick(`${state.sourceMessages.toLocaleString("de-DE")} frühere Nachrichten.`, `${state.sourceMessages.toLocaleString("en-US")} earlier messages.`) : "";
  return [
    state.mode === "initial"
      ? pick("Erstmalige Vorbereitung dieses bisherigen Verlaufs.", "First-time preparation of this earlier history.") : "",
    source,
    compactionCounts(state, de),
    state.checkpointReused
      ? pick("Bereits gespeicherte Zusammenfassungen werden weiterverwendet.", "Previously saved summaries are being reused.") : "",
    state.state === "retrying"
      ? pick("Ein Abschnitt wird erneut angefragt.", "A section is being requested again.") : "",
    pick("Die Antwort auf deinen Auftrag steht noch aus.", "The answer to your request is still pending."),
    pick("Gespeicherte Abschnitte bleiben bei Stopp erhalten.", "Saved sections are retained if you stop."),
  ].filter(Boolean).join(" ");
}

/** Public intentions come only from the accepted plan, never reasoning or tool
 * arguments. Host observations establish lifecycle/evidence, not business success.
 * Elapsed time alone cannot establish either a fault or healthy execution. */
export function customerProgress(data: RunProgressData, now: number, de: boolean) {
  const evidence = progressClock(data, now);
  const pick = (a: string, b: string) => de ? a : b;
  const last = data.events.at(-1);
  // Validate again at the projection boundary: callers can load older or
  // malformed persisted data without going through the live stream parser.
  const compaction = last?.phase === "context_compaction" ? parseCompactionProgress(last.compaction) : null;
  const plan = data.events.findLast(e => e.phase === "plan");
  let label = plan?.publicActivity ?? (plan
    ? pick("Die Antwort steht noch aus.", "The answer is still pending.")
    : last ? PHASE_LABELS[last.phase][de ? 0 : 1] : pick("Auftrag angenommen.", "Request received."));
  let detail = "";
  let tone: "working" | "waiting" | "warning" | "done" = "working";
  let stage = plan?.publicActivity ? "activity" : "accepted";
  if (!evidence.active) {
    tone = "done";
    stage = last?.phase ?? "ended";
    switch (last?.phase) {
      case "complete": label = pick("Antwort bereit", "Answer ready"); break;
      case "needs_input": label = pick("Deine Antwort wird benötigt.", "Your answer is needed."); break;
      case "failed": label = pick("Ich konnte den Auftrag nicht abschließen.", "I couldn't complete the request."); tone = "warning"; break;
      case "cancelled": label = pick("Auftrag gestoppt", "Request stopped"); break;
      default: label = pick("Bearbeitung beendet · Abschluss nicht bestätigt.", "Processing ended · completion unconfirmed.");
    }
    if (last?.phase === "cancelled" || last?.phase === "failed" || last?.phase === "context_compaction") {
      const saved = parseCompactionProgress(data.events.findLast(e => e.phase === "context_compaction")?.compaction);
      if (saved && saved.completedBatches > 0) detail = `${compactionCounts(saved, de)} ${pick("Gespeicherte Abschnitte bleiben für die Fortsetzung erhalten.", "Saved sections are retained for continuation.")}`;
    }
  } else if (last?.phase === "model_retry" || last?.phase === "tool_failed") {
    tone = "warning";
    stage = "problem";
    detail = last.phase === "model_retry"
      ? pick("Eine Anfrage ist fehlgeschlagen und wird erneut versucht.", "A request failed and is being retried.")
      : pick("Bei diesem Schritt wurde ein Problem gemeldet. Der Auftrag ist noch nicht abgeschlossen.", "A problem was reported for this step. The request is not finished yet.");
  } else if (last?.phase === "approval_pending" && evidence.waitingMs < 600_000) {
    tone = "waiting";
    stage = "approval_pending";
    label = pick("Deine Freigabe wird benötigt.", "Your approval is needed.");
    detail = pick("Bitte bestätige die Aktion im Warden. Danach geht es automatisch weiter.", "Please approve the action in Warden. It will continue automatically.");
  } else if (last?.phase === "approval_granted") {
    tone = "waiting";
    stage = "awaiting_response";
    label = pick("Freigabe erhalten.", "Approval received.");
    detail = evidence.stale
      ? pick("Die Ausführung hat noch keine Bestätigung geliefert. Bitte nicht erneut senden.", "Execution has not returned confirmation yet. Please do not send again.")
      : pick("Die Aktion wird fortgesetzt. Die Bestätigung steht noch aus.", "The action is continuing. Confirmation is still pending.");
  } else if (last?.phase === "context_compaction") {
    tone = compaction?.state === "retrying" ? "warning" : "waiting";
    stage = "context_compaction";
    label = pick("Ich fasse den bisherigen Chat zusammen.", "I'm summarizing the earlier conversation.");
    if (compaction && compaction.totalBatches > 0) {
      label = compaction.state === "complete"
        ? pick("Chat-Zusammenfassung gespeichert.", "Conversation summary saved.")
        : compaction.mode === "initial"
          ? pick("Ich fasse den bisherigen Chat erstmals zusammen.", "I'm summarizing the earlier conversation for the first time.")
          : compaction.mode === "resumed"
            ? pick("Ich setze die Zusammenfassung des Chats fort.", "I'm continuing the conversation summary.")
            : pick("Ich ergänze die Zusammenfassung des Chats.", "I'm updating the conversation summary.");
      detail = compactionDetail(compaction, de);
    } else {
      // Older events have no plan counts. Never fabricate an initial/full pass,
      // denominator, reused checkpoint or summary-completion receipt for them.
      detail = evidence.stale
        ? pick("Die Zusammenfassung steht noch aus. Fertige Abschnitte bleiben bei einem Abbruch erhalten.", "The summary is still pending. Completed sections are retained if you stop.")
        : pick("So bleiben frühere Ergebnisse und offene Aufgaben für diesen Auftrag erhalten.", "This preserves earlier results and unfinished tasks for this request.");
    }
  } else if (evidence.stale) {
    // Age qualifies the evidence, not the task. Keep the last declared intention
    // visible instead of inventing a new phase or implying a connection failure.
    tone = "waiting";
    stage = "unconfirmed";
    detail = pick("Für diesen Schritt liegt noch keine neuere Rückmeldung vor.", "No newer response is available for this step yet.");
  } else if (last?.phase === "tool") {
    // A call entered host dispatch: a pending response, NOT proof a remote action ran.
    tone = "waiting";
    stage = "awaiting_response";
    // Avoid flashing a second line for sub-second tool calls. The pending
    // response itself is evidenced by dispatch, never invented by this clock.
    if (evidence.waitingMs >= 1000) detail = pick("Die angefragte Rückmeldung steht noch aus.", "The requested response is still pending.");
  } else if (!plan?.publicActivity) {
    tone = "waiting";
  }
  return { label, detail, tone, stage, active: evidence.active,
    elapsedMs: evidence.elapsedMs, showElapsed: evidence.elapsedMs >= 10_000, guidance: "" };
}
