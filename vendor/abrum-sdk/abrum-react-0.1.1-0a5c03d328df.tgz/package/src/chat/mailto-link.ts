/*
 * A chat message may contain a bare email address (GFM autolinks it to
 * `mailto:`) or an authored `mailto:` link. On the desktop that address must
 * reach the operating system's mail app instead of navigating the renderer.
 *
 * Only a plain recipient is allowed: no injected headers, attachments,
 * multiple recipients, percent escapes or arbitrary app schemes. This mirrors
 * the desktop main-process policy in `desktop/src/external-link-policy.mjs`;
 * the renderer and the Electron bridge must agree on the same boundary.
 */
export function isPlainMailtoLink(value: string): boolean {
  return /^mailto:[a-z0-9.!#$&'*+\/=_`{|}~-]+@[a-z0-9.-]+\.[a-z]{2,}$/i.test(value);
}
