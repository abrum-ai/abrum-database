import type { AgentRuntimeChoice, AgentRuntimeSelection } from "./runtime-picker";

/** API providers the Station-owned native harness can run. */
export const SELECTABLE_AGENT_PROVIDER_IDS = ["openrouter", "ionos", "openai-compatible"] as const;

export type SelectableAgentProviderId = (typeof SELECTABLE_AGENT_PROVIDER_IDS)[number];

/** Providers a station offers before anyone visits Settings. */
export const DEFAULT_ENABLED_AGENT_PROVIDERS: SelectableAgentProviderId[] = [
  "openai-compatible",
];

/** IONOS speaks the OpenAI protocol; only this endpoint is German-hosted. */
export const IONOS_DEFAULT_BASE_URL = "https://openai.inference.de-txl.ionos.com/v1";

export const FALLBACK_AGENT_RUNTIME_OPTIONS: AgentRuntimeChoice[] = [
  {
    value: "openrouter",
    label: "OpenRouter API",
    description: "Uses the Room-linked OpenRouter credential. Any OpenRouter model id can be entered.",
    icon: "openrouter",
    defaultModel: "openai/gpt-5.4-mini",
    defaultReasoningEffort: "default",
    modelPlaceholder: "provider/model",
    allowCustomModel: true,
    models: [{ value: "openai/gpt-5.4-mini", label: "GPT-5.4 Mini", icon: "openai" }],
    reasoningEfforts: [
      { value: "default", label: "Default" },
      { value: "none", label: "None" },
      { value: "minimal", label: "Minimal" },
      { value: "low", label: "Low" },
      { value: "medium", label: "Medium" },
      { value: "high", label: "High" },
      { value: "xhigh", label: "Extra high" },
      { value: "max", label: "Max" },
      { value: "ultra", label: "Ultra" },
    ],
  },
  {
    value: "ionos",
    label: "IONOS AI Model Hub",
    description: "German-hosted inference. Uses the station-local IONOS credential.",
    icon: "ionos",
    defaultModel: "openai/gpt-oss-120b",
    defaultReasoningEffort: "default",
    modelPlaceholder: "model name",
    allowCustomModel: true,
    models: [
      { value: "openai/gpt-oss-120b", label: "GPT-OSS 120B", icon: "ionos" },
      { value: "meta-llama/Llama-3.3-70B-Instruct", label: "Llama 3.3 70B Instruct", icon: "ionos" },
      { value: "mistralai/Mistral-Small-24B-Instruct", label: "Mistral Small 24B Instruct", icon: "ionos" },
    ],
    reasoningEfforts: [
      { value: "default", label: "Default" },
      { value: "none", label: "None" },
      { value: "low", label: "Low" },
      { value: "medium", label: "Medium" },
      { value: "high", label: "High" },
    ],
  },
  {
    value: "openai-compatible",
    label: "ABRUM Gateway",
    description: "Uses the included ABRUM AI budget.",
    icon: "abrum",
    defaultModel: "abrum/glm-5.3-flash",
    defaultReasoningEffort: "default",
    modelPlaceholder: "model name",
    allowCustomModel: true,
    models: [{ value: "abrum/glm-5.3-flash", label: "GLM 5.3 Flash", icon: "abrum" }],
    reasoningEfforts: [
      { value: "default", label: "Default" },
      { value: "none", label: "None" },
      { value: "minimal", label: "Minimal" },
      { value: "low", label: "Low" },
      { value: "medium", label: "Medium" },
      { value: "high", label: "High" },
    ],
  },
];

const DEFAULT_AGENT_RUNTIME_OPTIONS = FALLBACK_AGENT_RUNTIME_OPTIONS.filter((option) =>
  DEFAULT_ENABLED_AGENT_PROVIDERS.includes(option.value as SelectableAgentProviderId),
);

export function defaultAgentRuntimeSelection(
  runtimeValue: unknown = "openai-compatible",
  options: AgentRuntimeChoice[] = DEFAULT_AGENT_RUNTIME_OPTIONS,
): AgentRuntimeSelection {
  const runtime = normalizeRuntimeName(runtimeValue);
  const option =
    options.find((candidate) => candidate.value === runtime && candidate.available !== false) ??
    options.find((candidate) => candidate.available !== false) ??
    // Nothing is ready yet (a provider enabled but not keyed). Stay inside the
    // offered list anyway, so what the picker SHOWS is what a message is sent
    // to — resolving to an unlisted provider is how the two drift apart.
    options.find((candidate) => candidate.value === runtime) ??
    options[0] ??
    DEFAULT_AGENT_RUNTIME_OPTIONS[0];
  return {
    runtime: option.value,
    model: option.defaultModel,
    reasoningEffort: option.defaultReasoningEffort,
  };
}

export function normalizeAgentRuntimeSelection(
  value: unknown,
  options: AgentRuntimeChoice[] = DEFAULT_AGENT_RUNTIME_OPTIONS,
): AgentRuntimeSelection {
  const raw = asRecord(value);
  const fallback = defaultAgentRuntimeSelection(raw.runtime ?? raw.agent, options);
  const option = options.find((candidate) => candidate.value === fallback.runtime);
  // A model id only means something WITH its provider. When the requested
  // runtime is not the one we land on — it was disabled, hidden or never
  // existed — the requested model belongs to another provider and must not
  // ride along; providers that accept any id would otherwise take it.
  const requestedRuntime = cleanString(raw.runtime) || cleanString(raw.agent);
  const runtimeHonoured = !requestedRuntime || requestedRuntime === fallback.runtime;
  const requestedModel = (runtimeHonoured && cleanString(raw.model)) || fallback.model;
  const model = option?.allowCustomModel || option?.models.some((candidate) => candidate.value === requestedModel)
    ? requestedModel
    : fallback.model;
  const modelOption = option?.models.find((candidate) => candidate.value === model);
  const reasoningOptions = modelOption?.reasoningEfforts ?? option?.reasoningEfforts ?? [];
  const requestedEffort = cleanString(raw.reasoningEffort) || fallback.reasoningEffort;
  return {
    runtime: fallback.runtime,
    model,
    reasoningEffort: reasoningOptions.some((effort) => effort.value === requestedEffort)
      ? requestedEffort
      : reasoningOptions.some((effort) => effort.value === fallback.reasoningEffort)
        ? fallback.reasoningEffort
        : (reasoningOptions[0]?.value ?? "default"),
  };
}

/** Turn the Station's native-provider catalog into picker options. */
export function agentRuntimeOptionsFromCatalog(
  value: unknown,
  enabledProviders?: readonly string[],
): AgentRuntimeChoice[] {
  const payload = asRecord(value);
  const rawRuntimes = Array.isArray(payload.runtimes) ? payload.runtimes : [];
  const discovered = new Map<string, AgentRuntimeChoice>();
  for (const rawRuntime of rawRuntimes) {
    const parsed = parseRuntimeChoice(rawRuntime);
    if (parsed) discovered.set(parsed.value, parsed);
  }
  const selectable = FALLBACK_AGENT_RUNTIME_OPTIONS.filter((fallback) =>
    (SELECTABLE_AGENT_PROVIDER_IDS as readonly string[]).includes(fallback.value),
  ).map((fallback) => discovered.get(fallback.value) ?? fallback);
  const options = filterEnabledAgentRuntimeOptions(selectable, enabledProviders ?? (
    payload.externalProvidersEnabled === true ? SELECTABLE_AGENT_PROVIDER_IDS : DEFAULT_ENABLED_AGENT_PROVIDERS
  ));
  // Product composers follow the Gateway default, including old cached catalogs
  // that still advertise multiple models. Explicit external-provider setups keep
  // their full catalogs.
  if (options.length !== 1 || options[0].value !== "openai-compatible") return options;
  return options.map((option) => ({
    ...option,
    allowCustomModel: false,
    models: [option.models.find((model) => model.value === option.defaultModel) ?? {
      value: option.defaultModel,
      label: option.defaultModel,
      icon: option.icon,
    }],
  }));
}

/**
 * Keep only the providers the user enabled. Disabling every provider would
 * leave the composer without a picker at all, so the ABRUM gateway stays as
 * the default floor. It becomes available as soon as a paid wallet session is
 * provisioned by the desktop host.
 */
export function filterEnabledAgentRuntimeOptions(
  options: AgentRuntimeChoice[],
  enabledProviders: readonly string[] = DEFAULT_ENABLED_AGENT_PROVIDERS,
): AgentRuntimeChoice[] {
  const enabled = new Set(enabledProviders);
  const filtered = options.filter((option) => enabled.has(option.value));
  if (filtered.length) return filtered;
  return options.filter((option) => option.value === "openai-compatible");
}

/** Sanitize a stored provider list down to the ids the picker can offer. */
export function normalizeEnabledAgentProviders(value: unknown): SelectableAgentProviderId[] {
  const raw = Array.isArray(value) ? value : [];
  const enabled = SELECTABLE_AGENT_PROVIDER_IDS.filter((id) =>
    raw.some((entry) => typeof entry === "string" && entry.trim() === id),
  );
  return enabled.length ? [...enabled] : [...DEFAULT_ENABLED_AGENT_PROVIDERS];
}

function normalizeRuntimeName(
  value: unknown,
): "openrouter" | "ionos" | "openai-compatible" {
  if (value === "openrouter") return "openrouter";
  if (value === "ionos") return "ionos";
  if (value === "openai-compatible") return "openai-compatible";
  return "openai-compatible";
}

function parseRuntimeChoice(value: unknown): AgentRuntimeChoice | null {
  const runtime = asRecord(value);
  const runtimeValue = cleanString(runtime.value);
  const label = cleanString(runtime.label);
  const defaultModel = cleanString(runtime.defaultModel);
  const defaultReasoningEffort = cleanString(runtime.defaultReasoningEffort);
  if (!runtimeValue || !label || !defaultModel || !defaultReasoningEffort) return null;
  const models = (Array.isArray(runtime.models) ? runtime.models : [])
    .map((modelValue) => {
      const model = asRecord(modelValue);
      const modelValueString = cleanString(model.value);
      const modelLabel = cleanString(model.label);
      if (!modelValueString || !modelLabel) return null;
      const reasoningEfforts = parseOptions(model.reasoningEfforts);
      return {
        value: modelValueString,
        label: modelLabel,
        description: cleanString(model.description) || undefined,
        icon: runtimeValue === "openai-compatible" ? "abrum" : cleanString(model.icon) || undefined,
        reasoningEfforts: reasoningEfforts.length ? reasoningEfforts : undefined,
      };
    })
    .filter((model): model is NonNullable<typeof model> => Boolean(model));
  const reasoningEfforts = parseOptions(runtime.reasoningEfforts);
  if (!models.length || !reasoningEfforts.length) return null;
  return {
    value: runtimeValue,
    label,
    description: cleanString(runtime.description) || undefined,
    icon: runtimeValue === "openai-compatible" ? "abrum" : cleanString(runtime.icon) || undefined,
    available: runtime.available !== false,
    source: cleanString(runtime.source) || undefined,
    defaultModel,
    defaultReasoningEffort,
    modelPlaceholder: cleanString(runtime.modelPlaceholder) || undefined,
    allowCustomModel: runtime.allowCustomModel === true,
    models,
    reasoningEfforts,
  };
}

function parseOptions(value: unknown): Array<{ value: string; label: string }> {
  if (!Array.isArray(value)) return [];
  return value
    .map((entry) => {
      const option = asRecord(entry);
      const optionValue = cleanString(option.value);
      const label = cleanString(option.label);
      return optionValue && label ? { value: optionValue, label } : null;
    })
    .filter((option): option is { value: string; label: string } => Boolean(option));
}

function cleanString(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
}
