import * as React from "react";
import { Check, ChevronsUpDown, Search } from "lucide-react";
import { ChevronDown } from "../brand-icons";
import { cn } from "../ui/cn";
import { Input } from "../ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { Select } from "../ui/select";

export type AgentRuntimeSelection = {
  runtime: string;
  model: string;
  reasoningEffort: string;
};

export type AgentProviderIconName =
  | "abrum"
  | "openai"
  | "anthropic"
  | "openrouter"
  | "gemini"
  | "meta"
  | "mistral"
  | "xai"
  | "deepseek"
  | "qwen"
  | "cohere"
  | "perplexity"
  | "moonshot"
  | "zai"
  | "nvidia"
  | "minimax"
  | "ionos";

export type AgentRuntimeModelChoice = {
  value: string;
  label: string;
  description?: string;
  icon?: AgentProviderIconName | string;
  reasoningEfforts?: Array<{ value: string; label: string }>;
};

export type AgentRuntimeChoice = {
  value: string;
  label: string;
  description?: string;
  icon?: AgentProviderIconName | string;
  available?: boolean;
  source?: string;
  models: AgentRuntimeModelChoice[];
  reasoningEfforts: Array<{ value: string; label: string }>;
  defaultModel: string;
  defaultReasoningEffort: string;
  modelPlaceholder?: string;
  allowCustomModel?: boolean;
};

// Device-local memory of the model/effort last used per provider, so switching
// providers returns to YOUR model instead of the provider default.
const RUNTIME_CHOICE_MEMORY_KEY = "abrum.agent.runtime.byProvider";

type RuntimeChoiceMemory = Record<string, { model: string; reasoningEffort: string }>;

function readRuntimeChoiceMemory(): RuntimeChoiceMemory {
  try {
    const raw = window.localStorage.getItem(RUNTIME_CHOICE_MEMORY_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    return parsed && typeof parsed === "object" ? (parsed as RuntimeChoiceMemory) : {};
  } catch {
    return {};
  }
}

function rememberRuntimeChoice(runtime: string, model: string, reasoningEffort: string) {
  try {
    window.localStorage.setItem(
      RUNTIME_CHOICE_MEMORY_KEY,
      JSON.stringify({
        ...readRuntimeChoiceMemory(),
        [runtime]: { model, reasoningEffort },
      }),
    );
  } catch {
    // Storage unavailable (private mode etc.) — switching just uses defaults.
  }
}

export interface AgentRuntimePickerProps {
  options: AgentRuntimeChoice[];
  value: AgentRuntimeSelection;
  onChange: (value: AgentRuntimeSelection) => void;
  disabled?: boolean;
  loading?: boolean;
  className?: string;
  align?: "start" | "center" | "end";
  side?: "top" | "right" | "bottom" | "left";
  ariaLabel?: string;
  /** Compact trigger for narrow composer toolbars: icon and model only. */
  compact?: boolean;
  /** Keep the selected provider fixed while still exposing model and reasoning. */
  allowProviderChange?: boolean;
  /** Hide provider and reasoning controls while retaining the selected runtime. */
  modelOnly?: boolean;
  /** Named controls for screenshot-led development acceptance. */
  affordanceScope?: string;
}

/** Icons drawn as a monochrome mask. "ionos" is a colour flag, so not here. */
const AI_ICON_URLS: Record<Exclude<AgentProviderIconName, "ionos">, string> = {
  abrum: new URL("../assets/ai/abrum.svg", import.meta.url).href,
  openai: new URL("../assets/ai/openai.svg", import.meta.url).href,
  anthropic: new URL("../assets/ai/anthropic.svg", import.meta.url).href,
  openrouter: new URL("../assets/ai/openrouter.svg", import.meta.url).href,
  gemini: new URL("../assets/ai/gemini.svg", import.meta.url).href,
  meta: new URL("../assets/ai/meta.svg", import.meta.url).href,
  mistral: new URL("../assets/ai/mistral.svg", import.meta.url).href,
  xai: new URL("../assets/ai/xai.svg", import.meta.url).href,
  deepseek: new URL("../assets/ai/deepseek.svg", import.meta.url).href,
  qwen: new URL("../assets/ai/qwen.svg", import.meta.url).href,
  cohere: new URL("../assets/ai/cohere.svg", import.meta.url).href,
  perplexity: new URL("../assets/ai/perplexity.svg", import.meta.url).href,
  moonshot: new URL("../assets/ai/moonshot.svg", import.meta.url).href,
  zai: new URL("../assets/ai/zai.svg", import.meta.url).href,
  nvidia: new URL("../assets/ai/nvidia.svg", import.meta.url).href,
  minimax: new URL("../assets/ai/minimax.svg", import.meta.url).href,
};

type MaskProviderIconName = Exclude<AgentProviderIconName, "ionos">;

function isProviderIconName(value: string | undefined): value is MaskProviderIconName {
  return Boolean(value && value in AI_ICON_URLS);
}

/**
 * Sovereignty marker for German-hosted inference (IONOS). It is a flag, not a
 * logo: the mask-based provider icons above are monochrome by construction, so
 * this one renders as real colour and keeps its own square.
 */
function GermanFlagIcon({ className }: { className?: string }) {
  return (
    <span
      role="img"
      aria-label="Hosted in Germany"
      title="Hosted in Germany"
      className={cn("inline-block size-4 shrink-0 overflow-hidden rounded-[2px] ring-1 ring-border", className)}
    >
      <svg viewBox="0 0 5 3" className="block size-full" aria-hidden="true" preserveAspectRatio="none">
        <rect width="5" height="1" y="0" fill="#000000" />
        <rect width="5" height="1" y="1" fill="#DD0000" />
        <rect width="5" height="1" y="2" fill="#FFCE00" />
      </svg>
    </span>
  );
}

export function AgentProviderIcon({
  name,
  className,
}: {
  name?: AgentProviderIconName | string;
  className?: string;
}) {
  if (name === "ionos") return <GermanFlagIcon className={className} />;
  const iconName = isProviderIconName(name) ? name : "openrouter";
  const url = AI_ICON_URLS[iconName];
  return (
    <span
      aria-hidden="true"
      className={cn("inline-block size-4 shrink-0 bg-current", className)}
      style={{
        WebkitMaskImage: `url("${url}")`,
        maskImage: `url("${url}")`,
        WebkitMaskPosition: "center",
        maskPosition: "center",
        WebkitMaskRepeat: "no-repeat",
        maskRepeat: "no-repeat",
        WebkitMaskSize: "contain",
        maskSize: "contain",
      }}
    />
  );
}

/**
 * Compact provider, model and reasoning picker for chat composers and Agent
 * forms. The catalog is supplied by the host so the component stays
 * provider-neutral and can render live Station-discovered capabilities.
 */
export function AgentRuntimePicker({
  options,
  value,
  onChange,
  disabled = false,
  className,
  align = "end",
  side = "top",
  ariaLabel = "Choose provider, model and reasoning",
  compact = false,
  allowProviderChange = true,
  modelOnly = false,
  affordanceScope,
}: AgentRuntimePickerProps) {
  const [pickerOpen, setPickerOpen] = React.useState(false);
  const [modelMenuOpen, setModelMenuOpen] = React.useState(false);
  const [modelQuery, setModelQuery] = React.useState("");
  const runtime = options.find((option) => option.value === value.runtime) ?? options[0];
  if (!runtime) return null;
  const selectedModel = runtime.models.find((model) => model.value === value.model);
  const modelLabel = selectedModel?.label ?? value.model;
  const reasoningEfforts = selectedModel?.reasoningEfforts ?? runtime.reasoningEfforts;
  const reasoningLabel =
    reasoningEfforts.find((effort) => effort.value === value.reasoningEffort)?.label ?? value.reasoningEffort;
  const triggerLabel = compact || modelOnly
    ? modelLabel
    : `${runtime.label} · ${modelLabel}${reasoningLabel && value.reasoningEffort !== "default" ? ` · ${reasoningLabel}` : ""}`;

  function updateRuntime(nextRuntimeValue: string) {
    const nextRuntime = options.find((option) => option.value === nextRuntimeValue);
    if (!nextRuntime) return;
    setModelMenuOpen(false);
    setModelQuery("");
    // Switching providers restores the model/effort last used WITH that
    // provider (a device-local preference) instead of always snapping back to
    // the provider's default model.
    const remembered = readRuntimeChoiceMemory()[nextRuntime.value];
    const rememberedModel =
      remembered &&
      (nextRuntime.allowCustomModel ||
        nextRuntime.models.some((model) => model.value === remembered.model))
        ? remembered.model
        : "";
    onChange({
      runtime: nextRuntime.value,
      model: rememberedModel || nextRuntime.defaultModel,
      reasoningEffort:
        (rememberedModel && remembered?.reasoningEffort) ||
        nextRuntime.defaultReasoningEffort,
    });
  }

  function updateModel(nextModelValue: string) {
    const nextModel = runtime.models.find((model) => model.value === nextModelValue);
    const allowedEfforts = nextModel?.reasoningEfforts ?? runtime.reasoningEfforts;
    const reasoningEffort = allowedEfforts.some((effort) => effort.value === value.reasoningEffort)
      ? value.reasoningEffort
      : allowedEfforts.some((effort) => effort.value === runtime.defaultReasoningEffort)
        ? runtime.defaultReasoningEffort
        : (allowedEfforts[0]?.value ?? "default");
    rememberRuntimeChoice(runtime.value, nextModelValue, reasoningEffort);
    onChange({ ...value, model: nextModelValue, reasoningEffort });
    setModelMenuOpen(false);
    if (modelOnly) setPickerOpen(false);
    setModelQuery("");
  }

  return (
    <Popover
      open={pickerOpen}
      onOpenChange={(open) => {
        setPickerOpen(open);
        if (!open) {
          setModelMenuOpen(false);
          setModelQuery("");
        }
      }}
    >
      <PopoverTrigger asChild>
        <button
          type="button"
          disabled={disabled}
          data-slot="runtime-picker-trigger"
          data-abrum-verb={affordanceScope ? `${affordanceScope}.runtime.open` : undefined}
          aria-label={ariaLabel}
          title={triggerLabel}
          className={cn(
            "inline-flex min-w-0 appearance-none items-center rounded-md border-0 bg-transparent text-body font-medium text-fg transition-colors",
            "hover:bg-surface-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-border-focus",
            "disabled:cursor-default disabled:opacity-60",
            compact ? "h-7 max-w-full gap-1 px-1.5" : "h-8 gap-1.5 px-2",
            className,
          )}
        >
          <AgentProviderIcon name={runtime.icon} className="size-3.5" />
          <span
            data-slot="runtime-picker-label"
            className={cn("truncate", compact ? "min-w-0 flex-1 font-normal text-fg-muted" : "max-w-64")}
          >
            {compact ? (
              modelLabel
            ) : (
              <>
                <span>{runtime.label}</span>
                <span className="font-normal text-fg-subtle"> · </span>
                <span className="font-normal text-fg-muted">{modelLabel}</span>
                {reasoningLabel && value.reasoningEffort !== "default" ? (
                  <>
                    <span className="font-normal text-fg-subtle"> · </span>
                    <span className="font-normal text-fg-muted">{reasoningLabel}</span>
                  </>
                ) : null}
              </>
            )}
          </span>
          <ChevronDown
            data-slot="runtime-picker-chevron"
            className="size-3.5 shrink-0 text-fg-subtle"
            aria-hidden="true"
          />
        </button>
      </PopoverTrigger>
      <PopoverContent
        align={align}
        side={side}
        sideOffset={6}
        className={cn(
          "overflow-hidden",
          compact
            ? "w-[min(19rem,calc(100vw-1rem))] space-y-3 rounded-xl p-3"
            : "w-[min(24rem,calc(100vw-2rem))] space-y-4",
        )}
      >
        {modelOnly ? (
          <div data-slot="runtime-picker-direct-model-menu">
            <div className="flex items-center gap-2 border-b border-border px-1 pb-2">
              <Search className="size-4 shrink-0 text-fg-subtle" aria-hidden="true" />
              <Input
                autoFocus
                data-abrum-verb={affordanceScope ? `${affordanceScope}.model.search` : undefined}
                value={modelQuery}
                onChange={(event) => setModelQuery(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Escape") {
                    event.stopPropagation();
                    setPickerOpen(false);
                  }
                }}
                placeholder={runtime.modelPlaceholder ?? "Search models"}
                className="h-10 border-0 px-0 shadow-none focus-visible:ring-0"
              />
            </div>
            <ModelResults
              affordanceScope={affordanceScope}
              runtime={runtime}
              query={modelQuery}
              selectedValue={value.model}
              onSelect={updateModel}
            />
          </div>
        ) : (
          <>
            {allowProviderChange && options.length > 1 ? (
              <fieldset className="m-0 min-w-0 space-y-1.5 border-0 p-0">
                <legend className="px-0 text-xs font-medium text-fg-muted">Provider</legend>
                <div className={cn("grid", compact ? "gap-0.5" : "gap-1")} role="radiogroup">
                  {options.map((option) => {
                    const selected = option.value === runtime.value;
                    return (
                      <button
                        key={option.value}
                        type="button"
                        role="radio"
                        aria-checked={selected}
                        disabled={option.available === false}
                        onClick={() => updateRuntime(option.value)}
                        className={cn(
                          "flex w-full appearance-none items-center rounded-lg border-0 bg-transparent text-left transition-colors",
                          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-border-focus disabled:opacity-45",
                          compact ? "min-h-9 gap-2 px-2 py-1.5" : "min-h-10 gap-3 px-3 py-2",
                          selected ? "bg-surface-muted text-fg" : "hover:bg-surface-muted/70",
                        )}
                      >
                        <AgentProviderIcon name={option.icon} />
                        <span className="min-w-0 flex-1 truncate text-body font-medium">{option.label}</span>
                        {selected ? <Check className="size-4 shrink-0" aria-hidden="true" /> : null}
                      </button>
                    );
                  })}
                </div>
              </fieldset>
            ) : null}

        <div className="space-y-1.5">
          <div className="text-xs font-medium text-fg-muted">Model</div>
          <Popover
            open={modelMenuOpen}
            onOpenChange={(open) => {
              setModelMenuOpen(open);
              if (!open) setModelQuery("");
            }}
          >
            <PopoverTrigger asChild>
              <button
                type="button"
                aria-expanded={modelMenuOpen}
                aria-haspopup="listbox"
                data-abrum-verb={affordanceScope ? `${affordanceScope}.model.open` : undefined}
                className={cn(
                  "flex w-full appearance-none items-center gap-2 rounded-md border border-border bg-surface px-3 text-left text-body",
                  "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-border-focus",
                  compact ? "h-9" : "h-10",
                )}
              >
                <AgentProviderIcon name={selectedModel?.icon ?? runtime.icon} />
                <span className="min-w-0 flex-1 truncate">{modelLabel || runtime.modelPlaceholder || "Choose model"}</span>
                <ChevronsUpDown className="size-4 shrink-0 text-fg-subtle" aria-hidden="true" />
              </button>
            </PopoverTrigger>
            <PopoverContent
              align="start"
              side={side}
              sideOffset={4}
              collisionPadding={8}
              className="w-[var(--radix-popover-trigger-width)] overflow-hidden rounded-lg p-0"
            >
              <div className="flex items-center gap-2 border-b border-border px-3">
                <Search className="size-4 shrink-0 text-fg-subtle" aria-hidden="true" />
                <Input
                  autoFocus
                  data-abrum-verb={affordanceScope ? `${affordanceScope}.model.search` : undefined}
                  value={modelQuery}
                  onChange={(event) => setModelQuery(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Escape") {
                      event.stopPropagation();
                      setModelMenuOpen(false);
                    }
                  }}
                  placeholder={runtime.modelPlaceholder ?? "Search models"}
                  className="h-10 border-0 px-0 shadow-none focus-visible:ring-0"
                />
              </div>
              <ModelResults
                affordanceScope={affordanceScope}
                runtime={runtime}
                query={modelQuery}
                selectedValue={value.model}
                onSelect={updateModel}
              />
            </PopoverContent>
          </Popover>
          {selectedModel?.description ? <p className="text-meta text-fg-subtle">{selectedModel.description}</p> : null}
        </div>

            <label className="block space-y-1.5">
              <span className="text-xs font-medium text-fg-muted">Reasoning</span>
              <Select
                className={cn("w-full", compact && "h-9")}
                value={value.reasoningEffort}
                disabled={reasoningEfforts.length <= 1}
                onChange={(event) => {
                  rememberRuntimeChoice(runtime.value, value.model, event.target.value);
                  onChange({ ...value, reasoningEffort: event.target.value });
                }}
              >
                {reasoningEfforts.map((effort) => (
                  <option key={effort.value} value={effort.value}>
                    {effort.label}
                  </option>
                ))}
              </Select>
              {reasoningEfforts.length <= 1 ? (
                <span className="block text-meta text-fg-subtle">This model does not expose a reasoning level.</span>
              ) : null}
            </label>
          </>
        )}
      </PopoverContent>
    </Popover>
  );
}

function ModelResults({
  affordanceScope,
  runtime,
  query,
  selectedValue,
  onSelect,
}: {
  affordanceScope?: string;
  runtime: AgentRuntimeChoice;
  query: string;
  selectedValue: string;
  onSelect: (value: string) => void;
}) {
  const normalizedQuery = query.trim().toLowerCase();
  const matches = runtime.models
    .filter((model) => {
      if (!normalizedQuery) return true;
      return model.label.toLowerCase().includes(normalizedQuery) || model.value.toLowerCase().includes(normalizedQuery);
    })
    .slice(0, 60);
  const exactMatch = runtime.models.some((model) => model.value.toLowerCase() === normalizedQuery);
  const allowCustom = runtime.allowCustomModel && query.trim() && !exactMatch;

  return (
    <div role="listbox" aria-label={`${runtime.label} models`} className="max-h-64 overflow-y-auto p-1">
      {allowCustom ? (
        <button
          type="button"
          role="option"
          aria-selected={false}
          onClick={() => onSelect(query.trim())}
          className="flex w-full appearance-none items-center gap-2 rounded-md border-0 bg-transparent px-2.5 py-2 text-left text-sm hover:bg-surface-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-border-focus"
        >
          <AgentProviderIcon name={runtime.icon} />
          <span className="min-w-0 flex-1 truncate">Use “{query.trim()}”</span>
        </button>
      ) : null}
      {matches.map((model) => (
        <button
          key={model.value}
          type="button"
          role="option"
          aria-selected={model.value === selectedValue}
          data-abrum-verb={affordanceScope ? `${affordanceScope}.model.select` : undefined}
          data-abrum-twin={affordanceScope ? model.value : undefined}
          onClick={() => onSelect(model.value)}
          className={cn(
            "flex w-full appearance-none items-center gap-2.5 rounded-md border-0 bg-transparent px-2.5 py-2 text-left hover:bg-surface-muted",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-border-focus",
          )}
        >
          <AgentProviderIcon name={model.icon ?? runtime.icon} />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-body">{model.label}</span>
            {model.value !== model.label ? <span className="block truncate text-micro text-fg-subtle">{model.value}</span> : null}
          </span>
          {model.value === selectedValue ? <Check className="size-4 shrink-0" aria-hidden="true" /> : null}
        </button>
      ))}
      {matches.length === 0 && !allowCustom ? (
        <div className="px-3 py-6 text-center text-xs text-fg-muted">No matching model.</div>
      ) : null}
      {runtime.models.length > matches.length && !normalizedQuery ? (
        <div className="px-3 py-2 text-center text-micro text-fg-subtle">Type to search all {runtime.models.length} models</div>
      ) : null}
    </div>
  );
}
