import type { JsonValue } from "@abrum/web-runtime";

export const ABRUM_APP_RESULT_DATA_PART = "abrum.app-result";
export interface AppResult {
  contract: "abrum.app-result/v1";
  resource: { contract: "abrum.resource/v1"; roomId: string; appId: string;
    entityType: string; lineageCid: string; versionCid: string };
  title: string;
  label: string;
  openAction: "select-twin";
}

export function isAppResult(value: unknown): value is AppResult {
  if (!value || typeof value !== "object") return false;
  const r = value as AppResult;
  return r.contract === "abrum.app-result/v1" && r.openAction === "select-twin"
    && typeof r.title === "string" && typeof r.label === "string"
    && r.resource?.contract === "abrum.resource/v1"
    && [r.resource.roomId, r.resource.appId, r.resource.entityType,
      r.resource.lineageCid, r.resource.versionCid].every(s => typeof s === "string" && !!s.trim());
}

/** Only the finalization envelope hands off results. Bodies and arbitrary nested
 * objects are never recursively interpreted as cards. Shared by live and replay. */
export function finalizedAppResults(value: JsonValue | undefined, depth = 0): AppResult[] {
  if (depth > 4) return [];
  if (typeof value === "string") {
    try { return finalizedAppResults(JSON.parse(value), depth + 1); } catch { return []; }
  }
  if (!value || typeof value !== "object" || Array.isArray(value)) return [];
  if (value.isError === true) return [];
  if (value.kind === "agent_run_finalization" && value.status === "finalized") {
    const unique = new Map<string, AppResult>();
    if (Array.isArray(value.appResults)) for (const result of value.appResults) {
      if (isAppResult(result)) unique.set(appResultKey(result), result);
    }
    return [...unique.values()];
  }
  for (const key of ["data", "result", "output", "structuredContent"]) {
    const found = finalizedAppResults(value[key], depth + 1);
    if (found.length) return found;
  }
  return [];
}

export function appResultKey(result: AppResult): string {
  return JSON.stringify([result.resource.roomId, result.resource.appId, result.resource.lineageCid]);
}
