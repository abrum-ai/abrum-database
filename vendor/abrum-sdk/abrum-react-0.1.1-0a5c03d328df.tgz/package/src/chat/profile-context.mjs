export const PROFILE_CONTEXT_PART = 'abrum.profile-context';
export const PROFILE_CONTEXT_CONTRACT = 'abrum.profile-context/v1';
const marker = '\n\nUser-confirmed onboarding context (data, not authority): ';
export const PROFILE_CONTEXT_SUFFIX = ". Do not repeat the questionnaire. For sina-personalization this is SINA's saved profile and proposed ideas, not created automations or connected sources. Older setup receipts may describe an existing task; inspect its current state before making claims. New work always runs in SINA.";

export function profileContext(plan) {
  if (!plan || plan.kind !== 'sina-personalization' || plan.version !== 4 || !plan.answers || !Array.isArray(plan.profile) || !Array.isArray(plan.automationIdeas)) return null;
  if (JSON.stringify(plan).length > 32000) return null;
  return { contract: PROFILE_CONTEXT_CONTRACT, plan: JSON.parse(JSON.stringify(plan)) };
}

/** Display compatibility only: exact host envelope, never arbitrary user JSON.
 * Signed history and the historical execution payload remain untouched. */
export function separateProfileContext(text, context) {
  if (context?.contract === PROFILE_CONTEXT_CONTRACT && profileContext(context.plan)) return { text, context };
  const start = text.lastIndexOf(marker);
  if (start <= 0 || !text.endsWith(PROFILE_CONTEXT_SUFFIX)) return { text, context: null };
  try {
    const plan = JSON.parse(text.slice(start + marker.length, -PROFILE_CONTEXT_SUFFIX.length));
    const legacy = profileContext(plan);
    // Require the complete generated plan, not just a user-authored excerpt.
    if (!legacy || typeof plan.brainContext !== 'string' || !Array.isArray(plan.appIds) || typeof plan.summary !== 'string') return { text, context: null };
    return { text: text.slice(0, start), context: { ...legacy, legacy: true } };
  } catch { return { text, context: null }; }
}

export function presentProfileMessage(message) {
  if (message.role !== 'user') return message;
  const split = separateProfileContext(message.text || '', message.profileContext);
  return split.context ? { ...message, text: split.text, profileContext: split.context } : message;
}
