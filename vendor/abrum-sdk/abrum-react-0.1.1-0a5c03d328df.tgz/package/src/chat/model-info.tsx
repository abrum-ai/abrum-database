import { CircleHelp } from "lucide-react";
import { Tooltip } from "@base-ui/react/tooltip";
import { cn } from "../ui/cn";
import type { AgentRuntimeChoice, AgentRuntimeSelection } from "./runtime-picker";

/** Read-only model information for the next message. */
export function AgentModelInfo({
  options,
  value,
  europeanHosted = false,
  locale = "en",
  className,
}: {
  options: AgentRuntimeChoice[];
  value: AgentRuntimeSelection;
  europeanHosted?: boolean;
  locale?: string;
  className?: string;
}) {
  const runtime = options.find((option) => option.value === value.runtime);
  const modelLabel = runtime?.models.find((model) => model.value === value.model)?.label ?? value.model;
  const hostingLabel = locale === "de" ? "In Europa gehostet" : locale === "fr" ? "Hébergé en Europe" : "Hosted in Europe";
  const label = europeanHosted ? `${modelLabel} · ${hostingLabel}` : modelLabel;

  return (
    <Tooltip.Root>
      <Tooltip.Trigger
        type="button"
        data-slot="model-info"
        delay={150}
        aria-label={label}
        className={cn(
          "inline-flex size-7 shrink-0 cursor-default items-center justify-center rounded-md border-0 bg-transparent text-fg-muted transition-colors",
          "hover:bg-surface-muted hover:text-fg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-border-focus",
          className,
        )}
      >
        <CircleHelp className="size-3.5" aria-hidden="true" />
      </Tooltip.Trigger>
      <Tooltip.Portal>
        <Tooltip.Positioner side="top" align="start" sideOffset={8} className="z-50">
          <Tooltip.Popup role="tooltip" className="max-w-xs rounded-lg border border-border bg-surface px-3 py-2 text-ui text-fg shadow-lg">
            <div>{modelLabel}</div>
            {europeanHosted ? <div className="mt-1 flex items-center gap-1.5 text-fg-muted">
              <svg data-slot="europe-hosting" width="18" height="12" viewBox="0 0 36 24" className="shrink-0" aria-hidden="true">
                <rect width="36" height="24" rx="2" fill="#003399" />
                {Array.from({ length: 12 }, (_, index) => {
                  const angle = index * Math.PI / 6;
                  return <path key={index} d="M0-1.5 .35-.46 1.43-.46 .56.18 .88 1.21 0 .57-.88 1.21-.56.18-1.43-.46-.35-.46Z"
                    transform={`translate(${18 + Math.sin(angle) * 7},${12 - Math.cos(angle) * 7})`} fill="#ffcc00" />;
                })}
              </svg>
              <span>{hostingLabel}</span>
            </div> : null}
          </Tooltip.Popup>
        </Tooltip.Positioner>
      </Tooltip.Portal>
    </Tooltip.Root>
  );
}
