/** Stable structured message part used for every abrum chat attachment. */
export const ABRUM_CHAT_ATTACHMENT_DATA_PART = "abrum.chat-attachment";

export const CHAT_ATTACHMENT_MAX_FILE_BYTES = 25 * 1024 * 1024;

export interface ChatAttachmentRef {
  blobHash: string;
  name: string;
  mime: string;
  size: number;
}

export type ChatAttachmentUploader = (file: File) => Promise<ChatAttachmentRef>;

export function isChatAttachmentRef(value: unknown): value is ChatAttachmentRef {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const record = value as Record<string, unknown>;
  return (
    typeof record.blobHash === "string" && record.blobHash.length > 0 &&
    typeof record.name === "string" && record.name.length > 0 &&
    typeof record.mime === "string" &&
    typeof record.size === "number" && Number.isFinite(record.size) && record.size >= 0
  );
}

/** Legacy presentation URL for one chat attachment. The Station requires an
 * actor signature as well; new callers should use runtime.blobUrl instead.
 * Carries the name the
 * transcript shows. A blob is addressed by content hash and holds no metadata,
 * and an anchor's `download` attribute is ignored cross-origin — an app frame
 * is always a different origin than the Station — so without the name in the
 * request the file saves as a bare hash with no extension. The Station answers
 * the `filename` parameter with a `Content-Disposition`. */
export function chatAttachmentDownloadUrl(
  stationUrl: string,
  attachment: Pick<ChatAttachmentRef, "blobHash" | "name">,
): string {
  const base = `${stationUrl.replace(/\/$/, "")}/api/blobs/${encodeURIComponent(attachment.blobHash)}`;
  const name = attachment.name?.trim();
  return name ? `${base}?filename=${encodeURIComponent(name)}` : base;
}

/** Extract durable blob references from an assistant-ui submitted message. */
export function chatAttachmentRefsFromMessage(message: {
  content?: readonly unknown[];
  attachments?: readonly { content?: readonly unknown[] }[];
}): ChatAttachmentRef[] {
  const refs = new Map<string, ChatAttachmentRef>();
  const readParts = (parts: readonly unknown[] | undefined) => {
    for (const part of parts ?? []) {
      if (!part || typeof part !== "object" || Array.isArray(part)) continue;
      const record = part as Record<string, unknown>;
      if (record.type === "data" && record.name === ABRUM_CHAT_ATTACHMENT_DATA_PART && isChatAttachmentRef(record.data)) {
        refs.set(record.data.blobHash, record.data);
      }
    }
  };
  readParts(message.content);
  for (const attachment of message.attachments ?? []) readParts(attachment.content);
  return [...refs.values()];
}
