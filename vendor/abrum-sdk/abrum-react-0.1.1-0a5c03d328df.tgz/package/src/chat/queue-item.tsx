import { chatText } from "./chat-text";
import * as React from "react";
import {
  QueueItemPrimitive,
  type QueueItemState,
  useAui,
} from "@assistant-ui/react";
import { CornerDownRight, ListRestart, MoreHorizontal, Pencil } from "lucide-react";
import { Trash2 } from "../brand-icons";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { moveQueuedMessageToComposer } from "./queue-item-edit";

export interface ChatQueueItemProps {
  queueItem: QueueItemState & {
    /** Legacy metadata accepted for compatibility, no longer shown in the queue. */
    detail?: string;
  };
}

/** Shared pending-turn row used by every ChatComposer host. */
export function ChatQueueItem({ queueItem }: ChatQueueItemProps) {
  const aui = useAui();
  const itemRef = React.useRef<HTMLDivElement>(null);
  const [menuOpen, setMenuOpen] = React.useState(false);

  const editQueuedMessage = React.useCallback(() => {
    const input = itemRef.current
      ?.closest<HTMLElement>('[data-slot="chat-composer"]')
      ?.querySelector<HTMLTextAreaElement>("textarea");

    moveQueuedMessageToComposer(
      {
        removeQueueItem: () => aui.queueItem().remove(),
        setText: (text) => aui.composer().setText(text),
      },
      queueItem,
    );
    setMenuOpen(false);

    requestAnimationFrame(() => {
      input?.focus();
      input?.setSelectionRange(
        queueItem.prompt.length,
        queueItem.prompt.length,
      );
    });
  }, [aui, queueItem]);

  return (
    <div
      ref={itemRef}
      data-slot="chat-queue-item"
      className="flex min-h-8 min-w-0 items-center gap-2 rounded-lg bg-surface/60 py-0.5 pl-2.5 pr-0.5 text-ui text-fg-muted shadow-[0_0_0_0.5px_var(--color-border)]"
    >
      <ListRestart
        className="size-3.5 shrink-0 text-fg-subtle"
        aria-hidden="true"
      />
      <span className="shrink-0 text-meta text-fg-subtle">{chatText("Up next", "Als Nächstes", "Ensuite")}</span>
      <QueueItemPrimitive.Text
        className="min-w-0 flex-1 truncate text-body text-fg"
        title={queueItem.prompt}
      />
      <QueueItemPrimitive.Steer
        data-slot="chat-queue-steer"
        className="inline-flex h-7 shrink-0 appearance-none items-center justify-center gap-1.5 rounded-md bg-transparent px-1.5 text-body text-fg-muted shadow-none transition-colors hover:bg-surface-hover hover:text-fg focus-visible:bg-surface-hover focus-visible:outline focus-visible:outline-fg-subtle active:bg-surface-hover"
        aria-label={`${chatText("Steer with queued message", "Mit dieser Nachricht einlenken", "Réorienter avec ce message")}: ${queueItem.prompt}`}
        title="Steuern"
      >
        <CornerDownRight className="size-4" aria-hidden="true" />
        <span>Steuern</span>
      </QueueItemPrimitive.Steer>
      <QueueItemPrimitive.Remove
        data-slot="chat-queue-remove"
        className="inline-flex size-7 shrink-0 appearance-none items-center justify-center rounded-md bg-transparent text-fg-muted shadow-none transition-colors hover:bg-surface-hover hover:text-fg focus-visible:bg-surface-hover active:bg-surface-hover"
        aria-label={`${chatText("Delete queued message", "Nachricht aus der Warteschlange löschen", "Supprimer le message en attente")}: ${queueItem.prompt}`}
        title={chatText("Delete queued message", "Aus der Warteschlange löschen", "Supprimer le message en attente")}
      >
        <Trash2 className="size-3.5" aria-hidden="true" />
      </QueueItemPrimitive.Remove>
      <Popover open={menuOpen} onOpenChange={setMenuOpen}>
        <PopoverTrigger asChild>
          <button
            type="button"
            data-slot="chat-queue-more"
            className="inline-flex size-7 shrink-0 appearance-none items-center justify-center rounded-md bg-transparent text-fg-muted shadow-none transition-colors hover:bg-surface-hover hover:text-fg focus-visible:bg-surface-hover active:bg-surface-hover"
            aria-label={`${chatText("More options for queued message", "Weitere Optionen für diese Nachricht", "Plus d’options pour ce message")}: ${queueItem.prompt}`}
            title={chatText("More options", "Weitere Optionen", "Plus d’options")}
          >
            <MoreHorizontal className="size-4" aria-hidden="true" />
          </button>
        </PopoverTrigger>
        <PopoverContent
          align="end"
          sideOffset={6}
          className="w-40 rounded-lg p-1"
        >
          <button
            type="button"
            onClick={editQueuedMessage}
            className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-left text-body text-fg transition-colors hover:bg-surface-hover"
          >
            <Pencil className="size-3.5 text-fg-muted" aria-hidden="true" />
            {chatText("Edit message", "Nachricht bearbeiten", "Modifier le message")}
          </button>
        </PopoverContent>
      </Popover>
    </div>
  );
}
