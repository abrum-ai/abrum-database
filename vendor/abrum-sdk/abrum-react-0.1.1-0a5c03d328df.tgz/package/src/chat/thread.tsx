import * as React from "react";
import { PROFILE_CONTEXT_PART } from "./profile-context.mjs";
import { ProfileContextPart } from "./profile-context-part";
import {
  ActionBarPrimitive,
  MessagePrimitive,
  ThreadPrimitive,
  type DataMessagePartComponent,
  useMessage,
  useThread,
  useAuiEvent,
} from "@assistant-ui/react";
import { Check } from "lucide-react";
import { Copy } from "../brand-icons";
import { cn } from "../ui/cn";
import { Bubble, BubbleContent, type BubbleVariant } from "../ui/bubble";
import { Message, MessageAvatar, MessageContent } from "../ui/message";
import {
  MessageScroller,
  MessageScrollerButton,
  MessageScrollerContent,
  MessageScrollerItem,
  MessageScrollerProvider,
  MessageScrollerViewport,
  useMessageScroller,
} from "../ui/message-scroller";
import { ABRUM_AGENT_ACTIVITY_DATA_PART, ABRUM_SOURCE_SUMMARY_DATA_PART, ABRUM_TOOL_ACTIVITY_DATA_PART } from "./agent-message";
import { HumanQuestionToolPart, HumanQuestionScopeContext, HumanQuestionReadOnlyContext, HumanQuestionSubmitContext, HumanQuestionDismissContext, type HumanQuestionDismiss, type HumanQuestionSubmit, ABRUM_REQUEST_USER_INPUT_TOOL } from "./human-question";
import { AgentActivityPart, AssistantText, ChatFailureActionsContext, ReasoningPart, SourceSummaryPart, ToolActivityPart, ToolCallPart, UserText, type ToolPresenterComponent } from "./parts";
import { formatToolName } from "./tool-name";
import { RUN_PROGRESS_PART, PUBLIC_PROGRESS_PART, type RunProgressData } from "./run-progress";
import { PublicProgressPart } from "./public-progress-part";
import { RunProgressPart } from "./run-progress-part";
import { chatText, isChatErrorText } from "./chat-text";

/*
 * ChatThread — the shared transcript view. It drops assistant-ui's own
 * <ThreadPrimitive.Viewport> in favour of the shadcn <MessageScroller> (edge
 * fades, jump-to-latest, intelligent follow), and renders each turn with the
 * <Message>/<Bubble> primitives. Every abrum chat surface mounts this inside its
 * own <AssistantRuntimeProvider>, so the look is identical while each app keeps
 * its own runtime + message converter.
 */

export interface ChatThreadConfig {
  onAssistantPaint?: (messageId: string, terminal: boolean, atMs: number, committedAtMs: number) => void;
  progressLocale?: string;
  visibleMessageIds?: ReadonlySet<string>;
  messageFollowUps?: ReadonlyMap<string, React.ReactNode>;
  showAvatars: boolean;
  assistantVariant: BubbleVariant;
  userVariant: BubbleVariant;
  assistantAvatar?: React.ReactNode;
  userAvatar?: React.ReactNode;
  dataComponents?: Record<string, DataMessagePartComponent | undefined>;
  toolNameFormatter?: (toolName: string) => string;
  toolPresenters?: Record<string, ToolPresenterComponent | undefined>;
}

const ChatThreadContext = React.createContext<ChatThreadConfig>({
  showAvatars: false,
  assistantVariant: "ghost",
  userVariant: "default",
});

const DEFAULT_DATA_COMPONENTS: Record<string, DataMessagePartComponent> = {
  [ABRUM_AGENT_ACTIVITY_DATA_PART]: AgentActivityPart,
  [ABRUM_SOURCE_SUMMARY_DATA_PART]: SourceSummaryPart,
};

/** A turn animates in only when it arrives as the newest message — a send or
 * a new answer — never when a stored history mounts all at once. */
function useArrivesAsNewest(messageId: string): boolean {
  const newestId = useThread((state) => state.messages.at(-1)?.id);
  const [arrives] = React.useState(() => newestId === messageId);
  return arrives;
}

function UserMessage() {
  const { showAvatars, userVariant, userAvatar, dataComponents, visibleMessageIds, messageFollowUps, progressLocale } = React.useContext(ChatThreadContext);
  const ProfilePart = React.useMemo(() => (props: React.ComponentProps<typeof ProfileContextPart>) => <ProfileContextPart {...props} locale={progressLocale} />, [progressLocale]);
  const messageId = useMessage((message) => message.id);
  const arrives = useArrivesAsNewest(messageId);
  if (visibleMessageIds && !visibleMessageIds.has(messageId)) return null;
  return (
    <MessageScrollerItem messageId={messageId} scrollAnchor>
      <MessagePrimitive.Root className={cn("w-full", arrives && "origin-bottom-right motion-safe:animate-chat-rise")}>
        <Message align="end">
          {showAvatars ? <MessageAvatar>{userAvatar}</MessageAvatar> : null}
          <MessageContent className="max-w-[85%]">
            <Bubble variant={userVariant} align="end">
              <BubbleContent className="select-text">
                <MessagePrimitive.Parts components={{ Text: UserText, data: { by_name: { ...dataComponents, [PROFILE_CONTEXT_PART]: ProfilePart } } }} />
              </BubbleContent>
            </Bubble>
          </MessageContent>
        </Message>
      </MessagePrimitive.Root>
      {messageFollowUps?.get(messageId)}
    </MessageScrollerItem>
  );
}

function AssistantMessageActions() {
  const canCopy = useMessage((message) =>
    message.status?.type !== "running" &&
    message.content.some(
      (part) => part.type === "text" && part.text.trim().length > 0 && !isChatErrorText(part.text),
    ),
  );
  if (!canCopy) return null;
  return (
    <ActionBarPrimitive.Root
      data-slot="message-actions"
      className="flex h-7 items-center"
    >
      <ActionBarPrimitive.Copy
        copiedDuration={1600}
        data-slot="message-copy"
        className="group/copy inline-flex size-7 appearance-none select-none items-center justify-center rounded-md bg-transparent text-fg-subtle transition-colors hover:bg-surface-muted hover:text-fg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40"
        aria-label={chatText("Copy message", "Nachricht kopieren", "Copier le message")}
        title={chatText("Copy message", "Nachricht kopieren", "Copier le message")}
      >
        <Copy className="size-3.5 group-data-[copied=true]/copy:hidden" aria-hidden="true" />
        <Check className="hidden size-3.5 text-emerald-600 group-data-[copied=true]/copy:block dark:text-emerald-400" aria-hidden="true" />
      </ActionBarPrimitive.Copy>
    </ActionBarPrimitive.Root>
  );
}

function FollowOwnSend({ enabled }: { enabled: boolean }) {
  const { scrollToEnd } = useMessageScroller();
  // This is scoped to this composer's accepted Send event, not Run starts or
  // background results. Users reading history must never be dragged away.
  useAuiEvent("composer.send", () => {
    if (enabled) scrollToEnd("instant");
  });
  return null;
}

function AssistantMessage() {
  const { showAvatars, assistantVariant, assistantAvatar, dataComponents, toolNameFormatter, toolPresenters, visibleMessageIds, messageFollowUps, progressLocale, onAssistantPaint } = React.useContext(ChatThreadContext);
  const messageId = useMessage((message) => message.id);
  const messageStatus = useMessage((message) => message.status?.type ?? "complete");
  const hasText = useMessage((message) => message.content.some(part => part.type === "text" && part.text.trim().length > 0));
  const arrives = useArrivesAsNewest(messageId);
  const paintTarget = React.useRef<HTMLDivElement>(null);
  const visible = !visibleMessageIds || visibleMessageIds.has(messageId);
  React.useLayoutEffect(() => {
    const element = paintTarget.current;
    if (!onAssistantPaint || !hasText || !visible || !element) return;
    const committedAtMs = Date.now();
    let first = 0, second = 0;
    const observer = new IntersectionObserver(entries => {
      if (!entries.some(entry => entry.isIntersecting) || document.visibilityState !== "visible") return;
      observer.disconnect();
      first = requestAnimationFrame(() => { second = requestAnimationFrame(() => {
        if (document.visibilityState === "visible" && element.isConnected)
          onAssistantPaint(messageId, messageStatus !== "running", Date.now(), committedAtMs);
      }); });
    });
    observer.observe(element);
    return () => { observer.disconnect(); cancelAnimationFrame(first); cancelAnimationFrame(second); };
  }, [onAssistantPaint, hasText, visible, messageId, messageStatus]);
  const hasProgress = useMessage((message) => message.content.some(
    (part) => part.type === "data" && part.name === RUN_PROGRESS_PART,
  ));
  const ToolFallback = React.useCallback(
    (props: React.ComponentProps<typeof ToolCallPart>) => (
      hasProgress ? null : <ToolCallPart {...props} displayName={toolNameFormatter?.(props.toolName)} />
    ),
    [toolNameFormatter, hasProgress],
  );
  const ToolActivity = React.useCallback(
    (props: React.ComponentProps<typeof ToolActivityPart>) => (
      <ToolActivityPart {...props} formatToolName={toolNameFormatter} presenters={toolPresenters} customerProgressOnly={hasProgress} />
    ),
    [toolNameFormatter, toolPresenters, hasProgress],
  );
  const failureShown = useMessage((message) => message.content.some(part => part.type === "text" && isChatErrorText(part.text)));
  const progressFailed = useMessage((message) => message.content.some((part) => part.type === "data"
    && part.name === RUN_PROGRESS_PART && (part.data as RunProgressData | undefined)?.events?.at(-1)?.phase === "failed"));
  // A failure card hosts the follow-up actions itself; otherwise they trail the message.
  const followUp = messageFollowUps?.get(messageId);
  const followUpInCard = failureShown || progressFailed;
  const Progress = React.useCallback((props: React.ComponentProps<typeof RunProgressPart>) =>
    <RunProgressPart {...props} locale={progressLocale} failureShown={failureShown} />, [progressLocale, failureShown]);
  const Reasoning = React.useCallback((props: React.ComponentProps<typeof ReasoningPart>) =>
    hasProgress ? null : <ReasoningPart {...props} />, [hasProgress]);
  const Activity = React.useCallback((props: React.ComponentProps<typeof AgentActivityPart>) =>
    hasProgress ? null : <AgentActivityPart {...props} />, [hasProgress]);
  const assistantDataComponents = React.useMemo(
    () => ({ ...dataComponents, [ABRUM_TOOL_ACTIVITY_DATA_PART]: ToolActivity, [RUN_PROGRESS_PART]: Progress, [PUBLIC_PROGRESS_PART]: PublicProgressPart, [ABRUM_AGENT_ACTIVITY_DATA_PART]: Activity }),
    [dataComponents, ToolActivity, Progress, Activity],
  );
  // A ghost/transparent assistant bubble lets markdown, tool markers and
  // reasoning render full-width (better for the narrow sidebar); a filled
  // variant still works for wider surfaces.
  const ghost = assistantVariant === "ghost";
  if (visibleMessageIds && !visibleMessageIds.has(messageId)) return null;
  return (
    <MessageScrollerItem messageId={messageId}>
      <MessagePrimitive.Root
        ref={paintTarget}
        data-slot="assistant-message"
        data-message-status={messageStatus}
        className={cn("w-full", arrives && "origin-bottom-left motion-safe:animate-chat-rise")}
      >
        <Message align="start">
          {showAvatars ? <MessageAvatar>{assistantAvatar}</MessageAvatar> : null}
          <MessageContent className={cn(showAvatars ? "max-w-[85%]" : "w-full max-w-full")}>
            <Bubble variant={assistantVariant} align="start" className={cn(ghost && "w-full max-w-full px-0 py-0")}>
              <BubbleContent className="select-text">
                <ChatFailureActionsContext.Provider value={followUpInCard ? followUp : null}>
                <MessagePrimitive.Parts
                  unstable_showEmptyOnNonTextEnd={!hasProgress}
                  components={{
                    Text: AssistantText,
                    Reasoning,
                    data: { by_name: assistantDataComponents },
                    tools: {
                      by_name: { [ABRUM_REQUEST_USER_INPUT_TOOL]: HumanQuestionToolPart },
                      Fallback: ToolFallback,
                    },
                  }}
                />
                </ChatFailureActionsContext.Provider>
              </BubbleContent>
            </Bubble>
            <AssistantMessageActions />
          </MessageContent>
        </Message>
      </MessagePrimitive.Root>
      {followUpInCard ? null : followUp}
    </MessageScrollerItem>
  );
}

export interface ChatThreadProps {
  /** Post-commit paint opportunity for visible text; not proof of a physical display refresh. */
  onAssistantPaint?: ChatThreadConfig["onAssistantPaint"];
  progressLocale?: string;
  /** Previews and historical snapshots must not offer nonfunctional answer controls. */
  humanQuestionsReadOnly?: boolean;
  /** A host admission receipt, not a business-result or completion receipt. */
  onHumanQuestionAnswer?: HumanQuestionSubmit;
  /** Durable host cancellation of this question's work; never a model prompt. */
  onHumanQuestionDismiss?: HumanQuestionDismiss;
  /** Keep the base transcript mounted behind a host-owned conversation layer. */
  inactive?: boolean;
  /** View-only filter: keep the runtime's complete chronological message identity. */
  visibleMessageIds?: ReadonlySet<string>;
  /** Rendered when the thread has no messages. */
  empty?: React.ReactNode;
  showAvatars?: boolean;
  assistantVariant?: BubbleVariant;
  userVariant?: BubbleVariant;
  assistantAvatar?: React.ReactNode;
  userAvatar?: React.ReactNode;
  autoScroll?: boolean;
  fade?: boolean;
  scrollButton?: boolean;
  /** Optional host-owned semantic navigation for screenshot-led acceptance. */
  affordanceScope?: string;
  /** undefined: single chat; null: global chronology; string: exact selected topic. */
  humanQuestionTopicKey?: string | null;
  className?: string;
  viewportClassName?: string;
  /** Restore a host-owned reading position on explicit filter changes only. */
  scrollRestoration?: { key: string; top?: number; anchorId?: string; offset?: number };
  /** Host-owned renderers for structured data parts such as abrum app surfaces. */
  dataComponents?: Record<string, DataMessagePartComponent | undefined>;
  /** Optional presentation-only formatter; the underlying tool identifier is unchanged. */
  toolNameFormatter?: (toolName: string) => string;
  /** Optional presenters for completed/running tool activities, keyed by exact tool name. */
  toolPresenters?: Record<string, ToolPresenterComponent | undefined>;
  /** Let the transcript continue behind a measured, floating footer/composer. */
  overlayFooter?: boolean;
  /**
   * Rendered inside <ThreadPrimitive.Root>, below the scroller — the home for
   * the composer (and any notice), so assistant-ui's ComposerPrimitive stays
   * within the thread context it expects.
   */
  footer?: React.ReactNode;
  /** Host-owned follow-up content that scrolls with the conversation. */
  afterMessages?: React.ReactNode;
  /** Presentation-only follow-ups beside exact message IDs; runtime history stays unchanged. */
  messageFollowUps?: ReadonlyMap<string, React.ReactNode>;
}

export function ChatThread({
  onAssistantPaint,
  progressLocale,
  humanQuestionsReadOnly = false,
  onHumanQuestionAnswer,
  onHumanQuestionDismiss,
  inactive = false,
  visibleMessageIds,
  empty,
  showAvatars = false,
  assistantVariant = "ghost",
  userVariant = "default",
  assistantAvatar,
  userAvatar,
  autoScroll = true,
  fade = true,
  scrollButton = true,
  affordanceScope,
  humanQuestionTopicKey,
  className,
  viewportClassName,
  scrollRestoration,
  dataComponents,
  toolNameFormatter = formatToolName,
  toolPresenters,
  overlayFooter = false,
  footer,
  afterMessages,
  messageFollowUps,
}: ChatThreadProps) {
  const footerRef = React.useRef<HTMLDivElement>(null);
  const [footerHeight, setFooterHeight] = React.useState(0);
  React.useLayoutEffect(() => {
    if (!overlayFooter || !footer) {
      setFooterHeight(0);
      return undefined;
    }
    const element = footerRef.current;
    if (!element) return undefined;
    const measure = () => setFooterHeight(element.getBoundingClientRect().height);
    measure();
    if (typeof ResizeObserver === "undefined") return undefined;
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    return () => observer.disconnect();
  }, [footer, overlayFooter]);
  const mergedDataComponents = React.useMemo(
    () => ({ ...DEFAULT_DATA_COMPONENTS, ...dataComponents }),
    [dataComponents],
  );
  const config = React.useMemo<ChatThreadConfig>(
    () => ({ onAssistantPaint, showAvatars, assistantVariant, userVariant, assistantAvatar, userAvatar, dataComponents: mergedDataComponents, toolNameFormatter, toolPresenters, visibleMessageIds, messageFollowUps, progressLocale }),
    [onAssistantPaint, showAvatars, assistantVariant, userVariant, assistantAvatar, userAvatar, mergedDataComponents, toolNameFormatter, toolPresenters, visibleMessageIds, messageFollowUps, progressLocale],
  );
  const overlayFooterStyle = overlayFooter && footerHeight > 0
    ? ({ "--abrum-chat-overlay-footer-height": `${footerHeight}px` } as React.CSSProperties)
    : undefined;
  const renderedFooter = footer && overlayFooter ? (
    <div
      ref={footerRef}
      data-slot="chat-thread-overlay-footer"
      className="pointer-events-none absolute inset-x-0 bottom-0 z-10 [&>*]:pointer-events-auto"
    >
      {footer}
    </div>
  ) : footer;
  return (
    <ChatThreadContext.Provider value={config}>
      <HumanQuestionReadOnlyContext.Provider value={humanQuestionsReadOnly}>
      <HumanQuestionScopeContext.Provider value={humanQuestionTopicKey}>
      <HumanQuestionSubmitContext.Provider value={onHumanQuestionAnswer}>
      <HumanQuestionDismissContext.Provider value={onHumanQuestionDismiss}>
      <ThreadPrimitive.Root
        className={cn("flex min-h-0 flex-1 flex-col", overlayFooter && "relative", className)}
        style={overlayFooterStyle}
      >
        <MessageScrollerProvider autoScroll={autoScroll} defaultScrollPosition="last-anchor" scrollRestoration={scrollRestoration}>
          <FollowOwnSend enabled={autoScroll && !inactive} />
          <MessageScroller fade={fade} inert={inactive} aria-hidden={inactive || undefined}>
            <MessageScrollerViewport
              className={cn("px-3 py-3", viewportClassName)}
              style={overlayFooter && footerHeight > 0 ? { paddingBottom: footerHeight + 16 } : undefined}
            >
              <MessageScrollerContent>
                {empty ? (
                  <ThreadPrimitive.Empty>{empty}</ThreadPrimitive.Empty>
                ) : null}
                <ThreadPrimitive.Messages
                  components={{ UserMessage, AssistantMessage, SystemMessage: AssistantMessage }}
                />
                {afterMessages}
              </MessageScrollerContent>
            </MessageScrollerViewport>
            {scrollButton ? (
              <MessageScrollerButton
                data-abrum-verb={affordanceScope ? `${affordanceScope}.latest` : undefined}
                direction="end"
                style={overlayFooter && footerHeight > 0 ? { bottom: footerHeight + 12 } : undefined}
              />
            ) : null}
          </MessageScroller>
        </MessageScrollerProvider>
        {renderedFooter}
      </ThreadPrimitive.Root>
      </HumanQuestionDismissContext.Provider>
      </HumanQuestionSubmitContext.Provider>
      </HumanQuestionScopeContext.Provider>
      </HumanQuestionReadOnlyContext.Provider>
    </ChatThreadContext.Provider>
  );
}
