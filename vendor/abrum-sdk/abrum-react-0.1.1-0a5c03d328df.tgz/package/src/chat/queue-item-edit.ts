import type { QueueItemState } from "@assistant-ui/react";

export interface QueueItemEditComposer {
  removeQueueItem: (queueItemId: string) => void;
  setText: (text: string) => void;
}

/**
 * Take a pending turn out of the queue and restore it as the current draft.
 * The user can then change it before submitting it again.
 */
export function moveQueuedMessageToComposer(
  composer: QueueItemEditComposer,
  queueItem: QueueItemState,
) {
  composer.removeQueueItem(queueItem.id);
  composer.setText(queueItem.prompt);
}
