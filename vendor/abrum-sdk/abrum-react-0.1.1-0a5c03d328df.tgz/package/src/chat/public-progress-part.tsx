import type { DataMessagePartProps } from '@assistant-ui/react';
import { parseProgress, type ProgressEvent } from './run-progress';

/** Explicit public prose, separate from private reasoning and terminal answers. */
export function PublicProgressPart({ data }: DataMessagePartProps<ProgressEvent>) {
  const report = parseProgress(data);
  if (!report?.publicReport) return null;
  return <p data-slot="public-progress-report" className="my-3 whitespace-pre-wrap text-body text-fg [overflow-wrap:anywhere]">{report.publicReport}</p>;
}
