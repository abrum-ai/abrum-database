const TOOL_WORDS: Record<string, string> = {
  api: "API",
  id: "ID",
  ids: "IDs",
  mcp: "MCP",
  ref: "reference",
  ui: "UI",
  url: "URL",
};

function humanWords(value: string): string {
  const words = value
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2")
    .replace(/[._-]+/g, " ")
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .map((word) => TOOL_WORDS[word.toLowerCase()] || word.toLowerCase());
  if (words.length === 0) return "Tool";
  const first = words[0];
  words[0] = /^[A-Z]{2,}$/.test(first)
    ? first
    : `${first.slice(0, 1).toUpperCase()}${first.slice(1)}`;
  return words.join(" ");
}

/**
 * The app segment of a tool name, in the shape an appId would take inside one.
 * `de.gsndht.admin` and `de_gsndht_admin` are the same app; the tool protocol
 * only allows the latter.
 */
function toolAppKey(appId: string): string {
  return appId.trim().toLowerCase().replace(/[^a-z0-9]+/g, "_");
}

/**
 * Build the lookup a host passes to `formatToolName`, from whatever it knows
 * about the apps installed for this user.
 */
export function toolAppTitles(
  apps: ReadonlyArray<{ appId: string; title: string }>,
): Record<string, string> {
  const titles: Record<string, string> = {};
  for (const app of apps) {
    const key = toolAppKey(app.appId);
    const title = app.title.trim();
    if (key && title) titles[key] = title;
  }
  return titles;
}

/** Presentation-only formatter shared by every abrum transcript. The durable
 * tool identifier remains untouched and is still exposed in tooltips.
 *
 * `appTitles` lets a host name an app the way the app names itself. Without it
 * the app id is the only thing to go on, and an id is not a name:
 * `de_gsndht_admin` reads as "De gsndht admin" while the app calls itself
 * "GSNDHT". Nothing about the id says which segment is the brand, so this is
 * not something the formatter can work out on its own. */
export function formatToolName(
  toolName: string,
  appTitles?: Readonly<Record<string, string>>,
): string {
  if (toolName === "mcp__abrum-room__startup") return "ABRUM tools";
  if (toolName === "mcp.node_repl.js") return "Browser";
  if (/^exec-[0-9a-f-]+$/i.test(toolName) || toolName.startsWith('"') || toolName.startsWith("'")) {
    return "Terminal";
  }
  if (toolName.startsWith("app_")) {
    // Native MCP names append provider and Room identity. Those are routing,
    // not a customer-facing name. Never require each app to fix the host UI.
    const [app, fn] = toolName.slice(4).split("__");
    if (fn) return `${appTitles?.[toolAppKey(app)] ?? humanWords(app.replace(/^abrum[._-]/i, ""))} · ${humanWords(fn)}`;
  }
  if (!toolName.startsWith("abrum_app__")) {
    return humanWords(toolName.replace(/^mcp[_-]+/i, ""));
  }
  const [rawApp = "app", rawFunction = "tool"] = toolName
    .slice("abrum_app__".length)
    .split("__");
  const declared = appTitles?.[toolAppKey(rawApp)];
  const app = declared ?? humanWords(rawApp.replace(/^abrum[._-]/i, ""));
  const fn = humanWords(rawFunction);
  return `${app} · ${fn}`;
}
