import type {
  AppendMessage,
  ExternalThreadQueueAdapter,
  QueueItemState,
} from "@assistant-ui/react";

// The scheduler's durable admission state remains available for a future
// queue UI. Interactive chats currently send corrections immediately.
export type ChatDeliveryMode = "steer" | "queue";

export interface DurableMessageQueueHandlers {
  /** Persist a new turn immediately. Station decides whether it starts or waits. */
  enqueue: (message: AppendMessage, options: { steer: boolean }) => void;
  /** Promote a persisted queued run and interrupt the active run, if any. */
  steer: (queueItemId: string) => void | Promise<void>;
  /** Cancel a persisted queued run without starting its provider. */
  remove: (queueItemId: string) => void | Promise<void>;
}

/** Hide an acted-on row while persistence catches up. Failed controls restore
 * it; stale clicks cannot promote a row already being removed for editing. */
export function createDurableQueueControls() {
  const hidden = new Set<string>();
  const pending = new Set<string>();
  const listeners = new Set<() => void>();
  let revision = 0;
  const notify = () => { revision++; listeners.forEach((listener) => listener()); };
  return {
    subscribe: (listener: () => void) => { listeners.add(listener); return () => { listeners.delete(listener); }; },
    getSnapshot: () => revision,
    isHidden: (id: string) => hidden.has(id),
    reconcile: (items: readonly QueueItemState[]) => {
      const ids = new Set(items.map((item) => item.id));
      for (const id of hidden) {
        if (!ids.has(id) && !pending.has(id)) { hidden.delete(id); notify(); }
      }
    },
    run: (id: string, action: () => void | Promise<void>) => {
      if (hidden.has(id)) return;
      hidden.add(id);
      pending.add(id);
      notify();
      void (async () => {
        try { await action(); }
        catch { hidden.delete(id); }
        finally { pending.delete(id); notify(); }
      })();
    },
  };
}

export function createDurableMessageQueueAdapter(
  items: readonly QueueItemState[],
  handlers: DurableMessageQueueHandlers,
  mode: ChatDeliveryMode = "steer",
): ExternalThreadQueueAdapter {
  return {
    items: mode === "queue" ? items : [],
    enqueue: (message, options) => handlers.enqueue(message, {
      steer: mode === "steer" || options.steer,
    }),
    steer: handlers.steer,
    remove: handlers.remove,
    clear: () => {
      if (mode === "queue") for (const item of items) handlers.remove(item.id);
    },
  };
}
