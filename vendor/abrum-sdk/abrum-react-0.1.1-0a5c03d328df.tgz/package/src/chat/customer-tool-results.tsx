import React from "react";
import type { ToolActivityData } from "./agent-message";
import type { ToolPresenterComponent } from "./parts";

/** Functional app results stay reachable even when generic execution logs are
 * not rendered. This is presentation only; original activities stay in the Run. */
export function CustomerToolResults({ activity, presenters, formatToolName }: {
  activity: ToolActivityData;
  presenters?: Record<string, ToolPresenterComponent | undefined>;
  formatToolName: (name: string) => string;
}) {
  return <React.Fragment>{activity.tools.map(tool => {
    const Presenter = presenters?.[tool.toolName];
    return Presenter ? <div key={tool.toolCallId} data-slot="tool-presenter">
      <Presenter tool={tool} displayName={formatToolName(tool.toolName)} activityStatus={activity.status} />
    </div> : null;
  })}</React.Fragment>;
}
