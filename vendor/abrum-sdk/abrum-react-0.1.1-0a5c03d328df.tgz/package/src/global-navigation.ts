import { useEffect, useMemo, useRef } from "react";
import {
  postAbrumGlobalNavigation,
  readEmbedSignal,
  readAbrumGlobalNavigationSelect,
  type AbrumGlobalNavigationItem,
  type AbrumGlobalNavigationMessage,
} from "@abrum/web-runtime/contracts";

const ABRUM_SURFACE_STATUS_REQUEST_MESSAGE_TYPE = "abrum:surface-status-request";

export type { AbrumGlobalNavigationItem } from "@abrum/web-runtime/contracts";

export interface UseAbrumGlobalNavigationOptions {
  /** Compact app destinations rendered by a capable host in its top app bar. */
  items: readonly AbrumGlobalNavigationItem[];
  activeItemId: string;
  onSelect: (itemId: string) => void;
  enabled?: boolean;
}

/**
 * A detached Electron app window has no DOM parent, but its trusted host shell
 * can expose this deliberately tiny navigation-only bridge. It gives detached
 * app windows the same top-bar navigation contract as embedded iframes without
 * exposing any general Electron or desktop authority to the app.
 */
interface AbrumAppHostNavigationBridge {
  publish: (navigation: Pick<AbrumGlobalNavigationMessage, "items" | "activeItemId">) => void;
  onSelect: (callback: (itemId: string) => void) => () => void;
}

function readAppHostNavigationBridge(): AbrumAppHostNavigationBridge | null {
  if (typeof window === "undefined") return null;
  const bridge = (window as Window & { abrumAppHostNavigation?: Partial<AbrumAppHostNavigationBridge> }).abrumAppHostNavigation;
  return bridge && typeof bridge.publish === "function" && typeof bridge.onSelect === "function"
    ? bridge as AbrumAppHostNavigationBridge
    : null;
}

/**
 * Publish an app's primary view navigation to its embedding host.
 *
 * Returns true only when the current host explicitly advertised support. Apps
 * should keep rendering their local navigation when it returns false, which
 * preserves standalone tabs and hosts without a navigation bridge without
 * duplicating chrome in the abrum desktop shell.
 */
export function useAbrumGlobalNavigation({
  items,
  activeItemId,
  onSelect,
  enabled = true,
}: UseAbrumGlobalNavigationOptions): boolean {
  const embed = useMemo(() => readEmbedSignal(), []);
  const appHostBridge = useMemo(() => readAppHostNavigationBridge(), []);
  const supported = Boolean(
    enabled
      && embed?.globalNavigation
      && typeof window !== "undefined"
      && (window.parent !== window || appHostBridge),
  );
  const onSelectRef = useRef(onSelect);
  const itemsRef = useRef(items);
  const activeItemIdRef = useRef(activeItemId);

  useEffect(() => {
    onSelectRef.current = onSelect;
    itemsRef.current = items;
    activeItemIdRef.current = activeItemId;
  }, [activeItemId, items, onSelect]);

  useEffect(() => {
    if (!supported) return;
    const navigation = { items: [...items], activeItemId };
    if (appHostBridge) appHostBridge.publish(navigation);
    else postAbrumGlobalNavigation(navigation, { appId: embed?.appId });
  }, [activeItemId, appHostBridge, embed?.appId, items, supported]);

  useEffect(() => {
    if (!supported) return;
    const handleSelection = (itemId: string) => {
      const item = itemsRef.current.find((candidate) => candidate.id === itemId);
      if (!item || item.disabled) return;
      onSelectRef.current(item.id);
    };
    if (appHostBridge) return appHostBridge.onSelect(handleSelection);
    const onMessage = (event: MessageEvent) => {
      if (event.source !== window.parent) return;
      // Native app views stay warm between app switches. Their host asks for
      // the current surface status whenever a cached frame becomes visible
      // again; replay navigation on that same handshake so a mount-time post
      // can never leave the desktop title bar empty.
      if (event.data?.type === ABRUM_SURFACE_STATUS_REQUEST_MESSAGE_TYPE) {
        postAbrumGlobalNavigation({
          items: [...itemsRef.current],
          activeItemId: activeItemIdRef.current,
        }, { appId: embed?.appId });
        return;
      }
      const selection = readAbrumGlobalNavigationSelect(event.data);
      if (!selection) return;
      handleSelection(selection.itemId);
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [appHostBridge, embed?.appId, supported]);

  useEffect(() => {
    if (!supported) return;
    return () => {
      if (appHostBridge) appHostBridge.publish({ items: [], activeItemId: "" });
      else postAbrumGlobalNavigation({ items: [], activeItemId: "" }, { appId: embed?.appId });
    };
  }, [appHostBridge, embed?.appId, supported]);

  return supported;
}
