import {
  type FormEvent,
  type ReactNode,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { Check, Share2, Users, X } from "lucide-react";
import {
  activeContentSharesFromEntries,
  lineageCidOf,
  type AbrumContact,
  type AbrumContentShareRecord,
  type AbrumUserProfile,
} from "@abrum/web-runtime";
import {
  useAbrum,
  useAbrumDirectory,
  useAbrumMutation,
  useAbrumSnapshot,
} from "./core";
import { isSharedWithMe } from "./sharing-state";


// Apps address content by its lineage root; re-exported here so a share
// call site never has to reach for the runtime package directly.
export { lineageCidOf };

/**
 * Was this record received through sharing rather than owned by the actor?
 *
 * Both apps that share content had written this comparison out by hand, and the
 * rule it encodes ("you cannot re-share what was shared to you") was enforced
 * only by whatever `disabled` each of them then passed. One rule, one place.
 */
export { isSharedWithMe } from "./sharing-state";
// One projection of "which shares are live" for every surface that asks —
// the app dialog, the desktop host, and Warden's overview.
export { activeContentSharesFromEntries };

export interface AbrumSharedByProps {
  issuerDid?: string | null;
  sharedByDid?: string | null;
  atMs?: string | number | Date | null;
  directory?: Record<string, AbrumUserProfile>;
  className?: string;
}

export function AbrumSharedBy(props: AbrumSharedByProps) {
  if (props.directory) {
    return <AbrumSharedByView {...props} directory={props.directory} />;
  }
  return <AbrumSharedByWithDirectory {...props} />;
}

function AbrumSharedByWithDirectory(props: AbrumSharedByProps) {
  const { directory } = useAbrumDirectory();
  return <AbrumSharedByView {...props} directory={directory} />;
}

function AbrumSharedByView({
  issuerDid,
  sharedByDid,
  atMs,
  directory,
  className,
}: AbrumSharedByProps & { directory: Record<string, AbrumUserProfile> }) {
  const snapshot = useAbrumSnapshot();
  const did = sharedByDid ?? issuerDid ?? null;
  if (!did) {
    return null;
  }
  const name = principalName(did, directory, snapshot.user?.did ?? null);
  const date = atMs ? noteDate(atMs) : null;
  return (
    <span className={`abrum-shared-by${className ? ` ${className}` : ""}`} title={did}>
      <Users size={13} aria-hidden="true" />
      <span>{sharedByDid ? "Shared by" : "By"} {name}</span>
      {date ? <time dateTime={date.toISOString()}>{formatShortDate(date)}</time> : null}
    </span>
  );
}

/** The three identifiers a share needs, as every entity record already carries
 *  them. Pass `record={thing.$}` instead of spelling them out. */
export interface AbrumShareableRecord {
  cid: string;
  lineageCid?: string | null;
  sourceRoomId?: string | null;
  authorityRoomId?: string | null;
  sharedWithMe?: boolean;
  shareProvenance?: "owned" | "room-membership" | "direct" | "unknown";
}

export interface AbrumContentShareButtonProps {
  /** Adoption in one prop: lineage, target and source Room are read from the
   *  record. Adding sharing to an app used to mean knowing which cid is the
   *  lineage and which is the version — a distinction two apps got wrong. */
  record?: AbrumShareableRecord;
  lineageCid?: string;
  targetCid?: string | null;
  targetType?: string | null;
  title?: string | null;
  roomId?: string | null;
  /** Compatibility input for non-entity callers. Prefer `record`, whose
   * authority and sharing provenance are explicit. */
  sourceRoomId?: string | null;
  directory?: Record<string, AbrumUserProfile>;
  className?: string;
  disabled?: boolean;
  children?: ReactNode;
}

export function AbrumContentShareButton(props: AbrumContentShareButtonProps) {
  if (props.directory) {
    return <AbrumContentShareButtonView {...props} directory={props.directory} />;
  }
  return <AbrumContentShareButtonWithDirectory {...props} />;
}

function AbrumContentShareButtonWithDirectory(props: AbrumContentShareButtonProps) {
  const { directory } = useAbrumDirectory();
  return <AbrumContentShareButtonView {...props} directory={directory} />;
}

function AbrumContentShareButtonView({
  record,
  lineageCid: lineageCidProp,
  targetCid: targetCidProp,
  targetType,
  title,
  roomId,
  sourceRoomId: sourceRoomIdProp,
  directory,
  className,
  disabled,
  children,
}: AbrumContentShareButtonProps & { directory: Record<string, AbrumUserProfile> }) {
  // Explicit props still win, for callers that address something other than a
  // whole record.
  const lineageCid = lineageCidProp ?? (record ? lineageCidOf(record) : "");
  const targetCid = targetCidProp ?? record?.cid ?? null;
  const sourceRoomId = sourceRoomIdProp ?? record?.sourceRoomId ?? null;
  const runtime = useAbrum();
  const snapshot = useAbrumSnapshot();
  const resolvedRoomId = roomId
    ?? record?.authorityRoomId
    ?? sourceRoomId
    ?? snapshot.selectedRoomId;
  const [open, setOpen] = useState(false);
  const [didInput, setDidInput] = useState("");
  // ONE set of state. This dialog used to keep a parallel copy of contacts,
  // shares, loading and error for the embedded-desktop path and pick between
  // them at every use site, while the runtime made the same host-vs-web
  // decision a second time. The runtime owns that decision now; from here there
  // is only "ask the runtime".
  const [context, setContext] = useState<{ contacts: AbrumContact[]; shares: AbrumContentShareRecord[] }>(
    { contacts: [], shares: [] },
  );
  const [loading, setLoading] = useState(false);
  const [contextError, setContextError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!resolvedRoomId || !lineageCid.trim()) return;
    setLoading(true);
    setContextError(null);
    try {
      setContext(await runtime.contentShareContext({ roomId: resolvedRoomId, lineageCid }));
    } catch (cause) {
      setContextError(cause instanceof Error ? cause.message : String(cause));
    } finally {
      setLoading(false);
    }
  }, [lineageCid, resolvedRoomId, runtime]);

  useEffect(() => {
    if (!open) return;
    void refresh();
  }, [open, refresh]);

  const share = useAbrumMutation(async ({ did, stationId }: { did: string; stationId?: string | null }) => {
    if (!resolvedRoomId) {
      throw new Error("select a room first");
    }
    const trimmed = did.trim();
    if (!trimmed) {
      throw new Error("choose a contact or enter a DID");
    }
    await runtime.shareContent({
      roomId: resolvedRoomId,
      lineageCid,
      targetCid,
      targetType,
      title,
      sharedWithDid: trimmed,
      recipientStationId: stationId,
    });
    setDidInput("");
    await refresh();
  });
  const revoke = useAbrumMutation(async (did: string) => {
    if (!resolvedRoomId) {
      throw new Error("select a room first");
    }
    await runtime.revokeContentShare({
      roomId: resolvedRoomId,
      lineageCid,
      sharedWithDid: did,
    });
    await refresh();
  });

  const visibleContacts = context.contacts;
  const sharedWith = useMemo(
    () => context.shares.map((item) => item.sharedWithDid),
    [context.shares],
  );
  // Modal hygiene the dialog never had: only a backdrop click closed it, focus
  // stayed behind on the page, and Tab walked straight out of the dialog into
  // the app underneath it.
  const dialogRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const close = useCallback(() => {
    setOpen(false);
    triggerRef.current?.focus();
  }, []);

  useEffect(() => {
    if (!open) return undefined;
    const dialog = dialogRef.current;
    dialog?.querySelector<HTMLElement>("[data-autofocus]")?.focus() ?? dialog?.focus();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.stopPropagation();
        close();
        return;
      }
      if (event.key !== "Tab" || !dialog) return;
      const focusable = Array.from(dialog.querySelectorAll<HTMLElement>(
        'button:not([disabled]), input:not([disabled]), [href], [tabindex]:not([tabindex="-1"])',
      ));
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      const active = document.activeElement;
      if (event.shiftKey && (active === first || !dialog.contains(active))) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && active === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onKeyDown, true);
    return () => document.removeEventListener("keydown", onKeyDown, true);
  }, [close, open]);

  // A DID is the one free-text field here. Say what is wrong before the submit
  // rather than surfacing a thrown message afterwards.
  const trimmedDid = didInput.trim();
  const didError = trimmedDid && !trimmedDid.startsWith("did:")
    ? "An identifier starts with did:"
    : trimmedDid && sharedWith.includes(trimmedDid)
      ? "This person already has access"
      : null;

  const receivedFromSomeoneElse = isSharedWithMe(record ?? {}, snapshot.selectedRoomId);
  const canShare = Boolean(snapshot.user && resolvedRoomId && lineageCid.trim())
    && !disabled
    && !receivedFromSomeoneElse;
  const triggerHint = receivedFromSomeoneElse
    ? "This was shared with you — pass it on from its own Room"
    : canShare
      ? "Manage who can see this"
      : "Sign in and select a room to share";

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        className={`abrum-button abrum-share-trigger${className ? ` ${className}` : ""}`}
        onClick={() => setOpen(true)}
        disabled={!canShare}
        title={triggerHint}
      >
        <Share2 size={14} aria-hidden="true" />
        <span>{children ?? (sharedWith.length > 0 ? "Sharing" : "Share")}</span>
      </button>
      {open ? (
        <div
          className="abrum-modal-backdrop"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) close();
          }}
          role="presentation"
        >
          {/* The desktop's Room dialog (ShareModal) lives in another document and
              cannot share this stylesheet, so the two are held together by
              structure and wording instead: same headings, same verbs, same
              closing sentence about what a revoke cannot undo. */}
          <div
            ref={dialogRef}
            className="abrum-modal abrum-share-dialog"
            role="dialog"
            aria-modal="true"
            aria-label="Manage access"
            tabIndex={-1}
          >
            <div className="abrum-modal-header">
              <div>
                <strong>Manage access</strong>
                <small>{title ? `Item · ${title}` : "This item only, not the Room"}</small>
              </div>
              <button type="button" className="abrum-icon-button" data-autofocus onClick={close} aria-label="Close">
                <X size={14} aria-hidden="true" />
              </button>
            </div>

            <div className="abrum-modal-section abrum-help">
              A signed Connection Room sends this item's history and future updates.
              The recipient gets no access to the source Room. Replicated readable
              bytes already delivered cannot be recalled.
            </div>

            <div className="abrum-modal-section">
              <div className="abrum-menu-heading">Add people</div>
              {loading ? (
                <p className="abrum-help">Loading contacts…</p>
              ) : visibleContacts.length === 0 ? (
                <p className="abrum-help">Connect a person first, then add them to this item.</p>
              ) : (
                <ul className="abrum-share-contact-list">
                  {visibleContacts.map((contact) => {
                    const name = contact.displayName ?? directory[contact.did]?.displayName ?? short(contact.did);
                    const shared = sharedWith.includes(contact.did);
                    return (
                      <li key={contact.did}>
                        <button
                          type="button"
                          className="abrum-share-contact"
                          onClick={() => share.run({ did: contact.did, stationId: contact.stationId }).catch(() => undefined)}
                          // Clicking an already-added person used to re-run the
                          // whole share for no effect. It is a state, not a button.
                          disabled={share.isPending || shared}
                          title={shared ? `${name} already has access` : `Give ${name} access`}
                        >
                          <span className="abrum-share-avatar" aria-hidden="true">
                            {name.trim().slice(0, 1).toUpperCase() || "?"}
                          </span>
                          <span className="abrum-share-contact-main">
                            <strong>{name}</strong>
                            <small>{contact.stationName ?? contact.stationId ?? short(contact.did)}</small>
                          </span>
                          <span className={`abrum-share-state${shared ? " abrum-share-state-done" : ""}`}>
                            {shared ? <Check size={14} aria-hidden="true" /> : <Share2 size={14} aria-hidden="true" />}
                            {shared ? "Added" : "Add"}
                          </span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>

            <form
              className="abrum-modal-section"
              onSubmit={(event: FormEvent) => {
                event.preventDefault();
                share.run({ did: didInput }).catch(() => undefined);
              }}
            >
              <div className="abrum-menu-heading">Add by identifier</div>
              <div className="abrum-share-did-row">
                <input
                  value={didInput}
                  onChange={(event) => setDidInput(event.target.value)}
                  placeholder="did:key:ed25519:..."
                  disabled={share.isPending}
                  aria-invalid={didError ? true : undefined}
                  aria-describedby={didError ? "abrum-share-did-error" : undefined}
                />
                <button
                  type="submit"
                  className="abrum-button abrum-button-primary"
                  disabled={!trimmedDid || Boolean(didError) || share.isPending}
                >
                  Add
                </button>
              </div>
              {didError ? <p className="abrum-help" id="abrum-share-did-error">{didError}</p> : null}
            </form>

            {sharedWith.length > 0 ? (
              <div className="abrum-modal-section">
                <div className="abrum-menu-heading">People with access</div>
                <ul className="abrum-share-current-list">
                  {sharedWith.map((did) => (
                    <li key={did}>
                      <span title={did}>{principalName(did, directory, snapshot.user?.did ?? null)}</span>
                      <button
                        type="button"
                        className="abrum-button"
                        disabled={revoke.isPending}
                        onClick={() => revoke.run(did).catch(() => undefined)}
                      >
                        Remove
                      </button>
                    </li>
                  ))}
                </ul>
                <p className="abrum-help">
                  Removing access stops future updates. Data already replicated to another station
                  cannot be recalled.
                </p>
              </div>
            ) : null}

            {/* Keyed by source: two failures with the same message used to
                collide on the same React key. */}
            {([["context", contextError], ["add", share.error], ["remove", revoke.error]] as const)
              .filter(([, error]) => Boolean(error))
              .map(([source, error]) => (
                <p className="abrum-error abrum-modal-section" key={source}>
                  {error}
                </p>
              ))}
          </div>
        </div>
      ) : null}
    </>
  );
}

function principalName(did: string, directory: Record<string, AbrumUserProfile>, ownDid: string | null): string {
  if (did === ownDid) {
    return "You";
  }
  return directory[did]?.displayName ?? short(did);
}

function short(value: string): string {
  return value.length <= 16 ? value : `${value.slice(0, 8)}...${value.slice(-4)}`;
}

function noteDate(value: string | number | Date): Date | null {
  const date = value instanceof Date ? value : new Date(value);
  return Number.isFinite(date.getTime()) ? date : null;
}

function formatShortDate(date: Date): string {
  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
  }).format(date);
}
