import * as React from "react";
import { cn } from "./cn";
import { ScrollFade } from "./scroll-fade";
import { followAfterScroll } from "./message-follow";

/*
 * MessageScroller — the transcript scroll region. Vendored from shadcn's radix
 * "message-scroller". Implements intelligent following rather than forced
 * stick-to-bottom: auto-scroll engages only while the reader sits at the live
 * edge and disengages the moment they scroll away, so streamed tokens never
 * yank a reader who has scrolled up into history.
 *
 * Parts (compose under <MessageScrollerProvider>):
 *   MessageScroller          relative frame (optional edge fades)
 *   MessageScrollerViewport  the scrollable element (owns scroll + autoscroll)
 *   MessageScrollerContent   transcript column (aria-live polite by default)
 *   MessageScrollerItem      a turn/row boundary (messageId, scrollAnchor)
 *   MessageScrollerButton    jump-to-end control, inert at the edge
 */

type Behavior = {
  autoScroll: boolean;
  defaultScrollPosition: "start" | "end" | "last-anchor";
  scrollPreviousItemPeek: number;
  scrollRestoration?: { key: string; top?: number; anchorId?: string; offset?: number };
};

type Ctx = Behavior & {
  viewportRef: React.RefObject<HTMLDivElement | null>;
  stick: React.RefObject<boolean>;
  restoring: React.RefObject<boolean>;
  atTop: boolean;
  atBottom: boolean;
  setEdges: (e: { atTop: boolean; atBottom: boolean }) => void;
  scrollToEnd: (behavior?: ScrollBehavior) => void;
  scrollToStart: (behavior?: ScrollBehavior) => void;
};

const MessageScrollerContext = React.createContext<Ctx | null>(null);

function useScroller(): Ctx {
  const ctx = React.useContext(MessageScrollerContext);
  if (!ctx) throw new Error("MessageScroller parts must be used within <MessageScrollerProvider>");
  return ctx;
}

/** Reuse the same live-edge state for explicit host navigation such as Send. */
export { useScroller as useMessageScroller };

export interface MessageScrollerProviderProps {
  children: React.ReactNode;
  autoScroll?: boolean;
  defaultScrollPosition?: Behavior["defaultScrollPosition"];
  scrollPreviousItemPeek?: number;
  /** Explicit filter navigation; restoring history also disarms live-edge following. */
  scrollRestoration?: Behavior["scrollRestoration"];
}

export function MessageScrollerProvider({
  children,
  autoScroll = true,
  defaultScrollPosition = "end",
  scrollPreviousItemPeek = 0,
  scrollRestoration,
}: MessageScrollerProviderProps) {
  const viewportRef = React.useRef<HTMLDivElement | null>(null);
  const stick = React.useRef<boolean>(autoScroll && defaultScrollPosition !== "start");
  const restoring = React.useRef(false);
  const [edges, setEdges] = React.useState({ atTop: true, atBottom: true });

  const scrollToEnd = React.useCallback((behavior: ScrollBehavior = "smooth") => {
    const el = viewportRef.current;
    if (!el) return;
    restoring.current = false;
    stick.current = true;
    el.scrollTo({ top: el.scrollHeight, behavior });
  }, []);

  const scrollToStart = React.useCallback((behavior: ScrollBehavior = "smooth") => {
    const el = viewportRef.current;
    if (!el) return;
    restoring.current = false;
    stick.current = false;
    el.scrollTo({ top: 0, behavior });
  }, []);

  const value = React.useMemo<Ctx>(
    () => ({
      autoScroll,
      defaultScrollPosition,
      scrollPreviousItemPeek,
      scrollRestoration,
      viewportRef,
      stick,
      restoring,
      atTop: edges.atTop,
      atBottom: edges.atBottom,
      setEdges,
      scrollToEnd,
      scrollToStart,
    }),
    [autoScroll, defaultScrollPosition, scrollPreviousItemPeek, scrollRestoration, edges, scrollToEnd, scrollToStart],
  );

  return <MessageScrollerContext.Provider value={value}>{children}</MessageScrollerContext.Provider>;
}

export interface MessageScrollerProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Render gradient fades at the top/bottom edges, tied to scroll position. */
  fade?: boolean;
}

export function MessageScroller({ className, children, fade = false, ...props }: MessageScrollerProps) {
  const { atTop, atBottom } = useScroller();
  return (
    <div
      data-slot="message-scroller"
      data-at-top={atTop ? "true" : "false"}
      data-at-bottom={atBottom ? "true" : "false"}
      className={cn("relative flex min-h-0 flex-1 flex-col", className)}
      {...props}
    >
      {fade ? <ScrollFade side="top" show={!atTop} /> : null}
      {children}
      {fade ? <ScrollFade side="bottom" show={!atBottom} /> : null}
    </div>
  );
}

export function MessageScrollerViewport({
  className,
  onScroll,
  onWheel,
  onPointerDown,
  onKeyDown,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  const { viewportRef, stick, restoring, setEdges, autoScroll, defaultScrollPosition, scrollPreviousItemPeek, scrollRestoration } = useScroller();
  const EDGE = 24; // px tolerance for "at the live edge"

  const recompute = React.useCallback(() => {
    const el = viewportRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    const atBottom = distanceFromBottom <= EDGE;
    const atTop = el.scrollTop <= 1;
    if (!restoring.current) stick.current = followAfterScroll(stick.current, atBottom, autoScroll);
    setEdges({ atTop, atBottom });
  }, [viewportRef, stick, setEdges, autoScroll]);

  // Initial position for restored threads.
  React.useLayoutEffect(() => {
    const el = viewportRef.current;
    if (!el) return;
    if (defaultScrollPosition === "start") {
      el.scrollTop = 0;
    } else if (defaultScrollPosition === "last-anchor") {
      const anchors = el.querySelectorAll<HTMLElement>('[data-scroll-anchor=""]');
      const anchor = anchors.item(anchors.length - 1);
      el.scrollTop = anchor
        ? Math.max(0, anchor.offsetTop - scrollPreviousItemPeek)
        : el.scrollHeight;
    } else {
      el.scrollTop = el.scrollHeight;
    }
    stick.current = autoScroll && el.scrollHeight - el.scrollTop - el.clientHeight <= EDGE;
    recompute();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // One owner for scroll position AND following intent. A host writing only
  // scrollTop leaves the previous short topic pinned; its ResizeObserver then
  // pulls the restored chronology to the end on the next layout notification.
  React.useLayoutEffect(() => {
    const el = viewportRef.current;
    if (!el || !scrollRestoration) return;
    const restored = Number.isFinite(scrollRestoration.top);
    const previousAnchor = el.style.overflowAnchor;
    // The old filter's DOM anchor must not pull the new filter during reflow.
    el.style.overflowAnchor = 'none';
    restoring.current = true;
    const apply = () => {
      stick.current = !restored && autoScroll;
      const anchor = scrollRestoration.anchorId
        ? el.querySelector<HTMLElement>(`[data-slot="message-scroller-item"][data-message-id="${CSS.escape(scrollRestoration.anchorId)}"]`)
        : null;
      if (anchor && Number.isFinite(scrollRestoration.offset)) {
        el.scrollTop += anchor.getBoundingClientRect().top - el.getBoundingClientRect().top - scrollRestoration.offset!;
      } else el.scrollTop = restored ? Math.max(0, scrollRestoration.top!) : el.scrollHeight;
      recompute();
    };
    apply();
    // Message clients publish the filtered children after the host's commit;
    // footer autosizing can follow in the next layout. Bound restoration to two
    // frames, cancel it on another selection, never poll or animate geometry.
    let frame = requestAnimationFrame(() => {
      if (restoring.current) apply();
      frame = requestAnimationFrame(() => {
        if (restoring.current) apply();
        restoring.current = false;
        recompute();
        el.style.overflowAnchor = previousAnchor;
      });
    });
    return () => { cancelAnimationFrame(frame); restoring.current = false; el.style.overflowAnchor = previousAnchor; };
    // A new result or rerender in the SAME filter is not navigation.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scrollRestoration?.key]);

  // Follow growth while pinned to the edge (streaming tokens, new turns).
  React.useEffect(() => {
    const el = viewportRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => {
      if (autoScroll && stick.current) el.scrollTop = el.scrollHeight;
      recompute();
    });
    ro.observe(el);
    for (const child of Array.from(el.children)) ro.observe(child);
    return () => ro.disconnect();
  }, [viewportRef, stick, recompute, autoScroll]);

  return (
    <div
      ref={viewportRef}
      data-slot="message-scroller-viewport"
      className={cn("min-h-0 flex-1 overflow-x-hidden overflow-y-auto overscroll-contain", className)}
      onScroll={(e) => {
        recompute();
        onScroll?.(e);
      }}
      onWheel={(e) => {
        restoring.current = false;
        if (e.deltaY < 0) stick.current = false;
        onWheel?.(e);
      }}
      onPointerDown={(e) => {
        const el = e.currentTarget;
        const rect = el.getBoundingClientRect();
        // Touch panning or dragging the native scrollbar is explicit navigation.
        // Clicking/selecting a message is not a request to leave the live edge.
        if (e.pointerType === "touch" || e.clientX >= rect.left + el.clientWidth) { restoring.current = false; stick.current = false; }
        onPointerDown?.(e);
      }}
      onKeyDown={(e) => {
        if (["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End", " "].includes(e.key)
          && !(e.target instanceof HTMLElement && e.target.closest('input,textarea,[contenteditable="true"]'))) restoring.current = false;
        if (["ArrowUp", "PageUp", "Home"].includes(e.key)
          && !(e.target instanceof HTMLElement && e.target.closest('input,textarea,[contenteditable="true"]'))) { restoring.current = false; stick.current = false; }
        onKeyDown?.(e);
      }}
      {...props}
    >
      {children}
    </div>
  );
}

export function MessageScrollerContent({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      data-slot="message-scroller-content"
      role="log"
      aria-live="polite"
      aria-relevant="additions text"
      className={cn("flex flex-col gap-3", className)}
      {...props}
    />
  );
}

export interface MessageScrollerItemProps extends React.HTMLAttributes<HTMLDivElement> {
  messageId?: string;
  scrollAnchor?: boolean;
}

export function MessageScrollerItem({ className, messageId, scrollAnchor, ...props }: MessageScrollerItemProps) {
  return (
    <div
      data-slot="message-scroller-item"
      data-message-id={messageId}
      data-scroll-anchor={scrollAnchor ? "" : undefined}
      className={cn(
        // content-visibility adds paint containment. Let bubble shadows paint
        // beyond the row without changing message spacing or virtualization.
        "min-w-0 shrink-0 scroll-mt-3 [contain-intrinsic-size:auto_10rem] [content-visibility:auto] [overflow-clip-margin:8px]",
        className,
      )}
      {...props}
    />
  );
}

export interface MessageScrollerButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  direction?: "start" | "end";
}

export function MessageScrollerButton({
  className,
  direction = "end",
  children,
  onClick,
  ...props
}: MessageScrollerButtonProps) {
  const { atTop, atBottom, scrollToEnd, scrollToStart } = useScroller();
  const inert = direction === "end" ? atBottom : atTop;
  return (
    <button
      type="button"
      data-slot="message-scroller-button"
      aria-label={direction === "end" ? "Scroll to latest" : "Scroll to top"}
      tabIndex={inert ? -1 : 0}
      onClick={(e) => {
        (direction === "end" ? scrollToEnd : scrollToStart)();
        onClick?.(e);
      }}
      className={cn(
        "absolute left-1/2 z-20 -translate-x-1/2 inline-flex size-8 items-center justify-center rounded-full border border-border shadow-sm transition-all",
        direction === "end"
          ? "bottom-3 bg-white text-zinc-600 hover:text-zinc-900"
          : "abrum-backdrop-blur--16 top-3 bg-surface/80 text-fg-muted hover:text-fg",
        inert ? "pointer-events-none scale-90 opacity-0" : "opacity-100",
        className,
      )}
      {...props}
    >
      {children ?? (
        <svg viewBox="0 0 24 24" fill="none" className="size-4" aria-hidden>
          <path
            d={direction === "end" ? "M6 9l6 6 6-6" : "M6 15l6-6 6 6"}
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )}
    </button>
  );
}
