import * as React from "react";
import { AppAccessList, type AppAccessListItem } from "./app-access-list";
import { preferredAgentCapabilityMode } from "./agent-capability-mode";
import { Button } from "./button";

export type AgentCapabilityMode =
  | "on_behalf_of_caller"
  | "delegated_service"
  | "autonomous";

export interface AgentCapabilityOffer {
  id: string;
  title: string;
  description?: string;
  functions: string[];
  modes: AgentCapabilityMode[];
  defaultMode: AgentCapabilityMode;
  risk?: string;
  resultPolicies: string[];
  defaultResultPolicy: string;
}

export interface AgentCapabilityProvider {
  roomId: string;
  roomName: string;
  appId: string;
  appTitle: string;
  icon?: string;
  offers: AgentCapabilityOffer[];
}

/** Display metadata resolved by the host for a provider binding. */
export type AgentCapabilityProviderIdentity = Pick<
  AgentCapabilityProvider,
  "roomId" | "roomName" | "appId" | "appTitle" | "icon"
>;

export interface AgentCapabilityAccess {
  providerRoomId: string;
  appId: string;
  offerId: string;
  mode: AgentCapabilityMode;
  resultPolicy: string;
  functions: string[];
}

export interface AgentCapabilityBinding {
  providerRoomId: string;
  appId: string;
  offerId: string;
  mode: string;
  resultPolicy: string;
  holderDid?: string;
  capCid?: string;
  functions: unknown;
  enabled: boolean;
  deleted?: boolean | null;
}

export interface AgentCapabilityDecision {
  kind: "granted" | "denied" | "error" | string;
  providerRoomId: string;
  appId: string;
  offerId?: string;
  requestId?: string;
  error?: string;
}

interface ProviderOption extends AgentCapabilityProvider {
  available: boolean;
}

export interface AgentAppAccessListProps {
  providers: AgentCapabilityProvider[];
  providerIdentities?: AgentCapabilityProviderIdentity[];
  bindings: AgentCapabilityBinding[];
  access: AgentCapabilityAccess[];
  /**
   * Permissions the host already knows are awaiting a Warden verdict. In-flight
   * requests are tracked internally, but that memory dies with the component —
   * a surface that can be closed and reopened has to say so from the outside,
   * or a waiting permission comes back looking simply switched off.
   */
  pending?: Array<{ providerRoomId: string; appId: string }>;
  loading?: boolean;
  error?: string | null;
  decision?: AgentCapabilityDecision | null;
  onAccessChange: (access: AgentCapabilityAccess[]) => void;
  onAuthorize: (
    access: AgentCapabilityAccess,
  ) => Promise<{ status: "granted" | "pending"; requestId?: string }>;
  onRevoke: (target: {
    providerRoomId: string;
    appId: string;
    offerId: string;
  }) => Promise<void>;
  compact?: boolean;
  emptyLabel?: string;
}

export function normalizeAgentCapabilityMode(mode: string): AgentCapabilityMode {
  if (mode === "delegated_service" || mode === "autonomous") return mode;
  return "on_behalf_of_caller";
}

export function agentCapabilityAccessFromBindings(
  bindings: AgentCapabilityBinding[],
): AgentCapabilityAccess[] {
  return bindings
    .filter((binding) => binding.enabled === true && binding.deleted !== true)
    .map((binding) => ({
      providerRoomId: binding.providerRoomId,
      appId: binding.appId,
      offerId: binding.offerId,
      mode: normalizeAgentCapabilityMode(binding.mode),
      resultPolicy: binding.resultPolicy,
      functions: stringArray(binding.functions),
    }));
}

function providerKey(provider: {
  roomId: string;
  appId: string;
}): string {
  return `${provider.roomId}\u0000${provider.appId}`;
}

function capabilityFunctions(appId: string, functions: string[]): string[] {
  return functions.map((name) =>
    name.startsWith(`${appId}/`) ? name : `${appId}/${name}`,
  );
}

function resultPolicyLabel(policy: string): string {
  if (policy === "private_to_invoker") return "Private result";
  if (policy === "agent_room") return "Share in Agent Room";
  return policy.replaceAll("_", " ");
}

function stringArray(value: unknown): string[] {
  return Array.isArray(value)
    ? value.filter((item): item is string => typeof item === "string")
    : [];
}

/**
 * One shared controller + presentation for Agent Room app access. Hosts only
 * discover providers and persist/revoke grants; grouping, drafts, pending
 * states and disclosure behavior stay identical in every surface.
 */
export function AgentAppAccessList({
  providers,
  providerIdentities = [],
  bindings,
  access,
  pending = [],
  loading = false,
  error = null,
  decision = null,
  onAccessChange,
  onAuthorize,
  onRevoke,
  compact = false,
  emptyLabel = "No apps with Agent permissions are available.",
}: AgentAppAccessListProps) {
  const providerIdentityByKey = React.useMemo(
    () =>
      new Map(
        providerIdentities.map((identity) => [providerKey(identity), identity]),
      ),
    [providerIdentities],
  );
  const providerOptions = React.useMemo(() => {
    const byKey = new Map(
      providers.map((provider) => [
        providerKey(provider),
        { ...provider, available: true },
      ]),
    );
    for (const binding of bindings) {
      const key = providerKey({
        roomId: binding.providerRoomId,
        appId: binding.appId,
      });
      if (byKey.has(key)) continue;
      const identity = providerIdentityByKey.get(key);
      byKey.set(key, {
        roomId: binding.providerRoomId,
        roomName: identity?.roomName ?? binding.providerRoomId,
        appId: binding.appId,
        appTitle: identity?.appTitle ?? binding.appId,
        icon: identity?.icon,
        offers: [{
          id: binding.offerId,
          title: binding.offerId,
          description: "",
          functions: stringArray(binding.functions),
          modes: [normalizeAgentCapabilityMode(binding.mode)],
          defaultMode: normalizeAgentCapabilityMode(binding.mode),
          risk: "unknown",
          resultPolicies: [binding.resultPolicy],
          defaultResultPolicy: binding.resultPolicy,
        }],
        available: false,
      });
    }
    return Array.from(byKey.values()).sort((left, right) =>
      `${left.appTitle}:${left.roomName}`.localeCompare(
        `${right.appTitle}:${right.roomName}`,
      ),
    );
  }, [bindings, providerIdentityByKey, providers]);
  const [rowState, setRowState] = React.useState<
    Record<
      string,
      {
        status: "authorizing" | "revoking" | "pending" | "error";
        error?: string;
        requestId?: string;
        desired?: AgentCapabilityAccess;
      }
    >
  >({});
  const [draftScope, setDraftScope] = React.useState<
    Record<
      string,
      {
        offerId: string;
        mode: AgentCapabilityMode;
        resultPolicy: string;
        functions: string[];
      }
    >
  >({});

  React.useEffect(() => {
    setRowState((current) => {
      let changed = false;
      const next = { ...current };
      for (const currentAccess of access) {
        const key = providerKey({
          roomId: currentAccess.providerRoomId,
          appId: currentAccess.appId,
        });
        // Nur aufraeumen, wenn das WARTEN wirklich vorbei ist — also die
        // Berechtigung eingetroffen ist, auf die gewartet wurde. Vorher genuegte
        // irgendein Eintrag fuer dieselbe App: wer eine BESTEHENDE Berechtigung
        // umstellte, dessen "warte auf Warden" wurde vom noch aktiven ALTEN
        // Eintrag sofort wieder geloescht — die Zeile sprang auf den alten Wert
        // zurueck und es sah aus, als waere nichts passiert (Thomas 2026-08-12).
        const wartet = next[key];
        if (wartet?.status !== "pending") continue;
        if (wartet.desired && wartet.desired.offerId !== currentAccess.offerId) continue;
        delete next[key];
        changed = true;
      }
      return changed ? next : current;
    });
  }, [access]);

  React.useEffect(() => {
    if (!decision?.providerRoomId || !decision.appId) return;
    const key = providerKey({
      roomId: decision.providerRoomId,
      appId: decision.appId,
    });
    const pending = rowState[key];
    if (!pending || pending.status !== "pending") return;
    if (
      decision.requestId &&
      pending.requestId &&
      decision.requestId !== pending.requestId
    ) {
      return;
    }
    if (decision.kind === "granted") {
      if (pending.desired) {
        onAccessChange([
          ...access.filter(
            (binding) =>
              binding.providerRoomId !== decision.providerRoomId ||
              binding.appId !== decision.appId,
          ),
          pending.desired,
        ]);
      }
      setRowState((current) => {
        const next = { ...current };
        delete next[key];
        return next;
      });
      return;
    }
    if (decision.kind === "denied" || decision.kind === "error") {
      setRowState((current) => ({
        ...current,
        [key]: {
          ...pending,
          status: "error",
          error:
            decision.error ||
            (decision.kind === "denied"
              ? "Warden denied this permission."
              : "Warden could not apply this permission."),
        },
      }));
    }
  }, [access, decision, onAccessChange, rowState]);

  const readDraft = React.useCallback(
    (provider: ProviderOption, active?: AgentCapabilityAccess) => {
      const key = providerKey(provider);
      const selectedOffer =
        provider.offers.find((offer) => offer.id === draftScope[key]?.offerId) ??
        provider.offers.find((offer) => offer.id === active?.offerId) ??
        provider.offers[0];
      const stored = draftScope[key];
      return {
        offer: selectedOffer,
        access: selectedOffer
          ? {
              providerRoomId: provider.roomId,
              appId: provider.appId,
              offerId: selectedOffer.id,
              mode:
                stored?.offerId === selectedOffer.id
                  ? stored.mode
                  : active?.offerId === selectedOffer.id
                    ? active.mode
                    : preferredAgentCapabilityMode(selectedOffer),
              resultPolicy:
                stored?.offerId === selectedOffer.id
                  ? stored.resultPolicy
                  : active?.offerId === selectedOffer.id
                    ? active.resultPolicy
                    : selectedOffer.defaultResultPolicy,
              functions:
                stored?.offerId === selectedOffer.id
                  ? stored.functions
                  : active?.offerId === selectedOffer.id
                    ? active.functions
                    : capabilityFunctions(provider.appId, selectedOffer.functions),
            }
          : null,
      };
    },
    [draftScope],
  );

  const authorize = React.useCallback(
    async (provider: ProviderOption, desired: AgentCapabilityAccess) => {
      const key = providerKey(provider);
      setRowState((current) => ({
        ...current,
        [key]: { status: "authorizing", desired },
      }));
      try {
        const result = await onAuthorize(desired);
        if (result.status === "pending") {
          setRowState((current) => ({
            ...current,
            [key]: {
              status: "pending",
              requestId: result.requestId,
              desired,
            },
          }));
          return;
        }
        setRowState((current) => {
          const next = { ...current };
          delete next[key];
          return next;
        });
        onAccessChange([
          ...access.filter(
            (binding) =>
              binding.providerRoomId !== provider.roomId ||
              binding.appId !== provider.appId,
          ),
          desired,
        ]);
      } catch (cause) {
        setRowState((current) => ({
          ...current,
          [key]: {
            status: "error",
            error: cause instanceof Error ? cause.message : String(cause),
            desired,
          },
        }));
      }
    },
    [access, onAccessChange, onAuthorize],
  );

  const revoke = React.useCallback(
    async (provider: ProviderOption, active: AgentCapabilityAccess) => {
      const key = providerKey(provider);
      setRowState((current) => ({
        ...current,
        [key]: { status: "revoking" },
      }));
      try {
        await onRevoke({
          providerRoomId: provider.roomId,
          appId: provider.appId,
          offerId: active.offerId,
        });
        setRowState((current) => {
          const next = { ...current };
          delete next[key];
          return next;
        });
        onAccessChange(
          access.filter(
            (binding) =>
              binding.providerRoomId !== provider.roomId ||
              binding.appId !== provider.appId,
          ),
        );
      } catch (cause) {
        setRowState((current) => ({
          ...current,
          [key]: {
            status: "error",
            error: cause instanceof Error ? cause.message : String(cause),
          },
        }));
      }
    },
    [access, onAccessChange, onRevoke],
  );

  const itemProviders = React.useMemo(
    () =>
      new Map(
        providerOptions.map((provider) => [
          providerKey(provider),
          provider,
        ]),
      ),
    [providerOptions],
  );
  const pendingKeys = React.useMemo(
    () =>
      new Set(
        pending.map((entry) =>
          providerKey({ roomId: entry.providerRoomId, appId: entry.appId }),
        ),
      ),
    [pending],
  );
  const items = React.useMemo(
    () =>
      providerOptions.map((provider): AppAccessListItem => {
        const key = providerKey(provider);
        const active = access.find(
          (binding) =>
            binding.providerRoomId === provider.roomId &&
            binding.appId === provider.appId,
        );
        const draft = readDraft(provider, active);
        const transient = rowState[key];
        const changed = Boolean(
          active &&
          draft.access &&
          (active.offerId !== draft.access.offerId ||
            active.mode !== draft.access.mode ||
            active.resultPolicy !== draft.access.resultPolicy),
        );
        const settings = draft.offer && draft.access ? (
          <div className="space-y-2.5">
            {provider.offers.length > 1 ? (
              <label className="grid gap-1 text-meta text-fg-muted">
                <span>Access</span>
                <select
                  value={draft.access.offerId}
                  onChange={(event) => {
                    const offer = provider.offers.find(
                      (candidate) => candidate.id === event.target.value,
                    );
                    if (!offer) return;
                    setDraftScope((current) => ({
                      ...current,
                      [key]: {
                        offerId: offer.id,
                        mode: preferredAgentCapabilityMode(offer),
                        resultPolicy: offer.defaultResultPolicy,
                        functions: capabilityFunctions(provider.appId, offer.functions),
                      },
                    }));
                  }}
                  className="h-8 rounded-md border border-border bg-surface px-2 text-xs text-fg"
                >
                  {provider.offers.map((offer) => (
                    <option key={offer.id} value={offer.id}>
                      {offer.title}
                    </option>
                  ))}
                </select>
              </label>
            ) : null}
            {draft.offer.resultPolicies.length > 1 ? (
              <div className="grid gap-2 sm:grid-cols-2">
                <label className="grid gap-1 text-meta text-fg-muted">
                  <span>Results</span>
                  <select
                    value={draft.access.resultPolicy}
                    onChange={(event) =>
                      setDraftScope((current) => ({
                        ...current,
                        [key]: {
                          ...draft.access!,
                          resultPolicy: event.target.value,
                        },
                      }))
                    }
                    className="h-8 rounded-md border border-border bg-surface px-2 text-xs text-fg"
                  >
                    {draft.offer.resultPolicies.map((policy) => (
                      <option key={policy} value={policy}>
                        {resultPolicyLabel(policy)}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
            ) : null}
            {draft.offer.description ? (
              <p className="m-0 text-meta text-fg-muted">
                {draft.offer.description}
              </p>
            ) : null}
            {changed ? (
              <Button
                type="button"
                size="sm"
                className="h-7 px-2.5 text-meta"
                onClick={() => void authorize(provider, draft.access!)}
              >
                Apply
              </Button>
            ) : null}
            {transient?.error ? (
              <p className="m-0 text-meta text-danger">{transient.error}</p>
            ) : null}
          </div>
        ) : null;
        return {
          id: key,
          appId: provider.appId,
          name: provider.appTitle,
          roomName: provider.roomName,
          icon: provider.icon,
          enabled: Boolean(active),
          disabled:
            !provider.available ||
            transient?.status === "authorizing" ||
            transient?.status === "revoking",
          status:
            transient?.status === "pending" || (!transient && pendingKeys.has(key))
              ? "pending"
              : transient?.status === "error"
                ? "error"
                : active
                  ? "connected"
                  : provider.available
                    ? "available"
                    : "unavailable",
          statusLabel:
            transient?.status === "authorizing"
              ? "Requesting…"
              : transient?.status === "revoking"
                ? "Disconnecting…"
                : transient?.status === "error"
                  ? "Retry"
                  : undefined,
          statusMessage: transient?.error,
          details: settings,
        };
      }),
    [access, authorize, pendingKeys, providerOptions, readDraft, rowState],
  );

  return (
    <div className="space-y-2">
      <AppAccessList
        items={items}
        loading={loading}
        compact={compact}
        emptyLabel={emptyLabel}
        onToggle={(item, enabled) => {
          const provider = itemProviders.get(item.id);
          if (!provider) return;
          const active = access.find(
            (binding) =>
              binding.providerRoomId === provider.roomId &&
              binding.appId === provider.appId,
          );
          const draft = readDraft(provider, active);
          if (enabled && draft.access) void authorize(provider, draft.access);
          if (!enabled && active) void revoke(provider, active);
        }}
      />
      {error ? (
        <p className="m-0 text-meta text-danger">{error}</p>
      ) : null}
    </div>
  );
}
