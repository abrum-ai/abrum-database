export type AgentCapabilityExecutionMode =
  | "on_behalf_of_caller"
  | "delegated_service"
  | "autonomous";

export function preferredAgentCapabilityMode<T extends AgentCapabilityExecutionMode>(
  offer: { modes: T[]; defaultMode: T },
): T {
  return offer.modes.includes("delegated_service" as T)
    ? "delegated_service" as T
    : offer.defaultMode;
}
