import { memo, useEffect, useState } from "react";
import {
  AGENT_AVATAR_RETRY_DELAYS_MS,
  agentAvatarTheme,
  retryableAgentAvatarUrl,
} from "@abrum/runtime";
import { cn } from "./cn";
import { agentAvatarPixels, agentAvatarRasterKey, cachedAgentAvatarRaster, loadAgentAvatarRaster } from "./agent-avatar-raster";

export interface AgentAvatarProps {
  roomId: string;
  name?: string;
  size?: number;
  className?: string;
  /** Optional persisted override; omitted Agent Rooms derive it from roomId. */
  paletteId?: string;
  /** Optional uploaded image. When present it replaces the generated Flare. */
  imageUrl?: string | null;
  /** Compact navigation crops the same Oreo artwork to a filled rounded square. */
  variant?: "flare" | "rounded";
}

function GeneratedAgentAvatar({
  theme,
  size,
}: {
  theme: ReturnType<typeof agentAvatarTheme>;
  size: number;
}) {
  const pixels = agentAvatarPixels(size, typeof window === "undefined" ? 1 : window.devicePixelRatio || 1);
  const key = agentAvatarRasterKey(theme, pixels);
  const [ready, setReady] = useState(() => ({ key, images: cachedAgentAvatarRaster(key) }));
  const sources = ready.key === key ? ready.images : cachedAgentAvatarRaster(key);
  useEffect(() => {
    let mounted = true;
    void loadAgentAvatarRaster(theme, pixels).then(images => { if (mounted) setReady({ key, images }); });
    return () => { mounted = false; };
  }, [key, pixels]);

  return (
    <>
      <img
        className="abrum-agent-avatar-light"
        src={sources?.light} alt="" width={size} height={size} draggable={false}
      />
      <img
        className="abrum-agent-avatar-dark"
        src={sources?.dark} alt="" width={size} height={size} draggable={false}
      />
    </>
  );
}

/** The shared Flare identity used by Agent lists and both chat headers. */
export const AgentAvatar = memo(function AgentAvatar({
  roomId,
  name = "Agent",
  size = 32,
  className,
  paletteId,
  imageUrl,
  variant = "flare",
}: AgentAvatarProps) {
  const [imageState, setImageState] = useState<{
    imageUrl: string | null;
    failed: boolean;
    retryAttempt: number;
  }>({ imageUrl: null, failed: false, retryAttempt: 0 });
  const imageStateIsCurrent = imageState.imageUrl === imageUrl;
  const imageFailed = imageStateIsCurrent && imageState.failed;
  const retryAttempt = imageStateIsCurrent ? imageState.retryAttempt : 0;
  const theme = agentAvatarTheme(roomId, paletteId);

  useEffect(() => {
    if (!imageUrl || !imageFailed) return;
    const retryDelay = AGENT_AVATAR_RETRY_DELAYS_MS[retryAttempt];
    if (retryDelay === undefined) return;

    const retryTimer = window.setTimeout(() => {
      setImageState((current) => {
        if (current.imageUrl !== imageUrl || !current.failed) return current;
        return { imageUrl, failed: false, retryAttempt: current.retryAttempt + 1 };
      });
    }, retryDelay);
    return () => window.clearTimeout(retryTimer);
  }, [imageFailed, imageUrl, retryAttempt]);

  if (imageUrl && !imageFailed) {
    return (
      <span
        className={cn("abrum-agent-avatar abrum-agent-avatar-image", className)}
        style={{ width: size, height: size }}
        role="img"
        aria-label={`${name} avatar`}
        data-agent-palette={theme.paletteId}
        data-avatar-variant={variant}
      >
        <img
          src={retryableAgentAvatarUrl(imageUrl, retryAttempt)}
          alt=""
          draggable={false}
          onError={() => {
            setImageState((current) => ({
              imageUrl,
              failed: true,
              retryAttempt: current.imageUrl === imageUrl ? current.retryAttempt : 0,
            }));
          }}
        />
      </span>
    );
  }

  return (
    <span
      className={cn("abrum-agent-avatar", className)}
      style={{ width: size, height: size }}
      role="img"
      aria-label={`${name} avatar`}
      data-agent-palette={theme.paletteId}
      data-avatar-variant={variant}
    >
      <GeneratedAgentAvatar theme={theme} size={size} />
    </span>
  );
});
