import type { AgentAvatarTheme } from "@abrum/runtime";
import { agentAvatarImages } from "./agent-avatar-svg";

type Images = { light: string; dark: string };
type Entry = { ready?: Images; promise: Promise<Images> };
const memory = new Map<string, Entry>();
const CACHE_NAME = "abrum-agent-avatar-webp-v1";
// Bump the recipe when the Oreo version, drift or rendering options change.
const RECIPE = "oreo-0.1.0-flare-drift8-v1";
const MAX_MEMORY = 128;
const MAX_DISK_IMAGES = 256;
let work = Promise.resolve();

export function agentAvatarPixels(size: number, density: number) {
  return Math.max(64, Math.min(512, 2 ** Math.ceil(Math.log2(Math.max(1, size * density)))));
}

export function agentAvatarRasterKey(theme: AgentAvatarTheme, pixels: number) {
  return JSON.stringify([RECIPE, theme.shape, theme.paletteId, theme.variantId, pixels]);
}

export function cachedAgentAvatarRaster(key: string) { return memory.get(key)?.ready; }

function dataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

async function bake(svg: string, pixels: number) {
  const image = new Image();
  image.src = svg;
  await image.decode();
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = pixels;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Avatar canvas unavailable");
  context.drawImage(image, 0, 0, pixels, pixels);
  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error("Avatar encoding failed")), "image/webp", 0.92);
  });
}

async function persistentCache(key: string) {
  try {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(key));
    const hash = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
    // CacheStorage keys only. These addresses are never requested over the network.
    return { cache: await caches.open(CACHE_NAME), url: `https://abrum.invalid/avatar-cache/${hash}` };
  } catch { return null; } // Private/embedded hosts can deny persistent storage.
}

async function render(theme: AgentAvatarTheme, pixels: number, key: string): Promise<Images> {
  const persistent = await persistentCache(key);
  const result = {} as Images;
  for (const appearance of ["light", "dark"] as const) {
    const url = `${persistent?.url}/${appearance}`;
    let cached: Response | undefined;
    try { cached = await persistent?.cache.match(url); } catch { /* optional cache */ }
    if (cached) {
      result[appearance] = await dataUrl(await cached.blob());
      continue;
    }
    const blob = await bake(agentAvatarImages(theme)[appearance], pixels);
    result[appearance] = await dataUrl(blob);
    try {
      await persistent?.cache.put(url, new Response(blob));
      const keys = await persistent?.cache.keys();
      for (const old of keys?.slice(0, Math.max(0, keys.length - MAX_DISK_IMAGES)) ?? []) await persistent?.cache.delete(old);
    } catch { /* A full/disabled disk cache must not break the avatar. */ }
  }
  return result;
}

export function loadAgentAvatarRaster(theme: AgentAvatarTheme, pixels: number): Promise<Images> {
  const key = agentAvatarRasterKey(theme, pixels);
  let entry = memory.get(key);
  if (entry) memory.delete(key);
  else {
    // Deduplicate all rows of an Agent and bake one recipe at a time, yielding
    // between jobs so opening a long list cannot monopolize the main thread.
    const promise = work.then(() => new Promise<void>(resolve => setTimeout(resolve, 0)))
      .then(() => render(theme, pixels, key)).catch(() => agentAvatarImages(theme));
    entry = { promise };
    const current = entry;
    work = promise.then(images => { current.ready = images; });
  }
  memory.set(key, entry);
  if (memory.size > MAX_MEMORY) memory.delete(memory.keys().next().value!);
  return entry.promise;
}
