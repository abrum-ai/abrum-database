import * as React from "react";
import { AppWindow } from "lucide-react";
import { cn } from "./cn";
import { formatAppSurfaceAppTitle } from "./app-surface-label";

export { formatAppSurfaceAppTitle, formatAppSurfaceTitle } from "./app-surface-label";

export interface AppSurfaceFrameProps extends Omit<React.HTMLAttributes<HTMLElement>, "title"> {
  appTitle?: string | null;
  appId?: string | null;
  surfaceTitle?: string | null;
  hideTitle?: boolean;
  actions?: React.ReactNode;
  headerClassName?: string;
  bodyClassName?: string;
  headerStyle?: React.CSSProperties;
  bodyStyle?: React.CSSProperties;
}

/**
 * Host-owned chrome for an app surface. Provider content belongs inside the
 * body; identity and window actions stay outside the provider iframe.
 */
export function AppSurfaceFrame({
  appTitle,
  appId,
  surfaceTitle,
  hideTitle = false,
  actions,
  className,
  headerClassName,
  bodyClassName,
  style,
  headerStyle,
  bodyStyle,
  children,
  ...props
}: AppSurfaceFrameProps) {
  const providerLabel = appTitle?.trim() || formatAppSurfaceAppTitle(appId);
  const surfaceLabel = surfaceTitle?.trim() || null;
  const showSurfaceLabel = Boolean(surfaceLabel && surfaceLabel !== providerLabel);

  return (
    <section
      {...props}
      data-slot="app-surface-frame"
      className={cn("flex min-h-0 flex-col overflow-hidden rounded-lg border border-border bg-surface text-fg", className)}
      style={{
        display: "flex",
        minHeight: 0,
        flexDirection: "column",
        overflow: "hidden",
        border: "1px solid var(--abrum-border, rgba(0,0,0,.12))",
        borderRadius: "var(--abrum-radius-md, 8px)",
        background: "var(--abrum-surface, #fff)",
        color: "var(--abrum-fg, #18181b)",
        ...style,
      }}
    >
      <header
        data-slot="app-surface-header"
        className={cn("flex h-10 shrink-0 items-center gap-2 border-b border-border px-3", headerClassName)}
        style={{
          display: "flex",
          minHeight: 40,
          flexShrink: 0,
          alignItems: "center",
          gap: 8,
          padding: "0 10px",
          borderBottom: hideTitle ? "none" : "1px solid var(--abrum-border, rgba(0,0,0,.10))",
          font: "12px/1.4 var(--abrum-font-sans, ui-sans-serif, system-ui, sans-serif)",
          ...headerStyle,
        }}
      >
        {!hideTitle ? (
          <>
            <AppWindow className="size-3.5 shrink-0 text-fg-subtle" size={14} aria-hidden="true" />
            <div
              className="flex min-w-0 flex-1 items-center gap-2 overflow-hidden"
              style={{ display: "flex", minWidth: 0, flex: 1, alignItems: "center", gap: 8, overflow: "hidden" }}
              title={appId && appId !== providerLabel ? `${providerLabel} (${appId})` : providerLabel}
            >
              <strong className="truncate font-medium" style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {providerLabel}
              </strong>
              {showSurfaceLabel ? (
                <>
                  <span className="shrink-0 text-fg-subtle" style={{ flexShrink: 0, color: "var(--abrum-fg-subtle, #a1a1aa)" }} aria-hidden="true">
                    ·
                  </span>
                  <span
                    className="truncate text-fg-muted"
                    style={{ overflow: "hidden", color: "var(--abrum-fg-muted, #52525b)", textOverflow: "ellipsis", whiteSpace: "nowrap" }}
                  >
                    {surfaceLabel}
                  </span>
                </>
              ) : null}
            </div>
          </>
        ) : null}
        {actions ? (
          <div className="ml-auto flex shrink-0 items-center gap-1" style={{ display: "flex", flexShrink: 0, alignItems: "center", gap: 4, marginLeft: "auto" }}>
            {actions}
          </div>
        ) : null}
      </header>
      <div
        data-slot="app-surface-body"
        className={cn("min-h-0 flex-1", bodyClassName)}
        style={{ minHeight: 0, flex: 1, ...bodyStyle }}
      >
        {children}
      </div>
    </section>
  );
}
