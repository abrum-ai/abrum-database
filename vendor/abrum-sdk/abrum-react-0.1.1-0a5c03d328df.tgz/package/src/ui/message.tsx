import * as React from "react";
import { cn } from "./cn";

/*
 * Message — the row that lays out a conversation turn: optional avatar, then a
 * content column (header · surface · footer). Vendored from shadcn's radix
 * "message" component and made token-driven. The bubble surface itself lives in
 * <Bubble>; this is purely the row scaffolding and alignment.
 */

export type MessageAlign = "start" | "end";

export interface MessageProps extends React.HTMLAttributes<HTMLDivElement> {
  align?: MessageAlign;
}

export function Message({ className, align = "start", ...props }: MessageProps) {
  return (
    <div
      data-slot="message"
      data-align={align}
      className={cn(
        "group/message flex w-full items-end gap-2",
        align === "end" ? "flex-row-reverse" : "flex-row",
        className,
      )}
      {...props}
    />
  );
}

export function MessageGroup({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div data-slot="message-group" className={cn("flex w-full flex-col gap-1.5", className)} {...props} />
  );
}

export function MessageAvatar({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      data-slot="message-avatar"
      className={cn(
        "flex size-7 shrink-0 select-none items-center justify-center self-end overflow-hidden rounded-full bg-surface-muted text-xs font-medium text-fg-muted",
        className,
      )}
      {...props}
    />
  );
}

export function MessageContent({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      data-slot="message-content"
      className={cn(
        "flex min-w-0 flex-col gap-1",
        "group-data-[align=end]/message:items-end",
        className,
      )}
      {...props}
    />
  );
}

export function MessageHeader({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      data-slot="message-header"
      className={cn("px-1 text-xs font-medium text-fg-subtle", className)}
      {...props}
    />
  );
}

export function MessageFooter({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      data-slot="message-footer"
      className={cn("flex items-center gap-1.5 px-1 text-xs text-fg-subtle", className)}
      {...props}
    />
  );
}
