import * as React from "react";
import { Activity, ArrowLeftRight, Archive, BookOpen, Bot, BriefcaseBusiness, Building2, CalendarDays, Car, Camera, ChartColumn, CloudSun, Code2, Coffee, Database, FileText, Folder, Gamepad2, Globe2, GraduationCap, Hammer, Heart, House, Image, KeyRound, LayoutDashboard, Lightbulb, Link, Mail, Map, MapPin, Megaphone, MessageCircle, Music2, Newspaper, Package, Palette, Percent, Phone, Plane, Plug, Radio, Receipt, Rocket, Search, Settings, Shapes, ShieldCheck, ShoppingBag, Smartphone, Sparkles, SquareTerminal, Star, Store, Truck, UserRound, UsersRound, Video, WalletCards, Wifi, Workflow, Wrench, Zap, type LucideIcon } from "lucide-react";
import { Brain } from "../brand-icons";
import { cn } from "./cn";

const APP_ICON_TOKENS: Record<string, LucideIcon> = {
  activity: Activity,
  app: Shapes,
  archive: Archive,
  book: BookOpen,
  bot: Bot,
  brain: Brain,
  briefcase: BriefcaseBusiness,
  building: Building2,
  calendar: CalendarDays,
  car: Car,
  camera: Camera,
  chart: ChartColumn,
  cloud: CloudSun,
  code: Code2,
  coffee: Coffee,
  database: Database,
  document: FileText,
  folder: Folder,
  game: Gamepad2,
  globe: Globe2,
  graduation: GraduationCap,
  hammer: Hammer,
  heart: Heart,
  home: House,
  image: Image,
  key: KeyRound,
  layout: LayoutDashboard,
  lightbulb: Lightbulb,
  link: Link,
  mail: Mail,
  map: Map,
  megaphone: Megaphone,
  message: MessageCircle,
  music: Music2,
  newspaper: Newspaper,
  package: Package,
  palette: Palette,
  percent: Percent,
  phone: Phone,
  pin: MapPin,
  plane: Plane,
  plug: Plug,
  radio: Radio,
  receipt: Receipt,
  rocket: Rocket,
  search: Search,
  settings: Settings,
  shield: ShieldCheck,
  shopping: ShoppingBag,
  smartphone: Smartphone,
  sparkles: Sparkles,
  terminal: SquareTerminal,
  star: Star,
  store: Store,
  transactions: ArrowLeftRight,
  truck: Truck,
  user: UserRound,
  users: UsersRound,
  video: Video,
  wallet: WalletCards,
  wifi: Wifi,
  workflow: Workflow,
  wrench: Wrench,
  zap: Zap,
};

export const APP_ICON_OPTIONS = Object.freeze(Object.keys(APP_ICON_TOKENS));

export interface AppIconProps extends React.HTMLAttributes<HTMLSpanElement> {
  icon?: string | null;
  size?: number;
}

/**
 * The canonical installed-app icon. Token names and image URLs intentionally
 * match the Desktop sidebar contract so app identity stays stable everywhere.
 */
export function AppIcon({
  icon,
  size = 18,
  className,
  ...props
}: AppIconProps) {
  const TokenIcon = APP_ICON_TOKENS[icon ?? ""] ?? Shapes;
  const image = Boolean(icon && /^(data:|https?:|\/)/.test(icon));
  return (
    <span
      {...props}
      className={cn(
        "inline-grid shrink-0 place-items-center overflow-hidden text-fg-muted",
        className,
      )}
      style={{ width: size, height: size, ...props.style }}
      aria-hidden="true"
    >
      {image ? (
        <img
          src={icon ?? ""}
          alt=""
          className="size-full object-contain"
        />
      ) : (
        <TokenIcon size={size} strokeWidth={1.8} />
      )}
    </span>
  );
}
