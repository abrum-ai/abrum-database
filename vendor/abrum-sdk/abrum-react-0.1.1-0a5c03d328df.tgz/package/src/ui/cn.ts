import { clsx, type ClassValue } from "clsx";
import { extendTailwindMerge } from "tailwind-merge";

const mergeAbrumClasses = extendTailwindMerge({
  extend: {
    theme: {
      text: ["micro", "meta", "ui", "body", "read", "title", "display", "code"],
    },
  },
});

/** Merge class names, de-duplicating conflicting Tailwind utilities. */
export function cn(...inputs: ClassValue[]) {
  return mergeAbrumClasses(clsx(inputs));
}
