// Geometry changes do not cancel the reader's intent. An explicit history
// gesture disarms following; reaching the live edge rearms it.
export function followAfterScroll(following: boolean, atBottom: boolean, autoScroll: boolean) {
  return autoScroll && (following || atBottom);
}
