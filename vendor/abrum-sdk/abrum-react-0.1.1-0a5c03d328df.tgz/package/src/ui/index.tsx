// The optional shared abrum UI kit. Import from "@abrum/react/ui".
//
// Components are token-driven (see ./theme.css) — they follow light/dark and any
// host theme automatically. Tailwind apps must import "@abrum/react/tailwind.css"
// (which registers the token utilities and scans these sources); plain-CSS apps
// import "@abrum/react/theme.css" for the raw variables.

export { cn } from "./cn";
export { Button, type ButtonProps, type ButtonVariant, type ButtonSize } from "./button";
export { Input } from "./input";
export { Textarea } from "./textarea";
export { Select } from "./select";
export { Switch } from "./switch";
export {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  type TabsProps,
  type TabsListProps,
  type TabsTriggerProps,
  type TabsContentProps,
} from "./tabs";
export { Popover, PopoverAnchor, PopoverTrigger, PopoverContent } from "./popover";
export {
  ContextMenu,
  ContextMenuTrigger,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuCheckboxItem,
  ContextMenuRadioItem,
  ContextMenuLabel,
  ContextMenuSeparator,
  ContextMenuShortcut,
  ContextMenuGroup,
  ContextMenuPortal,
  ContextMenuSub,
  ContextMenuSubContent,
  ContextMenuSubTrigger,
  ContextMenuRadioGroup,
} from "./context-menu";
export { Card, CardHeader, CardContent } from "./card";
export { ActivityWidget, type ActivityWidgetProps } from "./activity-widget";
export { Badge, type BadgeProps, type BadgeTone, type BadgeVariant } from "./badge";
export { SourceAppBadge, type SourceAppBadgeProps } from "./source-app";
export { StationTag, type StationTagProps } from "./station-tag";
export { APP_ICON_OPTIONS, AppIcon, type AppIconProps } from "./app-icon";
export {
  AppAccessList,
  type AppAccessListItem,
  type AppAccessListProps,
  type AppAccessStatus,
} from "./app-access-list";
export {
  AgentAppAccessList,
  agentCapabilityAccessFromBindings,
  normalizeAgentCapabilityMode,
  type AgentAppAccessListProps,
  type AgentCapabilityAccess,
  type AgentCapabilityBinding,
  type AgentCapabilityDecision,
  type AgentCapabilityMode,
  type AgentCapabilityOffer,
  type AgentCapabilityProvider,
  type AgentCapabilityProviderIdentity,
} from "./agent-app-access-list";
export {
  SelectableList,
  SelectableListItem,
  SelectableListAction,
  SelectableListEmpty,
  type SelectableListProps,
  type SelectableListItemProps,
  type SelectableListActionProps,
  type SelectableListEmptyProps,
} from "./selectable-list";
export {
  MasterDetail,
  MasterDetailMaster,
  MasterDetailDetail,
  MasterDetailHeader,
  type MasterDetailProps,
  type MasterDetailPaneKey,
} from "./master-detail";
export {
  AppSurfaceFrame,
  formatAppSurfaceAppTitle,
  formatAppSurfaceTitle,
  type AppSurfaceFrameProps,
} from "./app-surface-frame";
export {
  AgentAvatar,
  type AgentAvatarProps,
} from "./agent-avatar";
export {
  FolderAccessPicker,
  FolderAccessDropdown,
  AgentFolderAccessSettings,
  FolderAccessChips,
  type FolderAccessBinding,
  type FolderAccessMode,
  type FolderAccessPendingRequest,
  type FolderAccessRequest,
  type FolderAccessScope,
} from "./folder-access-picker";
export {
  agentAvatarTheme,
  type AgentAvatarTheme,
} from "@abrum/runtime";

// AI / conversation components (vendored from shadcn's radix registry,
// reconstructed against the documented API and made token-driven).
export {
  Bubble,
  BubbleContent,
  BubbleReactions,
  BubbleGroup,
  type BubbleProps,
  type BubbleVariant,
  type BubbleAlign,
} from "./bubble";
export {
  Message,
  MessageGroup,
  MessageAvatar,
  MessageContent,
  MessageHeader,
  MessageFooter,
  type MessageProps,
  type MessageAlign,
} from "./message";
export {
  Marker,
  MarkerIcon,
  MarkerContent,
  type MarkerProps,
  type MarkerVariant,
} from "./marker";
export {
  Attachment,
  AttachmentMedia,
  AttachmentContent,
  AttachmentTitle,
  AttachmentDescription,
  AttachmentActions,
  AttachmentAction,
  AttachmentTrigger,
  AttachmentGroup,
  type AttachmentProps,
  type AttachmentState,
  type AttachmentSize,
  type AttachmentOrientation,
} from "./attachment";
export {
  MessageScrollerProvider,
  MessageScroller,
  MessageScrollerViewport,
  MessageScrollerContent,
  MessageScrollerItem,
  MessageScrollerButton,
  type MessageScrollerProviderProps,
  type MessageScrollerProps,
} from "./message-scroller";
export { ScrollFade, type ScrollFadeProps } from "./scroll-fade";
export { Shimmer, type ShimmerProps } from "./shimmer";
