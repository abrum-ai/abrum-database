import { createAvatar } from "@oreo-design/avatar";
import type { AgentAvatarTheme } from "@abrum/runtime";

// Share one image resource across every chat belonging to the same Agent.
// Bound the cache for hosts that visit many different Agent Rooms over time.
const images = new Map<string, { light: string; dark: string }>();
const MAX_CACHED_AVATARS = 128;

export function agentAvatarImages(theme: AgentAvatarTheme) {
  const key = JSON.stringify([theme.shape, theme.paletteId, theme.variantId]);
  let result = images.get(key);
  if (result) images.delete(key);
  else {
    const render = (appearance: "light" | "dark") => {
      const { svg } = createAvatar({
        ...theme,
        palette: theme.paletteId,
        drift: 8,
        size: 64,
        background: null,
        appearance,
      });
      // An SVG image isolates filter ids and lets the browser reuse its decoded
      // surface, instead of maintaining two live filter trees in every row.
      return `data:image/svg+xml,${encodeURIComponent(svg)}`;
    };
    result = { light: render("light"), dark: render("dark") };
  }
  images.set(key, result);
  if (images.size > MAX_CACHED_AVATARS) images.delete(images.keys().next().value!);
  return result;
}
