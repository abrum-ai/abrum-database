import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cn } from "./cn";

/**
 * Filled tone palette. Canonical color names plus the domain-specific aliases
 * the apps already use (secrets: api-key/password/token/other; dev-view:
 * object/relation/schema/principal) all map to the same five colors, so those
 * call sites migrate to the shared Badge with zero changes. The `default` tone
 * is tokenized; the accent tones use fixed palette colors (decorative, always
 * available) with their own dark variants.
 */
const TONES = {
  default: "bg-surface-muted text-fg-muted",

  neutral: "bg-surface-muted text-fg-muted",
  info: "bg-sky-100 text-sky-700 dark:bg-sky-950/70 dark:text-sky-300",
  warning: "bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300",
  success: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300",
  danger: "bg-red-100 text-red-700 dark:bg-red-950/70 dark:text-red-300",

  sky: "bg-sky-100 text-sky-700 dark:bg-sky-950/70 dark:text-sky-300",
  violet: "bg-violet-100 text-violet-700 dark:bg-violet-950/70 dark:text-violet-300",
  amber: "bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300",
  emerald: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300",

  // secrets-web aliases
  "api-key": "bg-sky-100 text-sky-700 dark:bg-sky-950/70 dark:text-sky-300",
  password: "bg-violet-100 text-violet-700 dark:bg-violet-950/70 dark:text-violet-300",
  token: "bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300",
  other: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300",

  // dev-view aliases
  object: "bg-sky-100 text-sky-700 dark:bg-sky-950/70 dark:text-sky-300",
  relation: "bg-violet-100 text-violet-700 dark:bg-violet-950/70 dark:text-violet-300",
  schema: "bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300",
  principal: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300",
} as const;

export type BadgeTone = keyof typeof TONES;
export type BadgeVariant = "soft" | "default" | "secondary" | "destructive" | "outline" | "ghost";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  asChild?: boolean;
  tone?: BadgeTone;
  variant?: BadgeVariant;
}

const VARIANTS: Record<Exclude<BadgeVariant, "soft">, string> = {
  default: "border-transparent bg-fg text-primary-fg",
  secondary: "border-transparent bg-surface-muted text-fg",
  destructive: "border-transparent bg-red-600 text-white dark:bg-red-700",
  outline: "border-border bg-transparent text-fg-muted",
  ghost: "border-transparent bg-transparent text-fg-muted",
};

export function Badge({ asChild = false, className, tone = "default", variant = "soft", ...props }: BadgeProps) {
  const Component = asChild ? Slot : "span";
  return (
    <Component
      data-slot="badge"
      data-tone={tone}
      data-variant={variant}
      className={cn(
        "inline-flex w-fit shrink-0 items-center justify-center gap-1 overflow-hidden whitespace-nowrap rounded-full border px-2 py-0.5 text-micro font-medium transition-colors [&>[data-icon=inline-end]]:ml-0.5 [&>[data-icon=inline-start]]:mr-0.5 [&>svg]:pointer-events-none [&>svg]:size-3",
        variant === "soft" ? `border-transparent ${TONES[tone]}` : VARIANTS[variant],
        className,
      )}
      {...props}
    />
  );
}
