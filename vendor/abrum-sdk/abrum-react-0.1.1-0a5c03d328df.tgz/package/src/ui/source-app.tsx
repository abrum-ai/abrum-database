import * as React from "react";
import { AppWindow } from "lucide-react";
import { cn } from "./cn";

export interface SourceAppBadgeProps extends Omit<React.HTMLAttributes<HTMLSpanElement>, "title"> {
  appId?: string | null;
  title?: string | null;
  label?: string;
  icon?: React.ReactNode;
}

export function SourceAppBadge({
  appId,
  title,
  label = "Source",
  icon,
  className,
  ...props
}: SourceAppBadgeProps) {
  const display = (title || appId || "").trim();
  if (!display) return null;
  const fullTitle = appId && appId !== display ? `${label}: ${display} (${appId})` : `${label}: ${display}`;
  return (
    <span
      {...props}
      className={cn(
        "inline-flex min-w-0 items-center gap-1 rounded-md border border-border bg-surface-muted px-1.5 py-0.5 text-meta font-medium text-fg-muted",
        className,
      )}
      title={fullTitle}
    >
      <span className="shrink-0 text-fg-subtle" aria-hidden="true">
        {icon ?? <AppWindow className="size-3" />}
      </span>
      <span className="truncate">{display}</span>
    </span>
  );
}
