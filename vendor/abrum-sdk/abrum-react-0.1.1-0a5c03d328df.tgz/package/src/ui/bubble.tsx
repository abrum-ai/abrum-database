import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cn } from "./cn";

/*
 * Bubble — the conversational message surface. Vendored from shadcn's radix
 * "bubble" component (reconstructed against its documented API) and made
 * token-driven via the abrum utility layer, so it follows light/dark and the host
 * theme with no `dark:` variants. Scoped to the bubble surface only; pair it
 * with <Message> for avatars/headers/footers.
 */

export type BubbleVariant =
  | "default"
  | "secondary"
  | "muted"
  | "tinted"
  | "outline"
  | "ghost"
  | "destructive";
export type BubbleAlign = "start" | "end";

const VARIANTS: Record<BubbleVariant, string> = {
  default: "bg-primary text-primary-fg",
  secondary: "border border-border bg-secondary text-secondary-foreground",
  muted: "bg-muted text-foreground",
  tinted: "bg-accent-soft text-foreground",
  outline: "border border-border bg-transparent text-foreground",
  ghost: "bg-transparent text-foreground",
  destructive: "bg-danger-soft text-danger-strong",
};

export interface BubbleProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: BubbleVariant;
  align?: BubbleAlign;
}

export function Bubble({ className, variant = "default", align = "start", ...props }: BubbleProps) {
  return (
    <div
      data-slot="bubble"
      data-align={align}
      className={cn(
        "relative flex w-fit max-w-full flex-col gap-1 rounded-xl px-3 py-2 text-sm leading-relaxed",
        align === "end" ? "abrum-backdrop-blur--12 self-end rounded-br-md" : "self-start rounded-bl-md",
        VARIANTS[variant],
        className,
      )}
      {...props}
    />
  );
}

export interface BubbleContentProps extends React.HTMLAttributes<HTMLDivElement> {
  asChild?: boolean;
}

export function BubbleContent({ className, asChild = false, ...props }: BubbleContentProps) {
  const Comp = asChild ? Slot : "div";
  return (
    <Comp
      data-slot="bubble-content"
      className={cn("min-w-0 [overflow-wrap:anywhere]", className)}
      {...props}
    />
  );
}

export interface BubbleReactionsProps extends React.HTMLAttributes<HTMLDivElement> {
  side?: "top" | "bottom";
  align?: BubbleAlign;
}

export function BubbleReactions({
  className,
  side = "bottom",
  align = "end",
  ...props
}: BubbleReactionsProps) {
  return (
    <div
      data-slot="bubble-reactions"
      data-side={side}
      className={cn(
        "pointer-events-auto flex flex-wrap items-center gap-1",
        side === "top" ? "-mt-1 mb-1" : "mt-1",
        align === "end" ? "justify-end" : "justify-start",
        // each reaction child renders as a small token-driven pill
        "[&>*]:inline-flex [&>*]:items-center [&>*]:gap-1 [&>*]:rounded-full [&>*]:border [&>*]:border-border [&>*]:bg-surface [&>*]:px-1.5 [&>*]:py-0.5 [&>*]:text-xs [&>*]:leading-none [&>*]:text-fg-muted",
        className,
      )}
      {...props}
    />
  );
}

export function BubbleGroup({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div data-slot="bubble-group" className={cn("flex w-full flex-col gap-1", className)} {...props} />
  );
}
