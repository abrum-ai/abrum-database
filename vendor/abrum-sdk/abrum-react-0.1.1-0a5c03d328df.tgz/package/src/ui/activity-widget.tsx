import { useId, type ComponentProps, type HTMLAttributes, type ReactNode } from "react";
import { cn } from "./cn";

export interface ActivityWidgetProps extends Omit<HTMLAttributes<HTMLDivElement>, "title" | "onSelect" | "children"> {
  title: string;
  preview?: string;
  source: string;
  icon: ReactNode;
  /** Show the source/agent identity bar. Kanban columns can provide this context themselves. */
  showSource?: boolean;
  /** Place the status in the footer, beside the title or in the source header. */
  statusPlacement?: "footer" | "title" | "source";
  /** Render source, title and status as one horizontal row. */
  orientation?: "stacked" | "row" | "inline";
  status?: ReactNode;
  detail?: ReactNode;
  action?: ReactNode;
  /** Interactive content stays mounted outside the card's primary button. */
  richPreview?: ReactNode;
  selected?: boolean;
  state?: string;
  attention?: boolean;
  density?: "auto" | "comfortable" | "compact";
  selectProps?: Omit<ComponentProps<"button">, "children">;
  onSelect?: () => void;
}

/** Shared activity card for Runs, app activity and inline app surfaces. */
export function ActivityWidget({
  title, preview, source, icon, status, detail, action, richPreview,
  showSource = true, statusPlacement = "footer", orientation = "stacked", selected, state, attention, density = "auto", className, selectProps, onSelect,
  ...props
}: ActivityWidgetProps) {
  const id = useId();
  const titleId = `${id}-title`;
  const previewId = `${id}-preview`;
  const sourceId = `${id}-source`;
  const detailId = `${id}-detail`;
  return <div {...props} className={cn("activity-widget", className)} data-slot="activity-widget"
    data-selected={selected} data-status={state} data-attention={attention}
    data-density={density} data-selectable={Boolean(onSelect)} data-show-source={showSource}
    data-status-placement={statusPlacement} data-orientation={orientation} data-has-rich-preview={Boolean(richPreview)}>
    {onSelect ? <button type="button" aria-labelledby={selectProps?.["aria-label"] ? undefined : titleId}
      aria-describedby={[preview ? previewId : null, showSource ? sourceId : null, detail ? detailId : null].filter(Boolean).join(" ")}
      {...selectProps} className={cn("activity-widget-select", selectProps?.className)} onClick={onSelect} /> : null}
    {showSource ? <div id={sourceId} className="activity-widget-source-bar" data-slot="activity-widget-source">
      {icon}<span className="activity-widget-source">{source}</span>
      {statusPlacement === "source" && status ? <span className="activity-widget-status">{status}</span> : null}
    </div> : null}
    <div className="activity-widget-body" data-slot="activity-widget-body">
      <div className="activity-widget-title-row">
        <strong id={titleId}>{title}</strong>
        {statusPlacement === "title" && status ? <span className="activity-widget-title-status">{status}</span> : null}
      </div>
      {preview ? <span id={previewId} className="activity-widget-preview">{preview}</span> : null}
    </div>
    {richPreview ? <div className="activity-widget-rich-preview" data-slot="activity-widget-rich-preview">{richPreview}</div> : null}
    <div className="activity-widget-footer" data-slot="activity-widget-footer">
      {statusPlacement === "footer" && status ? <span className="activity-widget-status">{status}</span> : null}
    </div>
    {detail ? <div id={detailId} className="activity-widget-accessible">{detail}</div> : null}
    {action ? <div className="activity-widget-action" data-slot="activity-widget-action">{action}</div> : null}
  </div>;
}
