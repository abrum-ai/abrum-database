import * as React from "react";
import { Laptop, Monitor, Server, Smartphone } from "lucide-react";
import type { RoomOrigin, StationDeviceKind, StationPresence } from "@abrum/runtime";

export interface StationTagProps extends React.HTMLAttributes<HTMLSpanElement> {
  origin: RoomOrigin;
}

const PRESENCE_COLOR: Record<StationPresence, string> = {
  local: "var(--abrum-accent)",
  online: "var(--abrum-accent)",
  stale: "var(--abrum-danger)",
  offline: "var(--abrum-fg-subtle)",
  unknown: "var(--abrum-fg-subtle)",
};

const TAG_STYLE: React.CSSProperties = {
  minWidth: 0,
  maxWidth: "100%",
  display: "inline-flex",
  alignItems: "center",
  gap: "var(--abrum-room-1)",
  color: "var(--abrum-fg-muted)",
  font: "var(--abrum-type-ui)",
};

const TRUNCATE_STYLE: React.CSSProperties = {
  minWidth: 0,
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
};

const GENERIC_STATION_NAMES = new Set([
  "abrum-desktop",
  "kurrle-desktop",
  "pocket station",
  "station",
  "abrum",
  "abrum-beta",
  "abrum-desktop",
]);

const DEVICE_LABEL: Record<StationDeviceKind, string> = {
  laptop: "Laptop",
  desktop: "Desktop",
  server: "Server",
  phone: "Phone",
  unknown: "Station",
};

function stationLabel(origin: RoomOrigin): string {
  const stationName = origin.stationName?.trim() || "";
  const hostname = origin.hostname?.trim() || "";
  if (stationName && !GENERIC_STATION_NAMES.has(stationName.toLocaleLowerCase())) {
    return stationName;
  }
  return hostname || stationName || (origin.isLocal ? "This device" : "Station");
}

function DeviceIcon({ kind }: { kind: StationDeviceKind }) {
  const props = { style: { width: 14, height: 14, flex: "0 0 auto" }, "aria-hidden": true } as const;
  if (kind === "laptop") return <Laptop {...props} />;
  if (kind === "desktop") return <Monitor {...props} />;
  if (kind === "phone") return <Smartphone {...props} />;
  return <Server {...props} />;
}

export function StationTag({
  origin,
  className,
  style,
  title,
  ...props
}: StationTagProps) {
  const deviceKind = origin.deviceKind || "unknown";
  const station = stationLabel(origin);
  const fullTitle = title ?? `${station} · ${DEVICE_LABEL[deviceKind]}`;

  return (
    <span
      data-slot="station-tag"
      data-presence={origin.presence}
      data-device-kind={deviceKind}
      className={className}
      style={{ ...TAG_STYLE, ...style }}
      title={fullTitle}
      {...props}
    >
      <span style={{ width: 6, height: 6, flex: "0 0 auto", borderRadius: "50%", background: PRESENCE_COLOR[origin.presence] }} aria-hidden="true" />
      <DeviceIcon kind={deviceKind} />
      <span style={TRUNCATE_STYLE}>{station}</span>
    </span>
  );
}
