import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cn } from "./cn";
import { Button, type ButtonProps } from "./button";

/*
 * Attachment — a file/image card for chat composers and message footers.
 * Vendored from shadcn's radix "attachment". Token-driven. Compose:
 *
 *   <Attachment state="uploading">
 *     <AttachmentMedia variant="icon"><FileIcon/></AttachmentMedia>
 *     <AttachmentContent>
 *       <AttachmentTitle>report.pdf</AttachmentTitle>
 *       <AttachmentDescription>PDF · 1.2 MB</AttachmentDescription>
 *     </AttachmentContent>
 *     <AttachmentActions><AttachmentAction aria-label="Remove"><XIcon/></AttachmentAction></AttachmentActions>
 *   </Attachment>
 */

export type AttachmentState = "idle" | "uploading" | "processing" | "error" | "done";
export type AttachmentSize = "default" | "sm" | "xs";
export type AttachmentOrientation = "horizontal" | "vertical";

const SIZE: Record<AttachmentSize, string> = {
  default: "gap-3 p-2.5 text-sm",
  sm: "gap-2.5 p-2 text-sm",
  xs: "gap-2 p-1.5 text-xs",
};

export interface AttachmentProps extends React.HTMLAttributes<HTMLDivElement> {
  state?: AttachmentState;
  size?: AttachmentSize;
  orientation?: AttachmentOrientation;
}

export function Attachment({
  className,
  state = "done",
  size = "default",
  orientation = "horizontal",
  ...props
}: AttachmentProps) {
  const busy = state === "uploading" || state === "processing";
  return (
    <div
      data-slot="attachment"
      data-state={state}
      data-size={size}
      data-orientation={orientation}
      aria-busy={busy || undefined}
      className={cn(
        "relative flex min-w-0 items-center rounded-lg border border-border bg-surface text-foreground",
        orientation === "vertical" && "flex-col items-stretch text-center",
        SIZE[size],
        busy && "animate-pulse",
        state === "error" && "border-danger/60 text-danger-strong",
        className,
      )}
      {...props}
    />
  );
}

export interface AttachmentMediaProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "icon" | "image";
}

export function AttachmentMedia({ className, variant = "icon", ...props }: AttachmentMediaProps) {
  return (
    <div
      data-slot="attachment-media"
      data-variant={variant}
      className={cn(
        "flex shrink-0 items-center justify-center overflow-hidden",
        variant === "icon"
          ? "size-9 rounded-md bg-surface-muted text-fg-muted [&_svg]:size-4.5"
          : "size-10 rounded-md [&_img]:size-full [&_img]:object-cover",
        className,
      )}
      {...props}
    />
  );
}

export function AttachmentContent({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      data-slot="attachment-content"
      className={cn("flex min-w-0 flex-1 flex-col justify-center gap-0.5", className)}
      {...props}
    />
  );
}

export function AttachmentTitle({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      data-slot="attachment-title"
      className={cn("truncate font-medium leading-tight", className)}
      {...props}
    />
  );
}

export function AttachmentDescription({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      data-slot="attachment-description"
      className={cn("truncate text-xs text-fg-muted", className)}
      {...props}
    />
  );
}

export function AttachmentActions({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      data-slot="attachment-actions"
      className={cn("z-10 flex shrink-0 items-center gap-0.5", className)}
      {...props}
    />
  );
}

export function AttachmentAction({ className, size = "icon", variant = "ghost", ...props }: ButtonProps) {
  return (
    <Button
      data-slot="attachment-action"
      size={size}
      variant={variant}
      className={cn("size-7 appearance-none border-0 bg-transparent shadow-none", className)}
      {...props}
    />
  );
}

export interface AttachmentTriggerProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  asChild?: boolean;
}

export function AttachmentTrigger({ className, asChild = false, ...props }: AttachmentTriggerProps) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp
      data-slot="attachment-trigger"
      className={cn(
        "absolute inset-0 z-0 appearance-none rounded-lg border-0 bg-transparent p-0 outline-none focus-visible:ring-2 focus-visible:ring-ring",
        className,
      )}
      {...props}
    />
  );
}

export function AttachmentGroup({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      data-slot="attachment-group"
      className={cn("flex min-w-0 gap-2 overflow-x-auto [scrollbar-width:thin]", className)}
      {...props}
    />
  );
}
