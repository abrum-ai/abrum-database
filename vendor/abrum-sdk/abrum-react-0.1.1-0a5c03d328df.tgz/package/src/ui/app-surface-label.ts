export function formatAppSurfaceAppTitle(appId?: string | null): string {
  return humanizeAppSurfaceLabel(appId, "App");
}

export function formatAppSurfaceTitle(surfaceId?: string | null): string {
  return humanizeAppSurfaceLabel(surfaceId, "Widget");
}

function humanizeAppSurfaceLabel(value: string | null | undefined, fallback: string): string {
  const packageName = value?.trim().split("/").filter(Boolean).at(-1) ?? "";
  const normalized = packageName.replace(/^abrum[._-]/i, "").trim();
  if (!normalized) return fallback;
  return normalized
    .split(/[._-]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}
