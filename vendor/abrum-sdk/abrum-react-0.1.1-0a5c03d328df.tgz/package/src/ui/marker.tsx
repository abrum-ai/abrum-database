import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cn } from "./cn";

/*
 * Marker — an inline status line, system note, bordered row, or labeled
 * separator inside a conversation. Vendored from shadcn's radix "marker".
 * Token-driven. In abrum chat it renders tool-call status and "thinking"/section
 * breaks between turns.
 *
 *   default   → inline status chip (icon + text), left-aligned
 *   border    → full-width row with a hairline underneath
 *   separator → centered label flanked by divider lines
 */

export type MarkerVariant = "default" | "border" | "separator";

const VARIANTS: Record<MarkerVariant, string> = {
  default: "inline-flex w-fit items-center gap-1.5 text-xs text-fg-muted",
  border: "flex w-full items-center gap-2 border-b border-border pb-2 text-xs text-fg-muted",
  separator:
    "flex w-full items-center gap-2 text-xs text-fg-subtle before:h-px before:flex-1 before:bg-border after:h-px after:flex-1 after:bg-border",
};

export interface MarkerProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: MarkerVariant;
  asChild?: boolean;
}

export function Marker({ className, variant = "default", asChild = false, ...props }: MarkerProps) {
  const Comp = asChild ? Slot : "div";
  return <Comp data-slot="marker" data-variant={variant} className={cn(VARIANTS[variant], className)} {...props} />;
}

export function MarkerIcon({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) {
  return (
    <span
      data-slot="marker-icon"
      className={cn("inline-flex shrink-0 items-center justify-center [&_svg]:size-3.5", className)}
      {...props}
    />
  );
}

export function MarkerContent({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) {
  return <span data-slot="marker-content" className={cn("min-w-0 truncate", className)} {...props} />;
}
