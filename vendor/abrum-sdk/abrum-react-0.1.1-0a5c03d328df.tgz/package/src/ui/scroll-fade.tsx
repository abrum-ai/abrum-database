import * as React from "react";
import { cn } from "./cn";

/*
 * ScrollFade — a pointer-events-none gradient mask on one edge of a scroll
 * region, fading the host background into transparent so content dissolves at
 * the boundary instead of hard-clipping. Pure overlay: place it inside a
 * `relative` parent and drive `show` from the parent's scroll state (e.g.
 * MessageScroller toggles top/bottom fades as the reader moves). Defaults to
 * shown.
 */

export interface ScrollFadeProps extends React.HTMLAttributes<HTMLDivElement> {
  side?: "top" | "bottom" | "left" | "right";
  show?: boolean;
  /** Fade depth in pixels. */
  size?: number;
}

const SIDE: Record<NonNullable<ScrollFadeProps["side"]>, { pos: string; dir: string }> = {
  top: { pos: "inset-x-0 top-0", dir: "to bottom" },
  bottom: { pos: "inset-x-0 bottom-0", dir: "to top" },
  left: { pos: "inset-y-0 left-0", dir: "to right" },
  right: { pos: "inset-y-0 right-0", dir: "to left" },
};

export function ScrollFade({
  className,
  side = "bottom",
  show = true,
  size = 32,
  style,
  ...props
}: ScrollFadeProps) {
  const { pos, dir } = SIDE[side];
  const sizeStyle =
    side === "top" || side === "bottom" ? { height: size } : { width: size };
  return (
    <div
      data-slot="scroll-fade"
      data-side={side}
      aria-hidden
      className={cn(
        "pointer-events-none absolute z-10 transition-opacity duration-200",
        pos,
        show ? "opacity-100" : "opacity-0",
        className,
      )}
      style={{
        ...sizeStyle,
        background: `linear-gradient(${dir}, var(--abrum-bg), transparent)`,
        ...style,
      }}
      {...props}
    />
  );
}
