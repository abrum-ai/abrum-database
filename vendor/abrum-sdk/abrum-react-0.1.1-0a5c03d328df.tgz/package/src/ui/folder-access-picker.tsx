import * as React from "react";
import { Check, Clock3, Folder, FolderPlus, LoaderCircle, Settings2, X } from "lucide-react";
import { ChevronDown, Trash2 } from "../brand-icons";
import { Button } from "./button";
import { cn } from "./cn";
import { Select } from "./select";
import { Popover, PopoverContent, PopoverTrigger } from "./popover";

export type FolderAccessMode = "read" | "write" | "delete";
export type FolderAccessScope = "run" | "until" | "agent";

export interface FolderAccessBinding {
  bindingId: string;
  providerRoomId: string;
  slotId: string;
  displayName: string;
  mountName: string;
  access: FolderAccessMode;
  operations: string[];
  scopeKind: FolderAccessScope;
  holderDid: string;
  capCid: string;
  grantCid: string;
  expiresAtMs?: number;
  enabled?: boolean;
}

export interface FolderAccessRequest {
  access: FolderAccessMode;
  scopeKind: FolderAccessScope;
  ttlMs?: number;
  /** Re-authorize an existing path-free Station slot without opening a chooser. */
  slotId?: string;
  replaceGrantCid?: string;
}

/** A path-free request that is waiting for the user's Warden decision. */
export interface FolderAccessPendingRequest {
  requestId: string;
  slotIds: string[];
  displayNames: string[];
  scopeKind?: FolderAccessScope;
}

const TTL_OPTIONS = [
  { value: 60 * 60_000, label: "1 hour" },
  { value: 8 * 60 * 60_000, label: "8 hours" },
  { value: 24 * 60 * 60_000, label: "1 day" },
  { value: 7 * 24 * 60 * 60_000, label: "7 days" },
];

function scopeLabel(binding: FolderAccessBinding) {
  if (binding.scopeKind === "agent") return "This Agent";
  if (binding.scopeKind === "until" && binding.expiresAtMs) {
    return new Intl.DateTimeFormat(undefined, {
      dateStyle: "short",
      timeStyle: "short",
    }).format(binding.expiresAtMs);
  }
  return "This Run";
}

export function FolderAccessPicker({
  bindings,
  selectedGrantCids = [],
  onSelectedGrantCidsChange,
  onRequest,
  onChangeAccess,
  onRevoke,
  pendingRequests = [],
  fixedScopeKind,
  disabled = false,
  className,
}: {
  bindings: FolderAccessBinding[];
  selectedGrantCids?: string[];
  onSelectedGrantCidsChange?: (grantCids: string[]) => void;
  onRequest: (request: FolderAccessRequest) => Promise<unknown>;
  onChangeAccess?: (binding: FolderAccessBinding, access: FolderAccessMode) => Promise<unknown>;
  onRevoke?: (binding: FolderAccessBinding) => Promise<unknown>;
  pendingRequests?: FolderAccessPendingRequest[];
  /** Locks the picker to one standing scope, for example Agent settings. */
  fixedScopeKind?: FolderAccessScope;
  disabled?: boolean;
  className?: string;
}) {
  const [access, setAccess] = React.useState<FolderAccessMode>("delete");
  const [scopeKind, setScopeKind] = React.useState<FolderAccessScope>("run");
  const [ttlMs, setTtlMs] = React.useState(TTL_OPTIONS[0].value);
  const [busy, setBusy] = React.useState(false);
  const [updatingGrantCid, setUpdatingGrantCid] = React.useState<string | null>(null);
  const [revokingGrantCid, setRevokingGrantCid] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const liveBindings = bindings.filter(
    (binding) =>
      binding.enabled !== false &&
      (!binding.expiresAtMs || binding.expiresAtMs > Date.now()) &&
      (!fixedScopeKind || binding.scopeKind === fixedScopeKind),
  );
  const selectable = Boolean(onSelectedGrantCidsChange);
  const effectiveScopeKind = fixedScopeKind ?? scopeKind;

  function toggle(grantCid: string) {
    onSelectedGrantCidsChange?.(
      selectedGrantCids.includes(grantCid)
        ? selectedGrantCids.filter((candidate) => candidate !== grantCid)
        : [...selectedGrantCids, grantCid],
    );
  }

  async function chooseFolders() {
    setBusy(true);
    setError(null);
    try {
      await onRequest({
        access,
        scopeKind: effectiveScopeKind,
        ...(effectiveScopeKind === "until" ? { ttlMs } : {}),
      });
    } catch (requestError) {
      setError(
        requestError instanceof Error ? requestError.message : String(requestError),
      );
    } finally {
      setBusy(false);
    }
  }

  async function revoke(binding: FolderAccessBinding) {
    if (!onRevoke) return;
    setRevokingGrantCid(binding.grantCid);
    setError(null);
    try {
      await onRevoke(binding);
      onSelectedGrantCidsChange?.(
        selectedGrantCids.filter((grantCid) => grantCid !== binding.grantCid),
      );
    } catch (revokeError) {
      setError(
        revokeError instanceof Error ? revokeError.message : String(revokeError),
      );
    } finally {
      setRevokingGrantCid(null);
    }
  }

  async function changeAccess(binding: FolderAccessBinding, nextAccess: FolderAccessMode) {
    if (!onChangeAccess || nextAccess === binding.access) return;
    setUpdatingGrantCid(binding.grantCid);
    setError(null);
    try {
      await onChangeAccess(binding, nextAccess);
    } catch (updateError) {
      setError(
        updateError instanceof Error ? updateError.message : String(updateError),
      );
    } finally {
      setUpdatingGrantCid(null);
    }
  }

  const [optionsOpen, setOptionsOpen] = React.useState(false);
  const selectedCount = liveBindings.filter((binding) =>
    selectedGrantCids.includes(binding.grantCid),
  ).length;
  const headerStatus = pendingRequests.length
    ? "Warden…"
    : fixedScopeKind === "agent"
      ? "This Agent"
      : selectedCount > 0
      ? `${selectedCount} selected`
      : null;
  const accessLabel =
    access === "delete" ? "Delete" : access === "write" ? "Edit" : "Read";
  const scopeShort =
    effectiveScopeKind === "agent"
      ? "Agent"
      : effectiveScopeKind === "until"
        ? "Until…"
        : "Run";

  // A dense folder menu: the selected state is a check rather
  // than a full switch, and access details stay secondary to the folder name.
  // "Add folder" acts with the current access/scope choice.
  return (
    <section
      className={cn(
        "overflow-hidden rounded-lg border border-border bg-surface",
        className,
      )}
      aria-label="Local folder access"
      title={fixedScopeKind === "agent"
        ? "Paths stay on this Station. Grants apply to this Agent."
        : "Paths stay on this Station."}
    >
      <div className="flex min-h-9 items-center gap-2 px-2.5">
        <Folder className="size-4 shrink-0 text-fg-muted" aria-hidden="true" />
        <strong className="block min-w-0 flex-1 truncate text-body font-medium text-fg">
          Local folders
        </strong>
        {headerStatus ? (
          <span
            className={cn(
              "text-body font-normal",
              pendingRequests.length
                ? "text-amber-700 dark:text-amber-300"
                : selectedCount > 0
                  ? "text-emerald-700 dark:text-emerald-400"
                  : "text-fg-muted",
            )}
          >
            {headerStatus}
          </span>
        ) : null}
      </div>
      <div className="border-t border-border bg-surface-muted/35 py-1">
        {liveBindings.map((binding) => {
          const selected = selectedGrantCids.includes(binding.grantCid);
          return (
            <div
              key={binding.grantCid}
              className="group grid min-h-8 grid-cols-[minmax(0,1fr)_auto] items-center gap-1 px-1.5"
            >
              {selectable ? (
                <button
                  type="button"
                  className="flex h-7 min-w-0 appearance-none items-center gap-2 rounded-md border-0 bg-transparent px-1.5 text-left outline-none hover:bg-surface-hover focus-visible:ring-2 focus-visible:ring-border-focus"
                  aria-pressed={selected}
                  aria-label={`${selected ? "Detach" : "Attach"} ${binding.displayName} ${selected ? "from" : "to"} the next Run`}
                  onClick={() => toggle(binding.grantCid)}
                >
                  <Folder className="size-3.5 shrink-0 text-fg-muted" aria-hidden="true" />
                  <strong className="min-w-0 flex-1 truncate text-body font-medium text-fg">
                    {binding.displayName}
                  </strong>
                  <span className="shrink-0 text-body font-normal text-fg-subtle">
                    {scopeLabel(binding)}
                  </span>
                  <Check
                    className={cn(
                      "size-3.5 shrink-0 text-fg transition-opacity",
                      selected ? "opacity-100" : "opacity-0",
                    )}
                    aria-hidden="true"
                  />
                </button>
              ) : (
                <div className="flex h-7 min-w-0 items-center gap-2 px-1.5">
                  <Folder className="size-3.5 shrink-0 text-fg-muted" aria-hidden="true" />
                  <strong className="min-w-0 flex-1 truncate text-body font-medium text-fg">
                    {binding.displayName}
                  </strong>
                </div>
              )}
              <div className="flex items-center gap-1">
                {onChangeAccess ? (
                  <Select
                    value={binding.access}
                    onChange={(event) => void changeAccess(
                      binding,
                      event.target.value as FolderAccessMode,
                    )}
                    disabled={disabled || updatingGrantCid === binding.grantCid}
                    className="h-7 w-auto min-w-24 text-body"
                    aria-label={`Change ${binding.displayName} folder access`}
                  >
                    <option value="read">Read only</option>
                    <option value="write">Read and edit</option>
                    <option value="delete">Read, write and delete · high risk</option>
                  </Select>
                ) : (
                  <span className="px-1 text-body font-normal text-fg-subtle">
                    {binding.access === "delete"
                      ? "Delete"
                      : binding.access === "write"
                        ? "Edit"
                        : "Read"}
                  </span>
                )}
              {onRevoke ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="size-6 appearance-none border-0 bg-transparent text-fg-muted opacity-0 outline-none hover:text-red-600 focus-visible:opacity-100 focus-visible:ring-2 focus-visible:ring-border-focus group-hover:opacity-100"
                  disabled={disabled || revokingGrantCid === binding.grantCid}
                  aria-label={`Revoke ${binding.displayName} folder access`}
                  onClick={() => void revoke(binding)}
                >
                  <Trash2 className="size-3" aria-hidden="true" />
                </Button>
              ) : null}
              </div>
            </div>
          );
        })}
        {pendingRequests.map((request) => (
          <div
            key={request.requestId}
            className="flex min-h-8 items-center gap-2 px-3"
          >
            <Folder className="size-3.5 shrink-0 text-fg-muted" aria-hidden="true" />
            <strong className="min-w-0 flex-1 truncate text-body font-medium text-fg">
              {request.displayNames.join(", ")}
            </strong>
            <span className="shrink-0 text-body font-normal text-amber-700 dark:text-amber-300">
              Warden…
            </span>
            <LoaderCircle
              className="size-3.5 animate-spin text-fg-muted motion-reduce:animate-none"
              aria-hidden="true"
            />
          </div>
        ))}
        <div className="grid min-h-8 grid-cols-[minmax(0,1fr)_auto] items-center gap-1 px-1.5">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-7 min-w-0 appearance-none justify-start gap-2 border-0 bg-transparent px-1.5 text-body font-normal text-fg outline-none focus-visible:ring-2 focus-visible:ring-border-focus"
            disabled={disabled || busy}
            onClick={() => void chooseFolders()}
          >
            <FolderPlus className="size-3.5 text-fg-muted" aria-hidden="true" />
            {busy ? "Opening…" : "Add folder"}
          </Button>
          <button
            type="button"
            className="inline-flex h-7 appearance-none items-center gap-1 rounded-md border-0 bg-transparent px-1.5 text-body font-normal text-fg-muted outline-none hover:bg-surface-hover focus-visible:ring-2 focus-visible:ring-border-focus"
            disabled={disabled || busy}
            onClick={() => setOptionsOpen((open) => !open)}
            aria-expanded={optionsOpen}
            aria-label="Folder access options"
          >
            {accessLabel} · {scopeShort}
            <Settings2 className="size-3" aria-hidden="true" />
          </button>
        </div>
        {optionsOpen ? (
          <div className="space-y-1.5 border-t border-border/70 px-2 py-2">
            <div className={cn("grid gap-1.5", fixedScopeKind ? "grid-cols-1" : "grid-cols-2")}>
              <Select
                value={access}
                onChange={(event) => {
                  const next = event.target.value as FolderAccessMode;
                  setAccess(next);
                }}
                disabled={disabled || busy}
                className="h-7 text-body"
                aria-label="Folder access level"
              >
                <option value="read">Read only</option>
                <option value="write">Read and edit</option>
                <option value="delete">Read, write and delete · high risk</option>
              </Select>
              {fixedScopeKind ? null : (
                <Select
                  value={scopeKind}
                  onChange={(event) =>
                    setScopeKind(event.target.value as FolderAccessScope)
                  }
                  disabled={disabled || busy}
                  className="h-7 text-body"
                  aria-label="How long the access lasts"
                >
                  <option value="run">This Run</option>
                  <option value="until">Until…</option>
                  <option value="agent">This Agent</option>
                </Select>
              )}
            </div>
            {effectiveScopeKind === "until" ? (
              <label className="flex items-center gap-1.5">
                <Clock3 className="size-3 text-fg-muted" aria-hidden="true" />
                <Select
                  value={ttlMs}
                  onChange={(event) => setTtlMs(Number(event.target.value))}
                  disabled={disabled || busy}
                  className="h-7 flex-1 text-body"
                  aria-label="Access duration"
                >
                  {TTL_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </Select>
              </label>
            ) : null}
          </div>
        ) : null}
        {error ? (
          <p className="border-t border-border/70 px-2.5 py-1.5 text-body text-red-600" role="alert">
            {error}
          </p>
        ) : null}
      </div>
    </section>
  );
}

/** Compact composer control that keeps folder scope beside the model picker. */
export function FolderAccessDropdown({
  bindings,
  selectedGrantCids,
  onSelectedGrantCidsChange,
  onRequest,
  onChangeAccess,
  onRevoke,
  pendingRequests = [],
  disabled = false,
  className,
}: {
  bindings: FolderAccessBinding[];
  selectedGrantCids: string[];
  onSelectedGrantCidsChange: (grantCids: string[]) => void;
  onRequest: (request: FolderAccessRequest) => Promise<unknown>;
  onChangeAccess?: (binding: FolderAccessBinding, access: FolderAccessMode) => Promise<unknown>;
  onRevoke?: (binding: FolderAccessBinding) => Promise<unknown>;
  pendingRequests?: FolderAccessPendingRequest[];
  disabled?: boolean;
  className?: string;
}) {
  const selected = bindings.filter((binding) =>
    selectedGrantCids.includes(binding.grantCid),
  );
  const label =
    selected.length === 1
      ? selected[0]!.displayName
      : selected.length > 1
        ? `${selected.length} folders`
        : "Folders";
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          disabled={disabled}
          data-slot="folder-access-trigger"
          aria-label="Choose folders for the next run"
          title={label}
          className={cn(
            "inline-flex h-7 min-w-0 max-w-full items-center gap-1 rounded-md border-0 bg-transparent px-1.5 text-body font-medium text-fg transition-colors",
            "hover:bg-surface-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-border-focus",
            "disabled:cursor-default disabled:opacity-60",
            className,
          )}
        >
          <Folder className="size-3.5 shrink-0" aria-hidden="true" />
          <span
            data-slot="folder-access-label"
            className="min-w-0 flex-1 truncate font-normal text-fg-muted"
          >
            {label}
          </span>
          <ChevronDown
            data-slot="folder-access-chevron"
            className="size-3.5 shrink-0 text-fg-subtle"
            aria-hidden="true"
          />
        </button>
      </PopoverTrigger>
      <PopoverContent
        side="top"
        align="start"
        className="max-h-[min(30rem,70vh,var(--radix-popover-content-available-height))] w-[min(24rem,calc(100vw-2rem))] overflow-y-auto p-3"
      >
        <FolderAccessPicker
          bindings={bindings}
          selectedGrantCids={selectedGrantCids}
          onSelectedGrantCidsChange={onSelectedGrantCidsChange}
          onRequest={onRequest}
          onChangeAccess={onChangeAccess}
          onRevoke={onRevoke}
          pendingRequests={pendingRequests}
        />
      </PopoverContent>
    </Popover>
  );
}

/** Standing folder grants managed as part of an Agent's saved configuration. */
export function AgentFolderAccessSettings({
  bindings,
  onRequest,
  onChangeAccess,
  onRevoke,
  pendingRequests = [],
  disabled = false,
  className,
}: {
  bindings: FolderAccessBinding[];
  onRequest: (request: FolderAccessRequest) => Promise<unknown>;
  onChangeAccess: (binding: FolderAccessBinding, access: FolderAccessMode) => Promise<unknown>;
  onRevoke: (binding: FolderAccessBinding) => Promise<unknown>;
  pendingRequests?: FolderAccessPendingRequest[];
  disabled?: boolean;
  className?: string;
}) {
  return (
    <FolderAccessPicker
      bindings={bindings}
      pendingRequests={pendingRequests.filter(
        (request) => request.scopeKind === "agent",
      )}
      onRequest={onRequest}
      onChangeAccess={onChangeAccess}
      onRevoke={onRevoke}
      fixedScopeKind="agent"
      disabled={disabled}
      className={className}
    />
  );
}

export function FolderAccessChips({
  bindings,
  selectedGrantCids,
  onRemove,
}: {
  bindings: FolderAccessBinding[];
  selectedGrantCids: string[];
  onRemove: (grantCid: string) => void;
}) {
  const selected = bindings.filter((binding) =>
    selectedGrantCids.includes(binding.grantCid),
  );
  if (!selected.length) return null;
  return (
    <div className="flex flex-wrap gap-1.5" aria-label="Folders attached to the next Run">
      {selected.map((binding) => (
        <span
          key={binding.grantCid}
          className="inline-flex h-7 max-w-full items-center gap-1.5 rounded-full border border-border/70 bg-surface-muted px-2.5 text-body font-normal text-fg"
          title={`${binding.displayName} · ${
            binding.access === "delete"
              ? "Delete"
              : binding.access === "write"
                ? "Edit"
                : "Read"
          } · ${scopeLabel(binding)}`}
        >
          <Folder className="size-3.5 shrink-0 text-fg-muted" aria-hidden="true" />
          <span className="truncate">{binding.displayName}</span>
          <button
            type="button"
            className="ml-0.5 inline-flex size-4 items-center justify-center rounded-full text-fg-muted hover:bg-surface-hover hover:text-fg"
            aria-label={`Remove ${binding.displayName} from the next Run`}
            onClick={() => onRemove(binding.grantCid)}
          >
            <X className="size-3" aria-hidden="true" />
          </button>
        </span>
      ))}
    </div>
  );
}
