import * as React from "react";
import { cn } from "./cn";

type TabsOrientation = "horizontal" | "vertical";

interface TabsContextValue {
  baseId: string;
  value: string;
  orientation: TabsOrientation;
  setValue: (value: string) => void;
}

const TabsContext = React.createContext<TabsContextValue | null>(null);

function useTabsContext(component: string) {
  const context = React.useContext(TabsContext);
  if (!context) throw new Error(`${component} must be used inside Tabs`);
  return context;
}

function valueId(value: string) {
  return value.replace(/[^a-zA-Z0-9_-]/g, "-");
}

export interface TabsProps extends React.HTMLAttributes<HTMLDivElement> {
  value?: string;
  defaultValue?: string;
  orientation?: TabsOrientation;
  onValueChange?: (value: string) => void;
}

export function Tabs({
  id,
  value: controlledValue,
  defaultValue = "",
  orientation = "horizontal",
  onValueChange,
  className,
  children,
  ...props
}: TabsProps) {
  const generatedId = React.useId();
  const baseId = id ?? generatedId;
  const [uncontrolledValue, setUncontrolledValue] = React.useState(defaultValue);
  const value = controlledValue ?? uncontrolledValue;
  const setValue = React.useCallback((nextValue: string) => {
    if (controlledValue === undefined) setUncontrolledValue(nextValue);
    onValueChange?.(nextValue);
  }, [controlledValue, onValueChange]);
  const context = React.useMemo(
    () => ({ baseId, value, orientation, setValue }),
    [baseId, orientation, setValue, value],
  );

  return (
    <TabsContext.Provider value={context}>
      <div {...props} id={id} data-slot="tabs" data-orientation={orientation} className={cn("min-w-0", className)}>
        {children}
      </div>
    </TabsContext.Provider>
  );
}

export interface TabsListProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "pill" | "line";
}

export function TabsList({ className, variant = "pill", onKeyDown, ...props }: TabsListProps) {
  const { orientation } = useTabsContext("TabsList");
  return (
    <div
      {...props}
      role="tablist"
      aria-orientation={orientation}
      data-slot="tabs-list"
      data-variant={variant}
      onKeyDown={(event) => {
        onKeyDown?.(event);
        if (event.defaultPrevented) return;
        const previous = orientation === "vertical" ? "ArrowUp" : "ArrowLeft";
        const next = orientation === "vertical" ? "ArrowDown" : "ArrowRight";
        if (![previous, next, "Home", "End"].includes(event.key)) return;
        const tabs = Array.from(event.currentTarget.querySelectorAll<HTMLElement>('[role="tab"]:not([disabled])'));
        if (tabs.length === 0) return;
        const current = tabs.indexOf(document.activeElement as HTMLElement);
        const index = event.key === "Home"
          ? 0
          : event.key === "End"
            ? tabs.length - 1
            : event.key === previous
              ? (current <= 0 ? tabs.length - 1 : current - 1)
              : (current + 1) % tabs.length;
        event.preventDefault();
        tabs[index]?.focus();
        tabs[index]?.click();
      }}
      className={cn(
        "inline-flex items-center gap-0.5",
        orientation === "vertical" && "flex-col items-stretch",
        variant === "pill" && "bg-transparent",
        variant === "line" && "border-b border-border",
        className,
      )}
    />
  );
}

export interface TabsTriggerProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  value: string;
}

export function TabsTrigger({ value, className, onClick, ...props }: TabsTriggerProps) {
  const context = useTabsContext("TabsTrigger");
  const active = context.value === value;
  const id = valueId(value);
  return (
    <button
      {...props}
      id={`${context.baseId}-tab-${id}`}
      type="button"
      role="tab"
      aria-selected={active}
      aria-controls={`${context.baseId}-panel-${id}`}
      tabIndex={active ? 0 : -1}
      data-slot="tabs-trigger"
      data-active={active ? "true" : undefined}
      onClick={(event) => {
        onClick?.(event);
        if (!event.defaultPrevented) context.setValue(value);
      }}
      className={cn(
        "inline-flex min-h-8 items-center justify-center gap-1.5 rounded-md px-3 text-ui text-fg-muted transition-colors",
        "hover:text-fg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-border-focus",
        "data-[active=true]:bg-surface data-[active=true]:text-fg data-[active=true]:shadow-row-selected",
        "disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
    />
  );
}

export interface TabsContentProps extends React.HTMLAttributes<HTMLDivElement> {
  value: string;
}

export function TabsContent({ value, className, ...props }: TabsContentProps) {
  const context = useTabsContext("TabsContent");
  const active = context.value === value;
  const id = valueId(value);
  return (
    <div
      {...props}
      id={`${context.baseId}-panel-${id}`}
      role="tabpanel"
      aria-labelledby={`${context.baseId}-tab-${id}`}
      data-slot="tabs-content"
      data-active={active ? "true" : undefined}
      hidden={!active}
      tabIndex={0}
      className={cn("focus-visible:outline-none", className)}
    />
  );
}
