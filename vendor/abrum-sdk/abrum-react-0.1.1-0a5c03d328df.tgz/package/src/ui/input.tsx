import * as React from "react";
import { cn } from "./cn";

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => {
    return (
      <input
        ref={ref}
        className={cn(
          "h-8 w-full rounded-md border border-border bg-field px-3 text-sm text-fg outline-none placeholder:text-fg-subtle focus:border-border-focus",
          className,
        )}
        {...props}
      />
    );
  },
);

Input.displayName = "Input";
