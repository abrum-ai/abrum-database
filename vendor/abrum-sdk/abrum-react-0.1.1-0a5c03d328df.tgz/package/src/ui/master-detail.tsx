import * as React from "react";
import { cn } from "./cn";

/**
 * The shared two-pane master/detail layout: a narrow list rail on the left, the
 * selected item's detail on the right.
 *
 * Both panes are *translucent* — the master rail is fully transparent and the
 * detail pane sits on a 35% surface wash — so whatever the host paints behind
 * the app (the desktop glass, a room background, a wallpaper) stays visible and
 * the two panes read as one surface with a single hairline between them.
 *
 * The layout collapses to a single pane once the container is narrower than
 * `collapseBelow`; `activePane` then decides which one is shown. Collapse is
 * measured on the container, not the viewport, so an app embedded in a narrow
 * host frame collapses exactly like a narrow window.
 *
 *   <MasterDetail activePane={pane} masterWidth={360} masterMinWidth={280}>
 *     <MasterDetailMaster header={<MasterDetailHeader>…</MasterDetailHeader>}>
 *       …list…
 *     </MasterDetailMaster>
 *     <MasterDetailDetail>…reader…</MasterDetailDetail>
 *   </MasterDetail>
 */

export type MasterDetailPaneKey = "master" | "detail";

interface MasterDetailContextValue {
  compact: boolean;
  activePane: MasterDetailPaneKey;
  showMaster: boolean;
}

const MasterDetailContext = React.createContext<MasterDetailContextValue>({
  compact: false,
  activePane: "master",
  showMaster: true,
});

function track(width: number | string): string {
  return typeof width === "number" ? `${width}px` : width;
}

export interface MasterDetailProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Width of the master rail when both panes are visible. Default `280`. */
  masterWidth?: number | string;
  /** Lower bound for the rail, making it `minmax(min, width)`. */
  masterMinWidth?: number | string;
  /** Which pane is shown once the layout has collapsed. Default `"master"`. */
  activePane?: MasterDetailPaneKey;
  /** Container width (px) below which the layout collapses to one pane. Default `520`. `0` disables collapsing. */
  collapseBelow?: number;
  /** Hide the master rail entirely and give the detail the full width. Default `true`. */
  showMaster?: boolean;
}

export function MasterDetail({
  masterWidth = 280,
  masterMinWidth,
  activePane = "master",
  collapseBelow = 520,
  showMaster = true,
  className,
  style,
  children,
  ...props
}: MasterDetailProps) {
  const ref = React.useRef<HTMLDivElement | null>(null);
  const [compact, setCompact] = React.useState(false);

  React.useEffect(() => {
    const node = ref.current;
    if (!node || collapseBelow <= 0 || typeof ResizeObserver === "undefined") {
      setCompact(false);
      return;
    }
    const observer = new ResizeObserver((entries) => {
      const width = entries[0]?.contentRect.width ?? node.clientWidth;
      setCompact(width > 0 && width < collapseBelow);
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, [collapseBelow]);

  const railTrack = masterMinWidth
    ? `minmax(${track(masterMinWidth)}, ${track(masterWidth)})`
    : track(masterWidth);
  const columns = compact || !showMaster ? "minmax(0, 1fr)" : `${railTrack} minmax(0, 1fr)`;

  const context = React.useMemo<MasterDetailContextValue>(
    () => ({ compact, activePane, showMaster }),
    [compact, activePane, showMaster],
  );

  return (
    <MasterDetailContext.Provider value={context}>
      <div
        {...props}
        ref={ref}
        data-slot="master-detail"
        data-compact={compact ? "" : undefined}
        className={cn("grid min-h-0 min-w-0 flex-1 overflow-hidden text-fg", className)}
        style={{
          display: "grid",
          gridTemplateColumns: columns,
          minHeight: 0,
          minWidth: 0,
          overflow: "hidden",
          color: "var(--abrum-fg, #18181b)",
          ...style,
        }}
      >
        {children}
      </div>
    </MasterDetailContext.Provider>
  );
}

interface MasterDetailPaneProps extends React.HTMLAttributes<HTMLElement> {
  /** Sticky, non-scrolling chrome above the pane body. */
  header?: React.ReactNode;
  headerClassName?: string;
  bodyClassName?: string;
  /** Landmark element for the pane. Defaults to `aside` (master) / `section` (detail). */
  as?: "aside" | "section" | "main" | "div";
}

function paneHidden(context: MasterDetailContextValue, pane: MasterDetailPaneKey): boolean {
  if (pane === "master" && !context.showMaster) return true;
  return context.compact && context.activePane !== pane;
}

/** The list rail. Fully transparent — the host background shows through. */
export function MasterDetailMaster({
  header,
  className,
  headerClassName,
  bodyClassName,
  style,
  as: Element = "aside",
  children,
  ...props
}: MasterDetailPaneProps) {
  const context = React.useContext(MasterDetailContext);
  if (paneHidden(context, "master")) return null;

  return (
    <Element
      {...props}
      data-slot="master-detail-master"
      className={cn(
        "flex min-h-0 min-w-0 flex-col overflow-hidden bg-transparent",
        !context.compact && "border-r border-border",
        className,
      )}
      style={{
        display: "flex",
        flexDirection: "column",
        minHeight: 0,
        minWidth: 0,
        overflow: "hidden",
        background: "transparent",
        borderRight: context.compact ? undefined : "1px solid var(--abrum-border, rgba(0,0,0,.10))",
        ...style,
      }}
    >
      {header ? (
        <div data-slot="master-detail-master-header" className={cn("shrink-0", headerClassName)} style={{ flexShrink: 0 }}>
          {header}
        </div>
      ) : null}
      <div
        data-slot="master-detail-master-body"
        className={cn("flex min-h-0 min-w-0 flex-1 flex-col", bodyClassName)}
        style={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 0, minWidth: 0 }}
      >
        {children}
      </div>
    </Element>
  );
}

/** The detail pane. Sits on a translucent surface wash, not an opaque card. */
export function MasterDetailDetail({
  header,
  className,
  headerClassName,
  bodyClassName,
  style,
  as: Element = "section",
  children,
  ...props
}: MasterDetailPaneProps) {
  const context = React.useContext(MasterDetailContext);
  if (paneHidden(context, "detail")) return null;

  return (
    <Element
      {...props}
      data-slot="master-detail-detail"
      className={cn("relative flex min-h-0 min-w-0 flex-col overflow-hidden bg-surface/35", className)}
      style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        minHeight: 0,
        minWidth: 0,
        overflow: "hidden",
        background: "color-mix(in oklab, var(--abrum-surface, #fff) 35%, transparent)",
        ...style,
      }}
    >
      {header ? (
        <div data-slot="master-detail-detail-header" className={cn("shrink-0", headerClassName)} style={{ flexShrink: 0 }}>
          {header}
        </div>
      ) : null}
      <div
        data-slot="master-detail-detail-body"
        className={cn("flex min-h-0 min-w-0 flex-1 flex-col", bodyClassName)}
        style={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 0, minWidth: 0 }}
      >
        {children}
      </div>
    </Element>
  );
}

/** One row of pane chrome: a toolbar strip with the shared hairline below it. */
export function MasterDetailHeader({
  className,
  style,
  divided = true,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & { divided?: boolean }) {
  return (
    <div
      {...props}
      data-slot="master-detail-header"
      className={cn(
        "flex min-h-11 items-center gap-1.5 px-2.5 py-1.5",
        divided && "border-b border-border",
        className,
      )}
      style={{
        display: "flex",
        minHeight: 44,
        alignItems: "center",
        gap: 6,
        padding: "6px 10px",
        borderBottom: divided ? "1px solid var(--abrum-border, rgba(0,0,0,.10))" : undefined,
        ...style,
      }}
    />
  );
}
