import * as React from "react";
import { cn } from "./cn";

export const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(
  ({ className, ...props }, ref) => {
    return (
      <textarea
        ref={ref}
        className={cn(
          "min-h-24 w-full resize-none rounded-md border border-border bg-field px-3 py-2 text-sm text-fg outline-none placeholder:text-fg-subtle focus:border-border-focus",
          className,
        )}
        {...props}
      />
    );
  },
);

Textarea.displayName = "Textarea";
