import * as React from "react";
import { cn } from "./cn";

/*
 * Shimmer — a subtle gradient sweep across text, for "thinking"/streaming
 * status ("Working…", "Reading the room…"). The text is painted with a
 * muted→foreground→muted gradient clipped to the glyphs and animated via the
 * `animate-shimmer` utility registered in tailwind.css. Falls back to plain
 * muted text where background-clip:text is unsupported.
 */

export interface ShimmerProps extends React.HTMLAttributes<HTMLSpanElement> {
  asChild?: boolean;
}

export function Shimmer({ className, ...props }: ShimmerProps) {
  return (
    <span
      data-slot="shimmer"
      className={cn(
        "inline-block bg-[length:200%_100%] bg-clip-text text-fg-subtle",
        "bg-[linear-gradient(110deg,var(--abrum-fg-subtle)_35%,var(--abrum-fg)_50%,var(--abrum-fg-subtle)_65%)]",
        "supports-[background-clip:text]:text-transparent motion-safe:animate-shimmer",
        className,
      )}
      {...props}
    />
  );
}
