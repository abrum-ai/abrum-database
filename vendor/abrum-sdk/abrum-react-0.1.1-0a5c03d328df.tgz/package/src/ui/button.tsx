import * as React from "react";
import { cn } from "./cn";

export type ButtonVariant = "default" | "secondary" | "ghost" | "destructive" | "pro";
export type ButtonSize = "default" | "sm" | "icon";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
}

/**
 * The standard abrum button. Colors come from the `--abrum-*` token layer (via the
 * `bg-primary` / `text-fg` / … utilities), so light/dark and host theme follow
 * automatically — no `dark:` variants needed.
 *
 * `default` is the flat brand navy for every ordinary primary action. `pro` is
 * the gold button of abrum.ai and is reserved for upgrade/Pro moments.
 * Heights follow the control scale: sm 28, default 32 (same as inputs).
 */
export function Button({ className, variant = "default", size = "default", ...props }: ButtonProps) {
  return (
    <button
      data-slot="button"
      data-variant={variant}
      data-size={size}
      className={cn(
        "inline-flex items-center justify-center gap-1.5 rounded-md font-medium transition duration-[var(--abrum-duration-fast)] disabled:cursor-not-allowed disabled:opacity-50",
        size === "default" && "h-8 px-3 text-sm",
        size === "sm" && "h-7 px-2.5 text-xs",
        size === "icon" && "h-8 w-8",
        variant === "default" && "bg-primary text-primary-fg hover:bg-primary-hover",
        variant === "secondary" && "border border-border bg-surface text-fg hover:bg-surface-muted",
        variant === "ghost" && "text-fg-muted hover:bg-surface-muted hover:text-fg",
        variant === "destructive" && "text-danger hover:bg-danger-soft hover:text-danger-strong",
        variant === "pro" && "bg-[image:var(--abrum-brand-gold-fill)] text-[color:var(--abrum-brand-on-gold)] shadow-sm hover:brightness-105",
        className,
      )}
      {...props}
    />
  );
}
