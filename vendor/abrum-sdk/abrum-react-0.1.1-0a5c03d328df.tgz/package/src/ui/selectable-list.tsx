import * as React from "react";
import { cn } from "./cn";

/**
 * SelectableList — the ONE list for "pick one of these" surfaces.
 *
 * Agent runs, mail messages, and every other master column used to hand-roll
 * their own row: different paddings, different selected looks (a blue wash
 * here, a zinc fill there), different hover states. They sit next to the same
 * sidebar, so the sidebar's active tab is the look this component ships:
 * a lifted card — surface + hairline + 1px shadow — never a colour wash.
 *
 * The row is a `listbox`/`option` pair rather than a button, so per-row actions
 * (rename, delete, …) can be real buttons inside the row without nesting
 * interactive elements. Selection still answers to Enter/Space and the arrow
 * keys, and hosts that drive selection through their own trigger element (the
 * assistant-ui thread list, for one) pass it as `triggerAs`.
 */

export interface SelectableListProps
  extends React.HTMLAttributes<HTMLUListElement> {
  /** Accessible name for the list itself. */
  label?: string;
}

export const SelectableList = React.forwardRef<HTMLUListElement, SelectableListProps>(function SelectableList({
  label,
  className,
  children,
  ...props
}: SelectableListProps, forwardedRef) {
  const ref = React.useRef<HTMLUListElement | null>(null);
  const setRef = React.useCallback((node: HTMLUListElement | null) => {
    ref.current = node;
    if (typeof forwardedRef === "function") forwardedRef(node);
    else if (forwardedRef) forwardedRef.current = node;
  }, [forwardedRef]);

  // Roving focus across rows. The rows themselves stay tabbable so a click
  // never traps focus; this only makes Up/Down walk the list like a listbox.
  const onKeyDown = React.useCallback((event: React.KeyboardEvent<HTMLUListElement>) => {
    if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
    const root = ref.current;
    if (!root) return;
    const rows = Array.from(
      root.querySelectorAll('[role="option"]:not([aria-disabled="true"])'),
    ) as HTMLElement[];
    if (rows.length === 0) return;
    const active = document.activeElement as HTMLElement | null;
    const current = rows.findIndex((row) => row === active || row.contains(active));
    const next = event.key === "ArrowDown" ? current + 1 : current - 1;
    const target = rows[next < 0 ? 0 : next >= rows.length ? rows.length - 1 : next];
    if (!target) return;
    event.preventDefault();
    const trigger = target.querySelector("[data-slot='selectable-list-trigger']");
    ((trigger as HTMLElement | null) ?? target).focus();
  }, []);

  return (
    <ul
      {...props}
      ref={setRef}
      role="listbox"
      aria-label={label}
      data-slot="selectable-list"
      onKeyDown={onKeyDown}
      className={cn("flex min-h-0 flex-col gap-0.5 overflow-y-auto p-1", className)}
    >
      {children}
    </ul>
  );
});

SelectableList.displayName = "SelectableList";

export interface SelectableListItemProps
  extends Omit<React.LiHTMLAttributes<HTMLLIElement>, "title" | "onSelect"> {
  selected?: boolean;
  disabled?: boolean;
  /** Compact history rows use the smaller `meta` type role. */
  density?: "default" | "compact";
  onSelect?: () => void;
  /**
   * Element that owns the click/keyboard target. Defaults to a plain button;
   * pass a host primitive (e.g. `ThreadListItemPrimitive.Trigger`) to let that
   * host drive selection while this component owns the presentation.
   */
  triggerAs?: React.ElementType;
  /** Extra props forwarded to the trigger — `data-abrum-verb`, `title`, … */
  triggerProps?: Record<string, unknown>;
  /** Status dot, avatar or icon, left of the first line. */
  leading?: React.ReactNode;
  /** Optional first line above the title (mail: the sender). */
  headline?: React.ReactNode;
  /** The row's name. Replaced by an input while `renaming`. */
  title: React.ReactNode;
  /** Right-aligned metadata — a timestamp. Yields to `actions` on hover. */
  meta?: React.ReactNode;
  /** Optional last line (mail: the body snippet). */
  preview?: React.ReactNode;
  /** Row actions, revealed on hover/focus and while selected. */
  actions?: React.ReactNode;
  /** Inline rename. While true the title becomes a text field. */
  renaming?: boolean;
  renameValue?: string;
  renameLabel?: string;
  onRenameSubmit?: (value: string) => void;
  onRenameCancel?: () => void;
}

export const SelectableListItem = React.forwardRef<HTMLLIElement, SelectableListItemProps>(function SelectableListItem({
  selected = false,
  disabled = false,
  density = "default",
  onSelect,
  triggerAs,
  triggerProps,
  leading,
  headline,
  title,
  meta,
  preview,
  actions,
  renaming = false,
  renameValue = "",
  renameLabel = "Name",
  onRenameSubmit,
  onRenameCancel,
  className,
  ...props
}: SelectableListItemProps, forwardedRef) {
  const Trigger = (triggerAs ?? "button") as React.ElementType;
  const isButton = Trigger === "button";

  const content = (
    <>
      <span className="flex min-w-0 items-center gap-2">
        {leading}
        <span className="min-w-0 flex-1 truncate">{headline ?? title}</span>
        {meta ? (
          <span
            data-slot="selectable-list-meta"
            className={cn(
              "shrink-0 text-meta tabular-nums text-fg-muted transition-opacity",
              actions && "group-hover/row:opacity-0 group-focus-within/row:opacity-0",
            )}
          >
            {meta}
          </span>
        ) : null}
      </span>
      {headline ? <span className="block truncate">{title}</span> : null}
      {preview ? (
        <span className="block truncate text-meta text-fg-muted">{preview}</span>
      ) : null}
    </>
  );

  return (
    <li
      {...props}
      ref={forwardedRef}
      // The option is the trigger inside, so the listbox owns it directly.
      role="presentation"
      data-slot="selectable-list-item"
      data-selected={selected ? "true" : undefined}
      className={cn(
        "group/row relative rounded-lg border border-transparent transition-colors",
        selected
          ? "border-row-selected-border bg-row-selected shadow-row-selected"
          : !disabled && "hover:bg-row-hover",
        disabled && "opacity-60",
        className,
      )}
    >
      {renaming ? (
        <RenameField
          defaultValue={renameValue}
          label={renameLabel}
          onSubmit={onRenameSubmit}
          onCancel={onRenameCancel}
        />
      ) : (
        <Trigger
          {...triggerProps}
          data-slot="selectable-list-trigger"
          role="option"
          aria-selected={selected}
          aria-disabled={disabled || undefined}
          {...(isButton
            ? { type: "button", disabled }
            : { tabIndex: disabled ? -1 : 0 })}
          onClick={disabled ? undefined : onSelect}
          onKeyDown={
            isButton || disabled
              ? undefined
              : (event: React.KeyboardEvent) => {
                  if (event.key !== "Enter" && event.key !== " ") return;
                  event.preventDefault();
                  onSelect?.();
                }
          }
          className={cn(
            // `ui`, not `body`: this is dense chrome and it sits next to the
            // sidebar, which is on the same step. A comfortable-density host
            // scales it up on its own.
            "block w-full rounded-lg px-2 py-1.5 text-left text-fg",
            density === "compact" ? "text-meta" : "text-ui",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-border-focus",
            disabled ? "cursor-default" : "cursor-pointer",
          )}
        >
          {content}
        </Trigger>
      )}
      {actions && !renaming ? (
        <span
          data-slot="selectable-list-actions"
          className={cn(
            "absolute right-1.5 top-1 flex items-center gap-0.5 opacity-0 transition-opacity",
            "group-hover/row:opacity-100 group-focus-within/row:opacity-100",
          )}
        >
          {actions}
        </span>
      ) : null}
    </li>
  );
});

SelectableListItem.displayName = "SelectableListItem";

function RenameField({
  defaultValue,
  label,
  onSubmit,
  onCancel,
}: {
  defaultValue: string;
  label: string;
  onSubmit?: (value: string) => void;
  onCancel?: () => void;
}) {
  const ref = React.useRef<HTMLInputElement | null>(null);
  // Commit runs from both Enter and blur; guard so Enter (which blurs) cannot
  // submit twice, and so Escape's blur cannot resurrect a cancelled edit.
  const settled = React.useRef(false);

  React.useEffect(() => {
    ref.current?.select();
  }, []);

  const commit = () => {
    if (settled.current) return;
    settled.current = true;
    const value = ref.current?.value.trim() ?? "";
    if (value && value !== defaultValue) onSubmit?.(value);
    else onCancel?.();
  };

  return (
    <input
      ref={ref}
      data-slot="selectable-list-rename"
      aria-label={label}
      defaultValue={defaultValue}
      autoFocus
      className={cn(
        "block w-full rounded-lg border border-border-focus bg-field px-2 py-1.5",
        "text-ui text-fg focus-visible:outline-none",
      )}
      onBlur={commit}
      onKeyDown={(event) => {
        event.stopPropagation();
        if (event.key === "Enter") {
          event.preventDefault();
          commit();
        } else if (event.key === "Escape") {
          event.preventDefault();
          settled.current = true;
          onCancel?.();
        }
      }}
    />
  );
}

export interface SelectableListActionProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  tone?: "default" | "danger";
}

/** A small icon button for a row's `actions` slot. */
export function SelectableListAction({
  label,
  tone = "default",
  className,
  children,
  ...props
}: SelectableListActionProps) {
  return (
    <button
      {...props}
      type="button"
      aria-label={label}
      title={label}
      className={cn(
        "grid size-6 place-items-center rounded-md text-fg-muted transition-colors",
        "hover:bg-surface-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-border-focus",
        tone === "danger" ? "hover:text-danger" : "hover:text-fg",
        className,
      )}
    >
      {children}
    </button>
  );
}

export interface SelectableListEmptyProps
  extends React.HTMLAttributes<HTMLLIElement> {}

/** The list's own empty state, so callers don't invent one per surface. */
export function SelectableListEmpty({
  className,
  children,
  ...props
}: SelectableListEmptyProps) {
  return (
    <li
      {...props}
      role="presentation"
      className={cn("px-2 py-6 text-center text-meta text-fg-muted", className)}
    >
      {children}
    </li>
  );
}
