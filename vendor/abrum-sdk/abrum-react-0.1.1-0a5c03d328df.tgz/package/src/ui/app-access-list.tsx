import * as React from "react";
import { LoaderCircle, Settings2 } from "lucide-react";
import { ChevronDown } from "../brand-icons";
import { AppIcon } from "./app-icon";
import { Badge } from "./badge";
import { Button } from "./button";
import { cn } from "./cn";
import { Switch } from "./switch";

export type AppAccessStatus =
  | "available"
  | "connected"
  | "pending"
  | "unavailable"
  | "error";

export interface AppAccessListItem {
  id: string;
  appId: string;
  name: string;
  roomName?: string | null;
  icon?: string | null;
  enabled: boolean;
  disabled?: boolean;
  status?: AppAccessStatus;
  statusLabel?: string;
  statusMessage?: string;
  details?: React.ReactNode;
}

export interface AppAccessListProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange" | "onToggle"> {
  items: AppAccessListItem[];
  onToggle: (item: AppAccessListItem, enabled: boolean) => void;
  loading?: boolean;
  loadingLabel?: string;
  emptyLabel?: string;
  compact?: boolean;
}

function defaultStatusLabel(item: AppAccessListItem): string {
  if (item.status === "pending") return "Waiting for Warden";
  if (item.status === "unavailable") return "Unavailable";
  if (item.status === "error") return "Try again";
  return item.enabled || item.status === "connected" ? "Connected" : "Off";
}

/**
 * Reusable app/Room authority picker. The host owns capability discovery and
 * mutation; this component owns one consistent, accessible presentation.
 */
export function AppAccessList({
  items,
  onToggle,
  loading = false,
  loadingLabel = "Loading apps…",
  emptyLabel = "No apps available.",
  compact = false,
  className,
  ...props
}: AppAccessListProps) {
  const [expandedId, setExpandedId] = React.useState<string | null>(null);
  const groups = React.useMemo(() => {
    const grouped = new Map<
      string,
      {
        appId: string;
        name: string;
        icon?: string | null;
        items: AppAccessListItem[];
      }
    >();
    for (const item of items) {
      const current = grouped.get(item.appId);
      if (current) {
        current.items.push(item);
      } else {
        grouped.set(item.appId, {
          appId: item.appId,
          name: item.name,
          icon: item.icon,
          items: [item],
        });
      }
    }
    return [...grouped.values()];
  }, [items]);

  if (loading && items.length === 0) {
    return (
      <div
        {...props}
        className={cn(
          "flex min-h-14 items-center justify-center gap-2 rounded-lg border border-border px-3 text-xs text-fg-muted",
          className,
        )}
      >
        <LoaderCircle className="size-3.5 animate-spin" aria-hidden="true" />
        {loadingLabel}
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div
        {...props}
        className={cn(
          "flex min-h-14 items-center justify-center rounded-lg border border-border px-3 text-center text-xs text-fg-muted",
          className,
        )}
      >
        {emptyLabel}
      </div>
    );
  }

  return (
    <div
      {...props}
      className={cn(
        "overflow-hidden rounded-xl border border-border bg-surface",
        className,
      )}
      role="list"
    >
      {groups.map((group, groupIndex) => {
        return (
          <div
            key={group.appId}
            className={cn(groupIndex > 0 && "border-t border-border")}
            role="listitem"
          >
            <div
              className={cn(
                "grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3",
                compact ? "min-h-11 px-3 py-2" : "min-h-12 px-3.5 py-2.5",
              )}
            >
              <span className="grid size-8 place-items-center rounded-lg bg-surface-muted">
                <AppIcon icon={group.icon} size={18} />
              </span>
              <span className="min-w-0">
                <strong className="block truncate text-sm font-medium text-fg">
                  {group.name}
                </strong>
              </span>
            </div>
            <div className="border-t border-border bg-surface-muted/45">
              {group.items.map((item, itemIndex) => {
                const expanded = expandedId === item.id;
                const pending = item.status === "pending";
                const status = item.statusLabel ?? defaultStatusLabel(item);
                const statusTone = pending
                  ? "warning"
                  : item.status === "error"
                    ? "danger"
                    : item.enabled
                      ? "success"
                      : "neutral";
                // The switch already communicates an inactive row, so never
                // repeat that state as "Off" beside the Room name. Compact
                // surfaces also omit the redundant "Connected" label.
                const showStatus =
                  status !== "Off" &&
                  (!compact ||
                    Boolean(item.statusLabel) ||
                    status !== "Connected");
                return (
                  <div
                    key={item.id}
                    className={cn(
                      itemIndex > 0 && "border-t border-border/70",
                    )}
                  >
                    <div
                      className={cn(
                        "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 pl-[3.25rem]",
                        compact ? "min-h-10 py-1.5 pr-3" : "min-h-11 py-2 pr-3.5",
                      )}
                    >
                      <span className="min-w-0">
                        <span className="flex min-w-0 items-center gap-1.5">
                          <strong className="truncate text-xs font-medium text-fg">
                            {item.roomName || "Room"}
                          </strong>
                          {showStatus ? (
                            item.status === "error" ? (
                              <Badge asChild tone="danger">
                                <button
                                  type="button"
                                  className="shrink-0 cursor-pointer underline-offset-2 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-border-focus"
                                  onClick={() => onToggle(item, true)}
                                >
                                  {status}
                                </button>
                              </Badge>
                            ) : (
                              <Badge className="shrink-0" tone={statusTone}>{status}</Badge>
                            )
                          ) : null}
                        </span>
                        {item.statusMessage ? (
                          <span className="mt-0.5 block text-meta text-danger" role="alert">
                            {item.statusMessage}
                          </span>
                        ) : null}
                      </span>
                      <span className="flex items-center gap-1.5">
                        {item.details ? (
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="size-7 border-0 bg-transparent text-fg-muted shadow-none outline-none hover:bg-surface-muted hover:text-fg focus-visible:ring-2 focus-visible:ring-border-focus"
                            onClick={() => setExpandedId(expanded ? null : item.id)}
                            aria-label={`Settings for ${item.name} in ${item.roomName || "Room"}`}
                            aria-expanded={expanded}
                          >
                            {expanded ? (
                              <ChevronDown className="size-3.5" aria-hidden="true" />
                            ) : (
                              <Settings2 className="size-3.5" aria-hidden="true" />
                            )}
                          </Button>
                        ) : null}
                        {pending ? (
                          <LoaderCircle
                            className="size-4 animate-spin text-fg-muted"
                            aria-label={status}
                          />
                        ) : (
                          <Switch
                            checked={item.enabled}
                            disabled={item.disabled}
                            onCheckedChange={(enabled) => onToggle(item, enabled)}
                            aria-label={`${item.enabled ? "Disconnect" : "Connect"} ${item.name} in ${item.roomName || "Room"}`}
                            className="h-5 w-9 [&>span]:h-4 [&>span]:w-4 [&>span[data-state=checked]]:translate-x-4"
                          />
                        )}
                      </span>
                    </div>
                    {expanded && item.details ? (
                      <div className="border-t border-border/70 px-3.5 py-3 pl-[3.25rem]">
                        {item.details}
                      </div>
                    ) : null}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}
