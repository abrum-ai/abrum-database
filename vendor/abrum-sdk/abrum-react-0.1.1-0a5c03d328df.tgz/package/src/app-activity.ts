import { createContext, createElement, useContext, useEffect, type ReactNode } from "react";
import { postAbrumAppActivity } from "@abrum/web-runtime";

export interface AbrumAppActivityState {
  active: boolean;
  label?: string;
  threadLineageCids?: readonly string[];
}

type AbrumAppActivitySink = (activity: AbrumAppActivityState) => void;

const AbrumAppActivitySinkContext = createContext<AbrumAppActivitySink | null>(null);

/**
 * Trusted apps share the desktop window instead of living in an iframe, so
 * they cannot report activity through window.parent.postMessage. The host
 * provides this sink for that path; iframe apps continue using postMessage.
 */
export function AbrumAppActivityProvider({
  onActivity,
  children,
}: {
  onActivity: AbrumAppActivitySink;
  children: ReactNode;
}) {
  return createElement(
    AbrumAppActivitySinkContext.Provider,
    { value: onActivity },
    children,
  );
}

/**
 * Publish transient app activity to an embedding abrum host. The signal is
 * cleared when the component unmounts so host chrome cannot retain stale work.
 */
export function useAbrumAppActivity(
  active: boolean,
  label?: string,
  threadLineageCids?: readonly string[],
): void {
  const sink = useContext(AbrumAppActivitySinkContext);
  useEffect(() => {
    const activity = {
      active,
      ...(label ? { label } : {}),
      ...(threadLineageCids?.length ? { threadLineageCids } : {}),
    };
    if (sink) sink(activity);
    else postAbrumAppActivity(activity);
  }, [active, label, sink, threadLineageCids]);

  useEffect(() => {
    return () => {
      // Activity metadata can change for every streamed Agent update. Clearing
      // in the publishing effect's cleanup briefly removes the host spinner
      // before the next active payload restores it. Only clear when this
      // publisher actually unmounts or moves to another host sink.
      if (sink) sink({ active: false });
      else postAbrumAppActivity({ active: false });
    };
  }, [sink]);
}
