// One-call app bootstrap. An abrum app's entry becomes:
//
//   import { mountAbrumApp } from "@abrum/react";
//   import { App } from "./App";
//   mountAbrumApp({ app: <App />, install: myInstallManifest });
//
// The framework owns the whole lifecycle here — wasm core init, station/session
// resolution (via the @abrum/web-runtime host↔app contract), runtime open,
// loading/error UI, context, and self-install — so apps are just their UI + a
// generated install manifest.

import "./ui/theme.css";
import {
  Component,
  createContext,
  type ErrorInfo,
  type ReactNode,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { createRoot, type Root } from "react-dom/client";
import initAbrumWasm, * as abrumWasm from "@abrum/wasm";
import {
  createAbrumWasmProtocolCore,
  importAbrumSessionHandoff,
  postAbrumSurfaceStatus,
  readEmbedSignal,
  readHostedAppRoute,
  readAbrumHostTheme,
  readAbrumSurfaceStatusRequest,
  SESSION_HANDOFF_HASH_KEY,
  abrumStorageKeyForStation,
  AbrumRuntime,
  type AbrumEmbedTheme,
  type AbrumInstallAppOptions,
} from "@abrum/web-runtime";
import { AbrumProvider, useAbrum, useAbrumSnapshot } from "./core";
import { AbrumSurfaceModalHost, AbrumWindowModalHost } from "./window";
import { createSurfaceRuntimeLifecycle } from "./surface-runtime-lifecycle";

const DEFAULT_STATION_URL = "http://127.0.0.1:8792";

export interface MountAbrumAppOptions {
  /** The app UI to render once the runtime is open. */
  app: ReactNode;
  /** Mount target. Defaults to `#root`. */
  element?: HTMLElement | string;
  /** Namespaces the dev "remember my station" key and multi-session storage. */
  appId?: string;
  /** Station URL when none is provided by the host/URL. Defaults to localhost. */
  defaultStationUrl?: string;
  /** Generated install manifest. When set, the app self-installs (dev only). */
  install?: AbrumInstallAppOptions & { package?: string };
  /** Wait for an app-owned <AbrumAppReady /> marker before notifying an embed host. */
  deferReadyUntilAppCommit?: boolean;
  loading?: ReactNode;
  renderError?: (message: string) => ReactNode;
}

const AppReadyContext = createContext<(() => void) | null>(null);

/**
 * Marks the first meaningful app tree as committed. Apps with a top-level
 * Suspense boundary place this inside the resolved boundary and opt into
 * `deferReadyUntilAppCommit`, so the native host keeps its single loader up
 * until the lazy application — rather than only the abrum runtime — is ready.
 */
export function AbrumAppReady() {
  const markReady = useContext(AppReadyContext);
  useEffect(() => markReady?.(), [markReady]);
  return null;
}

let corePromise: Promise<unknown> | null = null;
function openCore() {
  corePromise ??= initAbrumWasm().then(() => createAbrumWasmProtocolCore(abrumWasm));
  return corePromise;
}

export function mountAbrumApp(options: MountAbrumAppOptions): Root {
  const target =
    typeof options.element === "string"
      ? document.querySelector<HTMLElement>(options.element)
      : options.element ?? document.getElementById("root");
  if (!target) {
    throw new Error("mountAbrumApp: mount target not found (pass `element` or add #root)");
  }
  // Apply the host theme before the first render so there's no flash of the
  // default theme. No-op when running standalone (token defaults / OS scheme).
  applyHostTheme();
  const root = createRoot(target);
  root.render(<AbrumAppHost {...options} />);
  return root;
}

/**
 * Apply the host's theme to <html>: a forced color scheme (`data-abrum-scheme`)
 * and any `--abrum-*` token overrides. The token layer (theme.css) supplies the
 * defaults; this only layers the host's choices on top.
 */
let appliedHostThemeVars = new Set<string>();

function applyHostTheme(theme: AbrumEmbedTheme | undefined = readEmbedSignal()?.theme): void {
  if (typeof document === "undefined") return;
  if (!theme) return;
  const root = document.documentElement;
  if (theme.scheme === "light" || theme.scheme === "dark") {
    root.setAttribute("data-abrum-scheme", theme.scheme);
  } else {
    root.removeAttribute("data-abrum-scheme");
  }
  const nextVars = new Set(Object.keys(theme.vars ?? {}));
  for (const key of appliedHostThemeVars) {
    if (!nextVars.has(key)) root.style.removeProperty(`--abrum-${key}`);
  }
  for (const [key, value] of Object.entries(theme.vars ?? {})) {
    if (typeof value === "string") root.style.setProperty(`--abrum-${key}`, value);
  }
  appliedHostThemeVars = nextVars;
}

function AbrumAppHost({
  app,
  appId,
  defaultStationUrl,
  install,
  deferReadyUntilAppCommit = false,
  loading,
  renderError,
}: MountAbrumAppOptions) {
  const sessionId = useMemo(() => {
    if (typeof window === "undefined") return null;
    return new URLSearchParams(window.location.search).get("session")?.trim() || null;
  }, []);
  const stationUrl = useMemo(() => resolveStationUrl(appId, defaultStationUrl), [appId, defaultStationUrl]);
  const mountedAppId = useMemo(
    () => readEmbedSignal()?.appId ?? readHostedAppRoute()?.appId ?? appId ?? install?.appId ?? null,
    [appId, install?.appId],
  );
  const storageKey = useMemo(() => {
    const ns = appId ?? "abrum";
    return sessionId ? `${ns}.${sessionId}:${stationUrl}` : abrumStorageKeyForStation(stationUrl);
  }, [appId, sessionId, stationUrl]);

  const [runtime, setRuntime] = useState<AbrumRuntime | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [appReady, setAppReady] = useState(!deferReadyUntilAppCommit);
  const embedded = useMemo(() => Boolean(readEmbedSignal()) && window.parent !== window, []);
  const markAppReady = useCallback(() => setAppReady(true), []);
  const reportAppRenderError = useCallback((cause: unknown) => {
    setError(cause instanceof Error ? cause.message : String(cause));
  }, []);

  useEffect(() => {
    let cancelled = false;
    const lifecycle = createSurfaceRuntimeLifecycle(window);
    setRuntime(null);
    setError(null);
    setAppReady(!deferReadyUntilAppCommit);
    try {
      consumeSessionHandoff(storageKey);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      lifecycle.close();
      return;
    }
    openCore()
      .then((core) => AbrumRuntime.open({ station: stationUrl, storageKey, core: core as never }))
      .then((next) => {
        if (lifecycle.attach(next)) setRuntime(next);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : String(err));
      });
    return () => {
      cancelled = true;
      lifecycle.close();
    };
  }, [deferReadyUntilAppCommit, stationUrl, storageKey]);

  const loadingView = loading !== undefined
    ? loading
    : embedded
      ? null
      : <AbrumLoadingSpinner />;

  return (
    <>
      <AbrumEmbedBridge ready={Boolean(runtime) && appReady} error={error} />
      {error ? (
        renderError ? renderError(error) : <DefaultBanner message={error} kind="error" />
      ) : !runtime ? (
        loadingView
      ) : (
        <AbrumAppRenderBoundary key={storageKey} onError={reportAppRenderError}>
          <AbrumProvider runtime={runtime} appId={mountedAppId}>
            <AppReadyContext.Provider value={markAppReady}>
              {app}
            </AppReadyContext.Provider>
            {install ? <AbrumAutoInstall manifest={install} /> : null}
            {/* Standalone/web fallback for openAbrumWindow (a native host opens a real
                window instead). Harmless when unused — renders nothing until called. */}
            <AbrumWindowModalHost />
            <AbrumSurfaceModalHost />
          </AbrumProvider>
        </AbrumAppRenderBoundary>
      )}
    </>
  );
}

class AbrumAppRenderBoundary extends Component<
  { children: ReactNode; onError: (cause: unknown) => void },
  { failed: boolean }
> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(cause: unknown, _info: ErrorInfo) {
    this.props.onError(cause);
  }

  render() {
    return this.state.failed ? null : this.props.children;
  }
}

function AbrumEmbedBridge({ ready, error }: { ready: boolean; error: string | null }) {
  const signal = useMemo(() => readEmbedSignal(), []);

  const postCurrentStatus = useCallback(() => {
    if (!signal || (!ready && !error)) return;
    postAbrumSurfaceStatus({
      status: error ? "error" : "ready",
      roomId: signal.roomId,
      appId: signal.appId,
      message: error,
    });
  }, [signal, ready, error]);

  useEffect(() => {
    if (!signal || window.parent === window) return;
    const onMessage = (event: MessageEvent) => {
      if (event.source !== window.parent) return;
      const message = readAbrumHostTheme(event.data);
      if (message) applyHostTheme(message.theme);
      if (readAbrumSurfaceStatusRequest(event.data)) postCurrentStatus();
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [signal, postCurrentStatus]);

  useEffect(() => {
    postCurrentStatus();
  }, [postCurrentStatus]);

  return null;
}

/**
 * Self-install the app into the selected room (dev convenience), so it shows up
 * in the launcher pointing at this dev server. Skipped when embedded in a host —
 * there the app was installed from the catalog with a real bundle artifact, and
 * a dev-url install would clobber it.
 */
function AbrumAutoInstall({ manifest }: { manifest: AbrumInstallAppOptions & { package?: string } }) {
  const runtime = useAbrum();
  const snapshot = useAbrumSnapshot();

  useEffect(() => {
    if (!snapshot.user || !snapshot.selectedRoomId) return;
    // Already installed with a real bundle artifact when embedded in a host or
    // served at /apps/<room>/<app>/ — a dev-url self-install would clobber it.
    if (readEmbedSignal() || (typeof window !== "undefined" && window.location.pathname.startsWith("/apps/"))) {
      return;
    }
    let cancelled = false;
    runtime
      .ensureAppInstalled(
        {
          ...manifest,
          surfaces: [{ kind: "web", label: manifest.title, entrypoint: window.location.pathname }],
          artifact: {
            kind: "dev-url",
            url: window.location.origin,
            package: manifest.package ?? manifest.appId,
          },
          grantedRights: manifest.grantedRights ?? ["read", "write"],
        },
        snapshot.selectedRoomId,
      )
      .catch((err) => {
        const message = err instanceof Error ? err.message : String(err);
        if (!cancelled && !message.startsWith("403 ") && !message.includes("403 Forbidden")) {
          console.warn(`abrum self-install failed: ${message}`);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [runtime, snapshot.selectedRoomId, snapshot.user?.did, manifest]);

  return null;
}

function resolveStationUrl(appId?: string, fallback?: string): string {
  const def = fallback ?? DEFAULT_STATION_URL;
  if (typeof window === "undefined") return def;
  // 1) Host-provided (embed signal) wins.
  const embedded = readEmbedSignal();
  if (embedded?.stationUrl) return embedded.stationUrl;
  // 2) Served by a station at /apps/<room>/<app>/ → same origin.
  if (window.location.pathname.startsWith("/apps/")) return window.location.origin;
  // 3) Dev "remember my station" override, else the default.
  const key = `${appId ?? "abrum"}.stationUrl`;
  return window.localStorage.getItem(key) ?? def;
}

function consumeSessionHandoff(storageKey: string): void {
  if (typeof window === "undefined") return;
  const rawHash = window.location.hash.startsWith("#") ? window.location.hash.slice(1) : window.location.hash;
  if (!rawHash) return;
  const params = new URLSearchParams(rawHash);
  const token = params.get(SESSION_HANDOFF_HASH_KEY);
  if (!token) return;
  importAbrumSessionHandoff(storageKey, token);
  params.delete(SESSION_HANDOFF_HASH_KEY);
  const remaining = params.toString();
  window.history.replaceState(
    null,
    "",
    `${window.location.pathname}${window.location.search}${remaining ? `#${remaining}` : ""}`,
  );
}

export function AbrumLoadingSpinner() {
  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <style>{"@keyframes abrum-spin{to{transform:rotate(360deg)}}@media (prefers-reduced-motion:reduce){.abrum-loading-spinner{animation:none!important}}"}</style>
      <div
        className="abrum-loading-spinner"
        role="status"
        aria-label="Loading"
        style={{
          width: 28,
          height: 28,
          borderRadius: "50%",
          border: "3px solid var(--abrum-border, #e4e4e7)",
          borderTopColor: "var(--abrum-fg-muted, #52525b)",
          animation: "abrum-spin 0.7s linear infinite",
        }}
      />
    </div>
  );
}

function DefaultBanner({ message, kind }: { message: string; kind: "info" | "error" }) {
  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <p
        style={{
          maxWidth: 480,
          font: "var(--abrum-type-body)",
          color: kind === "error" ? "#b91c1c" : "#71717a",
          margin: 0,
        }}
      >
        {message}
      </p>
    </div>
  );
}
