import * as React from "react";
import { cn } from "../ui/cn";
import { Input } from "../ui/input";
import { Select } from "../ui/select";
import { Switch } from "../ui/switch";

export type ScheduleKind = "interval" | "daily" | "weekly";
export type ScheduleUnit = "minutes" | "hours" | "days";
export type ScheduleWeekday =
  | "monday"
  | "tuesday"
  | "wednesday"
  | "thursday"
  | "friday"
  | "saturday"
  | "sunday";

export type ScheduleEditorValue = {
  enabled: boolean;
  kind: ScheduleKind;
  everyValue: string;
  everyUnit: ScheduleUnit;
  dailyAt: string;
  weekdays: ScheduleWeekday[];
};

export type ScheduleEditorProps = {
  value: ScheduleEditorValue;
  onChange: (value: ScheduleEditorValue) => void;
  nextRunLabel?: string | null;
  lastRunLabel?: string | null;
  lastRunStatus?: string | null;
  disabled?: boolean;
  className?: string;
};

const KINDS: ReadonlyArray<{ value: ScheduleKind; label: string }> = [
  { value: "interval", label: "Interval" },
  { value: "daily", label: "Every day" },
  { value: "weekly", label: "Days of week" },
];

export const SCHEDULE_WEEKDAYS: ReadonlyArray<{
  value: ScheduleWeekday;
  short: string;
  label: string;
}> = [
  { value: "monday", short: "Mon", label: "Monday" },
  { value: "tuesday", short: "Tue", label: "Tuesday" },
  { value: "wednesday", short: "Wed", label: "Wednesday" },
  { value: "thursday", short: "Thu", label: "Thursday" },
  { value: "friday", short: "Fri", label: "Friday" },
  { value: "saturday", short: "Sat", label: "Saturday" },
  { value: "sunday", short: "Sun", label: "Sunday" },
];

export function ScheduleEditor({
  value,
  onChange,
  nextRunLabel,
  lastRunLabel,
  lastRunStatus,
  disabled = false,
  className,
}: ScheduleEditorProps) {
  const update = React.useCallback(
    (patch: Partial<ScheduleEditorValue>) => onChange({ ...value, ...patch }),
    [onChange, value],
  );

  const toggleWeekday = React.useCallback(
    (weekday: ScheduleWeekday) => {
      const selected = new Set(value.weekdays);
      if (selected.has(weekday)) selected.delete(weekday);
      else selected.add(weekday);
      update({
        weekdays: SCHEDULE_WEEKDAYS.map(({ value: day }) => day).filter((day) =>
          selected.has(day),
        ),
      });
    },
    [update, value.weekdays],
  );

  return (
    <section
      className={cn(
        "overflow-hidden rounded-lg border border-border bg-surface",
        className,
      )}
      aria-labelledby="automatic-runs-title"
    >
      <div className="flex items-center justify-between gap-4 px-4 py-3">
        <div className="min-w-0">
          <h3
            id="automatic-runs-title"
            className="text-sm font-semibold text-fg"
          >
            Run automatically
          </h3>
          <p className="mt-0.5 text-xs leading-5 text-fg-muted">
            The Station runs this Agent even when the app is closed.
          </p>
        </div>
        <Switch
          checked={value.enabled}
          onCheckedChange={(enabled) => update({ enabled })}
          disabled={disabled}
          aria-label="Run Agent automatically"
        />
      </div>

      {value.enabled ? (
        <div className="space-y-4 border-t border-border px-4 py-4">
          <fieldset>
            <legend className="mb-2 text-xs font-medium text-fg-muted">
              Repeat
            </legend>
            <div className="inline-flex max-w-full flex-wrap gap-1 rounded-lg bg-surface-muted p-1">
              {KINDS.map((kind) => {
                const selected = value.kind === kind.value;
                return (
                  <button
                    key={kind.value}
                    type="button"
                    aria-pressed={selected}
                    disabled={disabled}
                    onClick={() => update({ kind: kind.value })}
                    className={cn(
                      "h-8 rounded-md px-3 text-xs font-medium outline-none transition-colors focus-visible:ring-2 focus-visible:ring-border-focus disabled:cursor-not-allowed disabled:opacity-50",
                      selected
                        ? "bg-surface text-fg shadow-sm"
                        : "text-fg-muted hover:text-fg",
                    )}
                  >
                    {kind.label}
                  </button>
                );
              })}
            </div>
          </fieldset>

          {value.kind === "interval" ? (
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm text-fg">Every</span>
              <label className="sr-only" htmlFor="agent-schedule-interval">
                Interval
              </label>
              <Input
                id="agent-schedule-interval"
                type="number"
                min="1"
                step="1"
                inputMode="numeric"
                value={value.everyValue}
                disabled={disabled}
                onChange={(event) => update({ everyValue: event.target.value })}
                className="w-24"
                name="agent-schedule-interval"
              />
              <label className="sr-only" htmlFor="agent-schedule-unit">
                Interval unit
              </label>
              <Select
                id="agent-schedule-unit"
                value={value.everyUnit}
                disabled={disabled}
                onChange={(event) =>
                  update({ everyUnit: parseScheduleUnit(event.target.value) })
                }
                className="min-w-32"
                name="agent-schedule-unit"
                autoComplete="off"
              >
                <option value="minutes">minutes</option>
                <option value="hours">hours</option>
                <option value="days">days</option>
              </Select>
            </div>
          ) : null}

          {value.kind === "daily" ? (
            <div className="flex flex-wrap items-center gap-2">
              <label
                htmlFor="agent-schedule-daily-at"
                className="text-sm text-fg"
              >
                Every day at
              </label>
              <Input
                id="agent-schedule-daily-at"
                type="time"
                value={value.dailyAt}
                disabled={disabled}
                onChange={(event) => update({ dailyAt: event.target.value })}
                className="w-36"
                name="agent-schedule-daily-at"
                autoComplete="off"
              />
            </div>
          ) : null}

          {value.kind === "weekly" ? (
            <div className="space-y-3">
              <fieldset>
                <legend className="mb-2 text-xs font-medium text-fg-muted">
                  Run on
                </legend>
                <div className="flex flex-wrap gap-1.5">
                  {SCHEDULE_WEEKDAYS.map((weekday) => {
                    const selected = value.weekdays.includes(weekday.value);
                    return (
                      <button
                        key={weekday.value}
                        type="button"
                        aria-label={weekday.label}
                        aria-pressed={selected}
                        disabled={disabled}
                        onClick={() => toggleWeekday(weekday.value)}
                        className={cn(
                          "h-9 min-w-11 rounded-md border px-2 text-xs font-medium outline-none transition-colors focus-visible:ring-2 focus-visible:ring-border-focus disabled:cursor-not-allowed disabled:opacity-50",
                          selected
                            ? "border-primary bg-primary text-primary-fg"
                            : "border-border bg-field text-fg-muted hover:bg-surface-muted hover:text-fg",
                        )}
                      >
                        {weekday.short}
                      </button>
                    );
                  })}
                </div>
              </fieldset>
              <div className="flex flex-wrap items-center gap-2">
                <label
                  htmlFor="agent-schedule-weekly-at"
                  className="text-sm text-fg"
                >
                  At
                </label>
                <Input
                  id="agent-schedule-weekly-at"
                  type="time"
                  value={value.dailyAt}
                  disabled={disabled}
                  onChange={(event) => update({ dailyAt: event.target.value })}
                  className="w-36"
                  name="agent-schedule-weekly-at"
                  autoComplete="off"
                />
                <span className="text-xs text-fg-muted">
                  Station local time
                </span>
              </div>
            </div>
          ) : null}

          {value.kind !== "weekly" ? (
            <p className="text-xs text-fg-muted">
              Uses the Station&apos;s local time.
            </p>
          ) : null}
          {nextRunLabel || lastRunLabel ? (
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-fg-muted">
              {nextRunLabel ? <p>Next run: {nextRunLabel}</p> : null}
              {lastRunLabel ? (
                <p>
                  Last run: {lastRunLabel}
                  {lastRunStatus ? ` · ${lastRunStatus}` : ""}
                </p>
              ) : null}
            </div>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}

function parseScheduleUnit(value: string): ScheduleUnit {
  if (value === "minutes" || value === "days") return value;
  return "hours";
}
