export interface AbrumSharingProvenance {
  /** Kept for structural compatibility; Room selection is never used to infer
   * sharing from this field alone. */
  sourceRoomId?: string | null;
  sharedWithMe?: boolean;
  shareProvenance?: "owned" | "room-membership" | "direct" | "unknown";
}

export function isSharedWithMe(
  ref: AbrumSharingProvenance,
  _selectedRoomId?: string | null,
): boolean {
  return ref.sharedWithMe === true
    || ref.shareProvenance === "direct"
    || ref.shareProvenance === "room-membership";
}
