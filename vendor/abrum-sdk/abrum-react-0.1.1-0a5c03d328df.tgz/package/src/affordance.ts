/** Named UI semantics consumed by the shared Co-Presence extractor. */
export function affordance(verb: string, twin?: string, options: {version?: string; completion?: string} = {}) {
  return {
    'data-abrum-verb': verb,
    ...(twin ? {'data-abrum-twin': twin} : {}),
    'data-abrum-action-version': options.version ?? '1',
    'data-abrum-completion': options.completion ?? 'state-changed',
  };
}

export function processAffordance(id: string, state: {
  phase: string; busy?: boolean; availableActions?: string[]; blockers?: string[];
  domainRefs?: Record<string, unknown>; actionReceipt?: Record<string, unknown> | null;
}) {
  return {
    'data-abrum-process': id,
    'data-abrum-phase': state.phase,
    'data-abrum-busy': String(state.busy ?? false),
    'data-abrum-available-actions': JSON.stringify(state.availableActions ?? []),
    'data-abrum-blockers': JSON.stringify(state.blockers ?? []),
    'data-abrum-domain-refs': JSON.stringify(state.domainRefs ?? {}),
    'data-abrum-action-receipt': JSON.stringify(state.actionReceipt ?? null),
  };
}
