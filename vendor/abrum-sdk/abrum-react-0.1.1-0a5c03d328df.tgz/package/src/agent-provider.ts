import * as React from "react";
import {
  readEmbedSignal,
  ABRUM_AGENT_PROVIDER_REQUEST_MESSAGE_TYPE,
  ABRUM_AGENT_PROVIDER_RESPONSE_MESSAGE_TYPE,
  ABRUM_AGENT_PROVIDER_CREDENTIALS_CHANGED_MESSAGE_TYPE,
} from "@abrum/web-runtime";

export interface AbrumAgentProviderStatus {
  slotConfigured: boolean;
  roomLinked: boolean;
  available: boolean;
  canLinkRoom: boolean;
}

type ProviderAction = "status" | "link" | "open-settings";

type ProviderResponse = {
  type?: string;
  requestId?: string;
  provider?: string;
  ok?: boolean;
  status?: Partial<AbrumAgentProviderStatus>;
  error?: string;
};

/**
 * Host-owned provider availability for an embedded abrum app. The desktop binds
 * every request to the iframe's actual Room, so apps never choose another Room,
 * receive a provider key, or duplicate credential ownership logic.
 */
export function useAbrumAgentProvider(provider: string, roomScope: string | null | undefined) {
  const nativeHost = React.useMemo(() => readEmbedSignal()?.kind === "native", []);
  const [status, setStatus] = React.useState<AbrumAgentProviderStatus | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState(false);
  const pending = React.useRef(new Map<string, ProviderAction>());
  const latestStatusRequest = React.useRef<string | null>(null);

  const receive = React.useCallback((message: ProviderResponse | null) => {
    if (
      !message ||
      message.type !== ABRUM_AGENT_PROVIDER_RESPONSE_MESSAGE_TYPE ||
      !message.requestId ||
      !pending.current.has(message.requestId)
    ) {
      return;
    }
    const action = pending.current.get(message.requestId);
    pending.current.delete(message.requestId);
    // A save can invalidate an in-flight mount-time status request. Ignore
    // that older response so it cannot overwrite the post-save refresh.
    if (action === "status" && latestStatusRequest.current !== message.requestId) {
      return;
    }
    setBusy(false);
    if (!message.ok) {
      setError(message.error || "Provider status is unavailable.");
      return;
    }
    if (message.status) {
      setStatus({
        slotConfigured: message.status.slotConfigured === true,
        roomLinked: message.status.roomLinked === true,
        available: message.status.available === true,
        canLinkRoom: message.status.canLinkRoom === true,
      });
    }
  }, []);

  const request = React.useCallback((action: ProviderAction) => {
    // The native WebView reaches the Agent app through Station HTTP and has no
    // desktop credential bridge. Runtime options still come from the Station;
    // do not report a missing desktop host on iOS or Android.
    if (nativeHost) return;
    const requestId = `agent-provider-${crypto.randomUUID()}`;
    pending.current.set(requestId, action);
    if (action === "status") latestStatusRequest.current = requestId;
    if (action === "link") setBusy(true);
    setError(null);
    const payload = {
      type: ABRUM_AGENT_PROVIDER_REQUEST_MESSAGE_TYPE,
      requestId,
      action,
      provider,
      linked: true,
    };
    if (window.parent !== window) {
      window.parent.postMessage(payload, "*");
      return;
    }

    // Trusted apps share the desktop document, so parent.postMessage would
    // only message themselves and the host could not bind the request to the
    // selected Agent Room. Retry briefly because child effects may run before
    // the host's listener on first mount.
    const dispatchToTrustedHost = (attempt: number) => {
      const event = new CustomEvent(ABRUM_AGENT_PROVIDER_REQUEST_MESSAGE_TYPE, {
        cancelable: true,
        detail: {
          ...payload,
          respond: (outcome: Omit<ProviderResponse, "type" | "requestId">) =>
            receive({
              ...outcome,
              type: ABRUM_AGENT_PROVIDER_RESPONSE_MESSAGE_TYPE,
              requestId,
            }),
        },
      });
      if (!window.dispatchEvent(event)) return;
      if (attempt < 5) {
        window.setTimeout(() => dispatchToTrustedHost(attempt + 1), 50 * (attempt + 1));
        return;
      }
      pending.current.delete(requestId);
      setBusy(false);
      setError("The desktop host did not answer the provider request.");
    };
    dispatchToTrustedHost(0);
  }, [nativeHost, provider, receive]);

  React.useEffect(() => {
    if (nativeHost) {
      pending.current.clear();
      latestStatusRequest.current = null;
      setStatus(null);
      setError(null);
      setBusy(false);
      return;
    }
    function onMessage(event: MessageEvent) {
      const message = event.data as ProviderResponse | null;
      if (
        message?.type === ABRUM_AGENT_PROVIDER_CREDENTIALS_CHANGED_MESSAGE_TYPE &&
        (!message.provider || message.provider === provider)
      ) {
        request("status");
        return;
      }
      receive(message);
    }
    function onTrustedCredentialChange(event: Event) {
      const message = (event as CustomEvent<ProviderResponse>).detail;
      if (!message?.provider || message.provider === provider) request("status");
    }
    window.addEventListener("message", onMessage);
    window.addEventListener(
      ABRUM_AGENT_PROVIDER_CREDENTIALS_CHANGED_MESSAGE_TYPE,
      onTrustedCredentialChange,
    );
    setStatus(null);
    request("status");
    return () => {
      window.removeEventListener("message", onMessage);
      window.removeEventListener(
        ABRUM_AGENT_PROVIDER_CREDENTIALS_CHANGED_MESSAGE_TYPE,
        onTrustedCredentialChange,
      );
    };
  }, [nativeHost, provider, receive, request, roomScope]);

  return React.useMemo(() => ({
    status,
    error,
    busy,
    refresh: () => request("status"),
    link: () => request("link"),
    openSettings: () => request("open-settings"),
  }), [busy, error, request, status]);
}
