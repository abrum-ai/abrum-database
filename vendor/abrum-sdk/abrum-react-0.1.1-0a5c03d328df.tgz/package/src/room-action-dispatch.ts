import { ABRUM_ROOM_ACTION_RESULT_MESSAGE_TYPE, type AbrumRoomActionMessage, type AbrumRoomActionResult } from "@abrum/web-runtime";

export type AbrumRoomActionHandlers = Readonly<Record<string, () => void | Promise<void>>>;

/** One execution per request for both embedded and trusted surfaces. No form values in receipts. */
export function createRoomActionDispatcher(
  handlers: () => AbrumRoomActionHandlers,
  report: (result: AbrumRoomActionResult) => void,
  afterRender: () => Promise<void>,
) {
  const requests = new Map<string, { actionId: string; result?: AbrumRoomActionResult }>();
  return async (action: AbrumRoomActionMessage) => {
    const id = action.requestId;
    if (id && requests.has(id)) {
      const previous = requests.get(id)!;
      if (previous.actionId === action.actionId && previous.result) report(previous.result);
      return;
    }
    // Fail closed at the per-surface bound instead of evicting replay protection.
    if (id && requests.size >= 1024) {
      report({ type: ABRUM_ROOM_ACTION_RESULT_MESSAGE_TYPE, requestId: id, actionId: action.actionId, status: "failed" });
      return;
    }
    const entry: { actionId: string; result?: AbrumRoomActionResult } = { actionId: action.actionId };
    if (id) requests.set(id, entry);
    let status: AbrumRoomActionResult["status"] = "unsupported";
    try {
      const current = handlers();
      const handler = Object.hasOwn(current, action.actionId) ? current[action.actionId] : undefined;
      if (handler) {
        await handler();
        await afterRender();
        status = "completed";
      }
    } catch { status = "failed"; }
    if (id) {
      entry.result = { type: ABRUM_ROOM_ACTION_RESULT_MESSAGE_TYPE, requestId: id, actionId: action.actionId, status };
      report(entry.result);
    }
  };
}
