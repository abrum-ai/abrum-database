import { useEffect, useRef } from "react";
import {
  ABRUM_ROOM_ACTION_MESSAGE_TYPE,
  ABRUM_ROOM_ACTION_RESULT_MESSAGE_TYPE,
  postAbrumRoomActionsReady,
  readAbrumRoomAction,
} from "@abrum/web-runtime";

import { createRoomActionDispatcher, type AbrumRoomActionHandlers } from "./room-action-dispatch";
export type { AbrumRoomActionHandlers } from "./room-action-dispatch";

/** Handle app-specific actions declared for a Room's sidebar menu. */
export function useAbrumRoomActions(handlers: AbrumRoomActionHandlers): void {
  const handlersRef = useRef(handlers);

  useEffect(() => {
    handlersRef.current = handlers;
  }, [handlers]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const dispatch = createRoomActionDispatcher(() => handlersRef.current, (result) => {
      if (window.parent === window) {
        window.dispatchEvent(new CustomEvent(ABRUM_ROOM_ACTION_RESULT_MESSAGE_TYPE, { detail: result }));
      } else window.parent.postMessage(result, "*");
    }, () => new Promise<void>((resolve) => requestAnimationFrame(() => resolve())));
    if (window.parent === window) {
      const onTrustedAction = (event: Event) => {
        const detail = (event as CustomEvent<unknown>).detail;
        const action = readAbrumRoomAction(detail);
        if (!action) return;
        void dispatch(action);
      };
      window.addEventListener(ABRUM_ROOM_ACTION_MESSAGE_TYPE, onTrustedAction);
      return () => window.removeEventListener(ABRUM_ROOM_ACTION_MESSAGE_TYPE, onTrustedAction);
    }
    const onMessage = (event: MessageEvent) => {
      if (event.source !== window.parent) return;
      const action = readAbrumRoomAction(event.data);
      if (!action) return;
      void dispatch(action);
    };
    window.addEventListener("message", onMessage);
    postAbrumRoomActionsReady(window);
    return () => window.removeEventListener("message", onMessage);
  }, []);
}
