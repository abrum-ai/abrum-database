import { useCallback, useEffect, useMemo, useState } from "react";
import { Sparkles } from "lucide-react";

/**
 * "New to you" for items that arrived by being shared.
 *
 * A direct share lands silently: the station opens the delivery Room and the
 * item simply appears inside the recipient's app lens. That is the right shape
 * — an inbox nobody opens is worse — but it left the recipient with no way to
 * tell a thing that has always been there from a thing that arrived while they
 * were not looking.
 *
 * Seen-state is deliberately device-local: it is a reading aid, not substance,
 * and it must never become a twin that syncs back to the sender and tells them
 * whether their share was looked at.
 */

const STORAGE_PREFIX = "abrum.seen-shared";

function readSeen(scope: string): Set<string> {
  try {
    const raw = window.localStorage.getItem(`${STORAGE_PREFIX}.${scope}`);
    const parsed = raw ? JSON.parse(raw) : null;
    return new Set(Array.isArray(parsed) ? parsed.filter((value) => typeof value === "string") : []);
  } catch {
    // Private mode, quota, or a corrupted entry: everything reads as seen,
    // which is the harmless direction to fail in.
    return new Set();
  }
}

function writeSeen(scope: string, ids: Set<string>): void {
  try {
    // Bound the list so a long-lived lens cannot grow it without limit.
    const trimmed = [...ids].slice(-500);
    window.localStorage.setItem(`${STORAGE_PREFIX}.${scope}`, JSON.stringify(trimmed));
  } catch {
    // Nothing to do — the marks are an aid, never a correctness requirement.
  }
}

export interface AbrumSeenMarks {
  /** Has this id never been acknowledged on this device? */
  isNew(id: string): boolean;
  /** Acknowledge one id (call when the user actually looks at the item). */
  markSeen(id: string): void;
  /** Acknowledge every id currently known — "mark all read". */
  markAllSeen(ids: readonly string[]): void;
  newCount(ids: readonly string[]): number;
}

/**
 * `scope` separates unrelated lists (usually the Room id plus the app's name),
 * so acknowledging a shared note does not silence a shared thought.
 */
export function useAbrumSeenMarks(scope: string | null | undefined): AbrumSeenMarks {
  const key = scope?.trim() || "default";
  const [seen, setSeen] = useState<Set<string>>(() => readSeen(key));

  useEffect(() => {
    setSeen(readSeen(key));
  }, [key]);

  const markSeen = useCallback((id: string) => {
    if (!id) return;
    setSeen((current) => {
      if (current.has(id)) return current;
      const next = new Set(current);
      next.add(id);
      writeSeen(key, next);
      return next;
    });
  }, [key]);

  const markAllSeen = useCallback((ids: readonly string[]) => {
    setSeen((current) => {
      const missing = ids.filter((id) => id && !current.has(id));
      if (missing.length === 0) return current;
      const next = new Set(current);
      for (const id of missing) next.add(id);
      writeSeen(key, next);
      return next;
    });
  }, [key]);

  return useMemo(() => ({
    isNew: (id: string) => Boolean(id) && !seen.has(id),
    markSeen,
    markAllSeen,
    newCount: (ids: readonly string[]) => ids.filter((id) => id && !seen.has(id)).length,
  }), [markAllSeen, markSeen, seen]);
}

/** The marker itself. Renders nothing once the item has been acknowledged. */
export function AbrumNewToYouBadge({
  isNew,
  label = "New",
  className,
}: {
  isNew: boolean;
  label?: string;
  className?: string;
}) {
  if (!isNew) return null;
  return (
    <span
      className={`abrum-new-to-you${className ? ` ${className}` : ""}`}
      title="This arrived since you last looked here"
    >
      <Sparkles size={11} aria-hidden="true" />
      {label}
    </span>
  );
}
