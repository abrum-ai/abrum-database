// Open one of an app's own routes in a separate window — with the right behavior
// in every environment, from a single call:
//
//   const openWindow = useAbrumWindow();
//   <button onClick={() => openWindow("report", { width: 720, height: 520 })}>Open</button>
//
// Embedded in a native host (the abrum desktop) → the host spawns a real OS window
// showing that route. Standalone (a browser tab) or embedded in a web host → an
// in-app modal renders the route in an iframe. Either way the spawned surface is
// the same app loaded with the `abrumWindow` route param, which the app reads via
// `useAbrumWindowRoute()` to render that surface. The host↔app wire format lives in
// the @abrum/web-runtime contract so producer and consumer can't drift.

import { type CSSProperties, type ReactElement, type ReactNode, useCallback, useEffect, useMemo, useState } from "react";
import { X } from "lucide-react";
import { Slot } from "@radix-ui/react-slot";
import {
  ABRUM_OPEN_SURFACE_MESSAGE_TYPE,
  postAbrumCloseSurface,
  postAbrumOpenSurface,
  postAbrumOpenWindow,
  readEmbedSignal,
  readHostedAppRoute,
  readAbrumAppSurface,
  readAbrumSurfaceResult,
  readAbrumWindowRoute,
  withAbrumAppSurface,
  withAbrumWindowRoute,
  type AbrumAppSurfaceReference,
  type AbrumApp,
  type AbrumAppFunctions,
  type AbrumAppSurfaceDef,
  type AbrumAppSurfaces,
  type AbrumEntities,
  type AbrumSurfaceJsonValue,
} from "@abrum/web-runtime";
import {
  AppSurfaceFrame,
  formatAppSurfaceAppTitle,
  formatAppSurfaceTitle,
} from "./ui/app-surface-frame";

export interface OpenAbrumWindowOptions {
  /** Preferred content size; a native host clamps it to the display. */
  width?: number;
  height?: number;
  /** Window title (native) / modal heading (standalone). */
  title?: string;
}

interface OpenRequest extends OpenAbrumWindowOptions {
  route: string;
}

export interface OpenAbrumSurfaceOptions extends OpenAbrumWindowOptions {
  /** Native hosts default to window; web/standalone defaults to modal. */
  placement?: "modal" | "window";
  /** Optional route override; normally declared by the app manifest/host. */
  entrypoint?: string;
}

export type AbrumAdaptiveDialogPlacement = "auto" | "modal" | "window";

export interface OpenAbrumAdaptiveDialogOptions
  extends Omit<OpenAbrumSurfaceOptions, "placement"> {
  /** Auto opens a native ABRUM window and falls back to a web modal. */
  placement?: AbrumAdaptiveDialogPlacement;
}

export interface AbrumAdaptiveDialogProps extends OpenAbrumAdaptiveDialogOptions {
  surfaceId: string;
  input?: AbrumSurfaceJsonValue;
  /** One interactive element that becomes the dialog trigger. */
  children: ReactElement;
}

interface SurfaceOpenRequest extends OpenAbrumSurfaceOptions {
  reference: AbrumAppSurfaceReference;
}

// Module-level bus so the imperative `openAbrumWindow` can reach the modal host
// that `mountAbrumApp` renders, without the caller needing a ref or context.
const modalListeners = new Set<(request: OpenRequest) => void>();
const surfaceModalListeners = new Set<(request: SurfaceOpenRequest) => void>();

/**
 * Open `route` in a new window. Native host → the host opens an OS window;
 * otherwise an in-app modal (rendered by {@link AbrumWindowModalHost}, which
 * `mountAbrumApp` includes by default). Imperative; also available as the
 * {@link useAbrumWindow} hook.
 */
export function openAbrumWindow(route: string, options: OpenAbrumWindowOptions = {}): void {
  const request: OpenRequest = { route, ...options };
  const embed = readEmbedSignal();
  // Any native host spawns real OS windows (the abrum desktop shell signals kind
  // "electron"; other shells "native"). Only web-embedded hosts (kind "web") and
  // standalone tabs (no embed signal) fall back to the in-app modal.
  if (embed && embed.kind !== "web") {
    const posted = postAbrumOpenWindow(request, { roomId: embed.roomId, appId: embed.appId });
    if (posted) return;
  }
  if (modalListeners.size === 0 && typeof console !== "undefined") {
    console.warn(
      "openAbrumWindow: no <AbrumWindowModalHost /> mounted — mountAbrumApp renders one by default.",
    );
  }
  for (const listener of modalListeners) listener(request);
}

/** Hook form of {@link openAbrumWindow}. Returns a stable opener. */
export function useAbrumWindow(): (route: string, options?: OpenAbrumWindowOptions) => void {
  return useCallback((route: string, options?: OpenAbrumWindowOptions) => {
    openAbrumWindow(route, options ?? {});
  }, []);
}

/** Open one declared app surface. The host owns placement and URL minting;
 * callers supply only the stable surface id and its schema-checked input. */
export function openAbrumSurface(
  surfaceId: string,
  input: AbrumSurfaceJsonValue = {},
  options: OpenAbrumSurfaceOptions = {},
): void {
  const embed = readEmbedSignal();
  if (embed && embed.kind !== "web" && options.placement !== "modal") {
    const posted = postAbrumOpenSurface(
      { surfaceId, input, placement: options.placement, title: options.title, width: options.width, height: options.height },
      { roomId: embed.roomId, appId: embed.appId },
    );
    if (posted) return;
  }
  // Trusted React apps render inside the desktop document rather than an
  // iframe, so window.parent cannot carry their surface request to the host.
  // Let the desktop claim the same contract through a cancellable event; a
  // normal standalone page has no listener and continues to the modal fallback.
  if (
    typeof window !== "undefined"
    && window.parent === window
    && options.placement !== "modal"
  ) {
    const event = new CustomEvent(ABRUM_OPEN_SURFACE_MESSAGE_TYPE, {
      cancelable: true,
      detail: {
        type: ABRUM_OPEN_SURFACE_MESSAGE_TYPE,
        surfaceId,
        input,
        placement: options.placement,
        entrypoint: options.entrypoint,
        title: options.title,
        width: options.width,
        height: options.height,
      },
    });
    if (!window.dispatchEvent(event)) return;
  }
  const current = readAbrumAppSurface();
  const hosted = readHostedAppRoute();
  const roomId = embed?.roomId ?? current?.roomId ?? hosted?.roomId ?? "";
  const appId = embed?.appId ?? current?.appId ?? hosted?.appId ?? "";
  if (!surfaceId.trim() || !roomId || !appId) {
    console.warn("openAbrumSurface: app/room context is unavailable");
    return;
  }
  const request: SurfaceOpenRequest = {
    ...options,
    reference: { roomId, appId, surfaceId: surfaceId.trim(), input, placement: "modal" },
  };
  for (const listener of surfaceModalListeners) listener(request);
}

export function useAbrumSurface(): (
  surfaceId: string,
  input?: AbrumSurfaceJsonValue,
  options?: OpenAbrumSurfaceOptions,
) => void {
  return useCallback((surfaceId, input = {}, options = {}) => openAbrumSurface(surfaceId, input, options), []);
}

/** Open a declared dialog surface with platform-adaptive placement. */
export function openAbrumAdaptiveDialog(
  surfaceId: string,
  input: AbrumSurfaceJsonValue = {},
  options: OpenAbrumAdaptiveDialogOptions = {},
): void {
  const { placement = "auto", ...surfaceOptions } = options;
  openAbrumSurface(surfaceId, input, {
    ...surfaceOptions,
    placement: placement === "auto" ? undefined : placement,
  });
}

/** Stable hook form of {@link openAbrumAdaptiveDialog}. */
export function useAbrumAdaptiveDialog(): (
  surfaceId: string,
  input?: AbrumSurfaceJsonValue,
  options?: OpenAbrumAdaptiveDialogOptions,
) => void {
  return useCallback(
    (surfaceId, input = {}, options = {}) =>
      openAbrumAdaptiveDialog(surfaceId, input, options),
    [],
  );
}

/**
 * Turn one button-like child into a trigger for a declared adaptive dialog.
 * The dialog content is rendered by the app surface in a fresh document, so
 * only serializable input crosses the native-window/web-modal boundary.
 */
export function AbrumAdaptiveDialog({
  surfaceId,
  input = {},
  placement = "auto",
  title,
  width,
  height,
  entrypoint,
  children,
}: AbrumAdaptiveDialogProps): ReactNode {
  const open = useAbrumAdaptiveDialog();
  return (
    <Slot
      aria-haspopup="dialog"
      onClick={() =>
        open(surfaceId, input, { placement, title, width, height, entrypoint })
      }
    >
      {children}
    </Slot>
  );
}

/** Close the current adaptive dialog from either its modal iframe or window. */
export function closeAbrumAdaptiveDialog(result?: AbrumSurfaceJsonValue): boolean {
  const surface = readAbrumAppSurface();
  if (!surface) return false;
  if (surface.placement === "window" && typeof window !== "undefined") {
    const nativeHost = (window as Window & {
      abrumSurfaceHost?: { close?: () => Promise<{ ok?: boolean }> };
    }).abrumSurfaceHost;
    if (typeof nativeHost?.close === "function") {
      void nativeHost.close();
      return true;
    }
    // Other native hosts can still implement normal top-level window closing.
    window.top?.close();
    return true;
  }
  if (postAbrumCloseSurface(result)) return true;
  if (typeof window === "undefined") return false;
  window.close();
  return true;
}

type ImportedSurfaceInput<Surface> = Surface extends AbrumAppSurfaceDef<infer Input>
  ? Input
  : AbrumSurfaceJsonValue;

export type AbrumImportedSurfaceOpener<App extends AbrumApp<AbrumEntities, AbrumAppFunctions, AbrumAppSurfaces>> = <
  Name extends keyof App["surfaces"] & string,
>(
  surface: Name,
  input: ImportedSurfaceInput<App["surfaces"][Name]>,
  options?: OpenAbrumSurfaceOptions,
) => Promise<AbrumSurfaceJsonValue | undefined>;

/** Open a named surface published by an imported app module. The generated app
 * binding supplies both the provider id and the input type; the native host
 * verifies that the current app actually imports this provider before loading
 * its isolated iframe. */
export function useAbrumAppSurface<
  const App extends AbrumApp<AbrumEntities, AbrumAppFunctions, AbrumAppSurfaces>,
>(app: App): AbrumImportedSurfaceOpener<App> {
  return useCallback((async (surface, input, options = {}) => {
    const definition = app.surfaces[surface];
    if (!definition) throw new Error(`app ${app.name} does not publish surface ${surface}`);
    const embed = readEmbedSignal();
    if (!embed || embed.kind === "web") {
      throw new Error("imported app surfaces require an ABRUM host");
    }
    const requestId = typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `surface-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    return new Promise<AbrumSurfaceJsonValue | undefined>((resolve, reject) => {
      const onMessage = (event: MessageEvent) => {
        if (event.source !== window.parent) return;
        const result = readAbrumSurfaceResult(event.data);
        if (!result || result.requestId !== requestId) return;
        window.removeEventListener("message", onMessage);
        if (result.error) reject(new Error(result.error));
        else resolve(result.result);
      };
      window.addEventListener("message", onMessage);
      const posted = postAbrumOpenSurface({
        appId: app.name,
        surfaceId: definition.name,
        input: input as AbrumSurfaceJsonValue,
        placement: options.placement ?? "modal",
        title: options.title,
        width: options.width,
        height: options.height,
        requestId,
      }, { roomId: embed.roomId, win: window });
      if (!posted) {
        window.removeEventListener("message", onMessage);
        reject(new Error("ABRUM could not open the imported app surface"));
      }
    });
  }) as AbrumImportedSurfaceOpener<App>, [app]);
}

/** The named surface context the host placed this app in, fixed for this page. */
export function useAbrumSurfaceContext(): AbrumAppSurfaceReference | null {
  return useMemo(() => readAbrumAppSurface(), []);
}

/**
 * The window route the app was opened at, or null for the app's main surface.
 * Branch on it in your app entry to render the windowed surface, e.g.
 * `const route = useAbrumWindowRoute(); if (route === "report") return <Report />;`
 * Fixed for the page's lifetime (set in the URL before scripts run).
 */
export function useAbrumWindowRoute(): string | null {
  return useMemo(() => readAbrumWindowRoute(), []);
}

/**
 * Renders the in-app modal for standalone {@link openAbrumWindow} calls. The modal
 * shows the requested route in an iframe (the same app reloaded with the route
 * param), so the app's own windowed-surface code path drives both the native
 * window and the modal. `mountAbrumApp` mounts one automatically — apps don't
 * normally render this themselves.
 */
export function AbrumWindowModalHost(): ReactNode {
  const [request, setRequest] = useState<OpenRequest | null>(null);

  useEffect(() => {
    const listener = (next: OpenRequest) => setRequest(next);
    modalListeners.add(listener);
    return () => {
      modalListeners.delete(listener);
    };
  }, []);

  useEffect(() => {
    if (!request) return;
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") setRequest(null);
    }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [request]);

  if (!request || typeof window === "undefined") return null;

  const src = withAbrumWindowRoute(window.location.href, request.route);
  const width = request.width && request.width > 0 ? request.width : 720;
  const height = request.height && request.height > 0 ? request.height : 520;
  const close = () => setRequest(null);

  return (
    <div
      role="presentation"
      onClick={(event) => {
        if (event.target === event.currentTarget) close();
      }}
      className="abrum-backdrop-blur--2"
      style={backdropStyle}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={request.title ?? "Window"}
        style={{ ...panelStyle, width: `min(${width}px, calc(100vw - 32px))`, height: `min(${height}px, calc(100vh - 32px))` }}
      >
        <header style={headerStyle}>
          <strong style={{ fontSize: "var(--abrum-text-body)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {request.title ?? "Window"}
          </strong>
          <button type="button" onClick={close} aria-label="Close" style={closeButtonStyle}>
            ✕
          </button>
        </header>
        <iframe title={request.title ?? "ABRUM window"} src={src} style={iframeStyle} />
      </div>
    </div>
  );
}

/** Standalone/web fallback for app surfaces. Native hosts open the same surface
 * in an OS window through `abrum:open-surface`. */
export function AbrumSurfaceModalHost(): ReactNode {
  const [request, setRequest] = useState<SurfaceOpenRequest | null>(null);

  useEffect(() => {
    const listener = (next: SurfaceOpenRequest) => setRequest(next);
    surfaceModalListeners.add(listener);
    return () => {
      surfaceModalListeners.delete(listener);
    };
  }, []);

  useEffect(() => {
    if (!request) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setRequest(null);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [request]);

  if (!request || typeof window === "undefined") return null;
  const src = withAbrumAppSurface(window.location.href, request.reference, request.entrypoint);
  const width = request.width && request.width > 0 ? request.width : 720;
  const height = request.height && request.height > 0 ? request.height : 520;
  const close = () => setRequest(null);
  const appTitle = formatAppSurfaceAppTitle(request.reference.appId);
  const surfaceTitle = request.title ?? formatAppSurfaceTitle(request.reference.surfaceId);
  return (
    <div role="presentation" onClick={(event) => event.target === event.currentTarget && close()} className="abrum-backdrop-blur--2" style={backdropStyle}>
      <AppSurfaceFrame
        role="dialog"
        aria-modal="true"
        aria-label={`${appTitle}: ${surfaceTitle}`}
        appTitle={appTitle}
        appId={request.reference.appId}
        surfaceTitle={surfaceTitle}
        bodyStyle={{ display: "flex" }}
        style={{
          width: `min(${width}px, calc(100vw - 32px))`,
          height: `min(${height}px, calc(100vh - 32px))`,
          boxShadow: "0 24px 64px rgba(0,0,0,.32)",
        }}
        actions={(
          <button type="button" onClick={close} aria-label="Close" title="Close" style={closeButtonStyle}>
            <X size={14} aria-hidden="true" />
          </button>
        )}
      >
        <iframe title={`${appTitle}: ${surfaceTitle}`} src={src} style={iframeStyle} />
      </AppSurfaceFrame>
    </div>
  );
}

const backdropStyle: CSSProperties = {
  position: "fixed",
  inset: 0,
  zIndex: 2147483646,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  background: "rgba(9,9,11,.45)",
};

const panelStyle: CSSProperties = {
  display: "flex",
  flexDirection: "column",
  background: "var(--abrum-bg, #fff)",
  color: "var(--abrum-fg, #18181b)",
  border: "1px solid var(--abrum-border, rgba(0,0,0,.12))",
  borderRadius: 12,
  boxShadow: "0 24px 64px rgba(0,0,0,.32)",
  overflow: "hidden",
};

const headerStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: 8,
  padding: "8px 8px 8px 14px",
  borderBottom: "1px solid var(--abrum-border, rgba(0,0,0,.10))",
  font: "var(--abrum-type-body)",
};

const closeButtonStyle: CSSProperties = {
  marginLeft: "auto",
  border: 0,
  background: "transparent",
  color: "inherit",
  cursor: "pointer",
  fontSize: "var(--abrum-text-body)",
  lineHeight: 1,
  padding: "6px 8px",
  borderRadius: 6,
};

const iframeStyle: CSSProperties = {
  flex: 1,
  width: "100%",
  border: 0,
  background: "var(--abrum-bg, #fff)",
};
