import {
  createContext,
  type ReactNode,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from "react";
import {
  buildUserDirectory,
  ABRUM_SELECT_TWIN_CANCEL_MESSAGE_TYPE,
  decodeProjectedEntityRecords,
  entityContentType,
  canWriteRoom,
  mergeProjectedEntityRecords,
  postAbrumAppLensReady,
  postAbrumSelection,
  readEmbedSignal,
  readHostedAppRoute,
  readAbrumAppLens,
  readAbrumSelectTwin,
} from "@abrum/web-runtime";
import type {
  JsonRecord,
  JsonValue,
  PullTwinsResult,
  RuntimeSnapshot,
  SignedTwin,
  RoomAccessLevel,
  RoomMemberGrant,
  SyncPushResult,
  AbrumContact,
  AbrumApp,
  AbrumAppFunctionDef,
  AbrumAppFunctions,
  AbrumAppRunResult,
  AbrumCreateEntityResult,
  AbrumEntities,
  AbrumEntityData,
  AbrumEntityInput,
  AbrumEntityRecord,
  AbrumShareContentResult,
  AbrumUpdateEntityResult,
  TwinLogEntry,
  AbrumUseManyOptions,
  AbrumRuntime,
  AbrumTwinSelection,
  AbrumUserProfile,
} from "@abrum/web-runtime";
import {
  BoundedHeadsQueryStore,
  HeadsQueryStore,
  InfiniteHeadsQueryStore,
  RoomLensStore,
  headsRealtimeRefreshMode,
  roomLensKey,
  type RoomDataPlane,
  type RoomLensDemand,
  type RoomLensDescriptor,
  type RoomLensEvent,
  type RoomLensStoreSnapshot,
  type RoomQuery,
  type RoomQueryResponse,
  type RoomRealtimeEvent,
} from "@abrum/runtime";
import { createTwinSelectionDispatcher, type ObservedTwinSelection, type TwinSelectionContext } from "./twin-selection-dispatch";

type WebRoomLensDataPlane = RoomDataPlane<SignedTwin>;

const roomLensDataPlanes = new WeakMap<AbrumRuntime, WebRoomLensDataPlane>();
const roomLensStores = new WeakMap<AbrumRuntime, Map<string, RoomLensStore<SignedTwin, unknown>>>();
const MAX_ROOM_LENS_STORES_PER_RUNTIME = 128;

function roomLensDataPlane(runtime: AbrumRuntime): WebRoomLensDataPlane {
  let plane = roomLensDataPlanes.get(runtime);
  if (plane) return plane;
  plane = {
    queryRoom: async (_roomId: string, _query: RoomQuery): Promise<RoomQueryResponse<SignedTwin>> => {
      throw new Error("Single-Room queries use the existing web runtime adapter");
    },
    subscribeRoomEvents: (_listener: (event: RoomRealtimeEvent) => void) => () => undefined,
    queryRoomLens: (demand) => runtime.queryRoomLens(demand),
    subscribeRoomLensEvents: <TDescriptor,>(
      listener: (event: RoomLensEvent<SignedTwin, TDescriptor>) => void,
    ) => {
      let lastRevision = runtime.snapshot().realtimeRevision;
      return runtime.subscribe(() => {
        const snapshot = runtime.snapshot();
        if (snapshot.realtimeRevision === lastRevision) return;
        lastRevision = snapshot.realtimeRevision;
        const realtime = snapshot.lastRealtimeEvent;
        const contentTypes = realtime && realtime.type !== "replay_gap"
          ? realtime.content_types
          : [];
        listener({
          type: "invalidated",
          change: {
            // HTTP/SSE and Station lens revisions are different clocks. Zero
            // deliberately requests refresh without pretending to order them.
            revision: 0,
            roomIds: realtime && realtime.type !== "replay_gap" ? [realtime.room_id] : [],
            contentTypes,
            directoryChanged: !realtime
              || realtime.type === "replay_gap"
              || contentTypes.some((type) => type === "app_install" || type === "room_descriptor"),
          },
        });
      });
    },
  };
  roomLensDataPlanes.set(runtime, plane);
  return plane;
}

function cachedRoomLensStore<TDescriptor>(
  runtime: AbrumRuntime,
  demand: RoomLensDemand,
): RoomLensStore<SignedTwin, TDescriptor> {
  let stores = roomLensStores.get(runtime);
  if (!stores) {
    stores = new Map();
    roomLensStores.set(runtime, stores);
  }
  const key = roomLensKey(demand);
  let store = stores.get(key) as RoomLensStore<SignedTwin, TDescriptor> | undefined;
  if (store) {
    stores.delete(key);
    stores.set(key, store as RoomLensStore<SignedTwin, unknown>);
    return store;
  }
  store = new RoomLensStore<SignedTwin, TDescriptor>(roomLensDataPlane(runtime), demand);
  stores.set(key, store as RoomLensStore<SignedTwin, unknown>);
  if (stores.size > MAX_ROOM_LENS_STORES_PER_RUNTIME) {
    const oldestKey = stores.keys().next().value;
    if (oldestKey) {
      stores.get(oldestKey)?.dispose();
      stores.delete(oldestKey);
    }
  }
  return store;
}

const AbrumContext = createContext<AbrumRuntime | null>(null);
const AbrumMountedAppContext = createContext<{ appId: string | null }>({ appId: null });

export function AbrumProvider({
  runtime,
  appId = null,
  children,
}: {
  runtime: AbrumRuntime;
  appId?: string | null;
  children: ReactNode;
}) {
  return (
    <AbrumContext.Provider value={runtime}>
      <AbrumMountedAppContext.Provider value={{ appId }}>
        {children}
      </AbrumMountedAppContext.Provider>
    </AbrumContext.Provider>
  );
}

export function useAbrum(): AbrumRuntime {
  const runtime = useContext(AbrumContext);
  if (!runtime) {
    throw new Error("useAbrum must be used inside AbrumProvider");
  }
  return runtime;
}

/**
 * May the current actor write in this Room?
 *
 * Apps used to answer this with "am I signed in and is a Room selected", which
 * is a different question — a viewer passed it, wrote anyway, and the station
 * answered 403. Defaults to true while the Room list is still loading, so this
 * cannot flicker a working app into read-only.
 */
export function useAbrumCanWrite(roomId?: string | null): boolean {
  const snapshot = useAbrumSnapshot();
  const id = roomId ?? snapshot.selectedRoomId;
  if (!snapshot.user || !id) return false;
  return canWriteRoom(snapshot.rooms.find((room) => room.id === id));
}

export function useAbrumSnapshot(): RuntimeSnapshot {
  const runtime = useAbrum();
  const [snapshot, setSnapshot] = useState(() => runtime.snapshot());

  useEffect(() => runtime.subscribe(() => setSnapshot(runtime.snapshot())), [runtime]);

  return snapshot;
}

export interface UseAbrumRoomLensResult<
  TDescriptor = RoomLensDescriptor,
> extends RoomLensStoreSnapshot<SignedTwin, TDescriptor> {
  refresh(): Promise<RoomLensStoreSnapshot<SignedTwin, TDescriptor>>;
}

/** One framework-level dynamic Room view shared with native and desktop.
 * The selector discovers Rooms; each result remains independently authorized
 * by the signed Station request. Existing entries stay visible during refresh. */
export function useAbrumRoomLens<TDescriptor = RoomLensDescriptor>(
  demand: RoomLensDemand | null | undefined,
): UseAbrumRoomLensResult<TDescriptor> {
  const runtime = useAbrum();
  const snapshot = useAbrumSnapshot();
  const actorDid = snapshot.user?.did ?? "";
  const canonicalDemand = useMemo(
    () => demand && actorDid ? { ...demand, actorDid } : null,
    [actorDid, demand ? roomLensKey(demand) : ""],
  );
  const store = useMemo(
    () => canonicalDemand
      ? cachedRoomLensStore<TDescriptor>(runtime, canonicalDemand)
      : null,
    [runtime, canonicalDemand ? roomLensKey(canonicalDemand) : ""],
  );
  const empty = useMemo<RoomLensStoreSnapshot<SignedTwin, TDescriptor>>(() => ({
    entries: [],
    isPending: Boolean(demand && actorDid),
    isRefreshing: false,
    hasSnapshot: !demand || !actorDid,
    error: null,
    revision: 0,
    updatedAtMs: null,
  }), [actorDid, demand ? roomLensKey(demand) : ""]);
  const lens = useSyncExternalStore(
    store?.subscribe ?? noRoomLensSubscribe,
    store?.getSnapshot ?? (() => empty),
    store?.getSnapshot ?? (() => empty),
  );
  const refresh = useCallback(
    () => store ? store.refresh() : Promise.resolve(empty),
    [empty, store],
  );
  return useMemo(() => ({ ...lens, refresh }), [lens, refresh]);
}

function noRoomLensSubscribe(): () => void {
  return () => undefined;
}

export function useAbrumMountedApp() {
  return useContext(AbrumMountedAppContext);
}

/**
 * Rooms contributing to the active host App Lens. The host signal is routing
 * metadata only: every read is still independently signed and authorized by
 * the Station. When no lens is active, the concrete selected Room is the sole
 * source.
 */
export function useAbrumAppLensRoomIds(): string[] {
  const snapshot = useAbrumSnapshot();
  const mountedApp = useAbrumMountedApp();
  const appId = currentAppId(mountedApp.appId);
  const selectedRoomId = snapshot.selectedRoomId;
  const [lensRoomIds, setLensRoomIds] = useState<string[]>([]);

  useEffect(() => {
    setLensRoomIds([]);
  }, [appId, selectedRoomId]);

  useEffect(() => {
    if (!appId) return;
    const onMessage = (event: MessageEvent) => {
      if (typeof window !== "undefined" && window.parent !== window && event.source !== window.parent) return;
      const message = readAbrumAppLens(event.data, appId);
      if (!message) return;
      setLensRoomIds(message.active ? message.roomIds : []);
    };
    window.addEventListener("message", onMessage);
    postAbrumAppLensReady();
    return () => window.removeEventListener("message", onMessage);
  }, [appId]);

  return useMemo(() => {
    const ids = lensRoomIds.length > 0
      ? lensRoomIds
      : selectedRoomId
        ? [selectedRoomId]
        : [];
    return [...new Set(ids)];
  }, [lensRoomIds, selectedRoomId]);
}

function currentAppId(fallback?: string | null): string | null {
  return readEmbedSignal()?.appId ?? readHostedAppRoute()?.appId ?? fallback ?? null;
}

/**
 * Report which twin the user has selected to the embedding host (desktop
 * shell), so the assistant gets it as context ("the selected calendar event",
 * "this mail"). Returns a stable setter; pass null to clear. No-op when the app
 * runs standalone (not embedded). The host tags it with the current room/app.
 */
export function useAbrumSelection() {
  const snapshot = useAbrumSnapshot();
  const mountedApp = useAbrumMountedApp();
  const roomId = snapshot.selectedRoomId ?? null;
  return useCallback(
    (selection: AbrumTwinSelection | null) => {
      postAbrumSelection(selection, { roomId, appId: currentAppId(mountedApp.appId) });
    },
    [roomId, mountedApp.appId],
  );
}

/**
 * Declarative form of {@link useAbrumSelection}: pass the currently-selected twin
 * (or null) and it is reported to the host whenever it changes, and cleared
 * when the component unmounts or the room changes. Example:
 * `useAbrumSelectedTwin(open ? { cid: event.cid, twinType: "calendar_event", title: event.title } : null)`.
 */
export function useAbrumSelectedTwin(selection: AbrumTwinSelection | null): void {
  const report = useAbrumSelection();
  const cid = selection?.cid ?? "";
  const twinType = selection?.twinType ?? "";
  const title = selection?.title ?? "";
  useEffect(() => {
    report(cid ? { cid, twinType: twinType || undefined, title: title || undefined } : null);
  }, [report, cid, twinType, title]);
  // Clear the host selection when this component unmounts or the room changes.
  useEffect(() => () => report(null), [report]);
}

export interface AbrumSelectedRecordOptions {
  /** Human-readable label shown to the assistant for the current selection. */
  title?: string | null;
  /** Legacy override; generated entity records normally carry content.type. */
  twinType?: string | null;
}

/** Minimal generated-record metadata needed to publish a host selection. */
export interface AbrumSelectableRecord {
  readonly $: {
    readonly cid: string;
    readonly twin: SignedTwin;
  };
}

/**
 * Report a generated entity record as the current host selection. CID and
 * content type come from the signed record metadata, so app code cannot drift
 * from its generated schema by repeating either value manually.
 */
export function useAbrumSelectedRecord(
  record: AbrumSelectableRecord | null | undefined,
  options: AbrumSelectedRecordOptions = {},
): void {
  const content = record?.$.twin.block.content as JsonRecord | undefined;
  const storedTwinType = typeof content?.type === "string" ? content.type : null;
  useAbrumSelectedTwin(record
    ? {
        cid: record.$.cid,
        twinType: options.twinType ?? storedTwinType ?? undefined,
        title: options.title ?? undefined,
      }
    : null);
}

/**
 * Receive "select this twin" commands the HOST sends when the chat agent's
 * navigateUi tool navigates here (the reverse of {@link useAbrumSelectedTwin}).
 * Calls `onSelect(cid)` for each command; the app then opens/highlights that
 * object (e.g. resolve the canonical record and route to it). Request IDs are
 * deduplicated; the context signal cancels stale asynchronous work. Apps opt
 * into verified completion by supplying their committed selection. Without
 * that observation legacy handlers remain best-effort, never verified.
 * Example: `useAbrumOnSelectTwin((cid) => setOpenEventCid(cid))`.
 */
export function useAbrumOnSelectTwin(
  onSelect: (cid: string, roomId?: string, context?: TwinSelectionContext) => void,
  observed: ObservedTwinSelection | null = null,
  failedRequestId?: string,
): void {
  const cb = useRef(onSelect);
  cb.current = onSelect;
  const dispatcher = useMemo(() => createTwinSelectionDispatcher(
    (cid, roomId, context) => cb.current(cid, roomId, context),
    (result) => window.parent.postMessage(result, "*"),
  ), []);
  useEffect(() => {
    const timers = new Set<ReturnType<typeof setTimeout>>();
    function onMessage(event: MessageEvent) {
      if (window.parent !== window && event.source !== window.parent) return;
      if (event.data?.type === ABRUM_SELECT_TWIN_CANCEL_MESSAGE_TYPE) {
        dispatcher.cancel(event.data.requestId);
        return;
      }
      const msg = readAbrumSelectTwin(event.data);
      if (!msg) return;
      // Old hosts retain their best-effort API; they cannot produce verified receipts.
      if (!msg.requestId || !msg.roomId) { cb.current(msg.cid, msg.roomId); return; }
      dispatcher.request(msg);
      const timer = setTimeout(() => { timers.delete(timer); dispatcher.expire(msg.requestId!); }, 19_000);
      timers.add(timer);
    }
    const cancelForHuman = (event: Event) => { if (event.isTrusted) dispatcher.cancel(); };
    window.addEventListener("message", onMessage);
    window.addEventListener("pointerdown", cancelForHuman, true);
    window.addEventListener("keydown", cancelForHuman, true);
    return () => {
      dispatcher.cancel();
      timers.forEach(clearTimeout);
      window.removeEventListener("message", onMessage);
      window.removeEventListener("pointerdown", cancelForHuman, true);
      window.removeEventListener("keydown", cancelForHuman, true);
    };
  }, [dispatcher]);
  // Effects run after React commits the reader, never merely after requesting setState.
  useEffect(() => { dispatcher.observe(observed); }, [dispatcher, observed]);
  useEffect(() => { if (failedRequestId) dispatcher.fail(failedRequestId); }, [dispatcher, failedRequestId]);
}

export function useAbrumUser() {
  const runtime = useAbrum();
  const snapshot = useAbrumSnapshot();
  return useMemo(
    () => ({
      user: snapshot.user,
      displayName: snapshot.displayName,
      create: (displayName?: string) => runtime.createUser(displayName),
      updateProfile: (input: { displayName?: string; avatarFileLineageCid?: string | null; bio?: string | null }) =>
        runtime.updateUserProfile(input),
      uploadAvatar: (blob: Blob) => runtime.uploadUserAvatar(blob),
      avatarUrl: (cid: string | null | undefined) => (cid ? runtime.blobUrl(cid) : null),
    }),
    [runtime, snapshot.displayName, snapshot.user],
  );
}

export function useAbrumStation() {
  const runtime = useAbrum();
  const snapshot = useAbrumSnapshot();
  return useMemo(
    () => ({
      station: snapshot.stationIdentity,
      stationUrl: snapshot.stationUrl,
      hostedRoomId: snapshot.hostedRoomId,
      selectedRoomId: snapshot.selectedRoomId,
      pair: (displayName?: string) => runtime.pair(displayName),
    }),
    [runtime, snapshot.hostedRoomId, snapshot.selectedRoomId, snapshot.stationIdentity, snapshot.stationUrl],
  );
}

export function useAbrumRooms() {
  const runtime = useAbrum();
  const snapshot = useAbrumSnapshot();
  return useMemo(
    () => ({
      rooms: snapshot.rooms,
      selectedRoomId: snapshot.selectedRoomId,
      selectedRoom: snapshot.rooms.find((room) => room.id === snapshot.selectedRoomId) ?? null,
      refresh: () => runtime.loadRooms(),
      select: (roomId: string) => runtime.selectRoom(roomId),
      create: (name: string, purpose?: string) => runtime.createRoom(name, purpose),
      rename: (roomId: string, name: string) => runtime.renameRoom(roomId, name),
      archive: (roomId: string) => runtime.archiveRoom(roomId),
    }),
    [runtime, snapshot.selectedRoomId, snapshot.rooms],
  );
}

export function useAbrumDirectory() {
  const runtime = useAbrum();
  const snapshot = useAbrumSnapshot();
  const userDid = snapshot.user?.did ?? null;
  const displayName = snapshot.displayName;
  const roomKey = snapshot.rooms.map((room) => room.id).join("\0");
  const [entries, setEntries] = useState<TwinLogEntry[]>([]);
  const [directory, setDirectory] = useState<Record<string, AbrumUserProfile>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!userDid || snapshot.rooms.length === 0) {
      setEntries([]);
      const fallback = userDid && displayName ? { [userDid]: { did: userDid, displayName } } : {};
      setDirectory(fallback);
      return [];
    }
    setIsLoading(true);
    setError(null);
    try {
      const results = await Promise.allSettled(
        snapshot.rooms.map((room) =>
          runtime.pullHeads(room.id, 0, { contentTypes: ["userProfile"], limit: 500 }),
        ),
      );
      const nextEntries = results.flatMap((result) => result.status === "fulfilled" ? result.value.entries : []);
      const nextDirectory = buildUserDirectory(nextEntries);
      if (userDid && displayName && !nextDirectory[userDid]) {
        nextDirectory[userDid] = { did: userDid, displayName };
      }
      setEntries(nextEntries);
      setDirectory(nextDirectory);
      const rejected = results.find((result) => result.status === "rejected");
      if (rejected?.status === "rejected") {
        setError(rejected.reason instanceof Error ? rejected.reason.message : String(rejected.reason));
      }
      return nextEntries;
    } finally {
      setIsLoading(false);
    }
  }, [runtime, roomKey, userDid, displayName]);

  useEffect(() => {
    refresh().catch((err) => setError(err instanceof Error ? err.message : String(err)));
  }, [refresh, snapshot.realtimeRevision]);

  return useMemo(
    () => ({ directory, entries, isLoading, error, refresh }),
    [directory, entries, error, isLoading, refresh],
  );
}

export function useAbrumContacts(enabled = true) {
  const runtime = useAbrum();
  const snapshot = useAbrumSnapshot();
  const userDid = snapshot.user?.did ?? null;
  const [contacts, setContacts] = useState<AbrumContact[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!enabled || !userDid) {
      setContacts([]);
      return [];
    }
    setIsLoading(true);
    setError(null);
    try {
      const next = await runtime.loadContacts();
      const sorted = [...next].sort((left, right) =>
        (left.displayName ?? left.did).localeCompare(right.displayName ?? right.did),
      );
      setContacts(sorted);
      return sorted;
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      setError(message);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [enabled, runtime, userDid]);

  useEffect(() => {
    refresh().catch(() => undefined);
  // Contacts are station relationship state, not room projection state. A
  // room Twin event must not blank and reload this list (the share dialog used
  // to flicker on every write, including the receipt created by sharing).
  }, [refresh]);

  return useMemo(
    () => ({ contacts, isLoading, error, refresh }),
    [contacts, error, isLoading, refresh],
  );
}

export function useAbrumRoomMembers(roomId?: string | null) {
  const runtime = useAbrum();
  const snapshot = useAbrumSnapshot();
  const selectedRoomId = roomId ?? snapshot.selectedRoomId;
  const userDid = snapshot.user?.did ?? null;
  const [members, setMembers] = useState<RoomMemberGrant[]>([]);
  const [canManage, setCanManage] = useState<boolean | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!selectedRoomId || !userDid) {
      setMembers([]);
      setCanManage(null);
      return [];
    }
    setIsLoading(true);
    setError(null);
    try {
      const next = await runtime.loadRoomMembers(selectedRoomId);
      setMembers(next);
      setCanManage(true);
      return next;
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (isForbidden(message)) {
        setMembers([]);
        setCanManage(false);
        return [];
      }
      setError(message);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [runtime, selectedRoomId, userDid]);

  const grant = useCallback(
    async (principalDid: string, level: RoomAccessLevel) => {
      if (!selectedRoomId) {
        throw new Error("select a room first");
      }
      const result = await runtime.grantRoomAccess(principalDid, level, selectedRoomId);
      await refresh();
      return result;
    },
    [refresh, runtime, selectedRoomId],
  );

  const revoke = useCallback(
    async (grantCid: string) => {
      if (!selectedRoomId) {
        throw new Error("select a room first");
      }
      const result = await runtime.revokeRoomAccess(grantCid, selectedRoomId);
      await refresh();
      return result;
    },
    [refresh, runtime, selectedRoomId],
  );

  useEffect(() => {
    refresh().catch(() => undefined);
  }, [refresh, snapshot.realtimeRevision]);

  return useMemo(
    () => ({ members, canManage, isLoading, error, refresh, grant, revoke }),
    [canManage, error, grant, isLoading, members, refresh, revoke],
  );
}

export function useAbrumTwins(roomId?: string | null) {
  const runtime = useAbrum();
  const snapshot = useAbrumSnapshot();
  const selectedRoomId = roomId ?? snapshot.selectedRoomId;
  const userDid = snapshot.user?.did ?? null;
  const [entries, setEntries] = useState<TwinLogEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const cursorRef = useRef<{ roomId: string | null; seq: number }>({ roomId: null, seq: 0 });

  const refresh = useCallback(
    async (afterSeq?: number) => {
      if (!selectedRoomId || !userDid) {
        cursorRef.current = { roomId: selectedRoomId ?? null, seq: 0 };
        setEntries([]);
        return [];
      }
      const reset = afterSeq === 0 || cursorRef.current.roomId !== selectedRoomId;
      let seq = afterSeq ?? (reset ? 0 : cursorRef.current.seq);
      setIsLoading(true);
      setError(null);
      try {
        // The station caps each pull at a fixed page size, so a single call
        // only returns the first page. Paginate to the head, otherwise twins
        // beyond the first page (e.g. recently-added accounts in a busy room)
        // never load.
        const pages: TwinLogEntry[] = [];
        for (;;) {
          const result = await runtime.pull(selectedRoomId, seq);
          pages.push(...result.entries);
          const nextSeq = result.cursor.seq;
          if (result.entries.length === 0 || nextSeq <= seq) {
            seq = nextSeq > seq ? nextSeq : seq;
            break;
          }
          seq = nextSeq;
        }
        cursorRef.current = { roomId: selectedRoomId, seq };
        setEntries((current) => (reset ? pages : mergeTwinEntries(current, pages)));
        return pages;
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        setError(message);
        throw err;
      } finally {
        setIsLoading(false);
      }
    },
    [runtime, selectedRoomId, userDid],
  );

  useEffect(() => {
    cursorRef.current = { roomId: selectedRoomId ?? null, seq: 0 };
    setEntries([]);
    refresh(0).catch(() => undefined);
  }, [refresh, selectedRoomId, userDid]);

  useEffect(() => {
    if (snapshot.realtimeRevision > 0) {
      refresh().catch(() => undefined);
    }
  }, [refresh, snapshot.realtimeRevision]);

  return useMemo(
    () => ({ entries, isLoading, error, refresh }),
    [entries, error, isLoading, refresh],
  );
}

const headsQueryStores = new WeakMap<AbrumRuntime, Map<string, HeadsQueryStore<TwinLogEntry>>>();
const MAX_HEADS_QUERY_STORES_PER_RUNTIME = 128;

function cachedHeadsQueryStore(
  runtime: AbrumRuntime,
  userDid: string | null,
  roomIds: readonly string[],
  contentTypes: readonly string[],
  lineageCids: readonly string[],
  limit: number,
): HeadsQueryStore<TwinLogEntry> {
  let runtimeStores = headsQueryStores.get(runtime);
  if (!runtimeStores) {
    runtimeStores = new Map();
    headsQueryStores.set(runtime, runtimeStores);
  }
  const normalizedRooms = [...new Set(roomIds.filter(Boolean))].sort();
  const normalizedTypes = [...new Set(contentTypes.filter(Boolean))].sort();
  const normalizedLineages = [...new Set(lineageCids.filter(Boolean))].sort();
  const key = JSON.stringify([userDid, normalizedRooms, normalizedTypes, normalizedLineages, limit]);
  let store = runtimeStores.get(key);
  if (store) {
    // Refresh insertion order so the bounded map behaves as a small LRU. The
    // runtime itself is weakly held; this second bound covers users navigating
    // through many distinct Room/lens combinations in one long-lived desktop.
    runtimeStores.delete(key);
    runtimeStores.set(key, store);
  }
  if (!store) {
    store = new HeadsQueryStore({
      roomIds: normalizedRooms,
      contentTypes: normalizedTypes,
      lineageCids: normalizedLineages,
      limit,
      pull: (sourceRoomId, afterSeq, options) =>
        runtime.pullHeads(sourceRoomId, afterSeq, options),
    });
    runtimeStores.set(key, store);
    if (runtimeStores.size > MAX_HEADS_QUERY_STORES_PER_RUNTIME) {
      const oldestKey = runtimeStores.keys().next().value;
      if (oldestKey) runtimeStores.delete(oldestKey);
    }
  }
  return store;
}

function useAbrumHeadsQuery(
  contentTypes: readonly string[],
  roomIds: readonly string[],
  limit: number,
  lineageCids: readonly string[] = [],
  enabled = true,
) {
  const runtime = useAbrum();
  const snapshot = useAbrumSnapshot();
  const userDid = snapshot.user?.did ?? null;
  const contentKey = contentTypes.filter(Boolean).sort().join("\0");
  const roomKey = roomIds.filter(Boolean).sort().join("\0");
  const lineageKey = lineageCids.filter(Boolean).sort().join("\0");
  const store = useMemo(
    () => cachedHeadsQueryStore(
      runtime,
      userDid,
      enabled && userDid ? roomKey.split("\0").filter(Boolean) : [],
      contentKey.split("\0").filter(Boolean),
      lineageKey.split("\0").filter(Boolean),
      limit,
    ),
    [contentKey, enabled, limit, lineageKey, roomKey, runtime, userDid],
  );
  const query = useSyncExternalStore(store.subscribe, store.getSnapshot, store.getSnapshot);

  useEffect(() => {
    if (enabled && userDid) store.refresh().catch(() => undefined);
  }, [enabled, store, userDid]);

  useEffect(() => {
    if (!enabled || !userDid || snapshot.realtimeRevision === 0) return;
    const event = snapshot.lastRealtimeEvent;
    const sources = roomKey.split("\0").filter(Boolean);
    const types = contentKey.split("\0").filter(Boolean);
    const mode = headsRealtimeRefreshMode(event, sources, types);
    const targetRooms = event && event.type !== "replay_gap"
      ? [event.room_id]
      : sources;
    if (mode) store.refresh(mode === "reset", targetRooms).catch(() => undefined);
  }, [
    contentKey,
    enabled,
    roomKey,
    snapshot.lastRealtimeEvent,
    snapshot.realtimeRevision,
    store,
    userDid,
  ]);

  const refresh = useCallback(
    (afterSeq?: number) => store.refresh(afterSeq === 0),
    [store],
  );
  return useMemo(
    () => ({ ...query, refresh }),
    [query, refresh],
  );
}

export function useAbrumHeads(
  contentTypes: readonly string[] = [],
  roomId?: string | null,
  limit = 5000,
  lineageCids: readonly string[] = [],
  enabled = true,
) {
  const snapshot = useAbrumSnapshot();
  const selectedRoomId = roomId ?? snapshot.selectedRoomId;
  const roomIds = useMemo(() => selectedRoomId ? [selectedRoomId] : [], [selectedRoomId]);
  return useAbrumHeadsQuery(contentTypes, roomIds, limit, lineageCids, enabled);
}

/** Subscribe to current heads across an explicit set of Rooms. Entries retain
 * `sourceRoomId`; one unavailable Room is reported through `roomErrors` while
 * successful Rooms stay live. Prefer this over app-local pull loops. */
export function useAbrumHeadsInRooms(
  contentTypes: readonly string[],
  roomIds: readonly string[],
  limit = 5000,
  lineageCids: readonly string[] = [],
  enabled = true,
) {
  return useAbrumHeadsQuery(contentTypes, roomIds, limit, lineageCids, enabled);
}

const boundedHeadsQueryStores = new WeakMap<AbrumRuntime, Map<string, BoundedHeadsQueryStore<TwinLogEntry>>>();
const infiniteHeadsQueryStores = new WeakMap<AbrumRuntime, Map<string, InfiniteHeadsQueryStore<TwinLogEntry>>>();

function useAbrumBoundedEntityQuery(
  contentType: string,
  roomIds: readonly string[],
  options: AbrumUseManyOptions<Record<string, unknown>>,
  enabled: boolean,
) {
  const runtime = useAbrum();
  const snapshot = useAbrumSnapshot();
  const userDid = snapshot.user?.did ?? null;
  const roomKey = roomIds.filter(Boolean).sort().join("\0");
  const queryKey = JSON.stringify({
    contentType,
    where: options.where ?? null,
    order: options.order ?? null,
    limit: options.limit ?? null,
  });
  const store = useMemo(() => {
    let stores = boundedHeadsQueryStores.get(runtime);
    if (!stores) {
      stores = new Map();
      boundedHeadsQueryStores.set(runtime, stores);
    }
    const normalizedRooms = enabled && userDid ? roomKey.split("\0").filter(Boolean) : [];
    const key = JSON.stringify([userDid, normalizedRooms, queryKey]);
    let current = stores.get(key);
    if (!current) {
      current = new BoundedHeadsQueryStore({
        roomIds: normalizedRooms,
        query: (roomId) => runtime.queryHeads({
          contentType,
          ...(options.where ? { where: options.where as JsonRecord } : {}),
          ...(options.order ? { order: options.order as [string, "asc" | "desc"] } : {}),
          limit: options.limit ?? 100,
        }, roomId),
      });
      stores.set(key, current);
      if (stores.size > MAX_HEADS_QUERY_STORES_PER_RUNTIME) {
        const oldestKey = stores.keys().next().value;
        if (oldestKey) stores.delete(oldestKey);
      }
    }
    return current;
  }, [contentType, enabled, options.limit, queryKey, roomKey, runtime, userDid]);
  const query = useSyncExternalStore(store.subscribe, store.getSnapshot, store.getSnapshot);

  useEffect(() => {
    if (enabled && userDid) store.refresh().catch(() => undefined);
  }, [enabled, store, userDid]);

  useEffect(() => {
    if (!enabled || !userDid || snapshot.realtimeRevision === 0) return;
    const mode = headsRealtimeRefreshMode(
      snapshot.lastRealtimeEvent,
      roomKey.split("\0").filter(Boolean),
      [contentType],
    );
    const event = snapshot.lastRealtimeEvent;
    const targetRooms = event && event.type !== "replay_gap"
      ? [event.room_id]
      : roomKey.split("\0").filter(Boolean);
    if (mode) store.refresh(targetRooms).catch(() => undefined);
  }, [contentType, enabled, roomKey, snapshot.lastRealtimeEvent, snapshot.realtimeRevision, store, userDid]);

  const refresh = useCallback(() => store.refresh(), [store]);
  return useMemo(() => ({ ...query, refresh }), [query, refresh]);
}

export interface AbrumQueryResult<TData> {
  data: TData;
  isLoading: boolean;
  error: string | null;
  roomErrors: Readonly<Record<string, string>>;
  refresh: () => Promise<TwinLogEntry[]>;
}

export interface AbrumInfiniteQueryResult<TData> extends AbrumQueryResult<TData> {
  hasMore: boolean;
  isLoadingMore: boolean;
  /** The previous query key's settled data is keeping the layout stable. */
  isPlaceholderData: boolean;
  loadMore: () => Promise<TwinLogEntry[]>;
}

export function useAbrumInfiniteEntityList<
  const App extends AbrumApp<AbrumEntities>,
  Name extends keyof App["entities"] & string,
>(
  app: App,
  entityName: Name,
  options: Omit<AbrumUseManyOptions<AbrumEntityData<App["entities"][Name]>>, "limit"> & {
    order: [keyof AbrumEntityData<App["entities"][Name]>, "asc" | "desc"];
    pageSize?: number;
    keepPreviousData?: boolean;
    /** Batch matching realtime notifications without delaying explicit refreshes. */
    realtimeRefreshDelayMs?: number;
  },
): AbrumInfiniteQueryResult<Array<AbrumEntityRecord<App["entities"][Name]>>> {
  const runtime = useAbrum();
  const snapshot = useAbrumSnapshot();
  const lensRoomIds = useAbrumAppLensRoomIds();
  const userDid = snapshot.user?.did ?? null;
  const contentType = entityContentType(app, entityName);
  const roomKey = lensRoomIds.filter(Boolean).sort().join("\0");
  const pageSize = Math.max(1, Math.min(500, options.pageSize ?? 100));
  const realtimeRefreshDelayMs = options.realtimeRefreshDelayMs ?? 0;
  const orderField = String(options.order[0]);
  const orderDirection = options.order[1];
  const queryKey = JSON.stringify({
    contentType,
    where: options.where ?? null,
    order: [orderField, orderDirection],
    pageSize,
    realtimeRefreshDelayMs,
  });
  const store = useMemo(() => {
    let stores = infiniteHeadsQueryStores.get(runtime);
    if (!stores) {
      stores = new Map();
      infiniteHeadsQueryStores.set(runtime, stores);
    }
    const normalizedRooms = userDid ? roomKey.split("\0").filter(Boolean) : [];
    const key = JSON.stringify([userDid, normalizedRooms, queryKey]);
    let current = stores.get(key);
    if (!current) {
      current = new InfiniteHeadsQueryStore({
        roomIds: normalizedRooms,
        pageSize,
        realtimeRefreshDelayMs,
        query: (roomId, after) => runtime.queryHeads({
          contentType,
          ...(options.where ? { where: options.where as JsonRecord } : {}),
          order: [orderField, orderDirection],
          ...(after ? { after } : {}),
          limit: pageSize,
        }, roomId),
        cursor: (entry) => {
          const content = entry.twin.block.content;
          if (!content || typeof content !== "object" || Array.isArray(content)) return null;
          const value = (content as Record<string, JsonValue>)[orderField];
          if (typeof value !== "string" && typeof value !== "number" && typeof value !== "boolean") {
            return null;
          }
          return { value, lineageCid: entry.lineageCid ?? entry.cid };
        },
      });
      stores.set(key, current);
      if (stores.size > MAX_HEADS_QUERY_STORES_PER_RUNTIME) {
        const oldestKey = stores.keys().next().value;
        if (oldestKey) stores.delete(oldestKey);
      }
    }
    return current;
  }, [contentType, options.where, orderDirection, orderField, pageSize, realtimeRefreshDelayMs, queryKey, roomKey, runtime, userDid]);
  const query = useSyncExternalStore(store.subscribe, store.getSnapshot, store.getSnapshot);

  useEffect(() => {
    if (userDid) store.refresh().catch(() => undefined);
  }, [store, userDid]);

  useEffect(() => {
    if (!userDid || snapshot.realtimeRevision === 0) return;
    const mode = headsRealtimeRefreshMode(
      snapshot.lastRealtimeEvent,
      roomKey.split("\0").filter(Boolean),
      [contentType],
    );
    const event = snapshot.lastRealtimeEvent;
    const targetRooms = event && event.type !== "replay_gap"
      ? [event.room_id]
      : roomKey.split("\0").filter(Boolean);
    if (mode) store.invalidate(targetRooms);
  }, [contentType, roomKey, snapshot.lastRealtimeEvent, snapshot.realtimeRevision, store, userDid]);

  const records = useMemo(
    () => entityRecordsWithRoomAuthority(
      mergeProjectedEntityRecords(app, entityName, query.entries, {
        order: options.order,
      }),
      snapshot.rooms,
    ),
    [app, entityName, options.order, options.where, query.entries, snapshot.rooms],
  );
  // Placeholder data is a presentation optimization for another query over
  // the SAME Room set (Mail uses it while switching folders). Never carry a
  // settled page across a Room/lens transition: an empty newly selected Room
  // would otherwise briefly render records from the previously open Room.
  const placeholderScopeKey = `${userDid ?? ""}\0${roomKey}`;
  const lastSettledRecordsRef = useRef<{
    scopeKey: string;
    records: Array<AbrumEntityRecord<App["entities"][Name]>>;
  }>({ scopeKey: placeholderScopeKey, records });
  if (lastSettledRecordsRef.current.scopeKey !== placeholderScopeKey) {
    lastSettledRecordsRef.current = { scopeKey: placeholderScopeKey, records: [] };
  }
  useEffect(() => {
    if (query.hasLoaded) {
      lastSettledRecordsRef.current = { scopeKey: placeholderScopeKey, records };
    }
  }, [placeholderScopeKey, query.hasLoaded, records]);
  const isPlaceholderData = Boolean(
    options.keepPreviousData
    && !query.hasLoaded
    && lastSettledRecordsRef.current.scopeKey === placeholderScopeKey
    && lastSettledRecordsRef.current.records.length > 0,
  );
  const visibleRecords = isPlaceholderData ? lastSettledRecordsRef.current.records : records;
  const refresh = useCallback(() => store.refresh(), [store]);
  const loadMore = useCallback(() => store.loadMore(), [store]);
  return useMemo(() => ({
    data: visibleRecords,
    isLoading: query.isLoading || !query.hasLoaded,
    isLoadingMore: query.isLoadingMore,
    hasMore: query.hasMore,
    isPlaceholderData,
    error: query.error,
    roomErrors: query.roomErrors,
    refresh,
    loadMore,
  }), [isPlaceholderData, loadMore, query.error, query.hasLoaded, query.hasMore, query.isLoading, query.isLoadingMore, query.roomErrors, refresh, visibleRecords]);
}

export interface AbrumEntityMutationOptions {
  roomId?: string;
}

export interface AbrumEntityShareInput {
  sharedWithDid: string;
  recipientStationId?: string | null;
  targetType?: string | null;
  title?: string | null;
}

export interface AbrumCollectionResult<Entity>
  extends AbrumQueryResult<Array<AbrumEntityRecord<Entity>>> {
  /** The read-side error before it is combined into `error`. */
  queryError: string | null;
  /** The latest create/update/remove error before it is combined into `error`. */
  mutationError: string | null;
  /** True while one or more collection mutations are in flight. */
  isMutating: boolean;
  create(
    input: AbrumEntityInput<Entity>,
    options?: AbrumEntityMutationOptions,
  ): Promise<AbrumCreateEntityResult>;
  update(
    record: AbrumEntityRecord<Entity>,
    patch: Partial<AbrumEntityInput<Entity>>,
    options?: AbrumEntityMutationOptions,
  ): Promise<AbrumUpdateEntityResult>;
  remove(
    record: AbrumEntityRecord<Entity>,
    options?: AbrumEntityMutationOptions,
  ): Promise<SyncPushResult>;
}

function entityRecordsWithRoomAuthority<Entity>(
  records: Array<AbrumEntityRecord<Entity>>,
  rooms: RuntimeSnapshot["rooms"],
): Array<AbrumEntityRecord<Entity>> {
  const roomById = new Map(rooms.map((room) => [room.id, room]));
  return records.map((record) => {
    const authorityRoomId = record.$.authorityRoomId ?? record.$.sourceRoomId;
    const room = authorityRoomId ? roomById.get(authorityRoomId) : undefined;
    const direct = room?.purpose === "direct-twin-shares"
      || room?.purpose?.startsWith("direct-twin-shares:") === true;
    const readOnlyMembership = room?.actor_access_level === "read";
    const shareProvenance = direct
      ? "direct"
      : readOnlyMembership
        ? "room-membership"
        : room
          ? "owned"
          : "unknown";
    return {
      ...record,
      $: {
        ...record.$,
        authorityRoomId,
        sourceRoomIds: authorityRoomId ? [authorityRoomId] : record.$.sourceRoomIds,
        shareProvenance,
        // Unknown authority fails closed: the Station remains the final gate,
        // but the UI must not advertise re-sharing before it can name a Room.
        sharedWithMe: direct || readOnlyMembership || !room,
      },
    };
  });
}

function authorityRoomForRecord<Entity>(
  record: AbrumEntityRecord<Entity>,
  explicitRoomId?: string,
): string {
  const recordRoomId = record.$.authorityRoomId ?? record.$.sourceRoomId;
  if (explicitRoomId && recordRoomId && explicitRoomId !== recordRoomId) {
    throw new Error(`${record.$.cid} belongs to Room ${recordRoomId}, not ${explicitRoomId}`);
  }
  const roomId = explicitRoomId ?? recordRoomId;
  if (!roomId) {
    throw new Error(`${record.$.cid} has no authority Room; pass { roomId } explicitly`);
  }
  return roomId;
}

/**
 * Subscribe to one entity type across the active App Lens.
 *
 * Prefer this for large or high-churn apps: unlike `useAbrumDb(app)`, it does not
 * download unrelated entity heads. Matching consumers share one incremental
 * request/cache, so a list, graph and detail panel do not replay the Room
 * independently.
 */
export function useAbrumEntityList<
  const App extends AbrumApp<AbrumEntities>,
  Name extends keyof App["entities"] & string,
>(
  app: App,
  entityName: Name,
  options: AbrumUseManyOptions<AbrumEntityData<App["entities"][Name]>> = {},
): AbrumQueryResult<Array<AbrumEntityRecord<App["entities"][Name]>>> {
  const snapshot = useAbrumSnapshot();
  const lensRoomIds = useAbrumAppLensRoomIds();
  const contentType = entityContentType(app, entityName);
  // Query options are values, not a React lifecycle. Apps normally pass an
  // inline object; using its identity recreated every decoded record on every
  // render and could feed an app's state effects forever. Match the value key
  // used by the bounded query store; real query/authority/data changes still
  // invalidate the projection.
  const optionsKey = JSON.stringify({
    where: options.where ?? null,
    order: options.order ?? null,
    limit: options.limit ?? 100,
  });
  const boundedOptions = useMemo(
    () => ({ ...options, limit: options.limit ?? 100 }),
    [optionsKey],
  );
  const twins = useAbrumBoundedEntityQuery(
    contentType,
    lensRoomIds,
    boundedOptions as AbrumUseManyOptions<Record<string, unknown>>,
    true,
  );
  const data = useMemo(
    () => entityRecordsWithRoomAuthority(
      mergeProjectedEntityRecords(app, entityName, twins.entries, {
        order: boundedOptions.order,
        limit: boundedOptions.limit,
      }),
      snapshot.rooms,
    ),
    [app, boundedOptions, entityName, snapshot.rooms, twins.entries],
  );
  return useMemo(
    () => ({
      data,
      isLoading: twins.isLoading,
      error: twins.error,
      roomErrors: twins.roomErrors,
      refresh: twins.refresh,
    }),
    [data, twins.error, twins.isLoading, twins.refresh, twins.roomErrors],
  );
}

/** Read the current entity head for a known lineage-member CID without
 * downloading every entity of that type. Named app surfaces use this when
 * their input already carries a selected twin CID. */
export function useAbrumEntityByCid<
  const App extends AbrumApp<AbrumEntities>,
  Name extends keyof App["entities"] & string,
>(
  app: App,
  entityName: Name,
  cid: string | null | undefined,
  roomId?: string | null,
): AbrumQueryResult<AbrumEntityRecord<App["entities"][Name]> | null> {
  const snapshot = useAbrumSnapshot();
  const contentType = entityContentType(app, entityName);
  const contentTypes = useMemo(() => [contentType], [contentType]);
  const lineageCids = useMemo(() => [cid || "__abrum_missing_lineage__"], [cid]);
  // Limit two means the expected one-row result completes pagination in one
  // request (`entries.length < limit`) while still remaining fail-closed if a
  // malformed response ever contains duplicate current heads for one lineage.
  const twins = useAbrumHeads(contentTypes, roomId, 2, lineageCids);
  const data = useMemo(() => {
    if (!cid) return null;
    return entityRecordsWithRoomAuthority(
      decodeProjectedEntityRecords(app, entityName, twins.entries),
      snapshot.rooms,
    )[0] ?? null;
  }, [app, cid, entityName, snapshot.rooms, twins.entries]);
  return useMemo(
    () => ({
      data,
      isLoading: twins.isLoading,
      error: twins.error,
      roomErrors: twins.roomErrors,
      refresh: twins.refresh,
    }),
    [data, twins.error, twins.isLoading, twins.refresh, twins.roomErrors],
  );
}

export type AbrumEntityApi<Entity> = {
  useMany(options?: AbrumUseManyOptions<AbrumEntityData<Entity>>): AbrumQueryResult<Array<AbrumEntityRecord<Entity>>>;
  create(input: AbrumEntityInput<Entity>, options?: AbrumEntityMutationOptions): Promise<AbrumCreateEntityResult>;
  update(
    record: AbrumEntityRecord<Entity>,
    patch: Partial<AbrumEntityInput<Entity>>,
    options?: AbrumEntityMutationOptions,
  ): Promise<AbrumUpdateEntityResult>;
  updateMany(
    updates: ReadonlyArray<{
      record: AbrumEntityRecord<Entity>;
      patch: Partial<AbrumEntityInput<Entity>>;
    }>,
    options?: AbrumEntityMutationOptions,
  ): Promise<SyncPushResult>;
  delete(record: AbrumEntityRecord<Entity>, options?: AbrumEntityMutationOptions): Promise<SyncPushResult>;
  deleteMany(
    records: ReadonlyArray<AbrumEntityRecord<Entity>>,
    options?: AbrumEntityMutationOptions,
  ): Promise<SyncPushResult>;
  share(
    record: AbrumEntityRecord<Entity>,
    input: AbrumEntityShareInput,
    options?: AbrumEntityMutationOptions,
  ): Promise<AbrumShareContentResult>;
};

export type AbrumDb<App extends AbrumApp<AbrumEntities>> = {
  [Name in keyof App["entities"] & string]: AbrumEntityApi<App["entities"][Name]>;
};

export type AbrumMutationDb<App extends AbrumApp<AbrumEntities>> = {
  [Name in keyof App["entities"] & string]: Omit<AbrumEntityApi<App["entities"][Name]>, "useMany">;
};

/** Entity writes without subscribing to every entity head in the App lens. */
export function useAbrumMutations<const App extends AbrumApp<AbrumEntities>>(
  app: App,
): AbrumMutationDb<App> {
  const runtime = useAbrum();
  return useMemo(() => {
    const db: Record<string, unknown> = {};
    for (const entityName of Object.keys(app.entities) as Array<keyof App["entities"] & string>) {
      db[entityName] = {
        create(input: AbrumEntityInput<App["entities"][typeof entityName]>, options: AbrumEntityMutationOptions = {}) {
          return runtime.createEntity(app, entityName, input, options.roomId);
        },
        update(
          record: AbrumEntityRecord<App["entities"][typeof entityName]>,
          patch: Partial<AbrumEntityInput<App["entities"][typeof entityName]>>,
          options: AbrumEntityMutationOptions = {},
        ) {
          return runtime.updateEntity(app, entityName, record, patch, options.roomId);
        },
        updateMany(
          updates: ReadonlyArray<{
            record: AbrumEntityRecord<App["entities"][typeof entityName]>;
            patch: Partial<AbrumEntityInput<App["entities"][typeof entityName]>>;
          }>,
          options: AbrumEntityMutationOptions = {},
        ) {
          return runtime.updateEntities(app, entityName, updates, options.roomId);
        },
        delete(record: AbrumEntityRecord<App["entities"][typeof entityName]>, options: AbrumEntityMutationOptions = {}) {
          return runtime.deleteEntity(record.$.cid, authorityRoomForRecord(record, options.roomId));
        },
        deleteMany(
          records: ReadonlyArray<AbrumEntityRecord<App["entities"][typeof entityName]>>,
          options: AbrumEntityMutationOptions = {},
        ) {
          return runtime.deleteEntities(records, options.roomId);
        },
        share(
          record: AbrumEntityRecord<App["entities"][typeof entityName]>,
          input: AbrumEntityShareInput,
          options: AbrumEntityMutationOptions = {},
        ) {
          return runtime.shareContent({
            roomId: authorityRoomForRecord(record, options.roomId),
            lineageCid: record.$.lineageCid ?? record.$.cid,
            targetCid: record.$.cid,
            targetType: input.targetType,
            title: input.title,
            sharedWithDid: input.sharedWithDid,
            recipientStationId: input.recipientStationId,
          });
        },
      };
    }
    return db as AbrumMutationDb<App>;
  }, [app, runtime]);
}

/**
 * The compact CRUD path for ordinary entity screens. One top-level hook owns
 * the bounded live query plus create/update/remove state; advanced apps can
 * keep using `useAbrumEntityList` and `useAbrumMutations` independently.
 */
export function useAbrumCollection<
  const App extends AbrumApp<AbrumEntities>,
  Name extends keyof App["entities"] & string,
>(
  app: App,
  entityName: Name,
  options: AbrumUseManyOptions<AbrumEntityData<App["entities"][Name]>> = {},
): AbrumCollectionResult<App["entities"][Name]> {
  const query = useAbrumEntityList(app, entityName, options);
  const mutations = useAbrumMutations(app);
  const entity = mutations[entityName];
  const pendingCount = useRef(0);
  const [isMutating, setIsMutating] = useState(false);
  const [mutationError, setMutationError] = useState<string | null>(null);

  const runMutation = useCallback(async <Result,>(operation: () => Promise<Result>) => {
    pendingCount.current += 1;
    setIsMutating(true);
    setMutationError(null);
    try {
      return await operation();
    } catch (error) {
      setMutationError(error instanceof Error ? error.message : String(error));
      throw error;
    } finally {
      pendingCount.current = Math.max(0, pendingCount.current - 1);
      if (pendingCount.current === 0) setIsMutating(false);
    }
  }, []);

  const create = useCallback(
    (input: AbrumEntityInput<App["entities"][Name]>, mutationOptions?: AbrumEntityMutationOptions) =>
      runMutation(() => entity.create(input, mutationOptions)),
    [entity, runMutation],
  );
  const update = useCallback(
    (
      record: AbrumEntityRecord<App["entities"][Name]>,
      patch: Partial<AbrumEntityInput<App["entities"][Name]>>,
      mutationOptions?: AbrumEntityMutationOptions,
    ) => runMutation(() => entity.update(record, patch, mutationOptions)),
    [entity, runMutation],
  );
  const remove = useCallback(
    (record: AbrumEntityRecord<App["entities"][Name]>, mutationOptions?: AbrumEntityMutationOptions) =>
      runMutation(() => entity.delete(record, mutationOptions)),
    [entity, runMutation],
  );

  return useMemo(() => ({
    ...query,
    error: mutationError ?? query.error,
    queryError: query.error,
    mutationError,
    isMutating,
    create,
    update,
    remove,
  }), [create, isMutating, mutationError, query, remove, update]);
}

export function useAbrumDb<const App extends AbrumApp<AbrumEntities>>(app: App): AbrumDb<App> {
  const runtime = useAbrum();

  return useMemo(() => {
    const db: Record<string, unknown> = {};
    for (const entityName of Object.keys(app.entities) as Array<keyof App["entities"] & string>) {
      db[entityName] = {
        useMany(options = {}) {
          return useAbrumEntityList(app, entityName, {
            ...options,
            limit: options.limit ?? 100,
          });
        },
        create(
          input: AbrumEntityInput<App["entities"][typeof entityName]>,
          options: AbrumEntityMutationOptions = {},
        ) {
          return runtime.createEntity(app, entityName, input, options.roomId);
        },
        update(
          record: AbrumEntityRecord<App["entities"][typeof entityName]>,
          patch: Partial<AbrumEntityInput<App["entities"][typeof entityName]>>,
          options: AbrumEntityMutationOptions = {},
        ) {
          return runtime.updateEntity(app, entityName, record, patch, options.roomId);
        },
        updateMany(
          updates: ReadonlyArray<{
            record: AbrumEntityRecord<App["entities"][typeof entityName]>;
            patch: Partial<AbrumEntityInput<App["entities"][typeof entityName]>>;
          }>,
          options: AbrumEntityMutationOptions = {},
        ) {
          return runtime.updateEntities(app, entityName, updates, options.roomId);
        },
        delete(
          record: AbrumEntityRecord<App["entities"][typeof entityName]>,
          options: AbrumEntityMutationOptions = {},
        ) {
          return runtime.deleteEntity(
            record.$.cid,
            authorityRoomForRecord(record, options.roomId),
          );
        },
        deleteMany(
          records: ReadonlyArray<AbrumEntityRecord<App["entities"][typeof entityName]>>,
          options: AbrumEntityMutationOptions = {},
        ) {
          return runtime.deleteEntities(records, options.roomId);
        },
        share(
          record: AbrumEntityRecord<App["entities"][typeof entityName]>,
          input: AbrumEntityShareInput,
          options: AbrumEntityMutationOptions = {},
        ) {
          return runtime.shareContent({
            roomId: authorityRoomForRecord(record, options.roomId),
            lineageCid: record.$.lineageCid ?? record.$.cid,
            targetCid: record.$.cid,
            targetType: input.targetType,
            title: input.title,
            sharedWithDid: input.sharedWithDid,
            recipientStationId: input.recipientStationId,
          });
        },
      } as AbrumDb<App>[typeof entityName];
    }
    return db as AbrumDb<App>;
  }, [app, runtime]);
}

export type AbrumActions<App extends AbrumApp<AbrumEntities, AbrumAppFunctions>> = {
  [K in keyof App["functions"]]: (
    input?: App["functions"][K] extends AbrumAppFunctionDef<infer In> ? In : JsonValue,
    roomId?: string,
    sourceAppId?: string | null,
  ) => Promise<
    App["functions"][K] extends AbrumAppFunctionDef<any, infer Out>
      ? AbrumAppRunResult<Out>
      : AbrumAppRunResult
  >;
};

/**
 * Call an app's registered functions from the UI — the counterpart to
 * `useAbrumDb` (which reads entities). Each action routes through
 * `runtime.runAppFunction` → `/api/apps/run` → the station's `run_app_function`,
 * the identical path the assistant uses for the same function. One manifest
 * declaration therefore serves both the user (here) and the agent.
 */
export function useAbrumActions<const App extends AbrumApp<AbrumEntities, AbrumAppFunctions>>(
  app: App,
): AbrumActions<App> {
  const runtime = useAbrum();
  const mountedApp = useAbrumMountedApp();
  return useMemo(() => {
    const actions: Record<string, unknown> = {};
    const sourceAppId = currentAppId(mountedApp.appId);
    for (const key of Object.keys(app.functions) as Array<keyof App["functions"] & string>) {
      const fnName = app.functions[key].name ?? key;
      actions[key] = (input: JsonValue = {}, roomId?: string, overrideSourceAppId?: string | null) =>
        runtime.runAppFunction(app.name, fnName, input ?? {}, roomId, {
          sourceAppId: overrideSourceAppId ?? sourceAppId,
        });
    }
    return actions as AbrumActions<App>;
  }, [app, runtime, mountedApp.appId]);
}

export function useAbrumPull() {
  const runtime = useAbrum();
  const [result, setResult] = useState<PullTwinsResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(
    async (afterSeq = 0) => {
      setIsLoading(true);
      setError(null);
      try {
        const next = await runtime.pull(undefined, afterSeq);
        setResult(next);
        return next;
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        setError(message);
        throw err;
      } finally {
        setIsLoading(false);
      }
    },
    [runtime],
  );

  return useMemo(
    () => ({ result, isLoading, error, refresh }),
    [error, isLoading, refresh, result],
  );
}

export function useAbrumMutation<TArgs extends unknown[], TResult>(
  mutation: (...args: TArgs) => Promise<TResult>,
) {
  const [isPending, setIsPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(
    async (...args: TArgs) => {
      setIsPending(true);
      setError(null);
      try {
        return await mutation(...args);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        setError(message);
        throw err;
      } finally {
        setIsPending(false);
      }
    },
    [mutation],
  );

  return { run, isPending, error };
}

function mergeTwinEntries(current: TwinLogEntry[], next: TwinLogEntry[]): TwinLogEntry[] {
  if (next.length === 0) {
    return current;
  }
  const byCid = new Map(current.map((entry) => [entry.cid, entry]));
  for (const entry of next) {
    byCid.set(entry.cid, entry);
  }
  return [...byCid.values()].sort((a, b) => a.seq - b.seq);
}

function isForbidden(message: string): boolean {
  return message.startsWith("403 ") || message.includes("403 Forbidden");
}

export {
  closeAbrumAdaptiveDialog,
  openAbrumAdaptiveDialog,
  openAbrumSurface,
  openAbrumWindow,
  useAbrumAppSurface,
  useAbrumAdaptiveDialog,
  useAbrumSurface,
  useAbrumSurfaceContext,
  useAbrumWindow,
  useAbrumWindowRoute,
  AbrumAdaptiveDialog,
  AbrumSurfaceModalHost,
  AbrumWindowModalHost,
} from "./window";
export type {
  OpenAbrumAdaptiveDialogOptions,
  OpenAbrumSurfaceOptions,
  OpenAbrumWindowOptions,
  AbrumAdaptiveDialogPlacement,
  AbrumAdaptiveDialogProps,
  AbrumImportedSurfaceOpener,
} from "./window";
export { useAbrumAgentProvider } from "./agent-provider";
export type { AbrumAgentProviderStatus } from "./agent-provider";
