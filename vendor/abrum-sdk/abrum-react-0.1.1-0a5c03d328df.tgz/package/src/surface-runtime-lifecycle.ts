import { readAbrumSurfaceVisibility } from "@abrum/web-runtime";

type SurfaceRuntime = { close(): void; setRealtimeActive(active: boolean): void };
type SurfaceHost = Pick<Window, "parent" | "addEventListener" | "removeEventListener">;

/** Track visibility even while WASM/runtime startup is pending. The host can
 * suspend transport only; signing identity and cached UI state never change. */
export function createSurfaceRuntimeLifecycle(host: SurfaceHost) {
  let runtime: SurfaceRuntime | null = null;
  let visible = true;
  let closed = false;
  const onMessage = (event: MessageEvent) => {
    if (event.source !== host.parent || host.parent === host) return;
    const message = readAbrumSurfaceVisibility(event.data);
    if (!message) return;
    visible = message.visible;
    runtime?.setRealtimeActive(visible);
  };
  host.addEventListener("message", onMessage as EventListener);
  return {
    attach(next: SurfaceRuntime): boolean {
      if (closed) { next.close(); return false; }
      runtime = next;
      next.setRealtimeActive(visible);
      return true;
    },
    close() {
      if (closed) return;
      closed = true;
      host.removeEventListener("message", onMessage as EventListener);
      runtime?.close();
      runtime = null;
    },
  };
}
