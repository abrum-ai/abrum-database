import "./app-shell.css";
import { CaretIcon, CheckIcon, XIcon, RoomIcon, StationIcon, PencilIcon, TrashIcon, CameraIcon, InvitePlusIcon } from "./icons";
import {
  type ReactNode,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { readEmbedSignal } from "@abrum/web-runtime";
import type {
  RoomAccessLevel,
  RoomDescriptor,
  RoomMemberGrant,
  StationIdentity,
  AbrumEmbedSignal,
  AbrumUserProfile,
} from "@abrum/web-runtime";
import {
  useAbrumMutation,
  useAbrumRoomMembers,
  useAbrumSnapshot,
  useAbrumRooms,
  useAbrumStation,
  useAbrumDirectory,
  useAbrumUser,
} from "./core";

/**
 * The host embed context. Defined once in the @abrum/web-runtime contract
 * (`AbrumEmbedSignal`) and consumed here; a host signals it by injecting
 * `window.abrumContainer` (WebView hosts) or via the app URL (iframe hosts).
 */
export type AbrumContainer = AbrumEmbedSignal;

/** Read the embed signal (`window.abrumContainer` or the app URL). */
export function readAbrumContainer(): AbrumContainer | null {
  return readEmbedSignal();
}

/** The host embed context, or null when running standalone (e.g. a browser). */
export function useAbrumContainer(): AbrumContainer | null {
  // Fixed for the app's lifetime (set before scripts run / in the URL).
  return useMemo(() => readEmbedSignal(), []);
}

export type AbrumChromeMode = "auto" | "show" | "hide";

export interface AbrumAppShellProps {
  appName: string;
  appIcon?: ReactNode;
  /**
   * Navbar visibility. `"auto"` (default) shows the navbar standalone and hides
   * it when a host shell requests it (`hideShellChrome`). `"show"`/`"hide"`
   * force it regardless of host.
   */
  chrome?: AbrumChromeMode;
  /** @deprecated use `chrome`. `false` → `"hide"`, `true` → `"show"`. */
  navbar?: boolean;
  children: ReactNode;
}

export function AbrumAppShell({ appName, appIcon, chrome = "auto", navbar, children }: AbrumAppShellProps) {
  const container = useAbrumContainer();
  // Back-compat: an explicit `navbar` boolean overrides `chrome`.
  const mode: AbrumChromeMode = navbar === false ? "hide" : navbar === true ? "show" : chrome;
  const showNavbar = mode === "show" ? true : mode === "hide" ? false : !container?.hideShellChrome;
  return (
    <div className="abrum-shell" data-abrum-embedded={container ? "true" : undefined}>
      {showNavbar ? <AbrumNavBar appName={appName} appIcon={appIcon} /> : null}
      <div className="abrum-shell-content">{children}</div>
    </div>
  );
}

export interface AbrumNavBarProps {
  appName: string;
  appIcon?: ReactNode;
}

export function AbrumNavBar({ appName, appIcon }: AbrumNavBarProps) {
  const [membersOpen, setMembersOpen] = useState(false);
  const { directory } = useAbrumDirectory();

  return (
    <>
      <header className="abrum-navbar" role="banner">
        <div className="abrum-navbar-left">
          <div className="abrum-app-name">
            {appIcon ? <span className="abrum-app-icon">{appIcon}</span> : null}
            <span>{appName}</span>
          </div>
        </div>
        <div className="abrum-navbar-center">
          <RoomSwitcher />
        </div>
        <div className="abrum-navbar-right">
          <MembersAvatarStack
            directory={directory}
            onOpen={() => setMembersOpen(true)}
          />
          <UserMenu directory={directory} />
        </div>
      </header>
      {membersOpen ? (
        <MembersDialog
          directory={directory}
          onClose={() => setMembersOpen(false)}
        />
      ) : null}
    </>
  );
}

function RoomSwitcher() {
  const snapshot = useAbrumSnapshot();
  const rooms = useAbrumRooms();
  const [open, setOpen] = useState(false);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useDismissOnOutside(ref, open, () => {
    setOpen(false);
    setRenamingId(null);
    setCreating(false);
  });

  const current = rooms.selectedRoom;
  const label = current?.name ?? (snapshot.selectedRoomId ? short(snapshot.selectedRoomId) : "No room");

  if (!snapshot.user) {
    return (
      <div className="abrum-room-switcher">
        <button type="button" className="abrum-pill abrum-pill-muted" disabled>
          No room
        </button>
      </div>
    );
  }

  return (
    <div className="abrum-room-switcher" ref={ref}>
      <button
        type="button"
        className="abrum-pill"
        onClick={() => setOpen((value) => !value)}
        aria-haspopup="listbox"
        aria-expanded={open}
        title={current ? `${current.name} (${current.purpose})` : "Choose a room"}
      >
        <RoomIcon />
        <span className="abrum-pill-label">{label}</span>
        <CaretIcon />
      </button>
      {open ? (
        <div className="abrum-menu" role="listbox">
          <div className="abrum-menu-section">
            <div className="abrum-menu-heading">Rooms</div>
            {rooms.rooms.length === 0 ? (
              <div className="abrum-menu-empty">No accessible rooms</div>
            ) : null}
            {rooms.rooms.map((room) =>
              renamingId === room.id ? (
                <RenameRoomRow
                  key={room.id}
                  room={room}
                  onCancel={() => setRenamingId(null)}
                  onDone={() => setRenamingId(null)}
                />
              ) : (
                <RoomMenuItem
                  key={room.id}
                  room={room}
                  selected={room.id === snapshot.selectedRoomId}
                  hosted={room.id === snapshot.hostedRoomId}
                  onSelect={() => {
                    rooms.select(room.id);
                    setOpen(false);
                  }}
                  onRename={() => setRenamingId(room.id)}
                  onDelete={async () => {
                    if (typeof window !== "undefined" && !window.confirm(`Delete "${room.name}"? This room will be archived.`)) {
                      return;
                    }
                    await rooms.archive(room.id).catch(() => undefined);
                  }}
                />
              ),
            )}
          </div>
          <div className="abrum-menu-divider" />
          <div className="abrum-menu-section">
            {creating ? (
              <CreateRoomRow
                onCancel={() => setCreating(false)}
                onDone={() => {
                  setCreating(false);
                  setOpen(false);
                }}
              />
            ) : (
              <button
                type="button"
                className="abrum-menu-action"
                onClick={() => setCreating(true)}
              >
                <InvitePlusIcon /> New room
              </button>
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function CreateRoomRow({ onCancel, onDone }: { onCancel: () => void; onDone: () => void }) {
  const rooms = useAbrumRooms();
  const [name, setName] = useState("");
  const create = useAbrumMutation(async () => {
    const trimmed = name.trim();
    if (!trimmed) return;
    await rooms.create(trimmed);
    onDone();
  });
  return (
    <form
      className="abrum-inline-form"
      onSubmit={(event) => {
        event.preventDefault();
        create.run().catch(() => undefined);
      }}
    >
      <input
        autoFocus
        value={name}
        onChange={(event) => setName(event.target.value)}
        placeholder="Room name"
      />
      <button type="submit" className="abrum-button abrum-button-primary" disabled={!name.trim() || create.isPending}>
        {create.isPending ? "Creating…" : "Create"}
      </button>
      <button type="button" className="abrum-button" onClick={onCancel}>
        Cancel
      </button>
      {create.error ? <p className="abrum-error">{create.error}</p> : null}
    </form>
  );
}

function RenameRoomRow({
  room,
  onCancel,
  onDone,
}: {
  room: RoomDescriptor;
  onCancel: () => void;
  onDone: () => void;
}) {
  const rooms = useAbrumRooms();
  const [name, setName] = useState(room.name);
  const rename = useAbrumMutation(async () => {
    const trimmed = name.trim();
    if (!trimmed || trimmed === room.name) {
      onDone();
      return;
    }
    await rooms.rename(room.id, trimmed);
    onDone();
  });
  return (
    <form
      className="abrum-inline-form"
      onSubmit={(event) => {
        event.preventDefault();
        rename.run().catch(() => undefined);
      }}
    >
      <input
        autoFocus
        value={name}
        onChange={(event) => setName(event.target.value)}
        onFocus={(event) => event.currentTarget.select()}
      />
      <button type="submit" className="abrum-button abrum-button-primary" disabled={!name.trim() || rename.isPending}>
        {rename.isPending ? "Saving…" : "Save"}
      </button>
      <button type="button" className="abrum-button" onClick={onCancel}>
        Cancel
      </button>
      {rename.error ? <p className="abrum-error">{rename.error}</p> : null}
    </form>
  );
}

function RoomMenuItem({
  room,
  selected,
  hosted,
  onSelect,
  onRename,
  onDelete,
}: {
  room: RoomDescriptor;
  selected: boolean;
  hosted: boolean;
  onSelect: () => void;
  onRename: () => void;
  onDelete: () => void;
}) {
  return (
    <div
      className={`abrum-menu-item abrum-menu-item-row${selected ? " abrum-menu-item-selected" : ""}`}
      role="option"
      aria-selected={selected}
    >
      <button
        type="button"
        className="abrum-menu-item-button"
        onClick={onSelect}
      >
        <span className="abrum-menu-item-main">
          <strong>{room.name}</strong>
          <small>{room.purpose}{hosted ? " · hosted" : ""}</small>
        </span>
        {selected ? <CheckIcon /> : null}
      </button>
      <span className="abrum-menu-item-actions">
        <button
          type="button"
          className="abrum-icon-button"
          onClick={(event) => {
            event.stopPropagation();
            onRename();
          }}
          title="Rename room"
          aria-label={`Rename ${room.name}`}
        >
          <PencilIcon />
        </button>
        {hosted ? null : (
          <button
            type="button"
            className="abrum-icon-button abrum-icon-button-danger"
            onClick={(event) => {
              event.stopPropagation();
              onDelete();
            }}
            title="Delete room"
            aria-label={`Delete ${room.name}`}
          >
            <TrashIcon />
          </button>
        )}
      </span>
    </div>
  );
}

function MembersAvatarStack({
  directory,
  onOpen,
}: {
  directory: Record<string, AbrumUserProfile>;
  onOpen: () => void;
}) {
  const snapshot = useAbrumSnapshot();
  const station = useAbrumStation();
  const members = useAbrumRoomMembers(snapshot.selectedRoomId);
  const stationDid = station.station?.principal_did;
  const others = useMemo(
    () =>
      members.members.filter(
        (member) =>
          member.principal_did !== snapshot.user?.did &&
          member.principal_did !== stationDid,
      ),
    [members.members, snapshot.user?.did, stationDid],
  );
  const visible = others.slice(0, 4);
  const overflow = others.length - visible.length;
  const canShare = Boolean(snapshot.selectedRoomId && snapshot.user);

  if (!canShare) {
    return null;
  }

  return (
    <button
      type="button"
      className="abrum-members-stack"
      onClick={onOpen}
      title={`${others.length} other ${others.length === 1 ? "member" : "members"} in this room — click to manage`}
      aria-label="Manage members"
    >
      {visible.length === 0 ? (
        <span className="abrum-members-empty">
          <InvitePlusIcon /> Invite
        </span>
      ) : (
        <span className="abrum-members-avatars">
          {visible.map((member) => (
            <AvatarCircle
              key={member.cid}
              profile={directory[member.principal_did] ?? null}
              fallback={member.principal_did}
              size="sm"
            />
          ))}
          {overflow > 0 ? <span className="abrum-avatar abrum-avatar-overflow abrum-avatar-sm">+{overflow}</span> : null}
        </span>
      )}
    </button>
  );
}

function UserMenu({ directory }: { directory: Record<string, AbrumUserProfile> }) {
  const snapshot = useAbrumSnapshot();
  const station = useAbrumStation();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useDismissOnOutside(ref, open, () => setOpen(false));

  if (!snapshot.user) {
    return <SignInControl />;
  }

  const did = snapshot.user.did;
  const profile = directory[did];
  const displayName = profile?.displayName ?? snapshot.displayName ?? "anonymous";
  return (
    <div className="abrum-user-menu" ref={ref}>
      <button
        type="button"
        className="abrum-user-trigger"
        onClick={() => setOpen((value) => !value)}
        aria-haspopup="menu"
        aria-expanded={open}
      >
        <AvatarCircle profile={profile ?? null} fallback={displayName} size="md" />
        <span className="abrum-user-trigger-label">
          <strong>{displayName}</strong>
        </span>
        <CaretIcon />
      </button>
      {open ? (
        <div className="abrum-menu abrum-user-menu-panel" role="menu">
          <div className="abrum-menu-section">
            <ProfileEditor profile={profile ?? null} fallbackName={displayName} did={did} />
          </div>
          <div className="abrum-menu-divider" />
          <div className="abrum-menu-section">
            <div className="abrum-menu-heading">Station</div>
            <StationCard station={station.station} stationUrl={station.stationUrl} hosted />
            {!snapshot.hostedRoomId ? <PairStationAction onDone={() => setOpen(false)} /> : null}
          </div>
          {snapshot.error ? (
            <>
              <div className="abrum-menu-divider" />
              <div className="abrum-menu-section">
                <p className="abrum-error">{snapshot.error}</p>
              </div>
            </>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

function StationCard({
  station,
  stationUrl,
  hosted,
}: {
  station: StationIdentity | null;
  stationUrl: string;
  hosted: boolean;
}) {
  if (!station) {
    return <div className="abrum-station-card abrum-station-card-empty">Not connected</div>;
  }
  return (
    <div className="abrum-station-card">
      <div className="abrum-station-card-row">
        <StationIcon />
        <div>
          <strong>{station.name}</strong>
          <small>{stationUrl}</small>
        </div>
        {hosted ? <span className="abrum-tag">hosted</span> : null}
      </div>
    </div>
  );
}

function PairStationAction({ onDone }: { onDone: () => void }) {
  const station = useAbrumStation();
  const user = useAbrumUser();
  const pair = useAbrumMutation(async () => {
    await station.pair(user.displayName ?? undefined);
    onDone();
  });
  return (
    <button
      type="button"
      className="abrum-button abrum-button-primary"
      onClick={() => pair.run().catch(() => undefined)}
      disabled={pair.isPending}
    >
      {pair.isPending ? "Pairing…" : "Pair this station"}
    </button>
  );
}

function SignInControl() {
  return (
    <span
      className="abrum-tag"
      title="Open this app from an enrolled ABRUM device. Identity enrollment is approved by another active device."
    >
      Device enrollment required
    </span>
  );
}

function MembersDialog({
  directory,
  onClose,
}: {
  directory: Record<string, AbrumUserProfile>;
  onClose: () => void;
}) {
  const snapshot = useAbrumSnapshot();
  const rooms = useAbrumRooms();
  const station = useAbrumStation();
  const members = useAbrumRoomMembers(snapshot.selectedRoomId);
  const stationDid = station.station?.principal_did;
  const userMembers = useMemo(
    () => members.members.filter((member) => member.principal_did !== stationDid),
    [members.members, stationDid],
  );
  const [memberDid, setMemberDid] = useState("");
  const [memberLevel, setMemberLevel] = useState<RoomAccessLevel>("write");
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") {
        onClose();
      }
    }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);

  const addMember = useAbrumMutation(async () => {
    const did = memberDid.trim();
    if (!did) return;
    await members.grant(did, memberLevel);
    setMemberDid("");
  });

  const removeMember = useAbrumMutation(async (grantCid: string) => {
    await members.revoke(grantCid);
  });

  const ownDid = snapshot.user?.did ?? "";
  const roomName = rooms.selectedRoom?.name ?? "this room";
  const canManage = members.canManage !== false;

  return (
    <div
      className="abrum-modal-backdrop"
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
      role="presentation"
    >
      <div className="abrum-modal" role="dialog" aria-modal="true" aria-label="Manage members" ref={dialogRef}>
        <div className="abrum-modal-header">
          <div>
            <strong>Members of {roomName}</strong>
            <small>
              {userMembers.length} {userMembers.length === 1 ? "person" : "people"}
            </small>
          </div>
          <button type="button" className="abrum-icon-button" onClick={onClose} aria-label="Close">
            <XIcon />
          </button>
        </div>

        {ownDid ? (
          <div className="abrum-modal-section">
            <div className="abrum-menu-heading">Your share DID</div>
            <p className="abrum-help">Send this to someone so they can invite you to their rooms.</p>
            <CopyableValue label="Share DID" value={ownDid} mono hideLabel />
          </div>
        ) : null}

        {canManage ? (
          <div className="abrum-modal-section">
            <div className="abrum-menu-heading">Invite to {roomName}</div>
            <form
              className="abrum-invite-form"
              onSubmit={(event) => {
                event.preventDefault();
                addMember.run().catch(() => undefined);
              }}
            >
              <input
                value={memberDid}
                onChange={(event) => setMemberDid(event.target.value)}
                placeholder="Paste a did:key:ed25519:… DID"
                disabled={addMember.isPending}
              />
              <select
                value={memberLevel}
                onChange={(event) => setMemberLevel(event.target.value as RoomAccessLevel)}
                disabled={addMember.isPending}
              >
                <option value="read">Can read</option>
                <option value="write">Can edit</option>
                <option value="admin">Admin</option>
              </select>
              <button
                type="submit"
                className="abrum-button abrum-button-primary"
                disabled={!memberDid.trim() || addMember.isPending}
              >
                {addMember.isPending ? "Inviting…" : "Invite"}
              </button>
            </form>
          </div>
        ) : (
          <div className="abrum-modal-section">
            <p className="abrum-help">Only admins can manage members for this room.</p>
          </div>
        )}

        <div className="abrum-modal-section">
          <div className="abrum-menu-heading">Members</div>
          {members.isLoading && userMembers.length === 0 ? (
            <p className="abrum-help">Loading…</p>
          ) : userMembers.length === 0 ? (
            <p className="abrum-help">No members visible.</p>
          ) : (
            <ul className="abrum-member-list">
              {userMembers.map((member) => (
                <MemberRow
                  key={member.cid}
                  member={member}
                  profile={directory[member.principal_did] ?? null}
                  isSelf={member.principal_did === ownDid}
                  canManage={canManage}
                  onRemove={() => removeMember.run(member.cid).catch(() => undefined)}
                  removing={removeMember.isPending}
                />
              ))}
            </ul>
          )}
        </div>

        {[members.error, addMember.error, removeMember.error].filter(Boolean).map((error) => (
          <p className="abrum-error abrum-modal-section" key={error}>
            {error}
          </p>
        ))}
      </div>
    </div>
  );
}

function MemberRow({
  member,
  profile,
  isSelf,
  canManage,
  onRemove,
  removing,
}: {
  member: RoomMemberGrant;
  profile: AbrumUserProfile | null;
  isSelf: boolean;
  canManage: boolean;
  onRemove: () => void;
  removing: boolean;
}) {
  const protectedGrant = member.relation_type === "owns" || isSelf;
  const name = profile?.displayName ?? short(member.principal_did);
  return (
    <li className="abrum-member-row">
      <AvatarCircle profile={profile} fallback={name} size="md" />
      <div className="abrum-member-info">
        <strong>{name}{isSelf ? " (you)" : ""}</strong>
        <small title={member.principal_did}>{short(member.principal_did)}</small>
      </div>
      <span className={`abrum-role abrum-role-${member.relation_type}`}>{relationLabel(member.relation_type)}</span>
      <button
        type="button"
        className="abrum-icon-button abrum-icon-button-danger"
        onClick={onRemove}
        disabled={!canManage || protectedGrant || removing}
        aria-label={`Remove ${name}`}
        title={protectedGrant ? "This member can't be removed" : `Remove ${name}`}
      >
        <XIcon />
      </button>
    </li>
  );
}

function AvatarCircle({
  profile,
  fallback,
  size,
}: {
  profile: AbrumUserProfile | null;
  fallback: string;
  size: "sm" | "md" | "lg";
}) {
  const user = useAbrumUser();
  const initial = (profile?.displayName ?? fallback).trim().slice(0, 1).toUpperCase() || "?";
  const tint = colorForKey(profile?.did ?? fallback);
  const avatarUrl = user.avatarUrl(profile?.avatarFileLineageCid ?? null);
  if (avatarUrl) {
    return (
      <span
        className={`abrum-avatar abrum-avatar-${size} abrum-avatar-image`}
        title={profile?.displayName ?? fallback}
      >
        <img src={avatarUrl} alt="" />
      </span>
    );
  }
  return (
    <span
      className={`abrum-avatar abrum-avatar-${size}`}
      style={{ background: tint.bg, color: tint.fg }}
      title={profile?.displayName ?? fallback}
    >
      {initial}
    </span>
  );
}

function ProfileEditor({
  profile,
  fallbackName,
  did,
}: {
  profile: AbrumUserProfile | null;
  fallbackName: string;
  did: string;
}) {
  const user = useAbrumUser();
  const snapshot = useAbrumSnapshot();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(profile?.displayName ?? fallbackName);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setName(profile?.displayName ?? fallbackName);
  }, [profile?.displayName, fallbackName]);

  const saveName = useAbrumMutation(async () => {
    const trimmed = name.trim();
    if (!trimmed || trimmed === (profile?.displayName ?? fallbackName)) {
      setEditing(false);
      return;
    }
    await user.updateProfile({ displayName: trimmed });
    setEditing(false);
  });

  const uploadAvatar = useAbrumMutation(async (file: File) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      throw new Error("avatar must be an image");
    }
    await user.uploadAvatar(file);
  });

  const canEdit = Boolean(snapshot.selectedRoomId);

  return (
    <div className="abrum-profile-editor">
      <div className="abrum-user-card">
        <label className={`abrum-avatar-upload${canEdit ? "" : " abrum-avatar-upload-disabled"}`}>
          <AvatarCircle profile={profile} fallback={fallbackName} size="lg" />
          <span className="abrum-avatar-upload-overlay" aria-hidden="true">
            <CameraIcon />
          </span>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            disabled={!canEdit || uploadAvatar.isPending}
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) uploadAvatar.run(file).catch(() => undefined);
              if (event.target) event.target.value = "";
            }}
          />
        </label>
        <div className="abrum-user-card-text">
          {editing ? (
            <form
              className="abrum-inline-form"
              onSubmit={(event) => {
                event.preventDefault();
                saveName.run().catch(() => undefined);
              }}
            >
              <input
                autoFocus
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="Your name"
              />
              <button
                type="submit"
                className="abrum-button abrum-button-primary"
                disabled={saveName.isPending || !name.trim()}
              >
                {saveName.isPending ? "Saving…" : "Save"}
              </button>
              <button
                type="button"
                className="abrum-button"
                onClick={() => {
                  setEditing(false);
                  setName(profile?.displayName ?? fallbackName);
                }}
              >
                Cancel
              </button>
            </form>
          ) : (
            <div className="abrum-profile-name-row">
              <strong>{profile?.displayName ?? fallbackName}</strong>
              <button
                type="button"
                className="abrum-icon-button"
                onClick={() => setEditing(true)}
                disabled={!canEdit}
                title={canEdit ? "Edit display name" : "Pair a station to edit your profile"}
                aria-label="Edit display name"
              >
                <PencilIcon />
              </button>
            </div>
          )}
          <CopyUserIdButton did={did} />
        </div>
      </div>
      {uploadAvatar.error ? <p className="abrum-error">{uploadAvatar.error}</p> : null}
      {saveName.error ? <p className="abrum-error">{saveName.error}</p> : null}
      {!canEdit ? (
        <p className="abrum-help">Pair a station to edit your profile or upload an avatar.</p>
      ) : null}
    </div>
  );
}

function CopyUserIdButton({ did }: { did: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      className="abrum-button"
      onClick={async () => {
        await copyText(did).catch(() => undefined);
        setCopied(true);
        window.setTimeout(() => setCopied(false), 1600);
      }}
    >
      {copied ? "Copied" : "Copy user ID"}
    </button>
  );
}

function CopyableValue({
  label,
  value,
  mono,
  hideLabel,
}: {
  label: string;
  value: string;
  mono?: boolean;
  hideLabel?: boolean;
}) {
  const [status, setStatus] = useState<"idle" | "copied">("idle");
  const inputRef = useRef<HTMLInputElement>(null);
  const onCopy = useCallback(async () => {
    try {
      await copyText(value);
    } catch {
      inputRef.current?.focus();
      inputRef.current?.select();
    }
    setStatus("copied");
    window.setTimeout(() => setStatus("idle"), 1600);
  }, [value]);
  return (
    <div className="abrum-copy-field">
      <input
        ref={inputRef}
        readOnly
        value={value}
        aria-label={label}
        className={mono ? "abrum-mono" : ""}
        onFocus={(event) => event.currentTarget.select()}
      />
      <button type="button" className="abrum-button" onClick={onCopy}>
        {status === "copied" ? "Copied" : "Copy"}
      </button>
      {hideLabel ? null : <span className="abrum-copy-field-label">{label}</span>}
    </div>
  );
}

function useDismissOnOutside(
  ref: React.RefObject<HTMLElement | null>,
  active: boolean,
  onDismiss: () => void,
) {
  useEffect(() => {
    if (!active) return;
    function onClick(event: MouseEvent) {
      if (!ref.current) return;
      if (event.target instanceof Node && !ref.current.contains(event.target)) {
        onDismiss();
      }
    }
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") onDismiss();
    }
    document.addEventListener("mousedown", onClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onClick);
      document.removeEventListener("keydown", onKey);
    };
  }, [active, onDismiss, ref]);
}

function short(value: string): string {
  return value.length <= 16 ? value : `${value.slice(0, 8)}…${value.slice(-4)}`;
}

function relationLabel(relation: RoomMemberGrant["relation_type"]): string {
  switch (relation) {
    case "owns":
      return "Owner";
    case "admins":
      return "Admin";
    case "writes":
      return "Editor";
    case "reads":
      return "Reader";
    case "controls":
      return "Controller";
  }
}

async function copyText(value: string): Promise<void> {
  if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(value);
    return;
  }
  if (typeof document === "undefined") return;
  const input = document.createElement("textarea");
  input.value = value;
  input.setAttribute("readonly", "true");
  input.style.position = "fixed";
  input.style.left = "-9999px";
  document.body.append(input);
  input.select();
  document.execCommand("copy");
  input.remove();
}

const AVATAR_PALETTE = [
  { bg: "#312e81", fg: "#e0e7ff" },
  { bg: "#0f766e", fg: "#ccfbf1" },
  { bg: "#9d174d", fg: "#fce7f3" },
  { bg: "#1d4ed8", fg: "#dbeafe" },
  { bg: "#92400e", fg: "#fef3c7" },
  { bg: "#065f46", fg: "#d1fae5" },
  { bg: "#7c2d12", fg: "#ffedd5" },
  { bg: "#581c87", fg: "#f3e8ff" },
];

function colorForKey(key: string): { bg: string; fg: string } {
  let hash = 0;
  for (let i = 0; i < key.length; i += 1) {
    hash = (hash * 31 + key.charCodeAt(i)) | 0;
  }
  const index = Math.abs(hash) % AVATAR_PALETTE.length;
  return AVATAR_PALETTE[index];
}
