import { ABRUM_SELECT_TWIN_RESULT_MESSAGE_TYPE, type AbrumSelectTwinMessage, type AbrumSelectTwinResult } from "@abrum/web-runtime";

export type TwinSelectionContext = { signal: AbortSignal; requestId: string };
export type ObservedTwinSelection = { cid: string; lineageCid?: string; roomId: string; title?: string };

/** Delivery is not completion. Only a committed app selection can acknowledge navigation. */
export function createTwinSelectionDispatcher(
  select: (cid: string, roomId: string, context: TwinSelectionContext) => void,
  report: (result: AbrumSelectTwinResult) => void,
) {
  const seen = new Map<string, { cid: string; roomId: string; result?: AbrumSelectTwinResult }>();
  let active: { request: AbrumSelectTwinMessage; controller: AbortController } | null = null;
  function finish(status: AbrumSelectTwinResult["status"], observed?: ObservedTwinSelection) {
    if (!active) return;
    const { request, controller } = active;
    active = null;
    const result: AbrumSelectTwinResult = { type: ABRUM_SELECT_TWIN_RESULT_MESSAGE_TYPE,
      requestId: request.requestId!, cid: request.cid, roomId: request.roomId!, status,
      ...(observed ? { selectedCid: observed.cid, title: observed.title ?? "" } : {}) };
    seen.get(request.requestId!)!.result = result;
    controller.abort();
    report(result);
  }
  return {
    request(request: AbrumSelectTwinMessage) {
      if (!request.requestId || !request.roomId) return;
      const previous = seen.get(request.requestId);
      if (previous) {
        if (previous.cid === request.cid && previous.roomId === request.roomId && previous.result) report(previous.result);
        return;
      }
      finish("cancelled");
      if (seen.size >= 1024) {
        report({ type: ABRUM_SELECT_TWIN_RESULT_MESSAGE_TYPE, requestId: request.requestId,
          cid: request.cid, roomId: request.roomId, status: "unconfirmed" });
        return;
      }
      seen.set(request.requestId, { cid: request.cid, roomId: request.roomId });
      active = { request, controller: new AbortController() };
      try { select(request.cid, request.roomId, { signal: active.controller.signal, requestId: request.requestId }); }
      catch { finish("failed"); }
    },
    observe(selection: ObservedTwinSelection | null) {
      if (active && selection && selection.roomId === active.request.roomId
        && (selection.cid === active.request.cid || selection.lineageCid === active.request.cid)) finish("completed", selection);
    },
    cancel(requestId?: string) { if (!requestId || active?.request.requestId === requestId) finish("cancelled"); },
    expire(requestId: string) { if (active?.request.requestId === requestId) finish("unconfirmed"); },
    fail(requestId: string) { if (active?.request.requestId === requestId) finish("failed"); },
  };
}
