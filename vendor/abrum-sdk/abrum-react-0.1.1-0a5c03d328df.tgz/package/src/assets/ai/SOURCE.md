# AI provider icons

The SVGs in this folder are copied from
[`@lobehub/icons-static-svg` 1.93.0](https://github.com/lobehub/lobe-icons)
and are used by the shared abrum runtime/model picker.

Lobe Icons is Copyright 2023 LobeHub and licensed under the MIT License.
The original project license is available at
<https://github.com/lobehub/lobe-icons/blob/master/LICENSE>.

`abrum.svg` is the ABRUM-owned monochrome Gateway mark and is not copied from
Lobe Icons.
