import * as React from "react";
import type { LucideIcon, LucideProps } from "lucide-react";

// ABRUM Icon Review 01: one geometry source for shell, chat and bundled apps.
// API-compatible with existing Lucide call sites; no theme-specific fills.
function icon(name: string, drawing: React.ReactNode, rotation = 0): LucideIcon {
  const Component = React.forwardRef<SVGSVGElement, LucideProps>(function AbrumIcon(
    { size = 24, color = "currentColor", strokeWidth = 1.65, absoluteStrokeWidth,
      className, children, ...props }, ref,
  ) {
    const labelled = props["aria-label"] || props["aria-labelledby"] || props.role === "img";
    return (
      <svg ref={ref} width={size} height={size} viewBox="0 0 24 24" fill="none"
        stroke={color} strokeWidth={absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth}
        strokeLinecap="round" strokeLinejoin="round" aria-hidden={labelled ? undefined : true}
        focusable="false" data-abrum-icon={name}
        className={["abrum-icon", className].filter(Boolean).join(" ")} {...props}>
        {rotation ? <g transform={`rotate(${rotation} 12 12)`}>{drawing}</g> : drawing}
        {children}
      </svg>
    );
  });
  Component.displayName = `Abrum${name}`;
  return Component;
}

export const Copy = icon("Copy", <><path d="M8 7V4h9l3 3v10h-3M4 9h9l3 3v9H4Z" /><path d="M13 9v3h3" /></>);
export const Sidebar = icon("Sidebar", <path d="M9 4H4v16h16V7l-3-3h-4M9 4v16M13 10l3 2-3 2" />);
export const SidebarRight = icon("SidebarRight", <g transform="translate(24 0) scale(-1 1)"><path d="M9 4H4v16h16V7l-3-3h-4M9 4v16M13 10l3 2-3 2" /></g>);
export const ArrowUp = icon("ArrowUp", <path d="M12 19V5M6 11l6-6 6 6" />);
export const Send = icon("Send", <><path d="M3 5l18 7-18 7 4-7Z" /><path d="M7 12h14" /></>);
export const Stop = icon("Stop", <rect x="5" y="5" width="14" height="14" fill="currentColor" stroke="none" />);
export const Paperclip = icon("Paperclip", <path d="m16 6-8.41 8.41a2 2 0 0 0 2.83 2.83l8.3-8.3a4 4 0 0 0-5.66-5.66l-8.3 8.3a6 6 0 1 0 8.48 8.48L21 12" />);
export const Mic = icon("Mic", <path d="M9 3h4l2 2v7l-2 2H9V3ZM5 10v3l4 5h6l4-5v-3M12 18v3M8 21h8" />);
export const Ellipsis = icon("Ellipsis", <path d="M3 10l2 2-2 2-2-2ZM12 10l2 2-2 2-2-2ZM21 10l2 2-2 2-2-2Z" fill="currentColor" stroke="none" />);
export const Brain = icon("Brain", <>
  <path d="M12 18V5" />
  <path d="M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4" />
  <path d="M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5" />
  <path d="M17.997 5.125a4 4 0 0 1 2.526 5.77" />
  <path d="M18 18a4 4 0 0 0 2-7.464" />
  <path d="M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517" />
  <path d="M6 18a4 4 0 0 1-2-7.464" />
  <path d="M6.003 5.125a4 4 0 0 0-2.526 5.77" />
</>);
// End connectors at node edges: transparent on every surface, unlike the review's --surface mask.
export const BrainCircuit = icon("BrainCircuit", <><path d="M9 9l3 3 3-3M12 12v5" /><path d="M3 3h6v6H3ZM15 3h6v6h-6ZM9 17h6v5H9Z" /></>);
export const Trash = icon("Trash", <path d="M4 6h16M9 6V3h6v3M6 9v12h9l3-3V9M10 10v7M14 10v7" />);
export const Trash2 = Trash;
const chevron = <path d="M9 5l7 7-7 7" />;
export const ChevronRight = icon("ChevronRight", chevron);
export const ChevronDown = icon("ChevronDown", chevron, 90);
export const ChevronLeft = icon("ChevronLeft", chevron, 180);
export const ChevronUp = icon("ChevronUp", chevron, 270);
