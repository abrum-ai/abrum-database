// Special projections (Agent process summaries, Mail envelopes, and similar
// host-owned views) can reuse the framework cursor/coalescing contract without
// reaching through an undeclared @abrum/runtime dependency.
export { HeadsQueryStore, headsRealtimeRefreshMode } from "@abrum/runtime";
