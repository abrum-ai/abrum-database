# @abrum/react

React framework and host-integration hooks for applications that run both on
the open web and inside ABRUM/abrum.

## Installation

```bash
npm install @abrum/react
```

The package ships typed ESM source. Next.js applications should let Next
transpile the framework and its shared host contract:

```ts
// next.config.ts
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  transpilePackages: ["@abrum/react", "@abrum/web-runtime"],
};

export default nextConfig;
```

## Native host navigation

An application declares destinations; the capable ABRUM host renders them in
its own top bar and sends selected IDs back to the application. In an ordinary
browser the hook returns `false`, so the application keeps its local navigation.

```tsx
"use client";

import { useAbrumGlobalNavigation } from "@abrum/react/navigation";
import { usePathname, useRouter } from "next/navigation";

const items = [
  { id: "home", label: "Home", icon: "home" },
  { id: "map", label: "Map", icon: "map" },
  { id: "chat", label: "Chat", icon: "chat" },
  { id: "inbox", label: "Inbox", icon: "inbox" },
  { id: "profile", label: "Profile", icon: "profile" },
];

export function Navigation() {
  const pathname = usePathname();
  const router = useRouter();
  const hostOwnsNavigation = useAbrumGlobalNavigation({
    items,
    activeItemId: pathname === "/app/map" ? "map" : "home",
    onSelect: (id) => router.push(id === "map" ? "/app/map" : "/app"),
  });

  return hostOwnsNavigation ? null : <LocalNavigation />;
}
```

The bridge is deliberately narrow: applications publish bounded labels, stable
IDs and host-known icon tokens. They receive only a selected ID. No Electron,
filesystem or general IPC authority is exposed.

## Framework exports

- `@abrum/react` — runtime hooks, app shell, mounting and host integration
- `@abrum/react/navigation` — lightweight native host-navigation hook
- `@abrum/react/core` — core React runtime
- `@abrum/react/ui` — optional shared UI components
- `@abrum/react/chat` — chat UI and runtime helpers
- `@abrum/react/scheduler` — scheduler UI
- `@abrum/react/theme.css` and `@abrum/react/tailwind.css` — design tokens

The UI layer is optional. `mountAbrumApp`, the data hooks, host navigation and
other framework APIs do not require an app to use the shared components. New
apps use `@abrum/react/ui` by default so generated apps and Electron begin from
the same accessible controls and tokens; replace those components or import
only `theme.css` when a product needs its own visual language.

## Entity screens

The compact path for an ordinary CRUD screen is one collection hook. Queries
are bounded and realtime by default; successful writes use the same Room and
authority metadata carried by each generated record.

```tsx
import {
  useAbrumCanWrite,
  useAbrumCollection,
  useAbrumSelectedRecord,
} from "@abrum/react";
import { notesApp, type NoteRecord } from "../generated/twins";

const notes = useAbrumCollection(notesApp, "note", {
  order: ["createdAtMs", "desc"],
});
const canWrite = useAbrumCanWrite();
const selected: NoteRecord | null = notes.data[0] ?? null;
useAbrumSelectedRecord(selected, { title: selected?.text });
```

`notes.create`, `notes.update`, and `notes.remove` share `isMutating` and
`mutationError`; `error` combines query and mutation failures. Complex screens
can compose `useAbrumEntityList`, `useAbrumMutations`, or `useAbrumDb` directly.

The installable **ABRUM UI** gallery (`apps/ui-gallery-web`) is the interactive
reference. Its coverage test fails whenever a new public UI component has not
yet been added to the gallery.

Source and issues: <https://github.com/abrum-ai/abrum-react>
